package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBHPPR {
    public static class  TUNE {
        private short slct;
        private short diff;
        private short fine;
        private short acc_lv;
        private int max_f;
        private short bipl;
        private short aipl;
        private int corner;
        private short clamp;
        private int radius;
        private int max_cf;
        private int min_cf;
        private int foward;
        private int reserve[];

        public short getSlct() {
            return slct;
        }

        public void setSlct(short slct) {
            this.slct = slct;
        }

        public short getDiff() {
            return diff;
        }

        public void setDiff(short diff) {
            this.diff = diff;
        }

        public short getFine() {
            return fine;
        }

        public void setFine(short fine) {
            this.fine = fine;
        }

        public short getAcc_lv() {
            return acc_lv;
        }

        public void setAcc_lv(short acc_lv) {
            this.acc_lv = acc_lv;
        }

        public int getMax_f() {
            return max_f;
        }

        public void setMax_f(int max_f) {
            this.max_f = max_f;
        }

        public short getBipl() {
            return bipl;
        }

        public void setBipl(short bipl) {
            this.bipl = bipl;
        }

        public short getAipl() {
            return aipl;
        }

        public void setAipl(short aipl) {
            this.aipl = aipl;
        }

        public int getCorner() {
            return corner;
        }

        public void setCorner(int corner) {
            this.corner = corner;
        }

        public short getClamp() {
            return clamp;
        }

        public void setClamp(short clamp) {
            this.clamp = clamp;
        }

        public int getRadius() {
            return radius;
        }

        public void setRadius(int radius) {
            this.radius = radius;
        }

        public int getMax_cf() {
            return max_cf;
        }

        public void setMax_cf(int max_cf) {
            this.max_cf = max_cf;
        }

        public int getMin_cf() {
            return min_cf;
        }

        public void setMin_cf(int min_cf) {
            this.min_cf = min_cf;
        }

        public int getFoward() {
            return foward;
        }

        public void setFoward(int foward) {
            this.foward = foward;
        }

        public int[] getReserve() {
            return reserve;
        }

        public void setReserve(int[] reserve) {
            this.reserve = reserve;
        }

        @Override
        public String toString() {
            return "TUNE{" +
                    "slct=" + slct +
                    ", diff=" + diff +
                    ", fine=" + fine +
                    ", acc_lv=" + acc_lv +
                    ", max_f=" + max_f +
                    ", bipl=" + bipl +
                    ", aipl=" + aipl +
                    ", corner=" + corner +
                    ", clamp=" + clamp +
                    ", radius=" + radius +
                    ", max_cf=" + max_cf +
                    ", min_cf=" + min_cf +
                    ", foward=" + foward +
                    ", reserve=" + Arrays.toString(reserve) +
                    '}';
        }
    }
    private TUNE tune[];

    public TUNE[] getTune() {
        return tune;
    }

    public void setTune(TUNE[] tune) {
        this.tune = tune;
    }

    @Override
    public String toString() {
        return "IODBHPPR{" +
                "tune=" + Arrays.toString(tune) +
                '}';
    }
}
