package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBGCD {
    private short group;
    private short flag;
    private String code;

    public short getGroup() {
        return group;
    }

    public void setGroup(short group) {
        this.group = group;
    }

    public short getFlag() {
        return flag;
    }

    public void setFlag(short flag) {
        this.flag = flag;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String toString() {
        return "ODBGCD{" +
                "group=" + group +
                ", flag=" + flag +
                ", code=" + code +
                '}';
    }
}
