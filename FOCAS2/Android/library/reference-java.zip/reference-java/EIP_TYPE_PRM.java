package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class EIP_TYPE_PRM {
    private short Type;
    private char pad[];

    public short getType() {
        return Type;
    }

    public void setType(short type) {
        Type = type;
    }

    public char[] getPad() {
        return pad;
    }

    public void setPad(char[] pad) {
        this.pad = pad;
    }
    public static class PRM {
        public static class PMC {
            private short Path;
            private short Addr;
            private int No;
            private int Size;

            public short getPath() {
                return Path;
            }

            public void setPath(short path) {
                Path = path;
            }

            public short getAddr() {
                return Addr;
            }

            public void setAddr(short addr) {
                Addr = addr;
            }

            public int getNo() {
                return No;
            }

            public void setNo(int no) {
                No = no;
            }

            public int getSize() {
                return Size;
            }

            public void setSize(int size) {
                Size = size;
            }

            @Override
            public String toString() {
                return "PMC{" +
                        "Path=" + Path +
                        ", Addr=" + Addr +
                        ", No=" + No +
                        ", Size=" + Size +
                        '}';
            }
        }
        public static class MACRO {
            private short Path;
            private char pad[];
            private int No;
            private int Num;

            public short getPath() {
                return Path;
            }

            public void setPath(short path) {
                Path = path;
            }

            public char[] getPad() {
                return pad;
            }

            public void setPad(char[] pad) {
                this.pad = pad;
            }

            public int getNo() {
                return No;
            }

            public void setNo(int no) {
                No = no;
            }

            public int getNum() {
                return Num;
            }

            public void setNum(int num) {
                Num = num;
            }

            @Override
            public String toString() {
                return "MACRO{" +
                        "Path=" + Path +
                        ", pad=" + Arrays.toString(pad) +
                        ", No=" + No +
                        ", Num=" + Num +
                        '}';
            }
        }
        private PMC pmc;
        private MACRO macro;

        public PMC getPmc() {
            return pmc;
        }

        public void setPmc(PMC pmc) {
            this.pmc = pmc;
        }

        public MACRO getMacro() {
            return macro;
        }

        public void setMacro(MACRO macro) {
            this.macro = macro;
        }

        @Override
        public String toString() {
            return "PRM{" +
                    "pmc=" + pmc +
                    ", macro=" + macro +
                    '}';
        }
    }
    private PRM prm;
    private char TagName[];
    private char pad2[];

    public PRM getPrm() {
        return prm;
    }

    public void setPrm(PRM prm) {
        this.prm = prm;
    }

    public char[] getTagName() {
        return TagName;
    }

    public void setTagName(char[] tagName) {
        TagName = tagName;
    }

    public char[] getPad2() {
        return pad2;
    }

    public void setPad2(char[] pad2) {
        this.pad2 = pad2;
    }

    @Override
    public String toString() {
        return "EIP_TYPE_PRM{" +
                "Type=" + Type +
                ", pad=" + Arrays.toString(pad) +
                ", prm=" + prm +
                ", TagName=" + Arrays.toString(TagName) +
                ", pad2=" + Arrays.toString(pad2) +
                '}';
    }
}
