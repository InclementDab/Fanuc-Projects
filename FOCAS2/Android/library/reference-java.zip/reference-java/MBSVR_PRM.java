package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class MBSVR_PRM {
    private int TcpPort;
    private short Option1;
    private short Option2;
    private PMC_ADDR StsPmcAddr;
    private MBSVR_AREA_PRM AreaPrm[];

    public int getTcpPort() {
        return TcpPort;
    }

    public void setTcpPort(int tcpPort) {
        TcpPort = tcpPort;
    }

    public short getOption1() {
        return Option1;
    }

    public void setOption1(short option1) {
        Option1 = option1;
    }

    public short getOption2() {
        return Option2;
    }

    public void setOption2(short option2) {
        Option2 = option2;
    }

    public PMC_ADDR getStsPmcAddr() {
        return StsPmcAddr;
    }

    public void setStsPmcAddr(PMC_ADDR stsPmcAddr) {
        StsPmcAddr = stsPmcAddr;
    }

    public MBSVR_AREA_PRM[] getAreaPrm() {
        return AreaPrm;
    }

    public void setAreaPrm(MBSVR_AREA_PRM[] areaPrm) {
        AreaPrm = areaPrm;
    }

    @Override
    public String toString() {
        return "MBSVR_PRM{" +
                "TcpPort=" + TcpPort +
                ", Option1=" + Option1 +
                ", Option2=" + Option2 +
                ", StsPmcAddr=" + StsPmcAddr +
                ", AreaPrm=" + Arrays.toString(AreaPrm) +
                '}';
    }
}
