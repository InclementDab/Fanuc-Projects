package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBCSVID {
    private char mt_spc[];
    private char mt_srn[];
    private char plc_spc[];
    private char plc_srn[];
    private char svm_spc[];
    private char svm_srn[];
    private char psm_spc[];
    private char psm_srn[];

    public char[] getMt_spc() {
        return mt_spc;
    }

    public void setMt_spc(char[] mt_spc) {
        this.mt_spc = mt_spc;
    }

    public char[] getMt_srn() {
        return mt_srn;
    }

    public void setMt_srn(char[] mt_srn) {
        this.mt_srn = mt_srn;
    }

    public char[] getPlc_spc() {
        return plc_spc;
    }

    public void setPlc_spc(char[] plc_spc) {
        this.plc_spc = plc_spc;
    }

    public char[] getPlc_srn() {
        return plc_srn;
    }

    public void setPlc_srn(char[] plc_srn) {
        this.plc_srn = plc_srn;
    }

    public char[] getSvm_spc() {
        return svm_spc;
    }

    public void setSvm_spc(char[] svm_spc) {
        this.svm_spc = svm_spc;
    }

    public char[] getSvm_srn() {
        return svm_srn;
    }

    public void setSvm_srn(char[] svm_srn) {
        this.svm_srn = svm_srn;
    }

    public char[] getPsm_spc() {
        return psm_spc;
    }

    public void setPsm_spc(char[] psm_spc) {
        this.psm_spc = psm_spc;
    }

    public char[] getPsm_srn() {
        return psm_srn;
    }

    public void setPsm_srn(char[] psm_srn) {
        this.psm_srn = psm_srn;
    }

    @Override
    public String toString() {
        return "ODBCSVID{" +
                "mt_spc=" + Arrays.toString(mt_spc) +
                ", mt_srn=" + Arrays.toString(mt_srn) +
                ", plc_spc=" + Arrays.toString(plc_spc) +
                ", plc_srn=" + Arrays.toString(plc_srn) +
                ", svm_spc=" + Arrays.toString(svm_spc) +
                ", svm_srn=" + Arrays.toString(svm_srn) +
                ", psm_spc=" + Arrays.toString(psm_spc) +
                ", psm_srn=" + Arrays.toString(psm_srn) +
                '}';
    }
}
