package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBHDDINF {
    private int file_num;
    private int remainder_l;
    private int remainder_h;
    private char current_dir[];

    public int getFile_num() {
        return file_num;
    }

    public void setFile_num(int file_num) {
        this.file_num = file_num;
    }

    public int getRemainder_l() {
        return remainder_l;
    }

    public void setRemainder_l(int remainder_l) {
        this.remainder_l = remainder_l;
    }

    public int getRemainder_h() {
        return remainder_h;
    }

    public void setRemainder_h(int remainder_h) {
        this.remainder_h = remainder_h;
    }

    public char[] getCurrent_dir() {
        return current_dir;
    }

    public void setCurrent_dir(char[] current_dir) {
        this.current_dir = current_dir;
    }

    @Override
    public String toString() {
        return "ODBHDDINF{" +
                "file_num=" + file_num +
                ", remainder_l=" + remainder_l +
                ", remainder_h=" + remainder_h +
                ", current_dir=" + Arrays.toString(current_dir) +
                '}';
    }
}
