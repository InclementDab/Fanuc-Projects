package jp.co.fanuc.fwlibe1;


public class BOARDLSI {
    private short SendRetryOver;
    private short Collision;
    private short CarrierSenseLost;
    private short NoCarrier;
    private short InvalidFrameLength;
    private short CrcError;
    private short ShortFrame;
    private short LongFrame;
    private short OddFrame;
    private short Overflow;
    private short PhyLsiError;

    public short getSendRetryOver() {
        return SendRetryOver;
    }

    public void setSendRetryOver(short sendRetryOver) {
        SendRetryOver = sendRetryOver;
    }

    public short getCollision() {
        return Collision;
    }

    public void setCollision(short collision) {
        Collision = collision;
    }

    public short getCarrierSenseLost() {
        return CarrierSenseLost;
    }

    public void setCarrierSenseLost(short carrierSenseLost) {
        CarrierSenseLost = carrierSenseLost;
    }

    public short getNoCarrier() {
        return NoCarrier;
    }

    public void setNoCarrier(short noCarrier) {
        NoCarrier = noCarrier;
    }

    public short getInvalidFrameLength() {
        return InvalidFrameLength;
    }

    public void setInvalidFrameLength(short invalidFrameLength) {
        InvalidFrameLength = invalidFrameLength;
    }

    public short getCrcError() {
        return CrcError;
    }

    public void setCrcError(short crcError) {
        CrcError = crcError;
    }

    public short getShortFrame() {
        return ShortFrame;
    }

    public void setShortFrame(short shortFrame) {
        ShortFrame = shortFrame;
    }

    public short getLongFrame() {
        return LongFrame;
    }

    public void setLongFrame(short longFrame) {
        LongFrame = longFrame;
    }

    public short getOddFrame() {
        return OddFrame;
    }

    public void setOddFrame(short oddFrame) {
        OddFrame = oddFrame;
    }

    public short getOverflow() {
        return Overflow;
    }

    public void setOverflow(short overflow) {
        Overflow = overflow;
    }

    public short getPhyLsiError() {
        return PhyLsiError;
    }

    public void setPhyLsiError(short phyLsiError) {
        PhyLsiError = phyLsiError;
    }

    @Override
    public String toString() {
        return "BOARDLSI{" +
                "SendRetryOver=" + SendRetryOver +
                ", Collision=" + Collision +
                ", CarrierSenseLost=" + CarrierSenseLost +
                ", NoCarrier=" + NoCarrier +
                ", InvalidFrameLength=" + InvalidFrameLength +
                ", CrcError=" + CrcError +
                ", ShortFrame=" + ShortFrame +
                ", LongFrame=" + LongFrame +
                ", OddFrame=" + OddFrame +
                ", Overflow=" + Overflow +
                ", PhyLsiError=" + PhyLsiError +
                '}';
    }
}
