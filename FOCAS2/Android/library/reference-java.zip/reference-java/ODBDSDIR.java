package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBDSDIR {
    private int file_num;
    private int remainder;
    private short data_num;

    public int getFile_num() {
        return file_num;
    }

    public void setFile_num(int file_num) {
        this.file_num = file_num;
    }

    public int getRemainder() {
        return remainder;
    }

    public void setRemainder(int remainder) {
        this.remainder = remainder;
    }

    public short getData_num() {
        return data_num;
    }

    public void setData_num(short data_num) {
        this.data_num = data_num;
    }

    public static class  DATA {
        private char file_name[];
        private char comment[];
        private int size;
        private char date[];

        public char[] getFile_name() {
            return file_name;
        }

        public void setFile_name(char[] file_name) {
            this.file_name = file_name;
        }

        public char[] getComment() {
            return comment;
        }

        public void setComment(char[] comment) {
            this.comment = comment;
        }

        public int getSize() {
            return size;
        }

        public void setSize(int size) {
            this.size = size;
        }

        public char[] getDate() {
            return date;
        }

        public void setDate(char[] date) {
            this.date = date;
        }

        @Override
        public String toString() {
            return "DATA{" +
                    "file_name=" + Arrays.toString(file_name) +
                    ", comment=" + Arrays.toString(comment) +
                    ", size=" + size +
                    ", date=" + Arrays.toString(date) +
                    '}';
        }
    }
    private DATA data[];

    public DATA[] getData() {
        return data;
    }

    public void setData(DATA[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ODBDSDIR{" +
                "file_num=" + file_num +
                ", remainder=" + remainder +
                ", data_num=" + data_num +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
