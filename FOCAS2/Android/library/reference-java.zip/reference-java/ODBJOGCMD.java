package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBJOGCMD {
    private ODBJOGCMDCODE gcode;
    private ODBJOGCMDCODE mcode;
    private ODBJOGCMDCODE scode;
    private ODBJOGCMDCODE tcode;
    private ODBJOGCMDCODE bcode;
    private ODBJOGCMDCODE padr;
    private ODBJOGCMDSCODE extscode;
    private ODBJOGCMDAXIS axis[];
    private int axis_cnt;

    public ODBJOGCMDCODE getGcode() {
        return gcode;
    }

    public void setGcode(ODBJOGCMDCODE gcode) {
        this.gcode = gcode;
    }

    public ODBJOGCMDCODE getMcode() {

        return mcode;
    }

    public void setMcode(ODBJOGCMDCODE mcode) {
        this.mcode = mcode;
    }

    public ODBJOGCMDCODE getScode() {

        return scode;
    }

    public void setScode(ODBJOGCMDCODE scode) {
        this.scode = scode;
    }

    public ODBJOGCMDCODE getTcode() {

        return tcode;
    }

    public void setTcode(ODBJOGCMDCODE tcode) {
        this.tcode = tcode;
    }

    public ODBJOGCMDCODE getBcode() {

        return bcode;
    }

    public void setBcode(ODBJOGCMDCODE bcode) {
        this.bcode = bcode;
    }

    public ODBJOGCMDCODE getPadr() {

        return padr;
    }

    public void setPadr(ODBJOGCMDCODE padr) {
        this.padr = padr;
    }

    public ODBJOGCMDSCODE getExtscode() {

        return extscode;
    }

    public void setExtscode(ODBJOGCMDSCODE extscode) {
        this.extscode = extscode;
    }

    public ODBJOGCMDAXIS[] getAxis() {

        return axis;
    }

    public void setAxis(ODBJOGCMDAXIS[] axis) {
        this.axis = axis;
    }

    public int getAxis_cnt() {

        return axis_cnt;
    }

    public void setAxis_cnt(int axis_cnt) {
        this.axis_cnt = axis_cnt;
    }

    @Override
    public String toString() {
        return "ODBJOGCMD{" +
                "gcode=" + gcode +
                ", mcode=" + mcode +
                ", scode=" + scode +
                ", tcode=" + tcode +
                ", bcode=" + bcode +
                ", padr=" + padr +
                ", extscode=" + extscode +
                ", axis=" + Arrays.toString(axis) +
                ", axis_cnt=" + axis_cnt +
                '}';
    }
}
