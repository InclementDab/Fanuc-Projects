package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBEDGE2 {
    private short    slct;
    private short    power;
    private short    freq;
    private short    duty;
    private short    g_press;
    private short    g_kind;
    private int     pier_t;
    private int     angle;
    private int     gap;
    private int     r_len;
    private int     r_feed;
    private short    r_freq;
    private short    r_duty;
    private char     gap_axis;
    private char     angle_dec;
    private char     gap_dec;
    private char     r_len_dec;
    private char     r_feed_dec;
    private char     reserve;
    private short    pb_power ;
    private short    reserves[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getPower() {
        return power;
    }

    public void setPower(short power) {
        this.power = power;
    }

    public short getFreq() {
        return freq;
    }

    public void setFreq(short freq) {
        this.freq = freq;
    }

    public short getDuty() {
        return duty;
    }

    public void setDuty(short duty) {
        this.duty = duty;
    }

    public short getG_press() {
        return g_press;
    }

    public void setG_press(short g_press) {
        this.g_press = g_press;
    }

    public short getG_kind() {
        return g_kind;
    }

    public void setG_kind(short g_kind) {
        this.g_kind = g_kind;
    }

    public int getPier_t() {
        return pier_t;
    }

    public void setPier_t(int pier_t) {
        this.pier_t = pier_t;
    }

    public int getAngle() {
        return angle;
    }

    public void setAngle(int angle) {
        this.angle = angle;
    }

    public int getGap() {
        return gap;
    }

    public void setGap(int gap) {
        this.gap = gap;
    }

    public int getR_len() {
        return r_len;
    }

    public void setR_len(int r_len) {
        this.r_len = r_len;
    }

    public int getR_feed() {
        return r_feed;
    }

    public void setR_feed(int r_feed) {
        this.r_feed = r_feed;
    }

    public short getR_freq() {
        return r_freq;
    }

    public void setR_freq(short r_freq) {
        this.r_freq = r_freq;
    }

    public short getR_duty() {
        return r_duty;
    }

    public void setR_duty(short r_duty) {
        this.r_duty = r_duty;
    }

    public char getGap_axis() {
        return gap_axis;
    }

    public void setGap_axis(char gap_axis) {
        this.gap_axis = gap_axis;
    }

    public char getAngle_dec() {
        return angle_dec;
    }

    public void setAngle_dec(char angle_dec) {
        this.angle_dec = angle_dec;
    }

    public char getGap_dec() {
        return gap_dec;
    }

    public void setGap_dec(char gap_dec) {
        this.gap_dec = gap_dec;
    }

    public char getR_len_dec() {
        return r_len_dec;
    }

    public void setR_len_dec(char r_len_dec) {
        this.r_len_dec = r_len_dec;
    }

    public char getR_feed_dec() {
        return r_feed_dec;
    }

    public void setR_feed_dec(char r_feed_dec) {
        this.r_feed_dec = r_feed_dec;
    }

    public char getReserve() {
        return reserve;
    }

    public void setReserve(char reserve) {
        this.reserve = reserve;
    }

    public short getPb_power() {
        return pb_power;
    }

    public void setPb_power(short pb_power) {
        this.pb_power = pb_power;
    }

    public short[] getReserves() {
        return reserves;
    }

    public void setReserves(short[] reserves) {
        this.reserves = reserves;
    }

    @Override
    public String toString() {
        return "IODBEDGE2{" +
                "slct=" + slct +
                ", power=" + power +
                ", freq=" + freq +
                ", duty=" + duty +
                ", g_press=" + g_press +
                ", g_kind=" + g_kind +
                ", pier_t=" + pier_t +
                ", angle=" + angle +
                ", gap=" + gap +
                ", r_len=" + r_len +
                ", r_feed=" + r_feed +
                ", r_freq=" + r_freq +
                ", r_duty=" + r_duty +
                ", gap_axis=" + gap_axis +
                ", angle_dec=" + angle_dec +
                ", gap_dec=" + gap_dec +
                ", r_len_dec=" + r_len_dec +
                ", r_feed_dec=" + r_feed_dec +
                ", reserve=" + reserve +
                ", pb_power=" + pb_power +
                ", reserves=" + Arrays.toString(reserves) +
                '}';
    }
}
