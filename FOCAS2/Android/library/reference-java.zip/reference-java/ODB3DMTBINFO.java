package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODB3DMTBINFO {
    private PRGINF prginf;
    private int mcode[];
    private int bcode;
    private TOOLINF tlinf;
    private int hisorder;
    private int dummy[];

    public PRGINF getPrginf() {
        return prginf;
    }

    public void setPrginf(PRGINF prginf) {
        this.prginf = prginf;
    }

    public int[] getMcode() {
        return mcode;
    }

    public void setMcode(int[] mcode) {
        this.mcode = mcode;
    }

    public int getBcode() {
        return bcode;
    }

    public void setBcode(int bcode) {
        this.bcode = bcode;
    }

    public TOOLINF getTlinf() {
        return tlinf;
    }

    public void setTlinf(TOOLINF tlinf) {
        this.tlinf = tlinf;
    }

    public int getHisorder() {
        return hisorder;
    }

    public void setHisorder(int hisorder) {
        this.hisorder = hisorder;
    }

    public int[] getDummy() {
        return dummy;
    }

    public void setDummy(int[] dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "ODB3DMTBINFO{" +
                "prginf=" + prginf +
                ", mcode=" + Arrays.toString(mcode) +
                ", bcode=" + bcode +
                ", tlinf=" + tlinf +
                ", hisorder=" + hisorder +
                ", dummy=" + Arrays.toString(dummy) +
                '}';
    }
}
