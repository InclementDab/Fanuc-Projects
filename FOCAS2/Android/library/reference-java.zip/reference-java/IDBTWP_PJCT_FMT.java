package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBTWP_PJCT_FMT {
    private double orign[];
    private double i;
    private double j;
    private double k;
    private int   reserve[];

    public double[] getOrign() {
        return orign;
    }

    public void setOrign(double[] orign) {
        this.orign = orign;
    }

    public double getI() {
        return i;
    }

    public void setI(double i) {
        this.i = i;
    }

    public double getJ() {
        return j;
    }

    public void setJ(double j) {
        this.j = j;
    }

    public double getK() {
        return k;
    }

    public void setK(double k) {
        this.k = k;
    }

    public int[] getReserve() {
        return reserve;
    }

    public void setReserve(int[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IDBTWP_PJCT_FMT{" +
                "orign=" + Arrays.toString(orign) +
                ", i=" + i +
                ", j=" + j +
                ", k=" + k +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
