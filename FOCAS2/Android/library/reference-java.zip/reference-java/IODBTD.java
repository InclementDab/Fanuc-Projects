package jp.co.fanuc.fwlibe1;


public class IODBTD {
    private short datano;
    private short type;
    private int tool_num;
    private int h_code;
    private int d_code;
    private int tool_inf;

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {

        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public int getTool_num() {

        return tool_num;
    }

    public void setTool_num(int tool_num) {
        this.tool_num = tool_num;
    }

    public int getH_code() {

        return h_code;
    }

    public void setH_code(int h_code) {
        this.h_code = h_code;
    }

    public int getD_code() {
        return d_code;
    }

    public void setD_code(int d_code) {
        this.d_code = d_code;
    }

    public int getTool_inf() {

        return tool_inf;
    }

    public void setTool_inf(int tool_inf) {
        this.tool_inf = tool_inf;
    }

    @Override
public String toString() {
        return "IODBTD{" +
                "datano=" + datano +
                ", type=" + type +
                ", tool_num=" + tool_num +
                ", h_code=" + h_code +
                ", d_code=" + d_code +
                ", tool_inf=" + tool_inf +
                '}';
    }
}
