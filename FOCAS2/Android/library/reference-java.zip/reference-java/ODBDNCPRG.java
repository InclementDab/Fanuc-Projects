package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBDNCPRG {
    private char name[];
    private int o_num;

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public int getO_num() {

        return o_num;
    }

    public void setO_num(int o_num) {
        this.o_num = o_num;
    }

    @Override
    public String toString() {
        return "ODBDNCPRG{" +
                "name=" + Arrays.toString(name) +
                ", o_num=" + o_num +
                '}';
    }
}
