package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class EXEPRG {
    private short length;
    private short prep_blk;
    private short act_blk;
    private short dummy;
    private char data[];

    public short getLength() {
        return length;
    }

    public void setLength(short length) {
        this.length = length;
    }

    public short getPrep_blk() {

        return prep_blk;
    }

    public void setPrep_blk(short prep_blk) {
        this.prep_blk = prep_blk;
    }

    public short getAct_blk() {

        return act_blk;
    }

    public void setAct_blk(short act_blk) {
        this.act_blk = act_blk;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public char[] getData() {

        return data;
    }

    public void setData(char[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "EXEPRG{" +
                "length=" + length +
                ", prep_blk=" + prep_blk +
                ", act_blk=" + act_blk +
                ", dummy=" + dummy +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
