package jp.co.fanuc.fwlibe1;

public class IDBPDFADIR {
    private String path;
    private short req_num;
    private short size_kind;
    private short type;
    private short dummy;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public short getReq_num() {

        return req_num;
    }

    public void setReq_num(short req_num) {
        this.req_num = req_num;
    }

    public short getSize_kind() {

        return size_kind;
    }

    public void setSize_kind(short size_kind) {
        this.size_kind = size_kind;
    }

    public short getType() {

        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "IDBPDFADIR{" +
                "path=" + path +
                ", req_num=" + req_num +
                ", size_kind=" + size_kind +
                ", type=" + type +
                ", dummy=" + dummy +
                '}';
    }
}
