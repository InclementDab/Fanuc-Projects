package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBFILESTATUS {
   private int  size;
    private char  min;
    private char  hour;
    private char  day;
    private char  month;
    private short year;
    private char  reserve[] ;
    private char           filename[];

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public char getMin() {
        return min;
    }

    public void setMin(char min) {
        this.min = min;
    }

    public char getHour() {
        return hour;
    }

    public void setHour(char hour) {
        this.hour = hour;
    }

    public char getDay() {
        return day;
    }

    public void setDay(char day) {
        this.day = day;
    }

    public char getMonth() {
        return month;
    }

    public void setMonth(char month) {
        this.month = month;
    }

    public short getYear() {
        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    public char[] getFilename() {
        return filename;
    }

    public void setFilename(char[] filename) {
        this.filename = filename;
    }

    @Override
    public String toString() {
        return "ODBFILESTATUS{" +
                "size=" + size +
                ", min=" + min +
                ", hour=" + hour +
                ", day=" + day +
                ", month=" + month +
                ", year=" + year +
                ", reserve=" + Arrays.toString(reserve) +
                ", filename=" + Arrays.toString(filename) +
                '}';
    }
}
