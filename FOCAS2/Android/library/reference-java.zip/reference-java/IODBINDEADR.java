package jp.co.fanuc.fwlibe1;


public class IODBINDEADR {
    private char dummy;
    private char indi_type;
    private short indi_addr;

    public char getDummy() {
        return dummy;
    }

    public void setDummy(char dummy) {
        this.dummy = dummy;
    }

    public char getIndi_type() {
        return indi_type;
    }

    public void setIndi_type(char indi_type) {
        this.indi_type = indi_type;
    }

    public short getIndi_addr() {
        return indi_addr;
    }

    public void setIndi_addr(short indi_addr) {
        this.indi_addr = indi_addr;
    }

    @Override
    public String toString() {
        return "IODBINDEADR{" +
                "dummy=" + dummy +
                ", indi_type=" + indi_type +
                ", indi_addr=" + indi_addr +
                '}';
    }
}
