package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBLRNINFO2 {
    private char name[];
    private char dummy1[];
    private char axis[][];
    private short year;
    private short month;
    private short day;
    private short hour;
    private short minute;
    private short second;
    private char comment[];
    private char dummy2[];

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public char[] getDummy1() {
        return dummy1;
    }

    public void setDummy1(char[] dummy1) {
        this.dummy1 = dummy1;
    }

    public char[][] getAxis() {
        return axis;
    }

    public void setAxis(char[][] axis) {
        this.axis = axis;
    }

    public short getYear() {
        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public short getMonth() {
        return month;
    }

    public void setMonth(short month) {
        this.month = month;
    }

    public short getDay() {
        return day;
    }

    public void setDay(short day) {
        this.day = day;
    }

    public short getHour() {
        return hour;
    }

    public void setHour(short hour) {
        this.hour = hour;
    }

    public short getMinute() {
        return minute;
    }

    public void setMinute(short minute) {
        this.minute = minute;
    }

    public short getSecond() {
        return second;
    }

    public void setSecond(short second) {
        this.second = second;
    }

    public char[] getComment() {
        return comment;
    }

    public void setComment(char[] comment) {
        this.comment = comment;
    }

    public char[] getDummy2() {
        return dummy2;
    }

    public void setDummy2(char[] dummy2) {
        this.dummy2 = dummy2;
    }

    @Override
    public String toString() {
        return "ODBLRNINFO2{" +
                "name=" + Arrays.toString(name) +
                ", dummy1=" + Arrays.toString(dummy1) +
                ", axis=" + Arrays.toString(axis) +
                ", year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", hour=" + hour +
                ", minute=" + minute +
                ", second=" + second +
                ", comment=" + Arrays.toString(comment) +
                ", dummy2=" + Arrays.toString(dummy2) +
                '}';
    }
}
