package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBFSSBINFO {
    private short card_num;

    public short getCard_num() {
        return card_num;
    }

    public void setCard_num(short card_num) {
        this.card_num = card_num;
    }

    public static class CARD {
        private short amp_num;
        private short plsm_num;

        public short getAmp_num() {
            return amp_num;
        }

        public void setAmp_num(short amp_num) {
            this.amp_num = amp_num;
        }

        public short getPlsm_num() {
            return plsm_num;
        }

        public void setPlsm_num(short plsm_num) {
            this.plsm_num = plsm_num;
        }

        @Override
        public String toString() {
            return "CARTD{" +
                    "amp_num=" + amp_num +
                    ", plsm_num=" + plsm_num +
                    '}';
        }
    }
    private CARD card[];

    public CARD[] getCard() {
        return card;
    }

    public void setCard(CARD[] card) {
        this.card = card;
    }

    @Override
    public String toString() {
        return "ODBFSSBINFO{" +
                "card_num=" + card_num +
                ", card=" + Arrays.toString(card) +
                '}';
    }
}
