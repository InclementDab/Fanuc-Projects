package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBPUNCH1_EX {
    private short number;
    private short attr;

    public short getNumber() {
        return number;
    }

    public void setNumber(short number) {
        this.number = number;
    }

    public short getAttr() {
        return attr;
    }

    public void setAttr(short attr) {
        this.attr = attr;
    }

    private short u2data;
    private short s2data;
    private int u4data;
    private int s4data;
    private int u8data[];

    public short getU2data() {
        return u2data;
    }

    public void setU2data(short u2data) {
        this.u2data = u2data;
    }

    public short getS2data() {
        return s2data;
    }

    public void setS2data(short s2data) {
        this.s2data = s2data;
    }

    public int getU4data() {
        return u4data;
    }

    public void setU4data(int u4data) {
        this.u4data = u4data;
    }

    public int getS4data() {
        return s4data;
    }

    public void setS4data(int s4data) {
        this.s4data = s4data;
    }

    public int[] getU8data() {
        return u8data;
    }

    public void setU8data(int[] u8data) {
        this.u8data = u8data;
    }


    private short decimal;
    private short reserve;


    public short getDecimal() {
        return decimal;
    }

    public void setDecimal(short decimal) {
        this.decimal = decimal;
    }

    public short getReserve() {
        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBPUNCH1_EX{" +
                "number=" + number +
                ", attr=" + attr +
                ", u2data=" + u2data +
                ", s2data=" + s2data +
                ", u4data=" + u4data +
                ", s4data=" + s4data +
                ", u8data=" + Arrays.toString(u8data) +
                ", decimal=" + decimal +
                ", reserve=" + reserve +
                '}';
    }
}
