package jp.co.fanuc.fwlibe1;


public class IN_PBSPRM {
    private char slave_no;
    private char pad;
    private char di_size;
    private char do_size;
    private char di_path;
    private char do_path;
    private char di_kind;
    private char do_kind;
    private short di_top_address;
    private short do_top_address;

    public char getSlave_no() {
        return slave_no;
    }

    public void setSlave_no(char slave_no) {
        this.slave_no = slave_no;
    }

    public char getPad() {
        return pad;
    }

    public void setPad(char pad) {
        this.pad = pad;
    }

    public char getDi_size() {
        return di_size;
    }

    public void setDi_size(char di_size) {
        this.di_size = di_size;
    }

    public char getDo_size() {
        return do_size;
    }

    public void setDo_size(char do_size) {
        this.do_size = do_size;
    }

    public char getDi_path() {
        return di_path;
    }

    public void setDi_path(char di_path) {
        this.di_path = di_path;
    }

    public char getDo_path() {
        return do_path;
    }

    public void setDo_path(char do_path) {
        this.do_path = do_path;
    }

    public char getDi_kind() {
        return di_kind;
    }

    public void setDi_kind(char di_kind) {
        this.di_kind = di_kind;
    }

    public char getDo_kind() {
        return do_kind;
    }

    public void setDo_kind(char do_kind) {
        this.do_kind = do_kind;
    }

    public short getDi_top_address() {
        return di_top_address;
    }

    public void setDi_top_address(short di_top_address) {
        this.di_top_address = di_top_address;
    }

    public short getDo_top_address() {
        return do_top_address;
    }

    public void setDo_top_address(short do_top_address) {
        this.do_top_address = do_top_address;
    }

    @Override
    public String toString() {
        return "IN_PBSPRM{" +
                "slave_no=" + slave_no +
                ", pad=" + pad +
                ", di_size=" + di_size +
                ", do_size=" + do_size +
                ", di_path=" + di_path +
                ", do_path=" + do_path +
                ", di_kind=" + di_kind +
                ", do_kind=" + do_kind +
                ", di_top_address=" + di_top_address +
                ", do_top_address=" + do_top_address +
                '}';
    }
}
