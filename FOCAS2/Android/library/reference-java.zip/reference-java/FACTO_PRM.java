package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class FACTO_PRM {
    private FACTOLINK_CLIENT_PRM opposite[];

    public FACTOLINK_CLIENT_PRM[] getOpposite() {
        return opposite;
    }

    public void setOpposite(FACTOLINK_CLIENT_PRM[] opposite) {
        this.opposite = opposite;
    }

    @Override
    public String toString() {
        return "FACTO_PRM{" +
                "opposite=" + Arrays.toString(opposite) +
                '}';
    }
}
