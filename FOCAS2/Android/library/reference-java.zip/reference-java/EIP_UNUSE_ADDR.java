package jp.co.fanuc.fwlibe1;


public class EIP_UNUSE_ADDR {
    private short Param1;
    private short Param2;
    private int Param3;

    public short getParam1() {
        return Param1;
    }

    public void setParam1(short param1) {
        Param1 = param1;
    }

    public short getParam2() {
        return Param2;
    }

    public void setParam2(short param2) {
        Param2 = param2;
    }

    public int getParam3() {
        return Param3;
    }

    public void setParam3(int param3) {
        Param3 = param3;
    }

    @Override
    public String toString() {
        return "EIP_UNUSE_ADDR{" +
                "Param1=" + Param1 +
                ", Param2=" + Param2 +
                ", Param3=" + Param3 +
                '}';
    }
}
