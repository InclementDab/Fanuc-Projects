package jp.co.fanuc.fwlibe1;


public class FOCAS2_PRM_FLG {
    private char TcpPort;
    private char UdpPort;
    private char TimeInterval;

    public char getTcpPort() {
        return TcpPort;
    }

    public void setTcpPort(char tcpPort) {
        TcpPort = tcpPort;
    }

    public char getUdpPort() {
        return UdpPort;
    }

    public void setUdpPort(char udpPort) {
        UdpPort = udpPort;
    }

    public char getTimeInterval() {
        return TimeInterval;
    }

    public void setTimeInterval(char timeInterval) {
        TimeInterval = timeInterval;
    }

    @Override
    public String toString() {
        return "FOCAS2_PRM_FLG{" +
                "TcpPort=" + TcpPort +
                ", UdpPort=" + UdpPort +
                ", TimeInterval=" + TimeInterval +
                '}';
    }
}
