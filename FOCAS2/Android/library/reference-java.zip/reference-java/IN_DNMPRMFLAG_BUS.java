package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_DNMPRMFLAG_BUS {
    private char            Network;
    private char            BaudRate;
    private char            DiDataOnAbnormal;
    private char            OwnMacId;
    private char            CommonStatus;
    private char            CommonStatusSize;
    private char            CycleTimeSetting;
    private char            reserved[];

    public char getNetwork() {
        return Network;
    }

    public void setNetwork(char network) {
        Network = network;
    }

    public char getBaudRate() {
        return BaudRate;
    }

    public void setBaudRate(char baudRate) {
        BaudRate = baudRate;
    }

    public char getDiDataOnAbnormal() {
        return DiDataOnAbnormal;
    }

    public void setDiDataOnAbnormal(char diDataOnAbnormal) {
        DiDataOnAbnormal = diDataOnAbnormal;
    }

    public char getOwnMacId() {
        return OwnMacId;
    }

    public void setOwnMacId(char ownMacId) {
        OwnMacId = ownMacId;
    }

    public char getCommonStatus() {
        return CommonStatus;
    }

    public void setCommonStatus(char commonStatus) {
        CommonStatus = commonStatus;
    }

    public char getCommonStatusSize() {
        return CommonStatusSize;
    }

    public void setCommonStatusSize(char commonStatusSize) {
        CommonStatusSize = commonStatusSize;
    }

    public char getCycleTimeSetting() {
        return CycleTimeSetting;
    }

    public void setCycleTimeSetting(char cycleTimeSetting) {
        CycleTimeSetting = cycleTimeSetting;
    }

    public char[] getReserved() {
        return reserved;
    }

    public void setReserved(char[] reserved) {
        this.reserved = reserved;
    }

    @Override
    public String toString() {
        return "IN_DNMPRMFLAG_BUS{" +
                "Network=" + Network +
                ", BaudRate=" + BaudRate +
                ", DiDataOnAbnormal=" + DiDataOnAbnormal +
                ", OwnMacId=" + OwnMacId +
                ", CommonStatus=" + CommonStatus +
                ", CommonStatusSize=" + CommonStatusSize +
                ", CycleTimeSetting=" + CycleTimeSetting +
                ", reserved=" + Arrays.toString(reserved) +
                '}';
    }
}
