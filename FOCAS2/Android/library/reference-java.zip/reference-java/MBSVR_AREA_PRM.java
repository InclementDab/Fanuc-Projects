package jp.co.fanuc.fwlibe1;


public class MBSVR_AREA_PRM {
    private int DatSize;
    private int DatModAddr;
    private PMC_ADDR DatPmcAddr;

    public int getDatSize() {
        return DatSize;
    }

    public void setDatSize(int datSize) {
        DatSize = datSize;
    }

    public int getDatModAddr() {
        return DatModAddr;
    }

    public void setDatModAddr(int datModAddr) {
        DatModAddr = datModAddr;
    }

    public PMC_ADDR getDatPmcAddr() {
        return DatPmcAddr;
    }

    public void setDatPmcAddr(PMC_ADDR datPmcAddr) {
        DatPmcAddr = datPmcAddr;
    }

    @Override
    public String toString() {
        return "MBSVR_AREA_PRM{" +
                "DatSize=" + DatSize +
                ", DatModAddr=" + DatModAddr +
                ", DatPmcAddr=" + DatPmcAddr +
                '}';
    }
}
