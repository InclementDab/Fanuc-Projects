package jp.co.fanuc.fwlibe1;


public class ODBJOGCMDCODE {
    private char adrs;
    private int num;

    public char getAdrs() {
        return adrs;
    }

    public void setAdrs(char adrs) {
        this.adrs = adrs;
    }

    public int getNum() {

        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    @Override
    public String toString() {
        return "ODBJOGCMDCODE{" +
                "adrs=" + adrs +
                ", num=" + num +
                '}';
    }
}
