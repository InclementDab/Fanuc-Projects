package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBCTPR {
    public static class DATA {
        private int acc_bip[];
        private int acc_chg_time;
        private int jerk_acc_diff[];
        private int jerk_acc_diff_lin[];
        private char jerk_acc_ratio;
        private int max_acc[];
        private short t_con_aip[];
        private int corner_feed_diff[];
        private int max_cut_fdrate[];

        public int[] getAcc_bip() {
            return acc_bip;
        }

        public void setAcc_bip(int[] acc_bip) {
            this.acc_bip = acc_bip;
        }

        public int getAcc_chg_time() {

            return acc_chg_time;
        }

        public void setAcc_chg_time(int acc_chg_time) {
            this.acc_chg_time = acc_chg_time;
        }

        public int[] getJerk_acc_diff() {

            return jerk_acc_diff;
        }

        public void setJerk_acc_diff(int[] jerk_acc_diff) {
            this.jerk_acc_diff = jerk_acc_diff;
        }

        public int[] getJerk_acc_diff_lin() {

            return jerk_acc_diff_lin;
        }

        public void setJerk_acc_diff_lin(int[] jerk_acc_diff_lin) {
            this.jerk_acc_diff_lin = jerk_acc_diff_lin;
        }

        public char getJerk_acc_ratio() {

            return jerk_acc_ratio;
        }

        public void setJerk_acc_ratio(char jerk_acc_ratio) {
            this.jerk_acc_ratio = jerk_acc_ratio;
        }

        public int[] getMax_acc() {

            return max_acc;
        }

        public void setMax_acc(int[] max_acc) {
            this.max_acc = max_acc;
        }

        public short[] getT_con_aip() {

            return t_con_aip;
        }

        public void setT_con_aip(short[] t_con_aip) {
            this.t_con_aip = t_con_aip;
        }

        public int[] getCorner_feed_diff() {

            return corner_feed_diff;
        }

        public void setCorner_feed_diff(int[] corner_feed_diff) {
            this.corner_feed_diff = corner_feed_diff;
        }

        public int[] getMax_cut_fdrate() {

            return max_cut_fdrate;
        }

        public void setMax_cut_fdrate(int[] max_cut_fdrate) {
            this.max_cut_fdrate = max_cut_fdrate;
        }

        @Override
        public String toString() {
            return "DATA{" +
                    "acc_bip=" + Arrays.toString(acc_bip) +
                    ", acc_chg_time=" + acc_chg_time +
                    ", jerk_acc_diff=" + Arrays.toString(jerk_acc_diff) +
                    ", jerk_acc_diff_lin=" + Arrays.toString(jerk_acc_diff_lin) +
                    ", jerk_acc_ratio=" + jerk_acc_ratio +
                    ", max_acc=" + Arrays.toString(max_acc) +
                    ", t_con_aip=" + Arrays.toString(t_con_aip) +
                    ", corner_feed_diff=" + Arrays.toString(corner_feed_diff) +
                    ", max_cut_fdrate=" + Arrays.toString(max_cut_fdrate) +
                    '}';
        }
    }

    public static class PRM {
        private short datano;
        private short type;

        public short getDatano() {
            return datano;
        }

        public void setDatano(short datano) {
            this.datano = datano;
        }

        public short getType() {

            return type;
        }

        public void setType(short type) {
            this.type = type;
        }

        private char cdata;
        private short idata;
        private int ldata;
        private char cdatas[];
        private short idatas[];
        private int ldatas[];

        public char getCdata() {
            return cdata;
        }

        public void setCdata(char cdata) {
            this.cdata = cdata;
        }

        public short getIdata() {

            return idata;
        }

        public void setIdata(short idata) {
            this.idata = idata;
        }

        public int getLdata() {

            return ldata;
        }

        public void setLdata(int ldata) {
            this.ldata = ldata;
        }

        public char[] getCdatas() {

            return cdatas;
        }

        public void setCdatas(char[] cdatas) {
            this.cdatas = cdatas;
        }

        public short[] getIdatas() {

            return idatas;
        }

        public void setIdatas(short[] idatas) {
            this.idatas = idatas;
        }

        public int[] getLdatas() {

            return ldatas;
        }

        public void setLdatas(int[] ldatas) {
            this.ldatas = ldatas;
        }


        @Override
        public String toString() {
            return "PRM{" +
                    "datano=" + datano +
                    ", type=" + type +
                    ", cdata=" + cdata +
                    ", idata=" + idata +
                    ", ldata=" + ldata +
                    ", cdatas=" + Arrays.toString(cdatas) +
                    ", idatas=" + Arrays.toString(idatas) +
                    ", ldatas=" + Arrays.toString(ldatas) +
                    '}';
        }
    }

    private DATA data;
    private PRM prm[];

    public DATA getData() {
        return data;
    }

    public void setData(DATA data) {
        this.data = data;
    }

    public PRM[] getPrm() {

        return prm;
    }

    public void setPrm(PRM[] prm) {
        this.prm = prm;
    }

    @Override
    public String toString() {
        return "IODBCTPR{" +
                "data=" + data +
                ", prm=" + Arrays.toString(prm) +
                '}';
    }
}
