package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBSVAMP {
    private short slave_num;
    private char name[];
    private char series[];
    private char cur[];
    private short as_axis_num;
    private char as_axis_name[];

    public short getSlave_num() {
        return slave_num;
    }

    public void setSlave_num(short slave_num) {
        this.slave_num = slave_num;
    }

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public char[] getSeries() {
        return series;
    }

    public void setSeries(char[] series) {
        this.series = series;
    }

    public char[] getCur() {
        return cur;
    }

    public void setCur(char[] cur) {
        this.cur = cur;
    }

    public short getAs_axis_num() {
        return as_axis_num;
    }

    public void setAs_axis_num(short as_axis_num) {
        this.as_axis_num = as_axis_num;
    }

    public char[] getAs_axis_name() {
        return as_axis_name;
    }

    public void setAs_axis_name(char[] as_axis_name) {
        this.as_axis_name = as_axis_name;
    }

    @Override
    public String toString() {
        return "ODBIFSBSVAMP{" +
                "slave_num=" + slave_num +
                ", name=" + Arrays.toString(name) +
                ", series=" + Arrays.toString(series) +
                ", cur=" + Arrays.toString(cur) +
                ", as_axis_num=" + as_axis_num +
                ", as_axis_name=" + Arrays.toString(as_axis_name) +
                '}';
    }
}
