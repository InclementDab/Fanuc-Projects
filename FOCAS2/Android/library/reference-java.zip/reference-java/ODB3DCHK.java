package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODB3DCHK {
    private int pathno;

    public int getPathno() {
        return pathno;
    }

    public void setPathno(int pathno) {
        this.pathno = pathno;
    }

    public static class PATH {
        private int mode;
        private PRGINF prginf;
        private int dummy[];
        private int mcode[];
        private TOOLINF tlinf;
        private int dummy2[];
        private int ctrlaxis;
        private POSINF data[];

        public int getMode() {
            return mode;
        }

        public void setMode(int mode) {
            this.mode = mode;
        }

        public PRGINF getPrginf() {
            return prginf;
        }

        public void setPrginf(PRGINF prginf) {
            this.prginf = prginf;
        }

        public int[] getDummy() {
            return dummy;
        }

        public void setDummy(int[] dummy) {
            this.dummy = dummy;
        }

        public int[] getMcode() {
            return mcode;
        }

        public void setMcode(int[] mcode) {
            this.mcode = mcode;
        }

        public TOOLINF getTlinf() {
            return tlinf;
        }

        public void setTlinf(TOOLINF tlinf) {
            this.tlinf = tlinf;
        }

        public int[] getDummy2() {
            return dummy2;
        }

        public void setDummy2(int[] dummy2) {
            this.dummy2 = dummy2;
        }

        public int getCtrlaxis() {
            return ctrlaxis;
        }

        public void setCtrlaxis(int ctrlaxis) {
            this.ctrlaxis = ctrlaxis;
        }

        public POSINF[] getData() {
            return data;
        }

        public void setData(POSINF[] data) {
            this.data = data;
        }

        @Override
        public String toString() {
            return "PATH{" +
                    "mode=" + mode +
                    ", prginf=" + prginf +
                    ", dummy=" + Arrays.toString(dummy) +
                    ", mcode=" + Arrays.toString(mcode) +
                    ", tlinf=" + tlinf +
                    ", dummy2=" + Arrays.toString(dummy2) +
                    ", ctrlaxis=" + ctrlaxis +
                    ", data=" + Arrays.toString(data) +
                    '}';
        }
    }
    private PATH path[];

    public PATH[] getPath() {
        return path;
    }

    public void setPath(PATH[] path) {
        this.path = path;
    }

    @Override
    public String toString() {
        return "ODB3DCHK{" +
                "pathno=" + pathno +
                ", path=" + Arrays.toString(path) +
                '}';
    }
}
