package jp.co.fanuc.fwlibe1;


public class EIP_PMC_ADDR {
    private short Path;
    private short Addr;
    private int No;

    public short getPath() {
        return Path;
    }

    public void setPath(short path) {
        Path = path;
    }

    public short getAddr() {
        return Addr;
    }

    public void setAddr(short addr) {
        Addr = addr;
    }

    public int getNo() {
        return No;
    }

    public void setNo(int no) {
        No = no;
    }

    @Override
    public String toString() {
        return "EIP_PMC_ADDR{" +
                "Path=" + Path +
                ", Addr=" + Addr +
                ", No=" + No +
                '}';
    }
}
