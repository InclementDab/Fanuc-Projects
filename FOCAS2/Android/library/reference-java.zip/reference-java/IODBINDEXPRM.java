package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBINDEXPRM {
    private int            ofs_limit;
    private int            detect_width;
    private short          jog_clamp[];
    private char           matrix_single;
    private char           torque_ovr;
    private char           ofs_adjust;
    private char           dummy[];

    public int getOfs_limit() {
        return ofs_limit;
    }

    public void setOfs_limit(int ofs_limit) {
        this.ofs_limit = ofs_limit;
    }

    public int getDetect_width() {
        return detect_width;
    }

    public void setDetect_width(int detect_width) {
        this.detect_width = detect_width;
    }

    public short[] getJog_clamp() {
        return jog_clamp;
    }

    public void setJog_clamp(short[] jog_clamp) {
        this.jog_clamp = jog_clamp;
    }

    public char getMatrix_single() {
        return matrix_single;
    }

    public void setMatrix_single(char matrix_single) {
        this.matrix_single = matrix_single;
    }

    public char getTorque_ovr() {
        return torque_ovr;
    }

    public void setTorque_ovr(char torque_ovr) {
        this.torque_ovr = torque_ovr;
    }

    public char getOfs_adjust() {
        return ofs_adjust;
    }

    public void setOfs_adjust(char ofs_adjust) {
        this.ofs_adjust = ofs_adjust;
    }

    public char[] getDummy() {
        return dummy;
    }

    public void setDummy(char[] dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "IODBINDEXPRM{" +
                "ofs_limit=" + ofs_limit +
                ", detect_width=" + detect_width +
                ", jog_clamp=" + Arrays.toString(jog_clamp) +
                ", matrix_single=" + matrix_single +
                ", torque_ovr=" + torque_ovr +
                ", ofs_adjust=" + ofs_adjust +
                ", dummy=" + Arrays.toString(dummy) +
                '}';
    }
}
