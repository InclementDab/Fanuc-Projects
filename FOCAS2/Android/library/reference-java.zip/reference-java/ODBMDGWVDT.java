package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMDGWVDT {
    private int ldata[];
    private short p_dec;
    private short num;
    private short channel;
    private short axis;
    private short kind;
    private short interval;
    private short t_cycle;
    private char unit;
    private char sw_alm;

    public int[] getLdata() {
        return ldata;
    }

    public void setLdata(int[] ldata) {
        this.ldata = ldata;
    }

    public short getP_dec() {
        return p_dec;
    }

    public void setP_dec(short p_dec) {
        this.p_dec = p_dec;
    }

    public short getNum() {
        return num;
    }

    public void setNum(short num) {
        this.num = num;
    }

    public short getChannel() {
        return channel;
    }

    public void setChannel(short channel) {
        this.channel = channel;
    }

    public short getAxis() {
        return axis;
    }

    public void setAxis(short axis) {
        this.axis = axis;
    }

    public short getKind() {
        return kind;
    }

    public void setKind(short kind) {
        this.kind = kind;
    }

    public short getInterval() {
        return interval;
    }

    public void setInterval(short interval) {
        this.interval = interval;
    }

    public short getT_cycle() {
        return t_cycle;
    }

    public void setT_cycle(short t_cycle) {
        this.t_cycle = t_cycle;
    }

    public char getUnit() {
        return unit;
    }

    public void setUnit(char unit) {
        this.unit = unit;
    }

    public char getSw_alm() {
        return sw_alm;
    }

    public void setSw_alm(char sw_alm) {
        this.sw_alm = sw_alm;
    }

    @Override
    public String toString() {
        return "ODBMDGWVDT{" +
                "ldata=" + Arrays.toString(ldata) +
                ", p_dec=" + p_dec +
                ", num=" + num +
                ", channel=" + channel +
                ", axis=" + axis +
                ", kind=" + kind +
                ", interval=" + interval +
                ", t_cycle=" + t_cycle +
                ", unit=" + unit +
                ", sw_alm=" + sw_alm +
                '}';
    }
}
