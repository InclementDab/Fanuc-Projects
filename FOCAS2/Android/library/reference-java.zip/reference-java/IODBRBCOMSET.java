package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBRBCOMSET {
    private IODBRBTOPSIG di_top;
    private IODBRBTOPSIG do_top;
    private IODBRBPOWERSIG power_on;
    private short di_offset;
    private short do_offset;
    private char property;
    private char reserve[];

    public IODBRBTOPSIG getDi_top() {
        return di_top;
    }

    public void setDi_top(IODBRBTOPSIG di_top) {
        this.di_top = di_top;
    }

    public IODBRBTOPSIG getDo_top() {
        return do_top;
    }

    public void setDo_top(IODBRBTOPSIG do_top) {
        this.do_top = do_top;
    }

    public IODBRBPOWERSIG getPower_on() {
        return power_on;
    }

    public void setPower_on(IODBRBPOWERSIG power_on) {
        this.power_on = power_on;
    }

    public short getDi_offset() {
        return di_offset;
    }

    public void setDi_offset(short di_offset) {
        this.di_offset = di_offset;
    }

    public short getDo_offset() {
        return do_offset;
    }

    public void setDo_offset(short do_offset) {
        this.do_offset = do_offset;
    }

    public char getProperty() {
        return property;
    }

    public void setProperty(char property) {
        this.property = property;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBRBCOMSET{" +
                "di_top=" + di_top +
                ", do_top=" + do_top +
                ", power_on=" + power_on +
                ", di_offset=" + di_offset +
                ", do_offset=" + do_offset +
                ", property=" + property +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
