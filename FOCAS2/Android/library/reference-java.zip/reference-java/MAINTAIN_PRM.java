package jp.co.fanuc.fwlibe1;


public class MAINTAIN_PRM {
    private PING_PRM opposite;

    public PING_PRM getOpposite() {
        return opposite;
    }

    public void setOpposite(PING_PRM opposite) {
        this.opposite = opposite;
    }

    @Override
    public String toString() {
        return "MAINTAIN_PRM{" +
                "opposite=" + opposite +
                '}';
    }
}
