package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBRSTINFO2 {
    private int  seq_no;
    private int  c_blck_cnt;
    private int  t_blck_cnt;
    private int  call_from_no;
    private int  call_from_blck;
    private short prg_rep;
    private short seq_rep;
    private short c_blck_rep;
    private short nest_lv;
    private char  prg_name[];
    private char  dummy1[];
    private char  call_from_prg[];
    private char  dummy2[];
    private char  edit_flag;
    private char  reserve;
    private short repeat;
    private int  wait_m_code;
    private char  time_s;
    private char  time_m;
    private char  time_h;
    private char  time_d;
    private int  id_no;
    private int  reserve2[];

    public int getSeq_no() {
        return seq_no;
    }

    public void setSeq_no(int seq_no) {
        this.seq_no = seq_no;
    }

    public int getC_blck_cnt() {
        return c_blck_cnt;
    }

    public void setC_blck_cnt(int c_blck_cnt) {
        this.c_blck_cnt = c_blck_cnt;
    }

    public int getT_blck_cnt() {
        return t_blck_cnt;
    }

    public void setT_blck_cnt(int t_blck_cnt) {
        this.t_blck_cnt = t_blck_cnt;
    }

    public int getCall_from_no() {
        return call_from_no;
    }

    public void setCall_from_no(int call_from_no) {
        this.call_from_no = call_from_no;
    }

    public int getCall_from_blck() {
        return call_from_blck;
    }

    public void setCall_from_blck(int call_from_blck) {
        this.call_from_blck = call_from_blck;
    }

    public short getPrg_rep() {
        return prg_rep;
    }

    public void setPrg_rep(short prg_rep) {
        this.prg_rep = prg_rep;
    }

    public short getSeq_rep() {
        return seq_rep;
    }

    public void setSeq_rep(short seq_rep) {
        this.seq_rep = seq_rep;
    }

    public short getC_blck_rep() {
        return c_blck_rep;
    }

    public void setC_blck_rep(short c_blck_rep) {
        this.c_blck_rep = c_blck_rep;
    }

    public short getNest_lv() {
        return nest_lv;
    }

    public void setNest_lv(short nest_lv) {
        this.nest_lv = nest_lv;
    }

    public char[] getPrg_name() {
        return prg_name;
    }

    public void setPrg_name(char[] prg_name) {
        this.prg_name = prg_name;
    }

    public char[] getDummy1() {
        return dummy1;
    }

    public void setDummy1(char[] dummy1) {
        this.dummy1 = dummy1;
    }

    public char[] getCall_from_prg() {
        return call_from_prg;
    }

    public void setCall_from_prg(char[] call_from_prg) {
        this.call_from_prg = call_from_prg;
    }

    public char[] getDummy2() {
        return dummy2;
    }

    public void setDummy2(char[] dummy2) {
        this.dummy2 = dummy2;
    }

    public char getEdit_flag() {
        return edit_flag;
    }

    public void setEdit_flag(char edit_flag) {
        this.edit_flag = edit_flag;
    }

    public char getReserve() {
        return reserve;
    }

    public void setReserve(char reserve) {
        this.reserve = reserve;
    }

    public short getRepeat() {
        return repeat;
    }

    public void setRepeat(short repeat) {
        this.repeat = repeat;
    }

    public int getWait_m_code() {
        return wait_m_code;
    }

    public void setWait_m_code(int wait_m_code) {
        this.wait_m_code = wait_m_code;
    }

    public char getTime_s() {
        return time_s;
    }

    public void setTime_s(char time_s) {
        this.time_s = time_s;
    }

    public char getTime_m() {
        return time_m;
    }

    public void setTime_m(char time_m) {
        this.time_m = time_m;
    }

    public char getTime_h() {
        return time_h;
    }

    public void setTime_h(char time_h) {
        this.time_h = time_h;
    }

    public char getTime_d() {
        return time_d;
    }

    public void setTime_d(char time_d) {
        this.time_d = time_d;
    }

    public int getId_no() {
        return id_no;
    }

    public void setId_no(int id_no) {
        this.id_no = id_no;
    }

    public int[] getReserve2() {
        return reserve2;
    }

    public void setReserve2(int[] reserve2) {
        this.reserve2 = reserve2;
    }

    @Override
    public String toString() {
        return "IODBRSTINFO2{" +
                "seq_no=" + seq_no +
                ", c_blck_cnt=" + c_blck_cnt +
                ", t_blck_cnt=" + t_blck_cnt +
                ", call_from_no=" + call_from_no +
                ", call_from_blck=" + call_from_blck +
                ", prg_rep=" + prg_rep +
                ", seq_rep=" + seq_rep +
                ", c_blck_rep=" + c_blck_rep +
                ", nest_lv=" + nest_lv +
                ", prg_name=" + Arrays.toString(prg_name) +
                ", dummy1=" + Arrays.toString(dummy1) +
                ", call_from_prg=" + Arrays.toString(call_from_prg) +
                ", dummy2=" + Arrays.toString(dummy2) +
                ", edit_flag=" + edit_flag +
                ", reserve=" + reserve +
                ", repeat=" + repeat +
                ", wait_m_code=" + wait_m_code +
                ", time_s=" + time_s +
                ", time_m=" + time_m +
                ", time_h=" + time_h +
                ", time_d=" + time_d +
                ", id_no=" + id_no +
                ", reserve2=" + Arrays.toString(reserve2) +
                '}';
    }
}
