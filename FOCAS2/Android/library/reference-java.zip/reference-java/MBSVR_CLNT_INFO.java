package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class MBSVR_CLNT_INFO {
    private char IpAddress[];
    private int ConnectTime;

    public char[] getIpAddress() {
        return IpAddress;
    }

    public void setIpAddress(char[] ipAddress) {
        IpAddress = ipAddress;
    }

    public int getConnectTime() {
        return ConnectTime;
    }

    public void setConnectTime(int connectTime) {
        ConnectTime = connectTime;
    }

    @Override
    public String toString() {
        return "MBSVR_CLNT_INFO{" +
                "IpAddress=" + Arrays.toString(IpAddress) +
                ", ConnectTime=" + ConnectTime +
                '}';
    }
}
