package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTLCTL {
    private short slct;
    private short used_tool;
    private short turret_indx;
    private int zero_tl_no;
    private int t_axis_move;
    private int total_punch[];
    private char t_axis_dec;
    private char reserve;
    private short reserves[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getUsed_tool() {
        return used_tool;
    }

    public void setUsed_tool(short used_tool) {
        this.used_tool = used_tool;
    }

    public short getTurret_indx() {
        return turret_indx;
    }

    public void setTurret_indx(short turret_indx) {
        this.turret_indx = turret_indx;
    }

    public int getZero_tl_no() {
        return zero_tl_no;
    }

    public void setZero_tl_no(int zero_tl_no) {
        this.zero_tl_no = zero_tl_no;
    }

    public int getT_axis_move() {
        return t_axis_move;
    }

    public void setT_axis_move(int t_axis_move) {
        this.t_axis_move = t_axis_move;
    }

    public int[] getTotal_punch() {
        return total_punch;
    }

    public void setTotal_punch(int[] total_punch) {
        this.total_punch = total_punch;
    }

    public char getT_axis_dec() {
        return t_axis_dec;
    }

    public void setT_axis_dec(char t_axis_dec) {
        this.t_axis_dec = t_axis_dec;
    }

    public char getReserve() {
        return reserve;
    }

    public void setReserve(char reserve) {
        this.reserve = reserve;
    }

    public short[] getReserves() {
        return reserves;
    }

    public void setReserves(short[] reserves) {
        this.reserves = reserves;
    }

    @Override
    public String toString() {
        return "IODBTLCTL{" +
                "slct=" + slct +
                ", used_tool=" + used_tool +
                ", turret_indx=" + turret_indx +
                ", zero_tl_no=" + zero_tl_no +
                ", t_axis_move=" + t_axis_move +
                ", total_punch=" + Arrays.toString(total_punch) +
                ", t_axis_dec=" + t_axis_dec +
                ", reserve=" + reserve +
                ", reserves=" + Arrays.toString(reserves) +
                '}';
    }
}
