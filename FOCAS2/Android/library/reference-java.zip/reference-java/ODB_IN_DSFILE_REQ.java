package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODB_IN_DSFILE_REQ {
    private char file[];
    private int fnum;
    private int offset;
    private short detail;
    private short option;

    public char[] getFile() {
        return file;
    }

    public void setFile(char[] file) {
        this.file = file;
    }

    public int getFnum() {

        return fnum;
    }

    public void setFnum(int fnum) {
        this.fnum = fnum;
    }

    public int getOffset() {

        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public short getDetail() {

        return detail;
    }

    public void setDetail(short detail) {
        this.detail = detail;
    }

    public short getOption() {

        return option;
    }

    public void setOption(short option) {
        this.option = option;
    }

    @Override
    public String toString() {
        return "ODB_IN_DSFILE_REQ{" +
                "file=" + Arrays.toString(file) +
                ", fnum=" + fnum +
                ", offset=" + offset +
                ", detail=" + detail +
                ", option=" + option +
                '}';
    }
}
