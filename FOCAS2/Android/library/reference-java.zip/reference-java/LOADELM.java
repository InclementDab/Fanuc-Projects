package jp.co.fanuc.fwlibe1;


public class LOADELM {
    private int data;
    private short dec;
    private short unit;
    private char name;
    private char suff1;
    private char suff2;
    private char reserve;

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    public short getDec() {

        return dec;
    }

    public void setDec(short dec) {
        this.dec = dec;
    }

    public short getUnit() {

        return unit;
    }

    public void setUnit(short unit) {
        this.unit = unit;
    }

    public char getName() {

        return name;
    }

    public void setName(char name) {
        this.name = name;
    }

    public char getSuff1() {

        return suff1;
    }

    public void setSuff1(char suff1) {
        this.suff1 = suff1;
    }

    public char getSuff2() {

        return suff2;
    }

    public void setSuff2(char suff2) {
        this.suff2 = suff2;
    }

    public char getReserve() {

        return reserve;
    }

    public void setReserve(char reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "LOADELM{" +
                "data=" + data +
                ", dec=" + dec +
                ", unit=" + unit +
                ", name=" + name +
                ", suff1=" + suff1 +
                ", suff2=" + suff2 +
                ", reserve=" + reserve +
                '}';
    }
}
