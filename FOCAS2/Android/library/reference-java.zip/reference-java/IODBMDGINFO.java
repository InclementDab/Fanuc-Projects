package jp.co.fanuc.fwlibe1;


public class IODBMDGINFO {
    private int alm_no;
    private short type;
    private short axis;
    private short path;
    private short reserved;

    public int getAlm_no() {
        return alm_no;
    }

    public void setAlm_no(int alm_no) {
        this.alm_no = alm_no;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getAxis() {
        return axis;
    }

    public void setAxis(short axis) {
        this.axis = axis;
    }

    public short getPath() {
        return path;
    }

    public void setPath(short path) {
        this.path = path;
    }

    public short getReserved() {
        return reserved;
    }

    public void setReserved(short reserved) {
        this.reserved = reserved;
    }

    @Override
    public String toString() {
        return "IODBMDGINFO{" +
                "alm_no=" + alm_no +
                ", type=" + type +
                ", axis=" + axis +
                ", path=" + path +
                ", reserved=" + reserved +
                '}';
    }
}
