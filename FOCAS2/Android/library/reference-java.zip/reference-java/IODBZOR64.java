package jp.co.fanuc.fwlibe1;

import java.util.Arrays;


public class IODBZOR64 {
    private short datano_s;
    private short type;
    private short datano_e;
    private short dummy;
    private REALDATA data[];

    public short getDatano_s() {
        return datano_s;
    }

    public void setDatano_s(short datano_s) {
        this.datano_s = datano_s;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getDatano_e() {
        return datano_e;
    }

    public void setDatano_e(short datano_e) {
        this.datano_e = datano_e;
    }

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public REALDATA[] getData() {
        return data;
    }

    public void setData(REALDATA[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBZOR64{" +
                "datano_s=" + datano_s +
                ", type=" + type +
                ", datano_e=" + datano_e +
                ", dummy=" + dummy +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
