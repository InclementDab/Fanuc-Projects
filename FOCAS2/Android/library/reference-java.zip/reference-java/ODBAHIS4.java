package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBAHIS4 {
    private short s_no;
    private short e_no;

    public short getS_no() {
        return s_no;
    }

    public void setS_no(short s_no) {
        this.s_no = s_no;
    }

    public short getE_no() {
        return e_no;
    }

    public void setE_no(short e_no) {
        this.e_no = e_no;
    }

    public static class ALM_HIS {
        private short alm_grp;
        private short alm_no;
        private short axis_no;
        private short year;
        private short month;
        private short day;
        private short hour;
        private short minute;
        private short second;
        private short len_msg;
        private short pth_no;
        private short dummy;
        private char alm_msg[];

        public short getAlm_grp() {
            return alm_grp;
        }

        public void setAlm_grp(short alm_grp) {
            this.alm_grp = alm_grp;
        }

        public short getAlm_no() {
            return alm_no;
        }

        public void setAlm_no(short alm_no) {
            this.alm_no = alm_no;
        }

        public short getAxis_no() {
            return axis_no;
        }

        public void setAxis_no(short axis_no) {
            this.axis_no = axis_no;
        }

        public short getYear() {
            return year;
        }

        public void setYear(short year) {
            this.year = year;
        }

        public short getMonth() {
            return month;
        }

        public void setMonth(short month) {
            this.month = month;
        }

        public short getDay() {
            return day;
        }

        public void setDay(short day) {
            this.day = day;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getLen_msg() {
            return len_msg;
        }

        public void setLen_msg(short len_msg) {
            this.len_msg = len_msg;
        }

        public short getPth_no() {
            return pth_no;
        }

        public void setPth_no(short pth_no) {
            this.pth_no = pth_no;
        }

        public short getDummy() {
            return dummy;
        }

        public void setDummy(short dummy) {
            this.dummy = dummy;
        }

        public char[] getAlm_msg() {
            return alm_msg;
        }

        public void setAlm_msg(char[] alm_msg) {
            this.alm_msg = alm_msg;
        }
    }
    private ALM_HIS alm_his[];

    public ALM_HIS[] getAlm_his() {
        return alm_his;
    }

    public void setAlm_his(ALM_HIS[] alm_his) {
        this.alm_his = alm_his;
    }

    @Override
    public String toString() {
        return "ODBAHIS4{" +
                "s_no=" + s_no +
                ", e_no=" + e_no +
                ", alm_his=" + Arrays.toString(alm_his) +
                '}';
    }
}