package jp.co.fanuc.fwlibe1;


public class ODBINDEXINFO {
    private short           mode;
    private short           nc_ax;
    private short           inpos_point;
    private short           ofs_edit_signal;

    public short getMode() {
        return mode;
    }

    public void setMode(short mode) {
        this.mode = mode;
    }

    public short getNc_ax() {
        return nc_ax;
    }

    public void setNc_ax(short nc_ax) {
        this.nc_ax = nc_ax;
    }

    public short getInpos_point() {
        return inpos_point;
    }

    public void setInpos_point(short inpos_point) {
        this.inpos_point = inpos_point;
    }

    public short getOfs_edit_signal() {
        return ofs_edit_signal;
    }

    public void setOfs_edit_signal(short ofs_edit_signal) {
        this.ofs_edit_signal = ofs_edit_signal;
    }

    @Override
    public String toString() {
        return "ODBINDEXINFO{" +
                "mode=" + mode +
                ", nc_ax=" + nc_ax +
                ", inpos_point=" + inpos_point +
                ", ofs_edit_signal=" + ofs_edit_signal +
                '}';
    }
}
