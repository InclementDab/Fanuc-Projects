package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBDIDO {
    private short slave_no;
    private short slot_no;
    private char di_size;
    private char di_type;
    private short di_addr;
    private char do_size;
    private char do_type;
    private short do_addr;
    private short shift;
    private char module_dlen;
    private char module_data[];

    public short getSlave_no() {
        return slave_no;
    }

    public void setSlave_no(short slave_no) {
        this.slave_no = slave_no;
    }

    public short getSlot_no() {
        return slot_no;
    }

    public void setSlot_no(short slot_no) {
        this.slot_no = slot_no;
    }

    public char getDi_size() {
        return di_size;
    }

    public void setDi_size(char di_size) {
        this.di_size = di_size;
    }

    public char getDi_type() {
        return di_type;
    }

    public void setDi_type(char di_type) {
        this.di_type = di_type;
    }

    public short getDi_addr() {
        return di_addr;
    }

    public void setDi_addr(short di_addr) {
        this.di_addr = di_addr;
    }

    public char getDo_size() {
        return do_size;
    }

    public void setDo_size(char do_size) {
        this.do_size = do_size;
    }

    public char getDo_type() {
        return do_type;
    }

    public void setDo_type(char do_type) {
        this.do_type = do_type;
    }

    public short getDo_addr() {
        return do_addr;
    }

    public void setDo_addr(short do_addr) {
        this.do_addr = do_addr;
    }

    public short getShift() {
        return shift;
    }

    public void setShift(short shift) {
        this.shift = shift;
    }

    public char getModule_dlen() {
        return module_dlen;
    }

    public void setModule_dlen(char module_dlen) {
        this.module_dlen = module_dlen;
    }

    public char[] getModule_data() {
        return module_data;
    }

    public void setModule_data(char[] module_data) {
        this.module_data = module_data;
    }

    @Override
    public String toString() {
        return "IODBDIDO{" +
                "slave_no=" + slave_no +
                ", slot_no=" + slot_no +
                ", di_size=" + di_size +
                ", di_type=" + di_type +
                ", di_addr=" + di_addr +
                ", do_size=" + do_size +
                ", do_type=" + do_type +
                ", do_addr=" + do_addr +
                ", shift=" + shift +
                ", module_dlen=" + module_dlen +
                ", module_data=" + Arrays.toString(module_data) +
                '}';
    }
}
