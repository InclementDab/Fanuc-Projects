package jp.co.fanuc.fwlibe1;


public class IODBOVSTR {
    private IODBOVMST mcode;
    private IODBOVMST scode;
    private IODBOVMST tcode;
    private IODBOVMST bcode;

    public IODBOVMST getMcode() {
        return mcode;
    }

    public void setMcode(IODBOVMST mcode) {
        this.mcode = mcode;
    }

    public IODBOVMST getScode() {

        return scode;
    }

    public void setScode(IODBOVMST scode) {
        this.scode = scode;
    }

    public IODBOVMST getTcode() {

        return tcode;
    }

    public void setTcode(IODBOVMST tcode) {
        this.tcode = tcode;
    }

    public IODBOVMST getBcode() {

        return bcode;
    }

    public void setBcode(IODBOVMST bcode) {
        this.bcode = bcode;
    }

    @Override
    public String toString() {
        return "IODBOVSTR{" +
                "mcode=" + mcode +
                ", scode=" + scode +
                ", tcode=" + tcode +
                ", bcode=" + bcode +
                '}';
    }
}
