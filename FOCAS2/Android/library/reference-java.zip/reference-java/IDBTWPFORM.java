package jp.co.fanuc.fwlibe1;


public class IDBTWPFORM {
    private IDBTWP_EULER_FMT euler;
    private IDBTWP_RPY_FMT   rpy;
    private IDBTWP_3P_FMT    p3;
    private IDBTWP_2VCT_FMT  vct2;
    private IDBTWP_PJCT_FMT  pjct;

    public IDBTWP_EULER_FMT getEuler() {
        return euler;
    }

    public void setEuler(IDBTWP_EULER_FMT euler) {
        this.euler = euler;
    }

    public IDBTWP_RPY_FMT getRpy() {
        return rpy;
    }

    public void setRpy(IDBTWP_RPY_FMT rpy) {
        this.rpy = rpy;
    }

    public IDBTWP_3P_FMT getP3() {
        return p3;
    }

    public void setP3(IDBTWP_3P_FMT p3) {
        this.p3 = p3;
    }

    public IDBTWP_2VCT_FMT getVct2() {
        return vct2;
    }

    public void setVct2(IDBTWP_2VCT_FMT vct2) {
        this.vct2 = vct2;
    }

    public IDBTWP_PJCT_FMT getPjct() {
        return pjct;
    }

    public void setPjct(IDBTWP_PJCT_FMT pjct) {
        this.pjct = pjct;
    }

    @Override
    public String toString() {
        return "IDBTWPFORM{" +
                "euler=" + euler +
                ", rpy=" + rpy +
                ", p3=" + p3 +
                ", vct2=" + vct2 +
                ", pjct=" + pjct +
                '}';
    }
}
