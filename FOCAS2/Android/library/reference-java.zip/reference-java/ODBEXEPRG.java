package jp.co.fanuc.fwlibe1;


public class ODBEXEPRG {
    private String name;
    private int o_num;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getO_num() {

        return o_num;
    }

    public void setO_num(int o_num) {
        this.o_num = o_num;
    }

    @Override
    public String toString() {
        return "ODBEXEPRG{" +
                "name=" + name +
                ", o_num=" + o_num +
                '}';
    }
}
