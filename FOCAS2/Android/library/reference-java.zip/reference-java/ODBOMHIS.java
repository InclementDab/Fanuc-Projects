package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBOMHIS {
    private short om_no;
    private short year;
    private short month;
    private short day;
    private short hour;
    private short minute;
    private short second;
    private char om_msg[];

    public short getOm_no() {
        return om_no;
    }

    public void setOm_no(short om_no) {
        this.om_no = om_no;
    }

    public short getYear() {
        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public short getMonth() {
        return month;
    }

    public void setMonth(short month) {
        this.month = month;
    }

    public short getDay() {
        return day;
    }

    public void setDay(short day) {
        this.day = day;
    }

    public short getHour() {
        return hour;
    }

    public void setHour(short hour) {
        this.hour = hour;
    }

    public short getMinute() {
        return minute;
    }

    public void setMinute(short minute) {
        this.minute = minute;
    }

    public short getSecond() {
        return second;
    }

    public void setSecond(short second) {
        this.second = second;
    }

    public char[] getOm_msg() {
        return om_msg;
    }

    public void setOm_msg(char[] om_msg) {
        this.om_msg = om_msg;
    }

    @Override
    public String toString() {
        return "ODBOMHIS{" +
                "om_no=" + om_no +
                ", year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", hour=" + hour +
                ", minute=" + minute +
                ", second=" + second +
                ", om_msg=" + Arrays.toString(om_msg) +
                '}';
    }
}
