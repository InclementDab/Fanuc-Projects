package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBLSWORK {
    private short   slct ;
    private short   skeyinf ;
    private short   reserve[] ;

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getSkeyinf() {
        return skeyinf;
    }

    public void setSkeyinf(short skeyinf) {
        this.skeyinf = skeyinf;
    }

    public short[] getReserve() {
        return reserve;
    }

    public void setReserve(short[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IDBLSWORK{" +
                "slct=" + slct +
                ", skeyinf=" + skeyinf +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
