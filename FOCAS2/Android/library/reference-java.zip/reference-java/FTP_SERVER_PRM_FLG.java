package jp.co.fanuc.fwlibe1;


public class FTP_SERVER_PRM_FLG {
    private char UserName;
    private char Password;
    private char LoginDirectory;

    public char getUserName() {
        return UserName;
    }

    public void setUserName(char userName) {
        UserName = userName;
    }

    public char getPassword() {
        return Password;
    }

    public void setPassword(char password) {
        Password = password;
    }

    public char getLoginDirectory() {
        return LoginDirectory;
    }

    public void setLoginDirectory(char loginDirectory) {
        LoginDirectory = loginDirectory;
    }

    @Override
    public String toString() {
        return "FTP_SERVER_PRM_FLG{" +
                "UserName=" + UserName +
                ", Password=" + Password +
                ", LoginDirectory=" + LoginDirectory +
                '}';
    }
}
