package jp.co.fanuc.fwlibe1;


public class ODBDIAGNUM {
    private short diag_min;
    private short diag_max;
    private short total_no;

    public short getDiag_min() {
        return diag_min;
    }

    public void setDiag_min(short diag_min) {
        this.diag_min = diag_min;
    }

    public short getDiag_max() {
        return diag_max;
    }

    public void setDiag_max(short diag_max) {
        this.diag_max = diag_max;
    }

    public short getTotal_no() {
        return total_no;
    }

    public void setTotal_no(short total_no) {
        this.total_no = total_no;
    }

    @Override
    public String toString() {
        return "ODBDIAGNUM{" +
                "diag_min=" + diag_min +
                ", diag_max=" + diag_max +
                ", total_no=" + total_no +
                '}';
    }
}
