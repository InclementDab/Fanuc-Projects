package jp.co.fanuc.fwlibe1;


public class EMBLSI {
    private short Collision;
    private short CarrierSenseLost;
    private short DelayOver;
    private short Underrun;
    private short SendParityError;
    private short AlignmentError;
    private short CrcError;
    private short Overrun;
    private short FrameLengthViolation;
    private short RecvParityError;

    public short getCollision() {
        return Collision;
    }

    public void setCollision(short collision) {
        Collision = collision;
    }

    public short getCarrierSenseLost() {
        return CarrierSenseLost;
    }

    public void setCarrierSenseLost(short carrierSenseLost) {
        CarrierSenseLost = carrierSenseLost;
    }

    public short getDelayOver() {
        return DelayOver;
    }

    public void setDelayOver(short delayOver) {
        DelayOver = delayOver;
    }

    public short getUnderrun() {
        return Underrun;
    }

    public void setUnderrun(short underrun) {
        Underrun = underrun;
    }

    public short getSendParityError() {
        return SendParityError;
    }

    public void setSendParityError(short sendParityError) {
        SendParityError = sendParityError;
    }

    public short getAlignmentError() {
        return AlignmentError;
    }

    public void setAlignmentError(short alignmentError) {
        AlignmentError = alignmentError;
    }

    public short getCrcError() {
        return CrcError;
    }

    public void setCrcError(short crcError) {
        CrcError = crcError;
    }

    public short getOverrun() {
        return Overrun;
    }

    public void setOverrun(short overrun) {
        Overrun = overrun;
    }

    public short getFrameLengthViolation() {
        return FrameLengthViolation;
    }

    public void setFrameLengthViolation(short frameLengthViolation) {
        FrameLengthViolation = frameLengthViolation;
    }

    public short getRecvParityError() {
        return RecvParityError;
    }

    public void setRecvParityError(short recvParityError) {
        RecvParityError = recvParityError;
    }

    @Override
    public String toString() {
        return "EMBLSI{" +
                "Collision=" + Collision +
                ", CarrierSenseLost=" + CarrierSenseLost +
                ", DelayOver=" + DelayOver +
                ", Underrun=" + Underrun +
                ", SendParityError=" + SendParityError +
                ", AlignmentError=" + AlignmentError +
                ", CrcError=" + CrcError +
                ", Overrun=" + Overrun +
                ", FrameLengthViolation=" + FrameLengthViolation +
                ", RecvParityError=" + RecvParityError +
                '}';
    }
}
