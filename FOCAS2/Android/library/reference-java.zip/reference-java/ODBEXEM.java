package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBEXEM {
    private short grp_no;
    private short mem_no;

    public short getGrp_no() {
        return grp_no;
    }

    public void setGrp_no(short grp_no) {
        this.grp_no = grp_no;
    }

    public short getMem_no() {
        return mem_no;
    }

    public void setMem_no(short mem_no) {
        this.mem_no = mem_no;
    }

    public static class M_CODE {
        private int no;
        private short flag;

        public int getNo() {
            return no;
        }

        public void setNo(int no) {
            this.no = no;
        }

        public short getFlag() {
            return flag;
        }

        public void setFlag(short flag) {
            this.flag = flag;
        }

        @Override
        public String toString() {
            return "M_CODE{" +
                    "no=" + no +
                    ", flag=" + flag +
                    '}';
        }
    }
    private M_CODE m_code[];
    private char m_name[];
    private char dummy;

    public M_CODE[] getM_code() {
        return m_code;
    }

    public void setM_code(M_CODE[] m_code) {
        this.m_code = m_code;
    }

    public char[] getM_name() {
        return m_name;
    }

    public void setM_name(char[] m_name) {
        this.m_name = m_name;
    }

    public char getDummy() {
        return dummy;
    }

    public void setDummy(char dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "ODBEXEM{" +
                "grp_no=" + grp_no +
                ", mem_no=" + mem_no +
                ", m_code=" + Arrays.toString(m_code) +
                ", m_name=" + Arrays.toString(m_name) +
                ", dummy=" + dummy +
                '}';
    }
}
