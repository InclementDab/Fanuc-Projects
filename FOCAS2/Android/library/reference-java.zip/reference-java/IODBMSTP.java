package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBMSTP {
    private short datano_s;
    private short dummy;
    private short datano_e;
    private char data[];

    public short getDatano_s() {
        return datano_s;
    }

    public void setDatano_s(short datano_s) {
        this.datano_s = datano_s;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public short getDatano_e() {

        return datano_e;
    }

    public void setDatano_e(short datano_e) {
        this.datano_e = datano_e;
    }

    public char[] getData() {

        return data;
    }

    public void setData(char[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBMSTP{" +
                "datano_s=" + datano_s +
                ", dummy=" + dummy +
                ", datano_e=" + datano_e +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
