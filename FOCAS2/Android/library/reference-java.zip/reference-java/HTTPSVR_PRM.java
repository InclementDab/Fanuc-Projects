package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class HTTPSVR_PRM {
    private int TcpPort;
    private int Timeout;
    private USER_ACCOUNT_PRM UserAccount[];

    public int getTcpPort() {
        return TcpPort;
    }

    public void setTcpPort(int tcpPort) {
        TcpPort = tcpPort;
    }

    public int getTimeout() {
        return Timeout;
    }

    public void setTimeout(int timeout) {
        Timeout = timeout;
    }

    public USER_ACCOUNT_PRM[] getUserAccount() {
        return UserAccount;
    }

    public void setUserAccount(USER_ACCOUNT_PRM[] userAccount) {
        UserAccount = userAccount;
    }

    @Override
    public String toString() {
        return "HTTPSVR_PRM{" +
                "TcpPort=" + TcpPort +
                ", Timeout=" + Timeout +
                ", UserAccount=" + Arrays.toString(UserAccount) +
                '}';
    }
}
