package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBSYSALM {
    private int num_sys_alm;
    private short error_line;
    private short error_slvnum1;
    private short error_slvnum2;
    private short year;
    private short mon;
    private short day;
    private short hour;
    private short min;
    private short sec;
    private char alarm_cause[];

    public int getNum_sys_alm() {
        return num_sys_alm;
    }

    public void setNum_sys_alm(int num_sys_alm) {
        this.num_sys_alm = num_sys_alm;
    }

    public short getError_line() {
        return error_line;
    }

    public void setError_line(short error_line) {
        this.error_line = error_line;
    }

    public short getError_slvnum1() {
        return error_slvnum1;
    }

    public void setError_slvnum1(short error_slvnum1) {
        this.error_slvnum1 = error_slvnum1;
    }

    public short getError_slvnum2() {
        return error_slvnum2;
    }

    public void setError_slvnum2(short error_slvnum2) {
        this.error_slvnum2 = error_slvnum2;
    }

    public short getYear() {
        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public short getMon() {
        return mon;
    }

    public void setMon(short mon) {
        this.mon = mon;
    }

    public short getDay() {
        return day;
    }

    public void setDay(short day) {
        this.day = day;
    }

    public short getHour() {
        return hour;
    }

    public void setHour(short hour) {
        this.hour = hour;
    }

    public short getMin() {
        return min;
    }

    public void setMin(short min) {
        this.min = min;
    }

    public short getSec() {
        return sec;
    }

    public void setSec(short sec) {
        this.sec = sec;
    }

    public char[] getAlarm_cause() {
        return alarm_cause;
    }

    public void setAlarm_cause(char[] alarm_cause) {
        this.alarm_cause = alarm_cause;
    }

    @Override
    public String toString() {
        return "ODBIFSBSYSALM{" +
                "num_sys_alm=" + num_sys_alm +
                ", error_line=" + error_line +
                ", error_slvnum1=" + error_slvnum1 +
                ", error_slvnum2=" + error_slvnum2 +
                ", year=" + year +
                ", mon=" + mon +
                ", day=" + day +
                ", hour=" + hour +
                ", min=" + min +
                ", sec=" + sec +
                ", alarm_cause=" + Arrays.toString(alarm_cause) +
                '}';
    }
}
