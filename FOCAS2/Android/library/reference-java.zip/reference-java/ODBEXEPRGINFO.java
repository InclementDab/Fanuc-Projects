package jp.co.fanuc.fwlibe1;


public class ODBEXEPRGINFO {
    private EXEPRG before_buffering;
    private EXEPRG after_buffering;

    public EXEPRG getBefore_buffering() {
        return before_buffering;
    }

    public void setBefore_buffering(EXEPRG before_buffering) {
        this.before_buffering = before_buffering;
    }

    public EXEPRG getAfter_buffering() {

        return after_buffering;
    }

    public void setAfter_buffering(EXEPRG after_buffering) {
        this.after_buffering = after_buffering;
    }

    @Override
    public String toString() {
        return "ODBEXEPRGINFO{" +
                "before_buffering=" + before_buffering +
                ", after_buffering=" + after_buffering +
                '}';
    }
}
