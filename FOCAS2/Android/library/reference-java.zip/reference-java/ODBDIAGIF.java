package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBDIAGIF {
    private short info_no;
    private short prev_no;
    private short next_no;

    public short getInfo_no() {
        return info_no;
    }

    public void setInfo_no(short info_no) {
        this.info_no = info_no;
    }

    public short getPrev_no() {
        return prev_no;
    }

    public void setPrev_no(short prev_no) {
        this.prev_no = prev_no;
    }

    public short getNext_no() {
        return next_no;
    }

    public void setNext_no(short next_no) {
        this.next_no = next_no;
    }

    public static class  INFO {
        private short diag_no;
        private short diag_type;

        public short getDiag_no() {
            return diag_no;
        }

        public void setDiag_no(short diag_no) {
            this.diag_no = diag_no;
        }

        public short getDiag_type() {
            return diag_type;
        }

        public void setDiag_type(short diag_type) {
            this.diag_type = diag_type;
        }

        @Override
        public String toString() {
            return "INFO{" +
                    "diag_no=" + diag_no +
                    ", diag_type=" + diag_type +
                    '}';
        }
    }
    private INFO info[];

    public INFO[] getInfo() {
        return info;
    }

    public void setInfo(INFO[] info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "ODBDIAGIF{" +
                "info_no=" + info_no +
                ", prev_no=" + prev_no +
                ", next_no=" + next_no +
                ", info=" + Arrays.toString(info) +
                '}';
    }
}
