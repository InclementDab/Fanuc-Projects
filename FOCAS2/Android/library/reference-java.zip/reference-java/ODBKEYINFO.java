package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBKEYINFO {
    private int key[];

    public int[] getKey() {
        return key;
    }

    public void setKey(int[] key) {
        this.key = key;
    }

    @Override
    public String toString() {
        return "ODBKEYINFO{" +
                "key=" + Arrays.toString(key) +
                '}';
    }
}
