package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBRBSIGNAL {
    private char nama[];

    public char[] getNama() {
        return nama;
    }

    public void setNama(char[] nama) {
        this.nama = nama;
    }

    @Override
    public String toString() {
        return "IDBRBSIGNAL{" +
                "nama=" + Arrays.toString(nama) +
                '}';
    }
}
