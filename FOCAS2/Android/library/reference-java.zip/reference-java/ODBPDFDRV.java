package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBPDFDRV {
    private short max_num;
    private short dummy;
    private String drive[];

    public short getMax_num() {
        return max_num;
    }

    public void setMax_num(short max_num) {
        this.max_num = max_num;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public String[] getDrive() {

        return drive;
    }

    public void setDrive(String[] drive) {
        this.drive = drive;
    }

    @Override
    public String toString() {
        return "ODBPDFDRV{" +
                "max_num=" + max_num +
                ", dummy=" + dummy +
                ", drive=" + Arrays.toString(drive) +
                '}';
    }
}
