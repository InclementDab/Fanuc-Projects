package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTLDT {
    private short slct;
    private int tool_no;
    private int x_axis_ofs;
    private int y_axis_ofs;
    private int turret_pos;
    private int chg_tl_no;
    private int punch_count;
    private int tool_life;
    private int m_tl_radius;
    private int m_tl_angle;
    private char tl_shape;
    private int tl_size_i;
    private int tl_size_j;
    private int tl_angle;
    private char x_axis_dec;
    private char y_axis_dec;
    private char turret_dec;
    private char m_radius_dec;
    private char m_angle_dec;
    private char tl_size_i_dec;
    private char tl_size_j_dec;
    private char angle_dec;
    private short reserve[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public int getTool_no() {
        return tool_no;
    }

    public void setTool_no(int tool_no) {
        this.tool_no = tool_no;
    }

    public int getX_axis_ofs() {
        return x_axis_ofs;
    }

    public void setX_axis_ofs(int x_axis_ofs) {
        this.x_axis_ofs = x_axis_ofs;
    }

    public int getY_axis_ofs() {
        return y_axis_ofs;
    }

    public void setY_axis_ofs(int y_axis_ofs) {
        this.y_axis_ofs = y_axis_ofs;
    }

    public int getTurret_pos() {
        return turret_pos;
    }

    public void setTurret_pos(int turret_pos) {
        this.turret_pos = turret_pos;
    }

    public int getChg_tl_no() {
        return chg_tl_no;
    }

    public void setChg_tl_no(int chg_tl_no) {
        this.chg_tl_no = chg_tl_no;
    }

    public int getPunch_count() {
        return punch_count;
    }

    public void setPunch_count(int punch_count) {
        this.punch_count = punch_count;
    }

    public int getTool_life() {
        return tool_life;
    }

    public void setTool_life(int tool_life) {
        this.tool_life = tool_life;
    }

    public int getM_tl_radius() {
        return m_tl_radius;
    }

    public void setM_tl_radius(int m_tl_radius) {
        this.m_tl_radius = m_tl_radius;
    }

    public int getM_tl_angle() {
        return m_tl_angle;
    }

    public void setM_tl_angle(int m_tl_angle) {
        this.m_tl_angle = m_tl_angle;
    }

    public char getTl_shape() {
        return tl_shape;
    }

    public void setTl_shape(char tl_shape) {
        this.tl_shape = tl_shape;
    }

    public int getTl_size_i() {
        return tl_size_i;
    }

    public void setTl_size_i(int tl_size_i) {
        this.tl_size_i = tl_size_i;
    }

    public int getTl_size_j() {
        return tl_size_j;
    }

    public void setTl_size_j(int tl_size_j) {
        this.tl_size_j = tl_size_j;
    }

    public int getTl_angle() {
        return tl_angle;
    }

    public void setTl_angle(int tl_angle) {
        this.tl_angle = tl_angle;
    }

    public char getX_axis_dec() {
        return x_axis_dec;
    }

    public void setX_axis_dec(char x_axis_dec) {
        this.x_axis_dec = x_axis_dec;
    }

    public char getY_axis_dec() {
        return y_axis_dec;
    }

    public void setY_axis_dec(char y_axis_dec) {
        this.y_axis_dec = y_axis_dec;
    }

    public char getTurret_dec() {
        return turret_dec;
    }

    public void setTurret_dec(char turret_dec) {
        this.turret_dec = turret_dec;
    }

    public char getM_radius_dec() {
        return m_radius_dec;
    }

    public void setM_radius_dec(char m_radius_dec) {
        this.m_radius_dec = m_radius_dec;
    }

    public char getM_angle_dec() {
        return m_angle_dec;
    }

    public void setM_angle_dec(char m_angle_dec) {
        this.m_angle_dec = m_angle_dec;
    }

    public char getTl_size_i_dec() {
        return tl_size_i_dec;
    }

    public void setTl_size_i_dec(char tl_size_i_dec) {
        this.tl_size_i_dec = tl_size_i_dec;
    }

    public char getTl_size_j_dec() {
        return tl_size_j_dec;
    }

    public void setTl_size_j_dec(char tl_size_j_dec) {
        this.tl_size_j_dec = tl_size_j_dec;
    }

    public char getAngle_dec() {
        return angle_dec;
    }

    public void setAngle_dec(char angle_dec) {
        this.angle_dec = angle_dec;
    }

    public short[] getReserve() {
        return reserve;
    }

    public void setReserve(short[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBTLDT{" +
                "slct=" + slct +
                ", tool_no=" + tool_no +
                ", x_axis_ofs=" + x_axis_ofs +
                ", y_axis_ofs=" + y_axis_ofs +
                ", turret_pos=" + turret_pos +
                ", chg_tl_no=" + chg_tl_no +
                ", punch_count=" + punch_count +
                ", tool_life=" + tool_life +
                ", m_tl_radius=" + m_tl_radius +
                ", m_tl_angle=" + m_tl_angle +
                ", tl_shape=" + tl_shape +
                ", tl_size_i=" + tl_size_i +
                ", tl_size_j=" + tl_size_j +
                ", tl_angle=" + tl_angle +
                ", x_axis_dec=" + x_axis_dec +
                ", y_axis_dec=" + y_axis_dec +
                ", turret_dec=" + turret_dec +
                ", m_radius_dec=" + m_radius_dec +
                ", m_angle_dec=" + m_angle_dec +
                ", tl_size_i_dec=" + tl_size_i_dec +
                ", tl_size_j_dec=" + tl_size_j_dec +
                ", angle_dec=" + angle_dec +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
