package jp.co.fanuc.fwlibe1;

import java.util.Arrays;

public class IODBZOFS64 {
    private short datano;
    private short type;
    private short dummy[];
    private REALDATA data[];

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {

        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short[] getDummy() {

        return dummy;
    }

    public void setDummy(short[] dummy) {
        this.dummy = dummy;
    }

    public REALDATA[] getData() {

        return data;
    }

    public void setData(REALDATA[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBZOFS64{" +
                "datano=" + datano +
                ", type=" + type +
                ", dummy=" + Arrays.toString(dummy) +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
