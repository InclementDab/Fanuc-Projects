package jp.co.fanuc.fwlibe1;


public class IODBPIRC {
    private short slct;
    private short power;
    private short freq;
    private short duty;
    private short i_freq;
    private short i_duty;
    private short step_t;
    private short step_sum;
    private int pier_t;
    private short g_press;
    private short g_kind;
    private short g_time;
    private short def_pos;
    private int def_pos2;
    private char gap_axis;
    private char def_pos2_dec;
    private short pb_power;

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getPower() {
        return power;
    }

    public void setPower(short power) {
        this.power = power;
    }

    public short getFreq() {
        return freq;
    }

    public void setFreq(short freq) {
        this.freq = freq;
    }

    public short getDuty() {
        return duty;
    }

    public void setDuty(short duty) {
        this.duty = duty;
    }

    public short getI_freq() {
        return i_freq;
    }

    public void setI_freq(short i_freq) {
        this.i_freq = i_freq;
    }

    public short getI_duty() {
        return i_duty;
    }

    public void setI_duty(short i_duty) {
        this.i_duty = i_duty;
    }

    public short getStep_t() {
        return step_t;
    }

    public void setStep_t(short step_t) {
        this.step_t = step_t;
    }

    public short getStep_sum() {
        return step_sum;
    }

    public void setStep_sum(short step_sum) {
        this.step_sum = step_sum;
    }

    public int getPier_t() {
        return pier_t;
    }

    public void setPier_t(int pier_t) {
        this.pier_t = pier_t;
    }

    public short getG_press() {
        return g_press;
    }

    public void setG_press(short g_press) {
        this.g_press = g_press;
    }

    public short getG_kind() {
        return g_kind;
    }

    public void setG_kind(short g_kind) {
        this.g_kind = g_kind;
    }

    public short getG_time() {
        return g_time;
    }

    public void setG_time(short g_time) {
        this.g_time = g_time;
    }

    public short getDef_pos() {
        return def_pos;
    }

    public void setDef_pos(short def_pos) {
        this.def_pos = def_pos;
    }

    public int getDef_pos2() {
        return def_pos2;
    }

    public void setDef_pos2(int def_pos2) {
        this.def_pos2 = def_pos2;
    }

    public char getGap_axis() {
        return gap_axis;
    }

    public void setGap_axis(char gap_axis) {
        this.gap_axis = gap_axis;
    }

    public char getDef_pos2_dec() {
        return def_pos2_dec;
    }

    public void setDef_pos2_dec(char def_pos2_dec) {
        this.def_pos2_dec = def_pos2_dec;
    }

    public short getPb_power() {
        return pb_power;
    }

    public void setPb_power(short pb_power) {
        this.pb_power = pb_power;
    }

    @Override
    public String toString() {
        return "IODBPIRC{" +
                "slct=" + slct +
                ", power=" + power +
                ", freq=" + freq +
                ", duty=" + duty +
                ", i_freq=" + i_freq +
                ", i_duty=" + i_duty +
                ", step_t=" + step_t +
                ", step_sum=" + step_sum +
                ", pier_t=" + pier_t +
                ", g_press=" + g_press +
                ", g_kind=" + g_kind +
                ", g_time=" + g_time +
                ", def_pos=" + def_pos +
                ", def_pos2=" + def_pos2 +
                ", gap_axis=" + gap_axis +
                ", def_pos2_dec=" + def_pos2_dec +
                ", pb_power=" + pb_power +
                '}';
    }
}
