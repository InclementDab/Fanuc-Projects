package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBHPAC {
    public static class TUNE {
        private short slct;
        private short diff;
        private short fine;
        private short acc_lv;
        private int bipl;
        private short aipl;
        private int corner;
        private int clamp;
        private int c_acc;
        private int foward;
        private int reserve[];

        public short getSlct() {
            return slct;
        }

        public void setSlct(short slct) {
            this.slct = slct;
        }

        public short getDiff() {
            return diff;
        }

        public void setDiff(short diff) {
            this.diff = diff;
        }

        public short getFine() {
            return fine;
        }

        public void setFine(short fine) {
            this.fine = fine;
        }

        public short getAcc_lv() {
            return acc_lv;
        }

        public void setAcc_lv(short acc_lv) {
            this.acc_lv = acc_lv;
        }

        public int getBipl() {
            return bipl;
        }

        public void setBipl(int bipl) {
            this.bipl = bipl;
        }

        public short getAipl() {
            return aipl;
        }

        public void setAipl(short aipl) {
            this.aipl = aipl;
        }

        public int getCorner() {
            return corner;
        }

        public void setCorner(int corner) {
            this.corner = corner;
        }

        public int getClamp() {
            return clamp;
        }

        public void setClamp(int clamp) {
            this.clamp = clamp;
        }

        public int getC_acc() {
            return c_acc;
        }

        public void setC_acc(int c_acc) {
            this.c_acc = c_acc;
        }

        public int getFoward() {
            return foward;
        }

        public void setFoward(int foward) {
            this.foward = foward;
        }

        public int[] getReserve() {
            return reserve;
        }

        public void setReserve(int[] reserve) {
            this.reserve = reserve;
        }

        @Override
        public String toString() {
            return "TUNE{" +
                    "slct=" + slct +
                    ", diff=" + diff +
                    ", fine=" + fine +
                    ", acc_lv=" + acc_lv +
                    ", bipl=" + bipl +
                    ", aipl=" + aipl +
                    ", corner=" + corner +
                    ", clamp=" + clamp +
                    ", c_acc=" + c_acc +
                    ", foward=" + foward +
                    ", reserve=" + Arrays.toString(reserve) +
                    '}';
        }
    }
    private TUNE tune[];

    public TUNE[] getTune() {
        return tune;
    }

    public void setTune(TUNE[] tune) {
        this.tune = tune;
    }

    @Override
    public String toString() {
        return "IODBHPAC{" +
                "tune=" + Arrays.toString(tune) +
                '}';
    }
}
