package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBRBGROUP {
    private char robot_program;
    private char nc_program_folder[];
    private char nc_program_name[];

    public char getRobot_program() {
        return robot_program;
    }

    public void setRobot_program(char robot_program) {
        this.robot_program = robot_program;
    }

    public char[] getNc_program_folder() {
        return nc_program_folder;
    }

    public void setNc_program_folder(char[] nc_program_folder) {
        this.nc_program_folder = nc_program_folder;
    }

    public char[] getNc_program_name() {
        return nc_program_name;
    }

    public void setNc_program_name(char[] nc_program_name) {
        this.nc_program_name = nc_program_name;
    }

    @Override
    public String toString() {
        return "IDBRBGROUP{" +
                "robot_program=" + robot_program +
                ", nc_program_folder=" + Arrays.toString(nc_program_folder) +
                ", nc_program_name=" + Arrays.toString(nc_program_name) +
                '}';
    }
}
