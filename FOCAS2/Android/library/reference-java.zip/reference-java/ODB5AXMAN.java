package jp.co.fanuc.fwlibe1;

public class ODB5AXMAN {
    private short type1;
    private short type2;
    private short type3;
    private int data1;
    private int data2;
    private int data3;
    private int c1;
    private int c2;
    private int dummy;
    private int td;
    private int r1;
    private int r2;
    private int vr;
    private int h1;
    private int h2;

    public short getType1() {
        return type1;
    }

    public void setType1(short type1) {
        this.type1 = type1;
    }

    public short getType2() {
        return type2;
    }

    public void setType2(short type2) {
        this.type2 = type2;
    }

    public short getType3() {
        return type3;
    }

    public void setType3(short type3) {
        this.type3 = type3;
    }

    public int getData1() {
        return data1;
    }

    public void setData1(int data1) {
        this.data1 = data1;
    }

    public int getData2() {
        return data2;
    }

    public void setData2(int data2) {
        this.data2 = data2;
    }

    public int getData3() {

        return data3;
    }

    public void setData3(int data3) {
        this.data3 = data3;
    }

    public int getC1() {

        return c1;
    }

    public void setC1(int c1) {
        this.c1 = c1;
    }

    public int getC2() {

        return c2;
    }

    public void setC2(int c2) {
        this.c2 = c2;
    }

    public int getDummy() {

        return dummy;
    }

    public void setDummy(int dummy) {
        this.dummy = dummy;
    }

    public int getTd() {

        return td;
    }

    public void setTd(int td) {
        this.td = td;
    }

    public int getR1() {

        return r1;
    }

    public void setR1(int r1) {
        this.r1 = r1;
    }

    public int getR2() {

        return r2;
    }

    public void setR2(int r2) {
        this.r2 = r2;
    }

    public int getVr() {

        return vr;
    }

    public void setVr(int vr) {
        this.vr = vr;
    }

    public int getH1() {

        return h1;
    }

    public void setH1(int h1) {
        this.h1 = h1;
    }

    public int getH2() {

        return h2;
    }

    public void setH2(int h2) {
        this.h2 = h2;
    }

    @Override
    public String toString() {
        return "ODB5AXMAN{" +
                "type1=" + type1 +
                ", type2=" + type2 +
                ", type3=" + type3 +
                ", data1=" + data1 +
                ", data2=" + data2 +
                ", data3=" + data3 +
                ", c1=" + c1 +
                ", c2=" + c2 +
                ", dummy=" + dummy +
                ", td=" + td +
                ", r1=" + r1 +
                ", r2=" + r2 +
                ", vr=" + vr +
                ", h1=" + h1 +
                ", h2=" + h2 +
                '}';
    }
}
