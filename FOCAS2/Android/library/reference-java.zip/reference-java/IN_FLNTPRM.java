package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_FLNTPRM {
    private char            OwnIpAddress[];
    private char            NodeName[];
    private short           Area1CmnMemAddr;
    private short           Area1CmnMemSize;
    private short           Area2CmnMemAddr;
    private short           Area2CmnMemSize;
    private char            TokenWatch;
    private char            MinFrame;
    private char            Reserved0[];
    private PMC_REG         OwnStatus;
    private PMC_REG         EntryNode;
    private PMC_REG         Area1PmcAddr;
    private short           Area1ExchgAddr;
    private short           Area1ExchgSize;
    private PMC_REG         Area2PmcAddr;
    private short           Area2ExchgAddr;
    private short           Area2ExchgSize;
    private PMC_REG         Area2PmcDoAddr;
    private short           Area2ExchgDoSize;
    private char            Reserved1[];
    private PMC_REG         Area2PmcDiAddr;
    private PMC_REG         Area2ConditionAddr;
    private PMC_REG         Area2AlterAddr;
    private short           Area2ExchgDiAddr;
    private short           Area2ExchgDiSize;
    private PMC_REG         ClientMsgAddr;
    private short           ClientMsgSize;
    private char            Reserved2[];
    private PMC_REG         ServerMsgAddr;
    private short           ServerMsgSize;
    private char            Reserved3[];
    private short           Option1;
    private short           Option2;

    public char[] getOwnIpAddress() {
        return OwnIpAddress;
    }

    public void setOwnIpAddress(char[] ownIpAddress) {
        OwnIpAddress = ownIpAddress;
    }

    public char[] getNodeName() {
        return NodeName;
    }

    public void setNodeName(char[] nodeName) {
        NodeName = nodeName;
    }

    public short getArea1CmnMemAddr() {
        return Area1CmnMemAddr;
    }

    public void setArea1CmnMemAddr(short area1CmnMemAddr) {
        Area1CmnMemAddr = area1CmnMemAddr;
    }

    public short getArea1CmnMemSize() {
        return Area1CmnMemSize;
    }

    public void setArea1CmnMemSize(short area1CmnMemSize) {
        Area1CmnMemSize = area1CmnMemSize;
    }

    public short getArea2CmnMemAddr() {
        return Area2CmnMemAddr;
    }

    public void setArea2CmnMemAddr(short area2CmnMemAddr) {
        Area2CmnMemAddr = area2CmnMemAddr;
    }

    public short getArea2CmnMemSize() {
        return Area2CmnMemSize;
    }

    public void setArea2CmnMemSize(short area2CmnMemSize) {
        Area2CmnMemSize = area2CmnMemSize;
    }

    public char getTokenWatch() {
        return TokenWatch;
    }

    public void setTokenWatch(char tokenWatch) {
        TokenWatch = tokenWatch;
    }

    public char getMinFrame() {
        return MinFrame;
    }

    public void setMinFrame(char minFrame) {
        MinFrame = minFrame;
    }

    public char[] getReserved0() {
        return Reserved0;
    }

    public void setReserved0(char[] reserved0) {
        Reserved0 = reserved0;
    }

    public PMC_REG getOwnStatus() {
        return OwnStatus;
    }

    public void setOwnStatus(PMC_REG ownStatus) {
        OwnStatus = ownStatus;
    }

    public PMC_REG getEntryNode() {
        return EntryNode;
    }

    public void setEntryNode(PMC_REG entryNode) {
        EntryNode = entryNode;
    }

    public PMC_REG getArea1PmcAddr() {
        return Area1PmcAddr;
    }

    public void setArea1PmcAddr(PMC_REG area1PmcAddr) {
        Area1PmcAddr = area1PmcAddr;
    }

    public short getArea1ExchgAddr() {
        return Area1ExchgAddr;
    }

    public void setArea1ExchgAddr(short area1ExchgAddr) {
        Area1ExchgAddr = area1ExchgAddr;
    }

    public short getArea1ExchgSize() {
        return Area1ExchgSize;
    }

    public void setArea1ExchgSize(short area1ExchgSize) {
        Area1ExchgSize = area1ExchgSize;
    }

    public PMC_REG getArea2PmcAddr() {
        return Area2PmcAddr;
    }

    public void setArea2PmcAddr(PMC_REG area2PmcAddr) {
        Area2PmcAddr = area2PmcAddr;
    }

    public short getArea2ExchgAddr() {
        return Area2ExchgAddr;
    }

    public void setArea2ExchgAddr(short area2ExchgAddr) {
        Area2ExchgAddr = area2ExchgAddr;
    }

    public short getArea2ExchgSize() {
        return Area2ExchgSize;
    }

    public void setArea2ExchgSize(short area2ExchgSize) {
        Area2ExchgSize = area2ExchgSize;
    }

    public PMC_REG getArea2PmcDoAddr() {
        return Area2PmcDoAddr;
    }

    public void setArea2PmcDoAddr(PMC_REG area2PmcDoAddr) {
        Area2PmcDoAddr = area2PmcDoAddr;
    }

    public short getArea2ExchgDoSize() {
        return Area2ExchgDoSize;
    }

    public void setArea2ExchgDoSize(short area2ExchgDoSize) {
        Area2ExchgDoSize = area2ExchgDoSize;
    }

    public char[] getReserved1() {
        return Reserved1;
    }

    public void setReserved1(char[] reserved1) {
        Reserved1 = reserved1;
    }

    public PMC_REG getArea2PmcDiAddr() {
        return Area2PmcDiAddr;
    }

    public void setArea2PmcDiAddr(PMC_REG area2PmcDiAddr) {
        Area2PmcDiAddr = area2PmcDiAddr;
    }

    public PMC_REG getArea2ConditionAddr() {
        return Area2ConditionAddr;
    }

    public void setArea2ConditionAddr(PMC_REG area2ConditionAddr) {
        Area2ConditionAddr = area2ConditionAddr;
    }

    public PMC_REG getArea2AlterAddr() {
        return Area2AlterAddr;
    }

    public void setArea2AlterAddr(PMC_REG area2AlterAddr) {
        Area2AlterAddr = area2AlterAddr;
    }

    public short getArea2ExchgDiAddr() {
        return Area2ExchgDiAddr;
    }

    public void setArea2ExchgDiAddr(short area2ExchgDiAddr) {
        Area2ExchgDiAddr = area2ExchgDiAddr;
    }

    public short getArea2ExchgDiSize() {
        return Area2ExchgDiSize;
    }

    public void setArea2ExchgDiSize(short area2ExchgDiSize) {
        Area2ExchgDiSize = area2ExchgDiSize;
    }

    public PMC_REG getClientMsgAddr() {
        return ClientMsgAddr;
    }

    public void setClientMsgAddr(PMC_REG clientMsgAddr) {
        ClientMsgAddr = clientMsgAddr;
    }

    public short getClientMsgSize() {
        return ClientMsgSize;
    }

    public void setClientMsgSize(short clientMsgSize) {
        ClientMsgSize = clientMsgSize;
    }

    public char[] getReserved2() {
        return Reserved2;
    }

    public void setReserved2(char[] reserved2) {
        Reserved2 = reserved2;
    }

    public PMC_REG getServerMsgAddr() {
        return ServerMsgAddr;
    }

    public void setServerMsgAddr(PMC_REG serverMsgAddr) {
        ServerMsgAddr = serverMsgAddr;
    }

    public short getServerMsgSize() {
        return ServerMsgSize;
    }

    public void setServerMsgSize(short serverMsgSize) {
        ServerMsgSize = serverMsgSize;
    }

    public char[] getReserved3() {
        return Reserved3;
    }

    public void setReserved3(char[] reserved3) {
        Reserved3 = reserved3;
    }

    public short getOption1() {
        return Option1;
    }

    public void setOption1(short option1) {
        Option1 = option1;
    }

    public short getOption2() {
        return Option2;
    }

    public void setOption2(short option2) {
        Option2 = option2;
    }

    @Override
    public String toString() {
        return "IN_FLNTPRM{" +
                "OwnIpAddress=" + Arrays.toString(OwnIpAddress) +
                ", NodeName=" + Arrays.toString(NodeName) +
                ", Area1CmnMemAddr=" + Area1CmnMemAddr +
                ", Area1CmnMemSize=" + Area1CmnMemSize +
                ", Area2CmnMemAddr=" + Area2CmnMemAddr +
                ", Area2CmnMemSize=" + Area2CmnMemSize +
                ", TokenWatch=" + TokenWatch +
                ", MinFrame=" + MinFrame +
                ", Reserved0=" + Arrays.toString(Reserved0) +
                ", OwnStatus=" + OwnStatus +
                ", EntryNode=" + EntryNode +
                ", Area1PmcAddr=" + Area1PmcAddr +
                ", Area1ExchgAddr=" + Area1ExchgAddr +
                ", Area1ExchgSize=" + Area1ExchgSize +
                ", Area2PmcAddr=" + Area2PmcAddr +
                ", Area2ExchgAddr=" + Area2ExchgAddr +
                ", Area2ExchgSize=" + Area2ExchgSize +
                ", Area2PmcDoAddr=" + Area2PmcDoAddr +
                ", Area2ExchgDoSize=" + Area2ExchgDoSize +
                ", Reserved1=" + Arrays.toString(Reserved1) +
                ", Area2PmcDiAddr=" + Area2PmcDiAddr +
                ", Area2ConditionAddr=" + Area2ConditionAddr +
                ", Area2AlterAddr=" + Area2AlterAddr +
                ", Area2ExchgDiAddr=" + Area2ExchgDiAddr +
                ", Area2ExchgDiSize=" + Area2ExchgDiSize +
                ", ClientMsgAddr=" + ClientMsgAddr +
                ", ClientMsgSize=" + ClientMsgSize +
                ", Reserved2=" + Arrays.toString(Reserved2) +
                ", ServerMsgAddr=" + ServerMsgAddr +
                ", ServerMsgSize=" + ServerMsgSize +
                ", Reserved3=" + Arrays.toString(Reserved3) +
                ", Option1=" + Option1 +
                ", Option2=" + Option2 +
                '}';
    }
}
