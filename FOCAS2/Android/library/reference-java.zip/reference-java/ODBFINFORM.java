package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBFINFORM {
    private int slotno;
    private String slotname;
    private int fromnum;

    public int getSlotno() {
        return slotno;
    }

    public void setSlotno(int slotno) {
        this.slotno = slotno;
    }

    public String getSlotname() {
        return slotname;
    }

    public void setSlotname(String slotname) {
        this.slotname = slotname;
    }

    public int getFromnum() {
        return fromnum;
    }

    public void setFromnum(int fromnum) {
        this.fromnum = fromnum;
    }

    public static class INFO {
        private String sysname;
        private int fromsize;
        private int fromattrib;

        public String getSysname() {
            return sysname;
        }

        public void setSysname(String sysname) {
            this.sysname = sysname;
        }

        public int getFromsize() {
            return fromsize;
        }

        public void setFromsize(int fromsize) {
            this.fromsize = fromsize;
        }

        public int getFromattrib() {
            return fromattrib;
        }

        public void setFromattrib(int fromattrib) {
            this.fromattrib = fromattrib;
        }

        @Override
        public String toString() {
            return "INFO{" +
                    "sysname=" + sysname +
                    ", fromsize=" + fromsize +
                    ", fromattrib=" + fromattrib +
                    '}';
        }
    }
    private INFO info[];

    public INFO[] getInfo() {
        return info;
    }

    public void setInfo(INFO[] info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "ODBFINFORM{" +
                "slotno=" + slotno +
                ", slotname=" + slotname +
                ", fromnum=" + fromnum +
                ", info=" + Arrays.toString(info) +
                '}';
    }
}
