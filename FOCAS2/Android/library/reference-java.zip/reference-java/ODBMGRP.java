package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMGRP {
    private int m_code;
    private short grp_no;
    private String m_name;
    private byte dummy;

    public int getM_code() {
        return m_code;
    }

    public void setM_code(int m_code) {
        this.m_code = m_code;
    }

    public short getGrp_no() {
        return grp_no;
    }

    public void setGrp_no(short grp_no) {
        this.grp_no = grp_no;
    }


    public String getM_name() {
        return m_name;
    }

    public void setM_name(String m_name) {
        this.m_name = m_name;
    }

    public byte getDummy() {
        return dummy;
    }

    public void setDummy(byte dummy) {
        this.dummy = dummy;
    }

    @Override

    public String toString() {
        return "ODBMGRP{" +
                "m_code=" + m_code +
                ", grp_no=" + grp_no +
                ", m_name=" + m_name +
                ", dummy=" + dummy +
                '}';
    }

    public void Dispose() {
        m_name = null;
    }
}
