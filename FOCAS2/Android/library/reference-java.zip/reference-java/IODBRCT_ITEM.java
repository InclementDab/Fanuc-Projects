package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBRCT_ITEM {
    private short  item_num;
    private char   type ;
    private char   axsp_num ;
    private char   ptn_num ;
    private char   dummy ;
    private short  attr ;

    public short getItem_num() {
        return item_num;
    }

    public void setItem_num(short item_num) {
        this.item_num = item_num;
    }

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }

    public char getAxsp_num() {
        return axsp_num;
    }

    public void setAxsp_num(char axsp_num) {
        this.axsp_num = axsp_num;
    }

    public char getPtn_num() {
        return ptn_num;
    }

    public void setPtn_num(char ptn_num) {
        this.ptn_num = ptn_num;
    }

    public char getDummy() {
        return dummy;
    }

    public void setDummy(char dummy) {
        this.dummy = dummy;
    }

    public short getAttr() {
        return attr;
    }

    public void setAttr(short attr) {
        this.attr = attr;
    }

    public static class DATA_INFO {
        private char enable;
        private char dummy2[];

        public char getEnable() {
            return enable;
        }

        public void setEnable(char enable) {
            this.enable = enable;
        }

        public char[] getDummy2() {
            return dummy2;
        }

        public void setDummy2(char[] dummy2) {
            this.dummy2 = dummy2;
        }

        public static class UPARAM {
            private char    bdata ;
            private char    cdata ;
            private short   idata ;
            private int    ldata ;
            private REALPRM rdata ;
            private char    bdatas[] ;
            private char    cdatas[] ;
            private short   idatas[] ;
            private int    ldatas[] ;
            private REALPRM rdatas[] ;

            public char getBdata() {
                return bdata;
            }

            public void setBdata(char bdata) {
                this.bdata = bdata;
            }

            public char getCdata() {
                return cdata;
            }

            public void setCdata(char cdata) {
                this.cdata = cdata;
            }

            public short getIdata() {
                return idata;
            }

            public void setIdata(short idata) {
                this.idata = idata;
            }

            public int getLdata() {
                return ldata;
            }

            public void setLdata(int ldata) {
                this.ldata = ldata;
            }

            public REALPRM getRdata() {
                return rdata;
            }

            public void setRdata(REALPRM rdata) {
                this.rdata = rdata;
            }

            public char[] getBdatas() {
                return bdatas;
            }

            public void setBdatas(char[] bdatas) {
                this.bdatas = bdatas;
            }

            public char[] getCdatas() {
                return cdatas;
            }

            public void setCdatas(char[] cdatas) {
                this.cdatas = cdatas;
            }

            public short[] getIdatas() {
                return idatas;
            }

            public void setIdatas(short[] idatas) {
                this.idatas = idatas;
            }

            public int[] getLdatas() {
                return ldatas;
            }

            public void setLdatas(int[] ldatas) {
                this.ldatas = ldatas;
            }

            public REALPRM[] getRdatas() {
                return rdatas;
            }

            public void setRdatas(REALPRM[] rdatas) {
                this.rdatas = rdatas;
            }

            @Override
            public String toString() {
                return "UPARAM{" +
                        "bdata=" + bdata +
                        ", cdata=" + cdata +
                        ", idata=" + idata +
                        ", ldata=" + ldata +
                        ", rdata=" + rdata +
                        ", bdatas=" + Arrays.toString(bdatas) +
                        ", cdatas=" + Arrays.toString(cdatas) +
                        ", idatas=" + Arrays.toString(idatas) +
                        ", ldatas=" + Arrays.toString(ldatas) +
                        ", rdatas=" + Arrays.toString(rdatas) +
                        '}';
            }
        }
        private UPARAM uparam;

        public UPARAM getUparam() {
            return uparam;
        }

        public void setUparam(UPARAM uparam) {
            this.uparam = uparam;
        }

        @Override
        public String toString() {
            return "DATA_INFO{" +
                    "enable=" + enable +
                    ", dummy2=" + Arrays.toString(dummy2) +
                    ", uparam=" + uparam +
                    '}';
        }
    }
    private DATA_INFO ptn[];

    public DATA_INFO[] getPtn() {
        return ptn;
    }

    public void setPtn(DATA_INFO[] ptn) {
        this.ptn = ptn;
    }

    @Override
    public String toString() {
        return "IODBRCT_ITEM{" +
                "item_num=" + item_num +
                ", type=" + type +
                ", axsp_num=" + axsp_num +
                ", ptn_num=" + ptn_num +
                ", dummy=" + dummy +
                ", attr=" + attr +
                ", ptn=" + Arrays.toString(ptn) +
                '}';
    }
}
