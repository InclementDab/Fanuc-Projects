package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBSLUPM {
    private short slave_num;
    private short axis_num[];
    private char axis_name[][];

    public short getSlave_num() {
        return slave_num;
    }

    public void setSlave_num(short slave_num) {
        this.slave_num = slave_num;
    }

    public short[] getAxis_num() {
        return axis_num;
    }

    public void setAxis_num(short[] axis_num) {
        this.axis_num = axis_num;
    }

    public char[][] getAxis_name() {
        return axis_name;
    }

    public void setAxis_name(char[][] axis_name) {
        this.axis_name = axis_name;
    }

    @Override
    public String toString() {
        return "ODBIFSBSLUPM{" +
                "slave_num=" + slave_num +
                ", axis_num=" + Arrays.toString(axis_num) +
                ", axis_name=" + Arrays.toString(axis_name) +
                '}';
    }
}
