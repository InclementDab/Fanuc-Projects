package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBDSSET {
    private char host_ip[];
    private char host_uname[];
    private char host_passwd[];
    private char host_dir[];
    private char dtsv_mac[];
    private char dtsv_ip[];
    private char dtsv_mask[];

    public char[] getHost_ip() {
        return host_ip;
    }

    public void setHost_ip(char[] host_ip) {
        this.host_ip = host_ip;
    }

    public char[] getHost_uname() {
        return host_uname;
    }

    public void setHost_uname(char[] host_uname) {
        this.host_uname = host_uname;
    }

    public char[] getHost_passwd() {
        return host_passwd;
    }

    public void setHost_passwd(char[] host_passwd) {
        this.host_passwd = host_passwd;
    }

    public char[] getHost_dir() {
        return host_dir;
    }

    public void setHost_dir(char[] host_dir) {
        this.host_dir = host_dir;
    }

    public char[] getDtsv_mac() {
        return dtsv_mac;
    }

    public void setDtsv_mac(char[] dtsv_mac) {
        this.dtsv_mac = dtsv_mac;
    }

    public char[] getDtsv_ip() {
        return dtsv_ip;
    }

    public void setDtsv_ip(char[] dtsv_ip) {
        this.dtsv_ip = dtsv_ip;
    }

    public char[] getDtsv_mask() {
        return dtsv_mask;
    }

    public void setDtsv_mask(char[] dtsv_mask) {
        this.dtsv_mask = dtsv_mask;
    }

    @Override
    public String toString() {
        return "IODBDSSET{" +
                "host_ip=" + Arrays.toString(host_ip) +
                ", host_uname=" + Arrays.toString(host_uname) +
                ", host_passwd=" + Arrays.toString(host_passwd) +
                ", host_dir=" + Arrays.toString(host_dir) +
                ", dtsv_mac=" + Arrays.toString(dtsv_mac) +
                ", dtsv_ip=" + Arrays.toString(dtsv_ip) +
                ", dtsv_mask=" + Arrays.toString(dtsv_mask) +
                '}';
    }
}
