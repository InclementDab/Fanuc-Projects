package jp.co.fanuc.fwlibe1;


public class ODBCMD {
    private byte adrs;
    private byte num;
    private short flag;
    private int cmd_val;
    private int dec_val;

    public byte getAdrs() {
        return adrs;
    }

    public void setAdrs(byte adrs) {
        this.adrs = adrs;
    }

    public byte getNum() {
        return num;
    }

    public void setNum(byte num) {
        this.num = num;
    }

    public short getFlag() {
        return flag;
    }

    public void setFlag(short flag) {
        this.flag = flag;
    }

    public int getCmd_val() {
        return cmd_val;
    }

    public void setCmd_val(int cmd_val) {
        this.cmd_val = cmd_val;
    }

    public int getDec_val() {
        return dec_val;
    }

    public void setDec_val(int dec_val) {
        this.dec_val = dec_val;
    }

    @Override
    public String toString() {
        return "ODBCMD{" +
                "adrs=" + adrs +
                ", num=" + num +
                ", flag=" + flag +
                ", cmd_val=" + cmd_val +
                ", dec_val=" + dec_val +
                '}';
    }
}
