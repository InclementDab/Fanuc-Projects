package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTGI3 {
    private short s_grp;
    private short dummy;
    private short e_grp;
    private int life_rest[];

    public short getS_grp() {
        return s_grp;
    }

    public void setS_grp(short s_grp) {
        this.s_grp = s_grp;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public short getE_grp() {

        return e_grp;
    }

    public void setE_grp(short e_grp) {
        this.e_grp = e_grp;
    }

    public int[] getLife_rest() {

        return life_rest;
    }

    public void setLife_rest(int[] life_rest) {
        this.life_rest = life_rest;
    }

    @Override
    public String toString() {
        return "IODBTGI3{" +
                "s_grp=" + s_grp +
                ", dummy=" + dummy +
                ", e_grp=" + e_grp +
                ", life_rest=" + Arrays.toString(life_rest) +
                '}';
    }

    public void Dispose() {
        life_rest = null;
    }
}
