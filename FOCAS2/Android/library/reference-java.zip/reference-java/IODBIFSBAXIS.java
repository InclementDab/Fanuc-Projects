package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBIFSBAXIS {
    private short axis_num;
    private char axis_name[];
    private short line;
    private char amp_name[];
    private short pm[];
    private short cs;
    private short tndm;

    public short getAxis_num() {
        return axis_num;
    }

    public void setAxis_num(short axis_num) {
        this.axis_num = axis_num;
    }

    public char[] getAxis_name() {
        return axis_name;
    }

    public void setAxis_name(char[] axis_name) {
        this.axis_name = axis_name;
    }

    public short getLine() {
        return line;
    }

    public void setLine(short line) {
        this.line = line;
    }

    public char[] getAmp_name() {
        return amp_name;
    }

    public void setAmp_name(char[] amp_name) {
        this.amp_name = amp_name;
    }

    public short[] getPm() {
        return pm;
    }

    public void setPm(short[] pm) {
        this.pm = pm;
    }

    public short getCs() {
        return cs;
    }

    public void setCs(short cs) {
        this.cs = cs;
    }

    public short getTndm() {
        return tndm;
    }

    public void setTndm(short tndm) {
        this.tndm = tndm;
    }

    @Override
    public String toString() {
        return "IODBIFSBAXIS{" +
                "axis_num=" + axis_num +
                ", axis_name=" + Arrays.toString(axis_name) +
                ", line=" + line +
                ", amp_name=" + Arrays.toString(amp_name) +
                ", pm=" + Arrays.toString(pm) +
                ", cs=" + cs +
                ", tndm=" + tndm +
                '}';
    }
}
