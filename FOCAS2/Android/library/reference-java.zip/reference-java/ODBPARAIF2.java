package jp.co.fanuc.fwlibe1;


public class ODBPARAIF2 {
    private short prm_no;
    private short size;
    private short array;
    private short unit;
    private short dim;
    private short input;
    private short display;
    private short others;

    public short getPrm_no() {
        return prm_no;
    }

    public void setPrm_no(short prm_no) {
        this.prm_no = prm_no;
    }

    public short getSize() {
        return size;
    }

    public void setSize(short size) {
        this.size = size;
    }

    public short getArray() {
        return array;
    }

    public void setArray(short array) {
        this.array = array;
    }

    public short getUnit() {
        return unit;
    }

    public void setUnit(short unit) {
        this.unit = unit;
    }

    public short getDim() {
        return dim;
    }

    public void setDim(short dim) {
        this.dim = dim;
    }

    public short getInput() {
        return input;
    }

    public void setInput(short input) {
        this.input = input;
    }

    public short getDisplay() {
        return display;
    }

    public void setDisplay(short display) {
        this.display = display;
    }

    public short getOthers() {
        return others;
    }

    public void setOthers(short others) {
        this.others = others;
    }

    @Override
    public String toString() {
        return "ODBPARAIF2{" +
                "prm_no=" + prm_no +
                ", size=" + size +
                ", array=" + array +
                ", unit=" + unit +
                ", dim=" + dim +
                ", input=" + input +
                ", display=" + display +
                ", others=" + others +
                '}';
    }
}
