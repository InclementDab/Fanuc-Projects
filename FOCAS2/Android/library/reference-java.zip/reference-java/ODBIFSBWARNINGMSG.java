package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBWARNINGMSG {
    private short line;
    private short slv_src;
    private short slv_dst;
    private short type;
    private char wm_typ[];
    private char wm_pnt[];

    public short getLine() {
        return line;
    }

    public void setLine(short line) {
        this.line = line;
    }

    public short getSlv_src() {
        return slv_src;
    }

    public void setSlv_src(short slv_src) {
        this.slv_src = slv_src;
    }

    public short getSlv_dst() {
        return slv_dst;
    }

    public void setSlv_dst(short slv_dst) {
        this.slv_dst = slv_dst;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public char[] getWm_typ() {
        return wm_typ;
    }

    public void setWm_typ(char[] wm_typ) {
        this.wm_typ = wm_typ;
    }

    public char[] getWm_pnt() {
        return wm_pnt;
    }

    public void setWm_pnt(char[] wm_pnt) {
        this.wm_pnt = wm_pnt;
    }

    @Override
    public String toString() {
        return "ODBIFSBWARNINGMSG{" +
                "line=" + line +
                ", slv_src=" + slv_src +
                ", slv_dst=" + slv_dst +
                ", type=" + type +
                ", wm_typ=" + Arrays.toString(wm_typ) +
                ", wm_pnt=" + Arrays.toString(wm_pnt) +
                '}';
    }
}
