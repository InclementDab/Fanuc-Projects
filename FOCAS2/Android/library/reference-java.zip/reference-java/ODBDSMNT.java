package jp.co.fanuc.fwlibe1;


public class ODBDSMNT {
    private int empty_cnt;
    private int total_size;
    private int read_ptr;
    private int write_ptr;

    public int getEmpty_cnt() {
        return empty_cnt;
    }

    public void setEmpty_cnt(int empty_cnt) {
        this.empty_cnt = empty_cnt;
    }

    public int getTotal_size() {
        return total_size;
    }

    public void setTotal_size(int total_size) {
        this.total_size = total_size;
    }

    public int getRead_ptr() {
        return read_ptr;
    }

    public void setRead_ptr(int read_ptr) {
        this.read_ptr = read_ptr;
    }

    public int getWrite_ptr() {
        return write_ptr;
    }

    public void setWrite_ptr(int write_ptr) {
        this.write_ptr = write_ptr;
    }

    @Override
    public String toString() {
        return "ODBDSMNT{" +
                "empty_cnt=" + empty_cnt +
                ", total_size=" + total_size +
                ", read_ptr=" + read_ptr +
                ", write_ptr=" + write_ptr +
                '}';
    }
}
