package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBFSSBMT {
    private short axis_num;
    private short reserve;
    private char axis_name[];
    private char amp_name[];
    private char amp_seires[];
    private char amp_unit[];
    private char amp_cur;
    private char amp_edt;
    private short amp_axis_num;
    private short test_year;
    private short test_month;
    private short test_day;
    private short amp_mainte;

    public short getAxis_num() {
        return axis_num;
    }

    public void setAxis_num(short axis_num) {
        this.axis_num = axis_num;
    }

    public short getReserve() {
        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    public char[] getAxis_name() {
        return axis_name;
    }

    public void setAxis_name(char[] axis_name) {
        this.axis_name = axis_name;
    }

    public char[] getAmp_name() {
        return amp_name;
    }

    public void setAmp_name(char[] amp_name) {
        this.amp_name = amp_name;
    }

    public char[] getAmp_seires() {
        return amp_seires;
    }

    public void setAmp_seires(char[] amp_seires) {
        this.amp_seires = amp_seires;
    }

    public char[] getAmp_unit() {
        return amp_unit;
    }

    public void setAmp_unit(char[] amp_unit) {
        this.amp_unit = amp_unit;
    }

    public char getAmp_cur() {
        return amp_cur;
    }

    public void setAmp_cur(char amp_cur) {
        this.amp_cur = amp_cur;
    }

    public char getAmp_edt() {
        return amp_edt;
    }

    public void setAmp_edt(char amp_edt) {
        this.amp_edt = amp_edt;
    }

    public short getAmp_axis_num() {
        return amp_axis_num;
    }

    public void setAmp_axis_num(short amp_axis_num) {
        this.amp_axis_num = amp_axis_num;
    }

    public short getTest_year() {
        return test_year;
    }

    public void setTest_year(short test_year) {
        this.test_year = test_year;
    }

    public short getTest_month() {
        return test_month;
    }

    public void setTest_month(short test_month) {
        this.test_month = test_month;
    }

    public short getTest_day() {
        return test_day;
    }

    public void setTest_day(short test_day) {
        this.test_day = test_day;
    }

    public short getAmp_mainte() {
        return amp_mainte;
    }

    public void setAmp_mainte(short amp_mainte) {
        this.amp_mainte = amp_mainte;
    }

    @Override
    public String toString() {
        return "ODBFSSBMT{" +
                "axis_num=" + axis_num +
                ", reserve=" + reserve +
                ", axis_name=" + Arrays.toString(axis_name) +
                ", amp_name=" + Arrays.toString(amp_name) +
                ", amp_seires=" + Arrays.toString(amp_seires) +
                ", amp_unit=" + Arrays.toString(amp_unit) +
                ", amp_cur=" + amp_cur +
                ", amp_edt=" + amp_edt +
                ", amp_axis_num=" + amp_axis_num +
                ", test_year=" + test_year +
                ", test_month=" + test_month +
                ", test_day=" + test_day +
                ", amp_mainte=" + amp_mainte +
                '}';
    }
}
