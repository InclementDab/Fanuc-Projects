package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class DNS_IDENTITY_INFO {
    private short  VenderID;
    private short  DeviceType;
    private short  ProductCode;
    private char   MajorRev;
    private char   MinorRev;
    private int    SerialNo;
    private char   ProductName[];
    private char   pad[];

    public short getVenderID() {
        return VenderID;
    }

    public void setVenderID(short venderID) {
        VenderID = venderID;
    }

    public short getDeviceType() {
        return DeviceType;
    }

    public void setDeviceType(short deviceType) {
        DeviceType = deviceType;
    }

    public short getProductCode() {
        return ProductCode;
    }

    public void setProductCode(short productCode) {
        ProductCode = productCode;
    }

    public char getMajorRev() {
        return MajorRev;
    }

    public void setMajorRev(char majorRev) {
        MajorRev = majorRev;
    }

    public char getMinorRev() {
        return MinorRev;
    }

    public void setMinorRev(char minorRev) {
        MinorRev = minorRev;
    }

    public int getSerialNo() {
        return SerialNo;
    }

    public void setSerialNo(int serialNo) {
        SerialNo = serialNo;
    }

    public char[] getProductName() {
        return ProductName;
    }

    public void setProductName(char[] productName) {
        ProductName = productName;
    }

    public char[] getPad() {
        return pad;
    }

    public void setPad(char[] pad) {
        this.pad = pad;
    }

    @Override
    public String toString() {
        return "DNS_IDENTITY_INFO{" +
                "VenderID=" + VenderID +
                ", DeviceType=" + DeviceType +
                ", ProductCode=" + ProductCode +
                ", MajorRev=" + MajorRev +
                ", MinorRev=" + MinorRev +
                ", SerialNo=" + SerialNo +
                ", ProductName=" + Arrays.toString(ProductName) +
                ", pad=" + Arrays.toString(pad) +
                '}';
    }
}
