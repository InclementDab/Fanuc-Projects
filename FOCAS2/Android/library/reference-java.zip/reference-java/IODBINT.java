package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBINT {
    private short datano_s;
    private short type;
    private short datano_e;
    private int data[];

    public short getDatano_s() {
        return datano_s;
    }

    public void setDatano_s(short datano_s) {
        this.datano_s = datano_s;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getDatano_e() {
        return datano_e;
    }

    public void setDatano_e(short datano_e) {
        this.datano_e = datano_e;
    }

    public int[] getData() {
        return data;
    }

    public void setData(int[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBINT{" +
                "datano_s=" + datano_s +
                ", type=" + type +
                ", datano_e=" + datano_e +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
