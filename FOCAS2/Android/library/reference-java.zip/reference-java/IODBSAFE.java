package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBSAFE {
    private short slct;
    private int data[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public int[] getData() {
        return data;
    }

    public void setData(int[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBSAFE{" +
                "slct=" + slct +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
