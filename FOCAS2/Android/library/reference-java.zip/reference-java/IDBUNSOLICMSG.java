package jp.co.fanuc.fwlibe1;


import java.nio.ByteBuffer;

public class IDBUNSOLICMSG {
    private short getno;

    public short getGetno() {
        return getno;
    }

    public void setGetno(short getno) {
        this.getno = getno;
    }

    public static class MSG {
        private short rdsize;
        private ByteBuffer data;

        public short getRdsize() {
            return rdsize;
        }

        public void setRdsize(short rdsize) {
            this.rdsize = rdsize;
        }

        public ByteBuffer getData() {
            return data;
        }

        public void setData(ByteBuffer data) {
            this.data = data;
        }

        @Override
        public String toString() {
            return "MSG{" +
                    "rdsize=" + rdsize +
                    ", data=" + data +
                    '}';
        }
    }
    private MSG msg;

    public MSG getMsg() {
        return msg;
    }

    public void setMsg(MSG msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "IDBUNSOLICMSG{" +
                "getno=" + getno +
                ", msg=" + msg +
                '}';
    }
}
