package jp.co.fanuc.fwlibe1;


public class ODBPDFNFIL {
    private short dir_num;
    private short file_num;

    public short getDir_num() {
        return dir_num;
    }

    public void setDir_num(short dir_num) {
        this.dir_num = dir_num;
    }

    public short getFile_num() {

        return file_num;
    }

    public void setFile_num(short file_num) {
        this.file_num = file_num;
    }

    @Override
    public String toString() {
        return "ODBPDFNFIL{" +
                "dir_num=" + dir_num +
                ", file_num=" + file_num +
                '}';
    }
}
