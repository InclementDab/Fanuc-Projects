package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBMNTSP {
    private short spdl_num;
    private char spdl_name[];
    private short line;
    private char amp_name[];
    private char amp_series[];
    private char amp_pwr[];
    private char amp_edt[];
    private short amp_spdl_num;
    private char amp_spec_num[];
    private char amp_serial_num[];

    public short getSpdl_num() {
        return spdl_num;
    }

    public void setSpdl_num(short spdl_num) {
        this.spdl_num = spdl_num;
    }

    public char[] getSpdl_name() {
        return spdl_name;
    }

    public void setSpdl_name(char[] spdl_name) {
        this.spdl_name = spdl_name;
    }

    public short getLine() {
        return line;
    }

    public void setLine(short line) {
        this.line = line;
    }

    public char[] getAmp_name() {
        return amp_name;
    }

    public void setAmp_name(char[] amp_name) {
        this.amp_name = amp_name;
    }

    public char[] getAmp_series() {
        return amp_series;
    }

    public void setAmp_series(char[] amp_series) {
        this.amp_series = amp_series;
    }

    public char[] getAmp_pwr() {
        return amp_pwr;
    }

    public void setAmp_pwr(char[] amp_pwr) {
        this.amp_pwr = amp_pwr;
    }

    public char[] getAmp_edt() {
        return amp_edt;
    }

    public void setAmp_edt(char[] amp_edt) {
        this.amp_edt = amp_edt;
    }

    public short getAmp_spdl_num() {
        return amp_spdl_num;
    }

    public void setAmp_spdl_num(short amp_spdl_num) {
        this.amp_spdl_num = amp_spdl_num;
    }

    public char[] getAmp_spec_num() {
        return amp_spec_num;
    }

    public void setAmp_spec_num(char[] amp_spec_num) {
        this.amp_spec_num = amp_spec_num;
    }

    public char[] getAmp_serial_num() {
        return amp_serial_num;
    }

    public void setAmp_serial_num(char[] amp_serial_num) {
        this.amp_serial_num = amp_serial_num;
    }

    @Override
    public String toString() {
        return "ODBIFSBMNTSP{" +
                "spdl_num=" + spdl_num +
                ", spdl_name=" + Arrays.toString(spdl_name) +
                ", line=" + line +
                ", amp_name=" + Arrays.toString(amp_name) +
                ", amp_series=" + Arrays.toString(amp_series) +
                ", amp_pwr=" + Arrays.toString(amp_pwr) +
                ", amp_edt=" + Arrays.toString(amp_edt) +
                ", amp_spdl_num=" + amp_spdl_num +
                ", amp_spec_num=" + Arrays.toString(amp_spec_num) +
                ", amp_serial_num=" + Arrays.toString(amp_serial_num) +
                '}';
    }
}
