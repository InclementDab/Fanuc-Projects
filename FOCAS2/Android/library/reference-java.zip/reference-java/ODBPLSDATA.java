package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBPLSDATA {
    private short	pulse_type;
    private short	channel_state;
    private short	reserve1;
    private short	reserve2;
    private short	alarm[];
    private short	cmd_val[];
    private short	reserve3[];
    private int	total_val[];
    private int	reserve4[];

    public short getPulse_type() {
        return pulse_type;
    }

    public void setPulse_type(short pulse_type) {
        this.pulse_type = pulse_type;
    }

    public short getChannel_state() {
        return channel_state;
    }

    public void setChannel_state(short channel_state) {
        this.channel_state = channel_state;
    }

    public short getReserve1() {
        return reserve1;
    }

    public void setReserve1(short reserve1) {
        this.reserve1 = reserve1;
    }

    public short getReserve2() {
        return reserve2;
    }

    public void setReserve2(short reserve2) {
        this.reserve2 = reserve2;
    }

    public short[] getAlarm() {
        return alarm;
    }

    public void setAlarm(short[] alarm) {
        this.alarm = alarm;
    }

    public short[] getCmd_val() {
        return cmd_val;
    }

    public void setCmd_val(short[] cmd_val) {
        this.cmd_val = cmd_val;
    }

    public short[] getReserve3() {
        return reserve3;
    }

    public void setReserve3(short[] reserve3) {
        this.reserve3 = reserve3;
    }

    public int[] getTotal_val() {
        return total_val;
    }

    public void setTotal_val(int[] total_val) {
        this.total_val = total_val;
    }

    public int[] getReserve4() {
        return reserve4;
    }

    public void setReserve4(int[] reserve4) {
        this.reserve4 = reserve4;
    }

    @Override
    public String toString() {
        return "ODBPLSDATA{" +
                "pulse_type=" + pulse_type +
                ", channel_state=" + channel_state +
                ", reserve1=" + reserve1 +
                ", reserve2=" + reserve2 +
                ", alarm=" + Arrays.toString(alarm) +
                ", cmd_val=" + Arrays.toString(cmd_val) +
                ", reserve3=" + Arrays.toString(reserve3) +
                ", total_val=" + Arrays.toString(total_val) +
                ", reserve4=" + Arrays.toString(reserve4) +
                '}';
    }
}
