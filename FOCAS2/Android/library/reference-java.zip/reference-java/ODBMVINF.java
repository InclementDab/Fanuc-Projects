package jp.co.fanuc.fwlibe1;


public class ODBMVINF {
    private short use_no1;
    private short use_no2;

    public short getUse_no1() {
        return use_no1;
    }

    public void setUse_no1(short use_no1) {
        this.use_no1 = use_no1;
    }

    public short getUse_no2() {

        return use_no2;
    }

    public void setUse_no2(short use_no2) {
        this.use_no2 = use_no2;
    }

    @Override
    public String toString() {
        return "ODBMVINF{" +
                "use_no1=" + use_no1 +
                ", use_no2=" + use_no2 +
                '}';
    }
}
