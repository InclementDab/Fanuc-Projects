package jp.co.fanuc.fwlibe1;


public class IODBPRFADR {
    private char di_size;
    private char di_type;
    private short di_addr;
    private short reserve1;
    private char do_size;
    private char do_type;
    private short do_addr;
    private short reserve2;
    private char dgn_size;
    private char dgn_type;
    private short dgn_addr;

    public char getDi_size() {
        return di_size;
    }

    public void setDi_size(char di_size) {
        this.di_size = di_size;
    }

    public char getDi_type() {
        return di_type;
    }

    public void setDi_type(char di_type) {
        this.di_type = di_type;
    }

    public short getDi_addr() {
        return di_addr;
    }

    public void setDi_addr(short di_addr) {
        this.di_addr = di_addr;
    }

    public short getReserve1() {
        return reserve1;
    }

    public void setReserve1(short reserve1) {
        this.reserve1 = reserve1;
    }

    public char getDo_size() {
        return do_size;
    }

    public void setDo_size(char do_size) {
        this.do_size = do_size;
    }

    public char getDo_type() {
        return do_type;
    }

    public void setDo_type(char do_type) {
        this.do_type = do_type;
    }

    public short getDo_addr() {
        return do_addr;
    }

    public void setDo_addr(short do_addr) {
        this.do_addr = do_addr;
    }

    public short getReserve2() {
        return reserve2;
    }

    public void setReserve2(short reserve2) {
        this.reserve2 = reserve2;
    }

    public char getDgn_size() {
        return dgn_size;
    }

    public void setDgn_size(char dgn_size) {
        this.dgn_size = dgn_size;
    }

    public char getDgn_type() {
        return dgn_type;
    }

    public void setDgn_type(char dgn_type) {
        this.dgn_type = dgn_type;
    }

    public short getDgn_addr() {
        return dgn_addr;
    }

    public void setDgn_addr(short dgn_addr) {
        this.dgn_addr = dgn_addr;
    }

    @Override
    public String toString() {
        return "IODBPRFADR{" +
                "di_size=" + di_size +
                ", di_type=" + di_type +
                ", di_addr=" + di_addr +
                ", reserve1=" + reserve1 +
                ", do_size=" + do_size +
                ", do_type=" + do_type +
                ", do_addr=" + do_addr +
                ", reserve2=" + reserve2 +
                ", dgn_size=" + dgn_size +
                ", dgn_type=" + dgn_type +
                ", dgn_addr=" + dgn_addr +
                '}';
    }
}
