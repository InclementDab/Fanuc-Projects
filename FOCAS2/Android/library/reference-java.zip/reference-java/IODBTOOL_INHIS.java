package jp.co.fanuc.fwlibe1;


public class IODBTOOL_INHIS {
    private short tool_no;
    private short reserve;
    IODBTOOL_DATE date;
    IODBTLMNG_F2 tool_f2;

    public short getTool_no() {
        return tool_no;
    }

    public void setTool_no(short tool_no) {
        this.tool_no = tool_no;
    }

    public short getReserve() {
        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    public IODBTOOL_DATE getDate() {
        return date;
    }

    public void setDate(IODBTOOL_DATE date) {
        this.date = date;
    }

    public IODBTLMNG_F2 getTool_f2() {
        return tool_f2;
    }

    public void setTool_f2(IODBTLMNG_F2 tool_f2) {
        this.tool_f2 = tool_f2;
    }

    @Override
    public String toString() {
        return "IODBTOOL_INHIS{" +
                "tool_no=" + tool_no +
                ", reserve=" + reserve +
                ", date=" + date +
                ", tool_f2=" + tool_f2 +
                '}';
    }
}
