package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBLAGST {
    public static class  GASFLOW {
        private short slct;
        private short pre_time;
        private short pre_press;
        private short proc_press;
        private short end_time;
        private short end_press;
        private short reserve[];

        public short getSlct() {
            return slct;
        }

        public void setSlct(short slct) {
            this.slct = slct;
        }

        public short getPre_time() {
            return pre_time;
        }

        public void setPre_time(short pre_time) {
            this.pre_time = pre_time;
        }

        public short getPre_press() {
            return pre_press;
        }

        public void setPre_press(short pre_press) {
            this.pre_press = pre_press;
        }

        public short getProc_press() {
            return proc_press;
        }

        public void setProc_press(short proc_press) {
            this.proc_press = proc_press;
        }

        public short getEnd_time() {
            return end_time;
        }

        public void setEnd_time(short end_time) {
            this.end_time = end_time;
        }

        public short getEnd_press() {
            return end_press;
        }

        public void setEnd_press(short end_press) {
            this.end_press = end_press;
        }

        public short[] getReserve() {
            return reserve;
        }

        public void setReserve(short[] reserve) {
            this.reserve = reserve;
        }

        @Override
        public String toString() {
            return "GASFLOW{" +
                    "slct=" + slct +
                    ", pre_time=" + pre_time +
                    ", pre_press=" + pre_press +
                    ", proc_press=" + proc_press +
                    ", end_time=" + end_time +
                    ", end_press=" + end_press +
                    ", reserve=" + Arrays.toString(reserve) +
                    '}';
        }
    }
    private GASFLOW gasflow[];

    public GASFLOW[] getGasflow() {
        return gasflow;
    }

    public void setGasflow(GASFLOW[] gasflow) {
        this.gasflow = gasflow;
    }

    @Override
    public String toString() {
        return "IODBLAGST{" +
                "gasflow=" + Arrays.toString(gasflow) +
                '}';
    }
}
