package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_DNMPRM_BUS2 {
    private short           Network;
    private short           BaudRate;
    private short           DiDataOnAbnormal;
    private short           OwnMacId;
    private PMC_REG         CommonStatus;
    private short           CommonStatusSize;
    private short           CycleTimeSetting;
    private short           reserved1[];
    private short           Option;
    private short           reserved2[];

    public short getNetwork() {
        return Network;
    }

    public void setNetwork(short network) {
        Network = network;
    }

    public short getBaudRate() {
        return BaudRate;
    }

    public void setBaudRate(short baudRate) {
        BaudRate = baudRate;
    }

    public short getDiDataOnAbnormal() {
        return DiDataOnAbnormal;
    }

    public void setDiDataOnAbnormal(short diDataOnAbnormal) {
        DiDataOnAbnormal = diDataOnAbnormal;
    }

    public short getOwnMacId() {
        return OwnMacId;
    }

    public void setOwnMacId(short ownMacId) {
        OwnMacId = ownMacId;
    }

    public PMC_REG getCommonStatus() {
        return CommonStatus;
    }

    public void setCommonStatus(PMC_REG commonStatus) {
        CommonStatus = commonStatus;
    }

    public short getCommonStatusSize() {
        return CommonStatusSize;
    }

    public void setCommonStatusSize(short commonStatusSize) {
        CommonStatusSize = commonStatusSize;
    }

    public short getCycleTimeSetting() {
        return CycleTimeSetting;
    }

    public void setCycleTimeSetting(short cycleTimeSetting) {
        CycleTimeSetting = cycleTimeSetting;
    }

    public short[] getReserved1() {
        return reserved1;
    }

    public void setReserved1(short[] reserved1) {
        this.reserved1 = reserved1;
    }

    public short getOption() {
        return Option;
    }

    public void setOption(short option) {
        Option = option;
    }

    public short[] getReserved2() {
        return reserved2;
    }

    public void setReserved2(short[] reserved2) {
        this.reserved2 = reserved2;
    }

    @Override
    public String toString() {
        return "IN_DNMPRM_BUS2{" +
                "Network=" + Network +
                ", BaudRate=" + BaudRate +
                ", DiDataOnAbnormal=" + DiDataOnAbnormal +
                ", OwnMacId=" + OwnMacId +
                ", CommonStatus=" + CommonStatus +
                ", CommonStatusSize=" + CommonStatusSize +
                ", CycleTimeSetting=" + CycleTimeSetting +
                ", reserved1=" + Arrays.toString(reserved1) +
                ", Option=" + Option +
                ", reserved2=" + Arrays.toString(reserved2) +
                '}';
    }
}
