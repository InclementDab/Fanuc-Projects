package jp.co.fanuc.fwlibe1;


public class ODBPDFADIR {
    private short data_kind;
    private short year;
    private short mon;
    private short day;
    private short hour;
    private short min;
    private short sec;
    private short dummy;
    private int dummy2;
    private int size;
    private int attr;
    private String d_f;
    private String comment;
    private String o_time;

    public short getData_kind() {
        return data_kind;
    }

    public void setData_kind(short data_kind) {
        this.data_kind = data_kind;
    }

    public short getYear() {

        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public short getMon() {

        return mon;
    }

    public void setMon(short mon) {
        this.mon = mon;
    }

    public short getDay() {

        return day;
    }

    public void setDay(short day) {
        this.day = day;
    }

    public short getHour() {

        return hour;
    }

    public void setHour(short hour) {
        this.hour = hour;
    }

    public short getMin() {

        return min;
    }

    public void setMin(short min) {
        this.min = min;
    }

    public short getSec() {

        return sec;
    }

    public void setSec(short sec) {
        this.sec = sec;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public int getDummy2() {

        return dummy2;
    }

    public void setDummy2(int dummy2) {
        this.dummy2 = dummy2;
    }

    public int getSize() {

        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getAttr() {

        return attr;
    }

    public void setAttr(int attr) {
        this.attr = attr;
    }

    public String getD_f() {

        return d_f;
    }

    public void setD_f(String d_f) {
        this.d_f = d_f;
    }

    public String getComment() {

        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getO_time() {

        return o_time;
    }

    public void setO_time(String o_time) {
        this.o_time = o_time;
    }

    @Override
    public String toString() {
        return "ODBPDFADIR{" +
                "data_kind=" + data_kind +
                ", year=" + year +
                ", mon=" + mon +
                ", day=" + day +
                ", hour=" + hour +
                ", min=" + min +
                ", sec=" + sec +
                ", dummy=" + dummy +
                ", dummy2=" + dummy2 +
                ", size=" + size +
                ", attr=" + attr +
                ", d_f=" + d_f +
                ", comment=" + comment +
                ", o_time=" + o_time +
                '}';
    }
}
