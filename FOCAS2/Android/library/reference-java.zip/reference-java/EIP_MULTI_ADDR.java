package jp.co.fanuc.fwlibe1;


public class EIP_MULTI_ADDR {
    public static class PRM {
        private EIP_UNUSE_ADDR Unuse;
        private EIP_PMC_ADDR Pmc;

        public EIP_UNUSE_ADDR getUnuse() {
            return Unuse;
        }

        public void setUnuse(EIP_UNUSE_ADDR unuse) {
            Unuse = unuse;
        }

        public EIP_PMC_ADDR getPmc() {
            return Pmc;
        }

        public void setPmc(EIP_PMC_ADDR pmc) {
            Pmc = pmc;
        }

        @Override
        public String toString() {
            return "PRM{" +
                    "Unuse=" + Unuse +
                    ", Pmc=" + Pmc +
                    '}';
        }
    }
    private PRM prm;

    public PRM getPrm() {
        return prm;
    }

    public void setPrm(PRM prm) {
        this.prm = prm;
    }

    @Override
    public String toString() {
        return "EIP_MULTI_ADDR{" +
                "prm=" + prm +
                '}';
    }
}
