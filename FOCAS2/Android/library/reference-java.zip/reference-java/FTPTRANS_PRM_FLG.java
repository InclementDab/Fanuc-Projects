package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class FTPTRANS_PRM_FLG {
    private FTP_CLIENT_PRM_FLG opposite[];

    public FTP_CLIENT_PRM_FLG[] getOpposite() {
        return opposite;
    }

    public void setOpposite(FTP_CLIENT_PRM_FLG[] opposite) {
        this.opposite = opposite;
    }

    @Override
    public String toString() {
        return "FTPTRANS_PRM_FLG{" +
                "opposite=" + Arrays.toString(opposite) +
                '}';
    }
}
