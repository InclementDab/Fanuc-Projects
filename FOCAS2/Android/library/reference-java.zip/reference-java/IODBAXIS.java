package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBAXIS {
    private int axnum;
    private int data[];
    private int dp[];

    public int getAxnum() {
        return axnum;
    }

    public void setAxnum(int axnum) {
        this.axnum = axnum;
    }

    public int[] getData() {
        return data;
    }

    public void setData(int[] data) {
        this.data = data;
    }

    public int[] getDp() {
        return dp;
    }

    public void setDp(int[] dp) {
        this.dp = dp;
    }

    @Override
    public String toString() {
        return "IODBAXIS{" +
                "axnum=" + axnum +
                ", data=" + Arrays.toString(data) +
                ", dp=" + Arrays.toString(dp) +
                '}';
    }
}
