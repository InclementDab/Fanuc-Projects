package jp.co.fanuc.fwlibe1;


public class ODBOPHIS {
    private short rec_len;
    private short rec_type;

    public short getRec_len() {
        return rec_len;
    }

    public void setRec_len(short rec_len) {
        this.rec_len = rec_len;
    }

    public short getRec_type() {
        return rec_type;
    }

    public void setRec_type(short rec_type) {
        this.rec_type = rec_type;
    }

    public static class REC_MDI {
        private char key_code;
        private char pw_flag;
        private short dummy;

        public char getKey_code() {
            return key_code;
        }

        public void setKey_code(char key_code) {
            this.key_code = key_code;
        }

        public char getPw_flag() {
            return pw_flag;
        }

        public void setPw_flag(char pw_flag) {
            this.pw_flag = pw_flag;
        }

        public short getDummy() {
            return dummy;
        }

        public void setDummy(short dummy) {
            this.dummy = dummy;
        }

        @Override
        public String toString() {
            return "REC_MDI{" +
                    "key_code=" + key_code +
                    ", pw_flag=" + pw_flag +
                    ", dummy=" + dummy +
                    '}';
        }
    }

    public static class REC_SGN {
        private short sig_name;
        private short sig_no;
        private char sig_old;
        private char sig_new;
        private short dummy;

        public short getSig_name() {
            return sig_name;
        }

        public void setSig_name(short sig_name) {
            this.sig_name = sig_name;
        }

        public short getSig_no() {
            return sig_no;
        }

        public void setSig_no(short sig_no) {
            this.sig_no = sig_no;
        }

        public char getSig_old() {
            return sig_old;
        }

        public void setSig_old(char sig_old) {
            this.sig_old = sig_old;
        }

        public char getSig_new() {
            return sig_new;
        }

        public void setSig_new(char sig_new) {
            this.sig_new = sig_new;
        }

        public short getDummy() {
            return dummy;
        }

        public void setDummy(short dummy) {
            this.dummy = dummy;
        }

        @Override
        public String toString() {
            return "REC_SGN{" +
                    "sig_name=" + sig_name +
                    ", sig_no=" + sig_no +
                    ", sig_old=" + sig_old +
                    ", sig_new=" + sig_new +
                    ", dummy=" + dummy +
                    '}';
        }
    }

    public static class REC_ALM {
        private short alm_grp;
        private short alm_no;
        private short axis_no;
        private short year;
        private short month;
        private short day;
        private short hour;
        private short minute;
        private short second;
        private short dummy;

        public short getAlm_grp() {
            return alm_grp;
        }

        public void setAlm_grp(short alm_grp) {
            this.alm_grp = alm_grp;
        }

        public short getAlm_no() {
            return alm_no;
        }

        public void setAlm_no(short alm_no) {
            this.alm_no = alm_no;
        }

        public short getAxis_no() {
            return axis_no;
        }

        public void setAxis_no(short axis_no) {
            this.axis_no = axis_no;
        }

        public short getYear() {
            return year;
        }

        public void setYear(short year) {
            this.year = year;
        }

        public short getMonth() {
            return month;
        }

        public void setMonth(short month) {
            this.month = month;
        }

        public short getDay() {
            return day;
        }

        public void setDay(short day) {
            this.day = day;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getDummy() {
            return dummy;
        }

        public void setDummy(short dummy) {
            this.dummy = dummy;
        }

        @Override
        public String toString() {
            return "REC_ALM{" +
                    "alm_grp=" + alm_grp +
                    ", alm_no=" + alm_no +
                    ", axis_no=" + axis_no +
                    ", year=" + year +
                    ", month=" + month +
                    ", day=" + day +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", dummy=" + dummy +
                    '}';
        }
    }

    public static class REC_DATE {
        private short evnt_type;
        private short year;
        private short month;
        private short day;
        private short hour;
        private short minute;
        private short second;
        private short dummy;

        public short getEvnt_type() {
            return evnt_type;
        }

        public void setEvnt_type(short evnt_type) {
            this.evnt_type = evnt_type;
        }

        public short getYear() {
            return year;
        }

        public void setYear(short year) {
            this.year = year;
        }

        public short getMonth() {
            return month;
        }

        public void setMonth(short month) {
            this.month = month;
        }

        public short getDay() {
            return day;
        }

        public void setDay(short day) {
            this.day = day;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getDummy() {
            return dummy;
        }

        public void setDummy(short dummy) {
            this.dummy = dummy;
        }

        @Override
        public String toString() {
            return "REC_DATE{" +
                    "evnt_type=" + evnt_type +
                    ", year=" + year +
                    ", month=" + month +
                    ", day=" + day +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", dummy=" + dummy +
                    '}';
        }
    }

    private REC_MDI rec_mdi;
    private REC_SGN rec_sgn;
    private REC_ALM rec_alm;
    private REC_DATE rec_date;

    public REC_MDI getRec_mdi() {
        return rec_mdi;
    }

    public void setRec_mdi(REC_MDI rec_mdi) {
        this.rec_mdi = rec_mdi;
    }

    public REC_SGN getRec_sgn() {
        return rec_sgn;
    }

    public void setRec_sgn(REC_SGN rec_sgn) {
        this.rec_sgn = rec_sgn;
    }

    public REC_ALM getRec_alm() {
        return rec_alm;
    }

    public void setRec_alm(REC_ALM rec_alm) {
        this.rec_alm = rec_alm;
    }

    public REC_DATE getRec_date() {
        return rec_date;
    }

    public void setRec_date(REC_DATE rec_date) {
        this.rec_date = rec_date;
    }

    @Override
    public String toString() {
        return "ODBOPHIS{" +
                "rec_len=" + rec_len +
                ", rec_type=" + rec_type +
                ", rec_mdi=" + rec_mdi +
                ", rec_sgn=" + rec_sgn +
                ", rec_alm=" + rec_alm +
                ", rec_date=" + rec_date +
                '}';
    }
}
