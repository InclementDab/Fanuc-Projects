package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBFIN {
    private short dummy;
    private char cdata[];

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public char[] getCdata() {
        return cdata;
    }

    public void setCdata(char[] cdata) {
        this.cdata = cdata;
    }

    @Override
    public String toString() {
        return "ODBFIN{" +
                "dummy=" + dummy +
                ", cdata=" + Arrays.toString(cdata) +
                '}';
    }
}
