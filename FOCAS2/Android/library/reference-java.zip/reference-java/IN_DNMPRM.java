package jp.co.fanuc.fwlibe1;


public class IN_DNMPRM {
    public static class PRM {
        private IN_DNMPRM_BUS bus;
        private IN_DNMPRM_SLAVE slave;

        public IN_DNMPRM_BUS getBus() {
            return bus;
        }

        public void setBus(IN_DNMPRM_BUS bus) {
            this.bus = bus;
        }

        public IN_DNMPRM_SLAVE getSlave() {
            return slave;
        }

        public void setSlave(IN_DNMPRM_SLAVE slave) {
            this.slave = slave;
        }

        @Override
        public String toString() {
            return "PRM{" +
                    "bus=" + bus +
                    ", slave=" + slave +
                    '}';
        }
    }
    private PRM prm;

    public PRM getPrm() {
        return prm;
    }

    public void setPrm(PRM prm) {
        this.prm = prm;
    }

    @Override
    public String toString() {
        return "IN_DNMPRM{" +
                "prm=" + prm +
                '}';
    }
}
