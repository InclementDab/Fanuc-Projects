package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBPLSMDL {
    private short ln_num;
    private short slave_num;
    private char name[];
    private char type[];
    private char pcb_id[];
    private char function[];

    public short getLn_num() {
        return ln_num;
    }

    public void setLn_num(short ln_num) {
        this.ln_num = ln_num;
    }

    public short getSlave_num() {
        return slave_num;
    }

    public void setSlave_num(short slave_num) {
        this.slave_num = slave_num;
    }

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public char[] getType() {
        return type;
    }

    public void setType(char[] type) {
        this.type = type;
    }

    public char[] getPcb_id() {
        return pcb_id;
    }

    public void setPcb_id(char[] pcb_id) {
        this.pcb_id = pcb_id;
    }

    public char[] getFunction() {
        return function;
    }

    public void setFunction(char[] function) {
        this.function = function;
    }

    @Override
    public String toString() {
        return "ODBPLSMDL{" +
                "ln_num=" + ln_num +
                ", slave_num=" + slave_num +
                ", name=" + Arrays.toString(name) +
                ", type=" + Arrays.toString(type) +
                ", pcb_id=" + Arrays.toString(pcb_id) +
                ", function=" + Arrays.toString(function) +
                '}';
    }
}
