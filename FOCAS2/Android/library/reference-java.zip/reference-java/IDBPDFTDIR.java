package jp.co.fanuc.fwlibe1;


public class IDBPDFTDIR {
    private int slct;
    private int attr;

    public int getSlct() {
        return slct;
    }

    public void setSlct(int slct) {
        this.slct = slct;
    }

    public int getAttr() {
        return attr;
    }

    public void setAttr(int attr) {
        this.attr = attr;
    }

    @Override
    public String toString() {
        return "IDBPDFTDIR{" +
                "slct=" + slct +
                ", attr=" + attr +
                '}';
    }
}
