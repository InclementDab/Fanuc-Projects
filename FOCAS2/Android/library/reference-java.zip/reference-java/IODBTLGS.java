package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTLGS {
    private int data1;
    private int data2;
    private char tooltype;
    private char install;
    private char toolname[];
    private char dummy;

    public int getData1() {
        return data1;
    }

    public void setData1(int data1) {
        this.data1 = data1;
    }

    public int getData2() {

        return data2;
    }

    public void setData2(int data2) {
        this.data2 = data2;
    }

    public char getTooltype() {

        return tooltype;
    }

    public void setTooltype(char tooltype) {
        this.tooltype = tooltype;
    }

    public char getInstall() {

        return install;
    }

    public void setInstall(char install) {
        this.install = install;
    }

    public char[] getToolname() {

        return toolname;
    }

    public void setToolname(char[] toolname) {
        this.toolname = toolname;
    }

    public char getDummy() {

        return dummy;
    }

    public void setDummy(char dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "IODBTLGS{" +
                "data1=" + data1 +
                ", data2=" + data2 +
                ", tooltype=" + tooltype +
                ", install=" + install +
                ", toolname=" + Arrays.toString(toolname) +
                ", dummy=" + dummy +
                '}';
    }
}
