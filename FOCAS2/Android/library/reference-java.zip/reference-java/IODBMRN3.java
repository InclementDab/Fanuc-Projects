package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBMRN3 {
    private double mcr_val;
    private String name;

    public double getMcr_val() {
        return mcr_val;
    }

    public void setMcr_val(double mcr_val) {
        this.mcr_val = mcr_val;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "IODBMRN3{" +
                "mcr_val=" + mcr_val +
                ", name=" + name +
                '}';
    }

    public void Dispose() {
        name = null;
    }
}
