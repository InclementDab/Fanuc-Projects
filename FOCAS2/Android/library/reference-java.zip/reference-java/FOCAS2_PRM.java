package jp.co.fanuc.fwlibe1;


public class FOCAS2_PRM {
    private int TcpPort;
    private int UdpPort;
    private int TimeInterval;

    public int getTcpPort() {
        return TcpPort;
    }

    public void setTcpPort(int tcpPort) {
        TcpPort = tcpPort;
    }

    public int getUdpPort() {
        return UdpPort;
    }

    public void setUdpPort(int udpPort) {
        UdpPort = udpPort;
    }

    public int getTimeInterval() {
        return TimeInterval;
    }

    public void setTimeInterval(int timeInterval) {
        TimeInterval = timeInterval;
    }

    @Override
    public String toString() {
        return "FOCAS2_PRM{" +
                "TcpPort=" + TcpPort +
                ", UdpPort=" + UdpPort +
                ", TimeInterval=" + TimeInterval +
                '}';
    }
}
