package jp.co.fanuc.fwlibe1;


public class IDBLPPFBFG {
    private short s_no;
    private short slct;
    private short s_freq;
    private short e_freq;
    private short s_duty;
    private short e_duty;

    public short getS_no() {
        return s_no;
    }

    public void setS_no(short s_no) {
        this.s_no = s_no;
    }

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getS_freq() {
        return s_freq;
    }

    public void setS_freq(short s_freq) {
        this.s_freq = s_freq;
    }

    public short getE_freq() {
        return e_freq;
    }

    public void setE_freq(short e_freq) {
        this.e_freq = e_freq;
    }

    public short getS_duty() {
        return s_duty;
    }

    public void setS_duty(short s_duty) {
        this.s_duty = s_duty;
    }

    public short getE_duty() {
        return e_duty;
    }

    public void setE_duty(short e_duty) {
        this.e_duty = e_duty;
    }

    @Override
    public String toString() {
        return "IDBLPPFBFG{" +
                "s_no=" + s_no +
                ", slct=" + slct +
                ", s_freq=" + s_freq +
                ", e_freq=" + e_freq +
                ", s_duty=" + s_duty +
                ", e_duty=" + e_duty +
                '}';
    }
}
