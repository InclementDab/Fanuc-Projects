package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBSLOP {
    private int slct;
    private int upleng;
    private short upsp[];
    private int dwleng;
    private short dwsp[];
    private char upleng_dec;
    private char dwleng_dec;
    private short reserve[];

    public int getSlct() {
        return slct;
    }

    public void setSlct(int slct) {
        this.slct = slct;
    }

    public int getUpleng() {
        return upleng;
    }

    public void setUpleng(int upleng) {
        this.upleng = upleng;
    }

    public short[] getUpsp() {
        return upsp;
    }

    public void setUpsp(short[] upsp) {
        this.upsp = upsp;
    }

    public int getDwleng() {
        return dwleng;
    }

    public void setDwleng(int dwleng) {
        this.dwleng = dwleng;
    }

    public short[] getDwsp() {
        return dwsp;
    }

    public void setDwsp(short[] dwsp) {
        this.dwsp = dwsp;
    }

    public char getUpleng_dec() {
        return upleng_dec;
    }

    public void setUpleng_dec(char upleng_dec) {
        this.upleng_dec = upleng_dec;
    }

    public char getDwleng_dec() {
        return dwleng_dec;
    }

    public void setDwleng_dec(char dwleng_dec) {
        this.dwleng_dec = dwleng_dec;
    }

    public short[] getReserve() {
        return reserve;
    }

    public void setReserve(short[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBSLOP{" +
                "slct=" + slct +
                ", upleng=" + upleng +
                ", upsp=" + Arrays.toString(upsp) +
                ", dwleng=" + dwleng +
                ", dwsp=" + Arrays.toString(dwsp) +
                ", upleng_dec=" + upleng_dec +
                ", dwleng_dec=" + dwleng_dec +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
