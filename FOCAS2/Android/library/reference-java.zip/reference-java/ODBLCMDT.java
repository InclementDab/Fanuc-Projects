package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBLCMDT {
    private short slct;
    private int feed;
    private short power;
    private short freq;
    private short duty;
    private short g_kind;
    private short g_ready_t;
    private short g_press;
    private short error;
    private int dsplc;
    private int error2;
    private char gap_axis;
    private char feed_dec;
    private char dsplc_dec;
    private char error2_dec;
    private short pb_power;
    private short reserve[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public int getFeed() {
        return feed;
    }

    public void setFeed(int feed) {
        this.feed = feed;
    }

    public short getPower() {
        return power;
    }

    public void setPower(short power) {
        this.power = power;
    }

    public short getFreq() {
        return freq;
    }

    public void setFreq(short freq) {
        this.freq = freq;
    }

    public short getDuty() {
        return duty;
    }

    public void setDuty(short duty) {
        this.duty = duty;
    }

    public short getG_kind() {
        return g_kind;
    }

    public void setG_kind(short g_kind) {
        this.g_kind = g_kind;
    }

    public short getG_ready_t() {
        return g_ready_t;
    }

    public void setG_ready_t(short g_ready_t) {
        this.g_ready_t = g_ready_t;
    }

    public short getG_press() {
        return g_press;
    }

    public void setG_press(short g_press) {
        this.g_press = g_press;
    }

    public short getError() {
        return error;
    }

    public void setError(short error) {
        this.error = error;
    }

    public int getDsplc() {
        return dsplc;
    }

    public void setDsplc(int dsplc) {
        this.dsplc = dsplc;
    }

    public int getError2() {
        return error2;
    }

    public void setError2(int error2) {
        this.error2 = error2;
    }

    public char getGap_axis() {
        return gap_axis;
    }

    public void setGap_axis(char gap_axis) {
        this.gap_axis = gap_axis;
    }

    public char getFeed_dec() {
        return feed_dec;
    }

    public void setFeed_dec(char feed_dec) {
        this.feed_dec = feed_dec;
    }

    public char getDsplc_dec() {
        return dsplc_dec;
    }

    public void setDsplc_dec(char dsplc_dec) {
        this.dsplc_dec = dsplc_dec;
    }

    public char getError2_dec() {
        return error2_dec;
    }

    public void setError2_dec(char error2_dec) {
        this.error2_dec = error2_dec;
    }

    public short getPb_power() {
        return pb_power;
    }

    public void setPb_power(short pb_power) {
        this.pb_power = pb_power;
    }

    public short[] getReserve() {
        return reserve;
    }

    public void setReserve(short[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "ODBLCMDT{" +
                "slct=" + slct +
                ", feed=" + feed +
                ", power=" + power +
                ", freq=" + freq +
                ", duty=" + duty +
                ", g_kind=" + g_kind +
                ", g_ready_t=" + g_ready_t +
                ", g_press=" + g_press +
                ", error=" + error +
                ", dsplc=" + dsplc +
                ", error2=" + error2 +
                ", gap_axis=" + gap_axis +
                ", feed_dec=" + feed_dec +
                ", dsplc_dec=" + dsplc_dec +
                ", error2_dec=" + error2_dec +
                ", pb_power=" + pb_power +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
