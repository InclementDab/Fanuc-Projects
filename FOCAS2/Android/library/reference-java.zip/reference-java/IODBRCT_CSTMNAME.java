package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBRCT_CSTMNAME {
    private short grp_num;
    private short dummy;
    private char grp_name[];
    private char ptn_name[][];

    public short getGrp_num() {
        return grp_num;
    }

    public void setGrp_num(short grp_num) {
        this.grp_num = grp_num;
    }

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public char[] getGrp_name() {
        return grp_name;
    }

    public void setGrp_name(char[] grp_name) {
        this.grp_name = grp_name;
    }

    public char[][] getPtn_name() {
        return ptn_name;
    }

    public void setPtn_name(char[][] ptn_name) {
        this.ptn_name = ptn_name;
    }

    @Override
    public String toString() {
        return "IODBRCT_CSTMNAME{" +
                "grp_num=" + grp_num +
                ", dummy=" + dummy +
                ", grp_name=" + Arrays.toString(grp_name) +
                ", ptn_name=" + Arrays.toString(ptn_name) +
                '}';
    }
}
