package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class DCSSVSPSTS {
    private char name[];
    private int dummy;
    private double ncdata;
    private double svspdata;

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public int getDummy() {
        return dummy;
    }

    public void setDummy(int dummy) {
        this.dummy = dummy;
    }

    public double getNcdata() {
        return ncdata;
    }

    public void setNcdata(double ncdata) {
        this.ncdata = ncdata;
    }

    public double getSvspdata() {
        return svspdata;
    }

    public void setSvspdata(double svspdata) {
        this.svspdata = svspdata;
    }

    @Override
    public String toString() {
        return "DCSSVSPSTS{" +
                "name=" + Arrays.toString(name) +
                ", dummy=" + dummy +
                ", ncdata=" + ncdata +
                ", svspdata=" + svspdata +
                '}';
    }
}
