package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBUNSOLICMSG2 {
    private short getnum;
    private char dummy[];
    private UNSOLICMSG_TYPE_MSG get[];

    public short getGetnum() {
        return getnum;
    }

    public void setGetnum(short getnum) {
        this.getnum = getnum;
    }

    public char[] getDummy() {
        return dummy;
    }

    public void setDummy(char[] dummy) {
        this.dummy = dummy;
    }

    public UNSOLICMSG_TYPE_MSG[] getGet() {
        return get;
    }

    public void setGet(UNSOLICMSG_TYPE_MSG[] get) {
        this.get = get;
    }

    @Override
    public String toString() {
        return "IDBUNSOLICMSG2{" +
                "getnum=" + getnum +
                ", dummy=" + Arrays.toString(dummy) +
                ", get=" + Arrays.toString(get) +
                '}';
    }
}
