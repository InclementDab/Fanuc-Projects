package jp.co.fanuc.fwlibe1;


public class NETSRV_PRM_FLG {
    private char HostName;
    private char Port;
    private char TimeInterval;
    private char UdpPeriod;
    private char MachineNumber;
    private char AcceptanceReply;
    private char ErrorReply;

    public char getHostName() {
        return HostName;
    }

    public void setHostName(char hostName) {
        HostName = hostName;
    }

    public char getPort() {
        return Port;
    }

    public void setPort(char port) {
        Port = port;
    }

    public char getTimeInterval() {
        return TimeInterval;
    }

    public void setTimeInterval(char timeInterval) {
        TimeInterval = timeInterval;
    }

    public char getUdpPeriod() {
        return UdpPeriod;
    }

    public void setUdpPeriod(char udpPeriod) {
        UdpPeriod = udpPeriod;
    }

    public char getMachineNumber() {
        return MachineNumber;
    }

    public void setMachineNumber(char machineNumber) {
        MachineNumber = machineNumber;
    }

    public char getAcceptanceReply() {
        return AcceptanceReply;
    }

    public void setAcceptanceReply(char acceptanceReply) {
        AcceptanceReply = acceptanceReply;
    }

    public char getErrorReply() {
        return ErrorReply;
    }

    public void setErrorReply(char errorReply) {
        ErrorReply = errorReply;
    }

    @Override
    public String toString() {
        return "NETSRV_PRM_FLG{" +
                "HostName=" + HostName +
                ", Port=" + Port +
                ", TimeInterval=" + TimeInterval +
                ", UdpPeriod=" + UdpPeriod +
                ", MachineNumber=" + MachineNumber +
                ", AcceptanceReply=" + AcceptanceReply +
                ", ErrorReply=" + ErrorReply +
                '}';
    }
}
