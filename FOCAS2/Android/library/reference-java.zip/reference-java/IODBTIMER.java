package jp.co.fanuc.fwlibe1;


public class IODBTIMER {
    private short type;
    private short dummy;

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }
        public static class DATE {
            private short year;
            private short month;
            private short date;

            public short getYear() {
                return year;
            }

            public void setYear(short year) {
                this.year = year;
            }

            public short getMonth() {
                return month;
            }

            public void setMonth(short month) {
                this.month = month;
            }

            public short getDate() {
                return date;
            }

            public void setDate(short date) {
                this.date = date;
            }

            @Override
            public String toString() {
                return "DATE{" +
                        "year=" + year +
                        ", month=" + month +
                        ", date=" + date +
                        '}';
            }
        }
        public static class TIME {
            private short hour;
            private short minute;
            private short second;

            public short getHour() {
                return hour;
            }

            public void setHour(short hour) {
                this.hour = hour;
            }

            public short getMinute() {
                return minute;
            }

            public void setMinute(short minute) {
                this.minute = minute;
            }

            public short getSecond() {
                return second;
            }

            public void setSecond(short second) {
                this.second = second;
            }

            @Override
            public String toString() {
                return "TIME{" +
                        "hour=" + hour +
                        ", minute=" + minute +
                        ", second=" + second +
                        '}';
            }
        }
        private DATE date;
        private TIME time;

        public DATE getDate() {
            return date;
        }

        public void setDate(DATE date) {
            this.date = date;
        }

        public TIME getTime() {
            return time;
        }

        public void setTime(TIME time) {
            this.time = time;
        }





    @Override
    public String toString() {
        return "IODBTIMER{" +
                "type=" + type +
                ", dummy=" + dummy +
                "date=" + date +
                ", time=" + time +
                '}';
    }
}
