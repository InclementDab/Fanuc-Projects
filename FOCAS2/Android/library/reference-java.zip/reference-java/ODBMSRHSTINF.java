package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMSRHSTINF {
    private short year;
    private char month;
    private char day;
    private char hour;
    private char minute;
    private char second;
    private char msu_num;
    private char path_num;
    private char pmc_num;
    private short nonsave;
    private char save_trigger;
    private char reserve[];

    public short getYear() {
        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public char getMonth() {
        return month;
    }

    public void setMonth(char month) {
        this.month = month;
    }

    public char getDay() {
        return day;
    }

    public void setDay(char day) {
        this.day = day;
    }

    public char getHour() {
        return hour;
    }

    public void setHour(char hour) {
        this.hour = hour;
    }

    public char getMinute() {
        return minute;
    }

    public void setMinute(char minute) {
        this.minute = minute;
    }

    public char getSecond() {
        return second;
    }

    public void setSecond(char second) {
        this.second = second;
    }

    public char getMsu_num() {
        return msu_num;
    }

    public void setMsu_num(char msu_num) {
        this.msu_num = msu_num;
    }

    public char getPath_num() {
        return path_num;
    }

    public void setPath_num(char path_num) {
        this.path_num = path_num;
    }

    public char getPmc_num() {
        return pmc_num;
    }

    public void setPmc_num(char pmc_num) {
        this.pmc_num = pmc_num;
    }

    public short getNonsave() {
        return nonsave;
    }

    public void setNonsave(short nonsave) {
        this.nonsave = nonsave;
    }

    public char getSave_trigger() {
        return save_trigger;
    }

    public void setSave_trigger(char save_trigger) {
        this.save_trigger = save_trigger;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "ODBMSRHSTINF{" +
                "year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", hour=" + hour +
                ", minute=" + minute +
                ", second=" + second +
                ", msu_num=" + msu_num +
                ", path_num=" + path_num +
                ", pmc_num=" + pmc_num +
                ", nonsave=" + nonsave +
                ", save_trigger=" + save_trigger +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
