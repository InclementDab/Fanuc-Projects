package jp.co.fanuc.fwlibe1;


public class IODBMNGTIME {
    private int life;
    private int total;

    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    @Override
    public String toString() {
        return "IODBMNGTIME{" +
                "life=" + life +
                ", total=" + total +
                '}';
    }
}
