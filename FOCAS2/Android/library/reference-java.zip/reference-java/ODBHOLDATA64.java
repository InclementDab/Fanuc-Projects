package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBHOLDATA64 {
    private double mes_val1[];
    private int mes_dp1[];
    private double mes_val2[];
    private int mes_dp2[];
    private double mes_val3;
    private int mes_dp3[];
    private char mes_axis[];
    private char mes_parl[];

    public double[] getMes_val1() {
        return mes_val1;
    }

    public void setMes_val1(double[] mes_val1) {
        this.mes_val1 = mes_val1;
    }

    public int[] getMes_dp1() {

        return mes_dp1;
    }

    public void setMes_dp1(int[] mes_dp1) {
        this.mes_dp1 = mes_dp1;
    }

    public double[] getMes_val2() {

        return mes_val2;
    }

    public void setMes_val2(double[] mes_val2) {
        this.mes_val2 = mes_val2;
    }

    public int[] getMes_dp2() {

        return mes_dp2;
    }

    public void setMes_dp2(int[] mes_dp2) {
        this.mes_dp2 = mes_dp2;
    }

    public double getMes_val3() {

        return mes_val3;
    }

    public void setMes_val3(double mes_val3) {
        this.mes_val3 = mes_val3;
    }

    public int[] getMes_dp3() {

        return mes_dp3;
    }

    public void setMes_dp3(int[] mes_dp3) {
        this.mes_dp3 = mes_dp3;
    }

    public char[] getMes_axis() {

        return mes_axis;
    }

    public void setMes_axis(char[] mes_axis) {
        this.mes_axis = mes_axis;
    }

    public char[] getMes_parl() {

        return mes_parl;
    }

    public void setMes_parl(char[] mes_parl) {
        this.mes_parl = mes_parl;
    }

    @Override
    public String toString() {
        return "ODBHOLDATA64{" +
                "mes_val1=" + Arrays.toString(mes_val1) +
                ", mes_dp1=" + Arrays.toString(mes_dp1) +
                ", mes_val2=" + Arrays.toString(mes_val2) +
                ", mes_dp2=" + Arrays.toString(mes_dp2) +
                ", mes_val3=" + mes_val3 +
                ", mes_dp3=" + Arrays.toString(mes_dp3) +
                ", mes_axis=" + Arrays.toString(mes_axis) +
                ", mes_parl=" + Arrays.toString(mes_parl) +
                '}';
    }
}
