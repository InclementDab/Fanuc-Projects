package jp.co.fanuc.fwlibe1;


public class IODBTLMNG_MU_EDGE_DATA {
    private int life_count;
    private int max_life;
    private int rest_life;
    private char life_stat;
    private char cust_bits;
    private short reserve_s;
    private short H_code;
    private short D_code;
    private int spindle_speed;
    private int feedrate;
    private short G_code;
    private short W_code;
    private int custom1;
    private int custom2;
    private int custom3;
    private int custom4;

    public int getLife_count() {
        return life_count;
    }

    public void setLife_count(int life_count) {
        this.life_count = life_count;
    }

    public int getMax_life() {
        return max_life;
    }

    public void setMax_life(int max_life) {
        this.max_life = max_life;
    }

    public int getRest_life() {
        return rest_life;
    }

    public void setRest_life(int rest_life) {
        this.rest_life = rest_life;
    }

    public char getLife_stat() {
        return life_stat;
    }

    public void setLife_stat(char life_stat) {
        this.life_stat = life_stat;
    }

    public char getCust_bits() {
        return cust_bits;
    }

    public void setCust_bits(char cust_bits) {
        this.cust_bits = cust_bits;
    }

    public short getReserve_s() {
        return reserve_s;
    }

    public void setReserve_s(short reserve_s) {
        this.reserve_s = reserve_s;
    }

    public short getH_code() {
        return H_code;
    }

    public void setH_code(short h_code) {
        H_code = h_code;
    }

    public short getD_code() {
        return D_code;
    }

    public void setD_code(short d_code) {
        D_code = d_code;
    }

    public int getSpindle_speed() {
        return spindle_speed;
    }

    public void setSpindle_speed(int spindle_speed) {
        this.spindle_speed = spindle_speed;
    }

    public int getFeedrate() {
        return feedrate;
    }

    public void setFeedrate(int feedrate) {
        this.feedrate = feedrate;
    }

    public short getG_code() {
        return G_code;
    }

    public void setG_code(short g_code) {
        G_code = g_code;
    }

    public short getW_code() {
        return W_code;
    }

    public void setW_code(short w_code) {
        W_code = w_code;
    }

    public int getCustom1() {
        return custom1;
    }

    public void setCustom1(int custom1) {
        this.custom1 = custom1;
    }

    public int getCustom2() {
        return custom2;
    }

    public void setCustom2(int custom2) {
        this.custom2 = custom2;
    }

    public int getCustom3() {
        return custom3;
    }

    public void setCustom3(int custom3) {
        this.custom3 = custom3;
    }

    public int getCustom4() {
        return custom4;
    }

    public void setCustom4(int custom4) {
        this.custom4 = custom4;
    }

    @Override
    public String toString() {
        return "IODBTLMNG_MU_EDGE_DATA{" +
                "life_count=" + life_count +
                ", max_life=" + max_life +
                ", rest_life=" + rest_life +
                ", life_stat=" + life_stat +
                ", cust_bits=" + cust_bits +
                ", reserve_s=" + reserve_s +
                ", H_code=" + H_code +
                ", D_code=" + D_code +
                ", spindle_speed=" + spindle_speed +
                ", feedrate=" + feedrate +
                ", G_code=" + G_code +
                ", W_code=" + W_code +
                ", custom1=" + custom1 +
                ", custom2=" + custom2 +
                ", custom3=" + custom3 +
                ", custom4=" + custom4 +
                '}';
    }
}
