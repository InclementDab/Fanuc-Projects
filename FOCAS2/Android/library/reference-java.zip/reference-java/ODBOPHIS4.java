package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBOPHIS4 {
    private short rec_len;
    private short rec_type;

    public short getRec_len() {
        return rec_len;
    }

    public void setRec_len(short rec_len) {
        this.rec_len = rec_len;
    }

    public short getRec_type() {
        return rec_type;
    }

    public void setRec_type(short rec_type) {
        this.rec_type = rec_type;
    }

    public static class REC_MDI {
        private byte key_code;
        private byte pw_flag;
        private short pth_no;
        private short ex_flag;
        private short hour;
        private short minute;
        private short second;

        public byte getKey_code() {
            return key_code;
        }

        public void setKey_code(byte key_code) {
            this.key_code = key_code;
        }

        public byte getPw_flag() {
            return pw_flag;
        }

        public void setPw_flag(byte pw_flag) {
            this.pw_flag = pw_flag;
        }

        public short getPth_no() {
            return pth_no;
        }

        public void setPth_no(short pth_no) {
            this.pth_no = pth_no;
        }

        public short getEx_flag() {
            return ex_flag;
        }

        public void setEx_flag(short ex_flag) {
            this.ex_flag = ex_flag;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        @Override
        public String toString() {
            return "REC_MDI{" +
                    "key_code=" + key_code +
                    ", pw_flag=" + pw_flag +
                    ", pth_no=" + pth_no +
                    ", ex_flag=" + ex_flag +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    '}';
        }
    }

    public static class REC_SGN {
        private short sig_name;
        private short sig_no;
        private byte sig_old;
        private byte sig_new;
        private short pmc_no;
        private short hour;
        private short minute;
        private short second;
        private short dummy;

        public short getSig_name() {
            return sig_name;
        }

        public void setSig_name(short sig_name) {
            this.sig_name = sig_name;
        }

        public short getSig_no() {
            return sig_no;
        }

        public void setSig_no(short sig_no) {
            this.sig_no = sig_no;
        }

        public byte getSig_old() {
            return sig_old;
        }

        public void setSig_old(byte sig_old) {
            this.sig_old = sig_old;
        }

        public byte getSig_new() {
            return sig_new;
        }

        public void setSig_new(byte sig_new) {
            this.sig_new = sig_new;
        }

        public short getPmc_no() {
            return pmc_no;
        }

        public void setPmc_no(short pmc_no) {
            this.pmc_no = pmc_no;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getDummy() {
            return dummy;
        }

        public void setDummy(short dummy) {
            this.dummy = dummy;
        }

        @Override
        public String toString() {
            return "REC_SGN{" +
                    "sig_name=" + sig_name +
                    ", sig_no=" + sig_no +
                    ", sig_old=" + sig_old +
                    ", sig_new=" + sig_new +
                    ", pmc_no=" + pmc_no +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", dummy=" + dummy +
                    '}';
        }
    }

    public static class REC_ALM {
        private short alm_grp;
        private short alm_no;
        private short axis_no;
        private short year;
        private short month;
        private short day;
        private short hour;
        private short minute;
        private short second;
        private short pth_no;
        private short sys_alm;
        private short dsp_flg;
        private short axis_num;

        public short getAlm_grp() {
            return alm_grp;
        }

        public void setAlm_grp(short alm_grp) {
            this.alm_grp = alm_grp;
        }

        public short getAlm_no() {
            return alm_no;
        }

        public void setAlm_no(short alm_no) {
            this.alm_no = alm_no;
        }

        public short getAxis_no() {
            return axis_no;
        }

        public void setAxis_no(short axis_no) {
            this.axis_no = axis_no;
        }

        public short getYear() {
            return year;
        }

        public void setYear(short year) {
            this.year = year;
        }

        public short getMonth() {
            return month;
        }

        public void setMonth(short month) {
            this.month = month;
        }

        public short getDay() {
            return day;
        }

        public void setDay(short day) {
            this.day = day;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getPth_no() {
            return pth_no;
        }

        public void setPth_no(short pth_no) {
            this.pth_no = pth_no;
        }

        public short getSys_alm() {
            return sys_alm;
        }

        public void setSys_alm(short sys_alm) {
            this.sys_alm = sys_alm;
        }

        public short getDsp_flg() {
            return dsp_flg;
        }

        public void setDsp_flg(short dsp_flg) {
            this.dsp_flg = dsp_flg;
        }

        public short getAxis_num() {
            return axis_num;
        }

        public void setAxis_num(short axis_num) {
            this.axis_num = axis_num;
        }

        @Override
        public String toString() {
            return "REC_ALM{" +
                    "alm_grp=" + alm_grp +
                    ", alm_no=" + alm_no +
                    ", axis_no=" + axis_no +
                    ", year=" + year +
                    ", month=" + month +
                    ", day=" + day +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", pth_no=" + pth_no +
                    ", sys_alm=" + sys_alm +
                    ", dsp_flg=" + dsp_flg +
                    ", axis_num=" + axis_num +
                    '}';
        }
    }

    public static class REC_DATE {
        private short evnt_type;
        private short year;
        private short month;
        private short day;
        private short hour;
        private short minute;
        private short second;
        private short dummy;

        public short getEvnt_type() {
            return evnt_type;
        }

        public void setEvnt_type(short evnt_type) {
            this.evnt_type = evnt_type;
        }

        public short getYear() {
            return year;
        }

        public void setYear(short year) {
            this.year = year;
        }

        public short getMonth() {
            return month;
        }

        public void setMonth(short month) {
            this.month = month;
        }

        public short getDay() {
            return day;
        }

        public void setDay(short day) {
            this.day = day;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getDummy() {
            return dummy;
        }

        public void setDummy(short dummy) {
            this.dummy = dummy;
        }

        @Override
        public String toString() {
            return "REC_DATE{" +
                    "evnt_type=" + evnt_type +
                    ", year=" + year +
                    ", month=" + month +
                    ", day=" + day +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", dummy=" + dummy +
                    '}';
        }
    }

    public static class REC_IAL {
        private short alm_grp;
        private short alm_no;
        private short axis_no;
        private short year;
        private short month;
        private short day;
        private short hour;
        private short minute;
        private short second;
        private short pth_no;
        private short sys_alm;
        private short dsp_flg;
        private short axis_num;
        private short dummy1;
        private int g_modal[];
        private String g_dp;
        private short dummy2;
        private int a_modal[];
        private String a_dp;
        private short dummy3;
        private int abs_pos[];
        private String abs_dp;
        private int mcn_pos[];
        private String mcn_dp;

        public short getAlm_grp() {
            return alm_grp;
        }

        public void setAlm_grp(short alm_grp) {
            this.alm_grp = alm_grp;
        }

        public short getAlm_no() {
            return alm_no;
        }

        public void setAlm_no(short alm_no) {
            this.alm_no = alm_no;
        }

        public short getAxis_no() {
            return axis_no;
        }

        public void setAxis_no(short axis_no) {
            this.axis_no = axis_no;
        }

        public short getYear() {
            return year;
        }

        public void setYear(short year) {
            this.year = year;
        }

        public short getMonth() {
            return month;
        }

        public void setMonth(short month) {
            this.month = month;
        }

        public short getDay() {
            return day;
        }

        public void setDay(short day) {
            this.day = day;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getPth_no() {
            return pth_no;
        }

        public void setPth_no(short pth_no) {
            this.pth_no = pth_no;
        }

        public short getSys_alm() {
            return sys_alm;
        }

        public void setSys_alm(short sys_alm) {
            this.sys_alm = sys_alm;
        }

        public short getDsp_flg() {
            return dsp_flg;
        }

        public void setDsp_flg(short dsp_flg) {
            this.dsp_flg = dsp_flg;
        }

        public short getAxis_num() {
            return axis_num;
        }

        public void setAxis_num(short axis_num) {
            this.axis_num = axis_num;
        }

        public short getDummy1() {
            return dummy1;
        }

        public void setDummy1(short dummy1) {
            this.dummy1 = dummy1;
        }

        public int[] getG_mada() {
            return g_modal;
        }

        public void setG_mada(int[] g_mada) {
            this.g_modal = g_mada;
        }



        public short getDummy2() {
            return dummy2;
        }

        public void setDummy2(short dummy2) {
            this.dummy2 = dummy2;
        }

        public int[] getA_moda() {
            return a_modal;
        }

        public void setA_moda(int[] a_moda) {
            this.a_modal = a_moda;
        }



        public short getDummy3() {
            return dummy3;
        }

        public void setDummy3(short dummy3) {
            this.dummy3 = dummy3;
        }

        public int[] getAbs_pos() {
            return abs_pos;
        }

        public void setAbs_pos(int[] abs_pos) {
            this.abs_pos = abs_pos;
        }



        public int[] getMcn_pos() {
            return mcn_pos;
        }

        public void setMcn_pos(int[] mcn_pos) {
            this.mcn_pos = mcn_pos;
        }

        public String getG_dp() {
            return g_dp;
        }

        public void setG_dp(String g_dp) {
            this.g_dp = g_dp;
        }

        public String getA_dp() {
            return a_dp;
        }

        public void setA_dp(String a_dp) {
            this.a_dp = a_dp;
        }

        public String getAbs_dp() {
            return abs_dp;
        }

        public void setAbs_dp(String abs_dp) {
            this.abs_dp = abs_dp;
        }

        public String getMcn_dp() {
            return mcn_dp;
        }

        public void setMcn_dp(String mcn_dp) {
            this.mcn_dp = mcn_dp;
        }

        @Override
        public String toString() {
            return "REC_IAL{" +
                    "alm_grp=" + alm_grp +
                    ", alm_no=" + alm_no +
                    ", axis_no=" + axis_no +
                    ", year=" + year +
                    ", month=" + month +
                    ", day=" + day +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", pth_no=" + pth_no +
                    ", sys_alm=" + sys_alm +
                    ", dsp_flg=" + dsp_flg +
                    ", axis_num=" + axis_num +
                    ", dummy1=" + dummy1 +
                    ", g_mada=" + Arrays.toString(g_modal) +
                    ", g_dp=" + g_dp +
                    ", dummy2=" + dummy2 +
                    ", a_moda=" + Arrays.toString(a_modal) +
                    ", a_dp=" + a_dp +
                    ", dummy3=" + dummy3 +
                    ", abs_pos=" + Arrays.toString(abs_pos) +
                    ", abs_dp=" + abs_dp +
                    ", mcn_pos=" + Arrays.toString(mcn_pos) +
                    ", mcn_dp=" + mcn_dp +
                    '}';
        }
    }

    public static class REC_MAL {
        private short alm_grp;
        private short alm_no;
        private short axis_no;
        private short year;
        private short month;
        private short day;
        private short hour;
        private short minute;
        private short second;
        private short pth_no;
        private short sys_alm;
        private short dsp_flg;
        private short axis_num;
        private String alm_msg;
        private short dummy1;
        private int g_moda[];
        private String g_dp;
        private short dummy2;
        private int a_moda[];
        private String a_dp;
        private short dummy3;
        private int abs_pos[];
        private String abs_dp;
        private int mcn_pos[];
        private String mcn_dp;

        public short getAlm_grp() {
            return alm_grp;
        }

        public void setAlm_grp(short alm_grp) {
            this.alm_grp = alm_grp;
        }

        public short getAlm_no() {
            return alm_no;
        }

        public void setAlm_no(short alm_no) {
            this.alm_no = alm_no;
        }

        public short getAxis_no() {
            return axis_no;
        }

        public void setAxis_no(short axis_no) {
            this.axis_no = axis_no;
        }

        public short getYear() {
            return year;
        }

        public void setYear(short year) {
            this.year = year;
        }

        public short getMonth() {
            return month;
        }

        public void setMonth(short month) {
            this.month = month;
        }

        public short getDay() {
            return day;
        }

        public void setDay(short day) {
            this.day = day;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getPth_no() {
            return pth_no;
        }

        public void setPth_no(short pth_no) {
            this.pth_no = pth_no;
        }

        public short getSys_alm() {
            return sys_alm;
        }

        public void setSys_alm(short sys_alm) {
            this.sys_alm = sys_alm;
        }

        public short getDsp_flg() {
            return dsp_flg;
        }

        public void setDsp_flg(short dsp_flg) {
            this.dsp_flg = dsp_flg;
        }

        public short getAxis_num() {
            return axis_num;
        }

        public void setAxis_num(short axis_num) {
            this.axis_num = axis_num;
        }



        public short getDummy1() {
            return dummy1;
        }

        public void setDummy1(short dummy1) {
            this.dummy1 = dummy1;
        }

        public int[] getG_moda() {
            return g_moda;
        }

        public void setG_moda(int[] g_moda) {
            this.g_moda = g_moda;
        }



        public short getDummy2() {
            return dummy2;
        }

        public void setDummy2(short dummy2) {
            this.dummy2 = dummy2;
        }

        public int[] getA_moda() {
            return a_moda;
        }

        public void setA_moda(int[] a_moda) {
            this.a_moda = a_moda;
        }



        public short getDummy3() {
            return dummy3;
        }

        public void setDummy3(short dummy3) {
            this.dummy3 = dummy3;
        }

        public int[] getAbs_pos() {
            return abs_pos;
        }

        public void setAbs_pos(int[] abs_pos) {
            this.abs_pos = abs_pos;
        }



        public int[] getMcn_pos() {
            return mcn_pos;
        }

        public void setMcn_pos(int[] mcn_pos) {
            this.mcn_pos = mcn_pos;
        }

        public String getAlm_msg() {
            return alm_msg;
        }

        public void setAlm_msg(String alm_msg) {
            this.alm_msg = alm_msg;
        }

        public String getG_dp() {
            return g_dp;
        }

        public void setG_dp(String g_dp) {
            this.g_dp = g_dp;
        }

        public String getA_dp() {
            return a_dp;
        }

        public void setA_dp(String a_dp) {
            this.a_dp = a_dp;
        }

        public String getAbs_dp() {
            return abs_dp;
        }

        public void setAbs_dp(String abs_dp) {
            this.abs_dp = abs_dp;
        }

        public String getMcn_dp() {
            return mcn_dp;
        }

        public void setMcn_dp(String mcn_dp) {
            this.mcn_dp = mcn_dp;
        }

        @Override
        public String toString() {
            return "REC_MAL{" +
                    "alm_grp=" + alm_grp +
                    ", alm_no=" + alm_no +
                    ", axis_no=" + axis_no +
                    ", year=" + year +
                    ", month=" + month +
                    ", day=" + day +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", pth_no=" + pth_no +
                    ", sys_alm=" + sys_alm +
                    ", dsp_flg=" + dsp_flg +
                    ", axis_num=" + axis_num +
                    ", alm_msg=" + alm_msg +
                    ", dummy1=" + dummy1 +
                    ", g_moda=" + Arrays.toString(g_moda) +
                    ", g_dp=" + g_dp +
                    ", dummy2=" + dummy2 +
                    ", a_moda=" + Arrays.toString(a_moda) +
                    ", a_dp=" + a_dp +
                    ", dummy3=" + dummy3 +
                    ", abs_pos=" + Arrays.toString(abs_pos) +
                    ", abs_dp=" + abs_dp +
                    ", mcn_pos=" + Arrays.toString(mcn_pos) +
                    ", mcn_dp=" + mcn_dp +
                    '}';
        }
    }

    public static class REC_OPM {
        private short dsp_flg;
        private short om_no;
        private short year;
        private short month;
        private short day;
        private short hour;
        private short minute;
        private short second;
        private String ope_msg;

        public short getDsp_flg() {
            return dsp_flg;
        }

        public void setDsp_flg(short dsp_flg) {
            this.dsp_flg = dsp_flg;
        }

        public short getOm_no() {
            return om_no;
        }

        public void setOm_no(short om_no) {
            this.om_no = om_no;
        }

        public short getYear() {
            return year;
        }

        public void setYear(short year) {
            this.year = year;
        }

        public short getMonth() {
            return month;
        }

        public void setMonth(short month) {
            this.month = month;
        }

        public short getDay() {
            return day;
        }

        public void setDay(short day) {
            this.day = day;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public String getOpe_msg() {
            return ope_msg;
        }

        public void setOpe_msg(String ope_msg) {
            this.ope_msg = ope_msg;
        }

        @Override
        public String toString() {
            return "REC_OPM{" +
                    "dsp_flg=" + dsp_flg +
                    ", om_no=" + om_no +
                    ", year=" + year +
                    ", month=" + month +
                    ", day=" + day +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", ope_msg=" + ope_msg +
                    '}';
        }
    }

    public static class REC_OFS {
        private short ofs_grp;
        private short ofs_no;
        private short hour;
        private short minute;
        private short second;
        private short pth_no;
        private int ofs_old;
        private int ofs_new;
        private short old_dp;
        private short new_dp;

        public short getOfs_grp() {
            return ofs_grp;
        }

        public void setOfs_grp(short ofs_grp) {
            this.ofs_grp = ofs_grp;
        }

        public short getOfs_no() {
            return ofs_no;
        }

        public void setOfs_no(short ofs_no) {
            this.ofs_no = ofs_no;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getPth_no() {
            return pth_no;
        }

        public void setPth_no(short pth_no) {
            this.pth_no = pth_no;
        }

        public int getOfs_old() {
            return ofs_old;
        }

        public void setOfs_old(int ofs_old) {
            this.ofs_old = ofs_old;
        }

        public int getOfs_new() {
            return ofs_new;
        }

        public void setOfs_new(int ofs_new) {
            this.ofs_new = ofs_new;
        }

        public short getOld_dp() {
            return old_dp;
        }

        public void setOld_dp(short old_dp) {
            this.old_dp = old_dp;
        }

        public short getNew_dp() {
            return new_dp;
        }

        public void setNew_dp(short new_dp) {
            this.new_dp = new_dp;
        }

        @Override
        public String toString() {
            return "REC_OFS{" +
                    "ofs_grp=" + ofs_grp +
                    ", ofs_no=" + ofs_no +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", pth_no=" + pth_no +
                    ", ofs_old=" + ofs_old +
                    ", ofs_new=" + ofs_new +
                    ", old_dp=" + old_dp +
                    ", new_dp=" + new_dp +
                    '}';
        }
    }

    public static class REC_PRM {
        private short prm_grp;
        private short prm_num;
        private short hour;
        private short minute;
        private short second;
        private short prm_len;
        private int prm_no;
        private int prm_old;
        private int prm_new;
        private short old_dp;
        private short new_dp;

        public short getPrm_grp() {
            return prm_grp;
        }

        public void setPrm_grp(short prm_grp) {
            this.prm_grp = prm_grp;
        }

        public short getPrm_num() {
            return prm_num;
        }

        public void setPrm_num(short prm_num) {
            this.prm_num = prm_num;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getPrm_len() {
            return prm_len;
        }

        public void setPrm_len(short prm_len) {
            this.prm_len = prm_len;
        }

        public int getPrm_no() {
            return prm_no;
        }

        public void setPrm_no(int prm_no) {
            this.prm_no = prm_no;
        }

        public int getPrm_old() {
            return prm_old;
        }

        public void setPrm_old(int prm_old) {
            this.prm_old = prm_old;
        }

        public int getPrm_new() {
            return prm_new;
        }

        public void setPrm_new(int prm_new) {
            this.prm_new = prm_new;
        }

        public short getOld_dp() {
            return old_dp;
        }

        public void setOld_dp(short old_dp) {
            this.old_dp = old_dp;
        }

        public short getNew_dp() {
            return new_dp;
        }

        public void setNew_dp(short new_dp) {
            this.new_dp = new_dp;
        }

        @Override
        public String toString() {
            return "REC_PRM{" +
                    "prm_grp=" + prm_grp +
                    ", prm_num=" + prm_num +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", prm_len=" + prm_len +
                    ", prm_no=" + prm_no +
                    ", prm_old=" + prm_old +
                    ", prm_new=" + prm_new +
                    ", old_dp=" + old_dp +
                    ", new_dp=" + new_dp +
                    '}';
        }
    }

    public static class REC_WOF {
        private short ofs_grp;
        private short ofs_no;
        private short hour;
        private short minute;
        private short second;
        private short pth_no;
        private short axis_no;
        private short dummy;
        private int ofs_old;
        private int ofs_new;
        private short old_dp;
        private short new_dp;

        public short getOfs_grp() {
            return ofs_grp;
        }

        public void setOfs_grp(short ofs_grp) {
            this.ofs_grp = ofs_grp;
        }

        public short getOfs_no() {
            return ofs_no;
        }

        public void setOfs_no(short ofs_no) {
            this.ofs_no = ofs_no;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getPth_no() {
            return pth_no;
        }

        public void setPth_no(short pth_no) {
            this.pth_no = pth_no;
        }

        public short getAxis_no() {
            return axis_no;
        }

        public void setAxis_no(short axis_no) {
            this.axis_no = axis_no;
        }

        public short getDummy() {
            return dummy;
        }

        public void setDummy(short dummy) {
            this.dummy = dummy;
        }

        public int getOfs_old() {
            return ofs_old;
        }

        public void setOfs_old(int ofs_old) {
            this.ofs_old = ofs_old;
        }

        public int getOfs_new() {
            return ofs_new;
        }

        public void setOfs_new(int ofs_new) {
            this.ofs_new = ofs_new;
        }

        public short getOld_dp() {
            return old_dp;
        }

        public void setOld_dp(short old_dp) {
            this.old_dp = old_dp;
        }

        public short getNew_dp() {
            return new_dp;
        }

        public void setNew_dp(short new_dp) {
            this.new_dp = new_dp;
        }

        @Override
        public String toString() {
            return "REC_WOF{" +
                    "ofs_grp=" + ofs_grp +
                    ", ofs_no=" + ofs_no +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", pth_no=" + pth_no +
                    ", axis_no=" + axis_no +
                    ", dummy=" + dummy +
                    ", ofs_old=" + ofs_old +
                    ", ofs_new=" + ofs_new +
                    ", old_dp=" + old_dp +
                    ", new_dp=" + new_dp +
                    '}';
        }
    }

    public static class REC_MAC {
        private short mac_no;
        private short hour;
        private short minute;
        private short second;
        private short pth_no;
        private short dummy;
        private int mac_old;
        private int mac_new;
        private short old_dp;
        private short new_dp;

        public short getMac_no() {
            return mac_no;
        }

        public void setMac_no(short mac_no) {
            this.mac_no = mac_no;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getPth_no() {
            return pth_no;
        }

        public void setPth_no(short pth_no) {
            this.pth_no = pth_no;
        }

        public short getDummy() {
            return dummy;
        }

        public void setDummy(short dummy) {
            this.dummy = dummy;
        }

        public int getMac_old() {
            return mac_old;
        }

        public void setMac_old(int mac_old) {
            this.mac_old = mac_old;
        }

        public int getMac_new() {
            return mac_new;
        }

        public void setMac_new(int mac_new) {
            this.mac_new = mac_new;
        }

        public short getOld_dp() {
            return old_dp;
        }

        public void setOld_dp(short old_dp) {
            this.old_dp = old_dp;
        }

        public short getNew_dp() {
            return new_dp;
        }

        public void setNew_dp(short new_dp) {
            this.new_dp = new_dp;
        }

        @Override
        public String toString() {
            return "REC_MAC{" +
                    "mac_no=" + mac_no +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", pth_no=" + pth_no +
                    ", dummy=" + dummy +
                    ", mac_old=" + mac_old +
                    ", mac_new=" + mac_new +
                    ", old_dp=" + old_dp +
                    ", new_dp=" + new_dp +
                    '}';
        }
    }

    public static class REC_MAC2 {
        private int mac_no;
        private short hour;
        private short minute;
        private short second;
        private short pth_no;
        private int mac_old;
        private int mac_new;
        private short old_dp;
        private short new_dp;

        public int getMac_no() {
            return mac_no;
        }

        public void setMac_no(int mac_no) {
            this.mac_no = mac_no;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getPth_no() {
            return pth_no;
        }

        public void setPth_no(short pth_no) {
            this.pth_no = pth_no;
        }

        public int getMac_old() {
            return mac_old;
        }

        public void setMac_old(int mac_old) {
            this.mac_old = mac_old;
        }

        public int getMac_new() {
            return mac_new;
        }

        public void setMac_new(int mac_new) {
            this.mac_new = mac_new;
        }

        public short getOld_dp() {
            return old_dp;
        }

        public void setOld_dp(short old_dp) {
            this.old_dp = old_dp;
        }

        public short getNew_dp() {
            return new_dp;
        }

        public void setNew_dp(short new_dp) {
            this.new_dp = new_dp;
        }

        @Override
        public String toString() {
            return "REC_MAC2{" +
                    "mac_no=" + mac_no +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", pth_no=" + pth_no +
                    ", mac_old=" + mac_old +
                    ", mac_new=" + mac_new +
                    ", old_dp=" + old_dp +
                    ", new_dp=" + new_dp +
                    '}';
        }
    }

    public static class REC_SCRN {
        private short scrn_old;
        private short scrn_new;
        private short dummy;
        private short hour;
        private short minute;
        private short second;

        public short getScrn_old() {
            return scrn_old;
        }

        public void setScrn_old(short scrn_old) {
            this.scrn_old = scrn_old;
        }

        public short getScrn_new() {
            return scrn_new;
        }

        public void setScrn_new(short scrn_new) {
            this.scrn_new = scrn_new;
        }

        public short getDumy() {
            return dummy;
        }

        public void setDumy(short dumy) {
            this.dummy = dumy;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        @Override
        public String toString() {
            return "REC_SCRN{" +
                    "scrn_old=" + scrn_old +
                    ", scrn_new=" + scrn_new +
                    ", dummy=" + dummy +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    '}';
        }
    }

    private REC_MDI rec_mdi;
    private REC_SGN rec_sgn;
    private REC_ALM rec_alm;
    private REC_DATE rec_date;
    private REC_IAL rec_ial;
    private REC_MAL rec_mal;
    private REC_OPM rec_opm;
    private REC_OFS rec_ofs;
    private REC_PRM rec_prm;
    private REC_WOF rec_wof;
    private REC_MAC rec_mac;
    private REC_MAC2 rec_mac2;
    private REC_SCRN rec_scrn;

    public REC_MDI getRec_mdi() {
        return rec_mdi;
    }

    public void setRec_mdi(REC_MDI rec_mdi) {
        this.rec_mdi = rec_mdi;
    }

    public REC_SGN getRec_sgn() {
        return rec_sgn;
    }

    public void setRec_sgn(REC_SGN rec_sgn) {
        this.rec_sgn = rec_sgn;
    }

    public REC_ALM getRec_alm() {
        return rec_alm;
    }

    public void setRec_alm(REC_ALM rec_alm) {
        this.rec_alm = rec_alm;
    }

    public REC_DATE getRec_date() {
        return rec_date;
    }

    public void setRec_date(REC_DATE rec_date) {
        this.rec_date = rec_date;
    }

    public REC_IAL getRec_ial() {
        return rec_ial;
    }

    public void setRec_ial(REC_IAL rec_ial) {
        this.rec_ial = rec_ial;
    }

    public REC_MAL getRec_mal() {
        return rec_mal;
    }

    public void setRec_mal(REC_MAL rec_mal) {
        this.rec_mal = rec_mal;
    }

    public REC_OPM getRec_opm() {
        return rec_opm;
    }

    public void setRec_opm(REC_OPM rec_opm) {
        this.rec_opm = rec_opm;
    }

    public REC_OFS getRec_ofs() {
        return rec_ofs;
    }

    public void setRec_ofs(REC_OFS rec_ofs) {
        this.rec_ofs = rec_ofs;
    }

    public REC_PRM getRec_prm() {
        return rec_prm;
    }

    public void setRec_prm(REC_PRM rec_prm) {
        this.rec_prm = rec_prm;
    }

    public REC_WOF getRec_wof() {
        return rec_wof;
    }

    public void setRec_wof(REC_WOF rec_wof) {
        this.rec_wof = rec_wof;
    }

    public REC_MAC getRec_mac() {
        return rec_mac;
    }

    public void setRec_mac(REC_MAC rec_mac) {
        this.rec_mac = rec_mac;
    }

    public REC_MAC2 getRec_mac2() {
        return rec_mac2;
    }

    public void setRec_mac2(REC_MAC2 rec_mac2) {
        this.rec_mac2 = rec_mac2;
    }

    public REC_SCRN getRec_scrn() {
        return rec_scrn;
    }

    public void setRec_scrn(REC_SCRN rec_scrn) {
        this.rec_scrn = rec_scrn;
    }

    @Override
    public String toString() {
        return "ODBOPHIS4{" +
                "rec_len=" + rec_len +
                ", rec_type=" + rec_type +
                ", rec_mdi=" + rec_mdi +
                ", rec_sgn=" + rec_sgn +
                ", rec_alm=" + rec_alm +
                ", rec_date=" + rec_date +
                ", rec_ial=" + rec_ial +
                ", rec_mal=" + rec_mal +
                ", rec_opm=" + rec_opm +
                ", rec_ofs=" + rec_ofs +
                ", rec_prm=" + rec_prm +
                ", rec_wof=" + rec_wof +
                ", rec_mac=" + rec_mac +
                ", rec_mac2=" + rec_mac2 +
                ", rec_scrn=" + rec_scrn +
                '}';
    }

    public void Dispose() {
        rec_mdi = null;
        rec_sgn = null;
        rec_alm = null;
        rec_date = null;
        rec_ial = null;
        rec_mal = null;
        rec_opm = null;
        rec_ofs = null;
        rec_prm = null;
        rec_wof = null;
        rec_mac = null;
        rec_mac2 = null;
        rec_scrn = null;
    }
}
