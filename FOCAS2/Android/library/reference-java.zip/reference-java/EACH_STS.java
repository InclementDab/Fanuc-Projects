package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class EACH_STS {
    private char   StatusFlag;
    private char   ErrDetectNode;
    private char   ErrSendNode;
    private char   Reserved[];

    public char getStatusFlag() {
        return StatusFlag;
    }

    public void setStatusFlag(char statusFlag) {
        StatusFlag = statusFlag;
    }

    public char getErrDetectNode() {
        return ErrDetectNode;
    }

    public void setErrDetectNode(char errDetectNode) {
        ErrDetectNode = errDetectNode;
    }

    public char getErrSendNode() {
        return ErrSendNode;
    }

    public void setErrSendNode(char errSendNode) {
        ErrSendNode = errSendNode;
    }

    public char[] getReserved() {
        return Reserved;
    }

    public void setReserved(char[] reserved) {
        Reserved = reserved;
    }

    @Override
    public String toString() {
        return "EACH_STS{" +
                "StatusFlag=" + StatusFlag +
                ", ErrDetectNode=" + ErrDetectNode +
                ", ErrSendNode=" + ErrSendNode +
                ", Reserved=" + Arrays.toString(Reserved) +
                '}';
    }
}
