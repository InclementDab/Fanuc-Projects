package jp.co.fanuc.fwlibe1;


public class ODBIFSBLINE {
    private short hrv_ln;
    private short ax_num_ln;
    private short sp_num_ln;
    private short pm_num_ln;

    public short getHrv_ln() {
        return hrv_ln;
    }

    public void setHrv_ln(short hrv_ln) {
        this.hrv_ln = hrv_ln;
    }

    public short getAx_num_ln() {
        return ax_num_ln;
    }

    public void setAx_num_ln(short ax_num_ln) {
        this.ax_num_ln = ax_num_ln;
    }

    public short getSp_num_ln() {
        return sp_num_ln;
    }

    public void setSp_num_ln(short sp_num_ln) {
        this.sp_num_ln = sp_num_ln;
    }

    public short getPm_num_ln() {
        return pm_num_ln;
    }

    public void setPm_num_ln(short pm_num_ln) {
        this.pm_num_ln = pm_num_ln;
    }

    @Override
    public String toString() {
        return "ODBIFSBLINE{" +
                "hrv_ln=" + hrv_ln +
                ", ax_num_ln=" + ax_num_ln +
                ", sp_num_ln=" + sp_num_ln +
                ", pm_num_ln=" + pm_num_ln +
                '}';
    }
}
