package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBNME {
    private short ob_type;
    private short obj_no;
    private short nme_no;
    private short suffix;
    private char name[];

    public short getOb_type() {
        return ob_type;
    }

    public void setOb_type(short ob_type) {
        this.ob_type = ob_type;
    }

    public short getObj_no() {
        return obj_no;
    }

    public void setObj_no(short obj_no) {
        this.obj_no = obj_no;
    }

    public short getNme_no() {
        return nme_no;
    }

    public void setNme_no(short nme_no) {
        this.nme_no = nme_no;
    }

    public short getSuffix() {
        return suffix;
    }

    public void setSuffix(short suffix) {
        this.suffix = suffix;
    }

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "ODBNME{" +
                "ob_type=" + ob_type +
                ", obj_no=" + obj_no +
                ", nme_no=" + nme_no +
                ", suffix=" + suffix +
                ", name=" + Arrays.toString(name) +
                '}';
    }
}
