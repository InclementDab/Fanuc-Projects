package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBAHDCK {
    private short dat_path;

    public short getDat_path() {
        return dat_path;
    }

    public void setDat_path(short dat_path) {
        this.dat_path = dat_path;
    }
    public static class INFO {
        private short stat;
        private short data;

        public short getStat() {
            return stat;
        }

        public void setStat(short stat) {
            this.stat = stat;
        }

        public short getData() {
            return data;
        }

        public void setData(short data) {
            this.data = data;
        }

        @Override
        public String toString() {
            return "INFO{" +
                    "stat=" + stat +
                    ", data=" + data +
                    '}';
        }
    }
    private INFO info[];

    public INFO[] getInfo() {
        return info;
    }

    public void setInfo(INFO[] info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "ODBAHDCK{" +
                "dat_path=" + dat_path +
                ", info=" + Arrays.toString(info) +
                '}';
    }
}
