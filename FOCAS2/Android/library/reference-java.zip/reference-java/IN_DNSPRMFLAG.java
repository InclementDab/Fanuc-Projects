package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_DNSPRMFLAG {
    private char            BaudRate;
    private char            DiDataOnAbnormal;
    private char            OwnMacId;
    private char            Di;
    private char            DiSize;
    private char            Do;
    private char            DoSize;
    private char            Status;
    private char            StatusSize;
    private char            pad[];

    public char getBaudRate() {
        return BaudRate;
    }

    public void setBaudRate(char baudRate) {
        BaudRate = baudRate;
    }

    public char getDiDataOnAbnormal() {
        return DiDataOnAbnormal;
    }

    public void setDiDataOnAbnormal(char diDataOnAbnormal) {
        DiDataOnAbnormal = diDataOnAbnormal;
    }

    public char getOwnMacId() {
        return OwnMacId;
    }

    public void setOwnMacId(char ownMacId) {
        OwnMacId = ownMacId;
    }

    public char getDi() {
        return Di;
    }

    public void setDi(char di) {
        Di = di;
    }

    public char getDiSize() {
        return DiSize;
    }

    public void setDiSize(char diSize) {
        DiSize = diSize;
    }

    public char getDo() {
        return Do;
    }

    public void setDo(char aDo) {
        Do = aDo;
    }

    public char getDoSize() {
        return DoSize;
    }

    public void setDoSize(char doSize) {
        DoSize = doSize;
    }

    public char getStatus() {
        return Status;
    }

    public void setStatus(char status) {
        Status = status;
    }

    public char getStatusSize() {
        return StatusSize;
    }

    public void setStatusSize(char statusSize) {
        StatusSize = statusSize;
    }

    public char[] getPad() {
        return pad;
    }

    public void setPad(char[] pad) {
        this.pad = pad;
    }

    @Override
    public String toString() {
        return "IN_DNSPRMFLAG{" +
                "BaudRate=" + BaudRate +
                ", DiDataOnAbnormal=" + DiDataOnAbnormal +
                ", OwnMacId=" + OwnMacId +
                ", Di=" + Di +
                ", DiSize=" + DiSize +
                ", Do=" + Do +
                ", DoSize=" + DoSize +
                ", Status=" + Status +
                ", StatusSize=" + StatusSize +
                ", pad=" + Arrays.toString(pad) +
                '}';
    }
}
