package jp.co.fanuc.fwlibe1;


public class FWLIBPRMW {
    private short TcpPort;
    private short UdpPort;
    private short UdpInterval;

    public short getTcpPort() {
        return TcpPort;
    }

    public void setTcpPort(short tcpPort) {
        TcpPort = tcpPort;
    }

    public short getUdpPort() {
        return UdpPort;
    }

    public void setUdpPort(short udpPort) {
        UdpPort = udpPort;
    }

    public short getUdpInterval() {
        return UdpInterval;
    }

    public void setUdpInterval(short udpInterval) {
        UdpInterval = udpInterval;
    }

    @Override
    public String toString() {
        return "FWLIBPRMW{" +
                "TcpPort=" + TcpPort +
                ", UdpPort=" + UdpPort +
                ", UdpInterval=" + UdpInterval +
                '}';
    }
}
