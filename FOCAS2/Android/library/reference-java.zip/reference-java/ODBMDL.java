package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMDL {
    private short datano;
    private short type;
    private byte g_data;
    private byte g_rdata[];
    private byte g_1shot[];
    private AUX aux;
    private AUX raux1[];
    private AUX raux2[];


    public static class AUX {
        private int aux_data;
        private byte flag1;
        private byte flag2;

        public int getAux_data() {
            return aux_data;
        }

        public void setAux_data(int aux_data) {
            this.aux_data = aux_data;
        }

        public byte getFlag1() {
            return flag1;
        }

        public void setFlag1(byte flag1) {
            this.flag1 = flag1;
        }

        public byte getFlag2() {
            return flag2;
        }

        public void setFlag2(byte flag2) {
            this.flag2 = flag2;
        }

        @Override
        public String toString() {
            return "AUX{" +
                    "aux_data=" + aux_data +
                    ", flag1=" + flag1 +
                    ", flag2=" + flag2 +
                    '}';
        }
    }

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public byte getG_data() {
        return g_data;
    }

    public void setG_data(byte g_data) {
        this.g_data = g_data;
    }

    public byte[] getG_rdata() {
        return g_rdata;
    }

    public void setG_rdata(byte[] g_rdata) {
        this.g_rdata = g_rdata;
    }

    public byte[] getG_1shot() {
        return g_1shot;
    }

    public void setG_1shot(byte[] g_1shot) {
        this.g_1shot = g_1shot;
    }

    public AUX getAux() {
        return aux;
    }

    public void setAux(AUX aux) {
        this.aux = aux;
    }

    public AUX[] getRaux1() {
        return raux1;
    }

    public void setRaux1(AUX[] raux1) {
        this.raux1 = raux1;
    }

    public AUX[] getRaux2() {
        return raux2;
    }

    public void setRaux2(AUX[] raux2) {
        this.raux2 = raux2;
    }

    @Override
    public String toString() {
        return "ODBMDL{" +
                "datano=" + datano +
                ", type=" + type +
                ", g_data=" + g_data +
                ", g_rdata=" + Arrays.toString(g_rdata) +
                ", g_1shot=" + Arrays.toString(g_1shot) +
                ", aux=" + aux +
                ", raux1=" + Arrays.toString(raux1) +
                ", raux2=" + Arrays.toString(raux2) +
                '}';
    }

    public void Dispose(){
        aux = null;
        raux1 = null;
        raux2 = null;
    }
}
