package jp.co.fanuc.fwlibe1;


public class IODBRMTPRM {
    private short condition;
    private short reserve;

    public short getCondition() {
        return condition;
    }

    public void setCondition(short condition) {
        this.condition = condition;
    }

    public short getReserve() {
        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    public static class TRG {
        public static class ALM {
            private short no;
            private char axis;
            private char type;

            public short getNo() {
                return no;
            }

            public void setNo(short no) {
                this.no = no;
            }

            public char getAxis() {
                return axis;
            }

            public void setAxis(char axis) {
                this.axis = axis;
            }

            public char getType() {
                return type;
            }

            public void setType(char type) {
                this.type = type;
            }

            @Override
            public String toString() {
                return "ALM{" +
                        "no=" + no +
                        ", axis=" + axis +
                        ", type=" + type +
                        '}';
            }
        }
        public static class IO{
            private char adr;
            private char bit;
            private short no;

            public char getAdr() {
                return adr;
            }

            public void setAdr(char adr) {
                this.adr = adr;
            }

            public char getBit() {
                return bit;
            }

            public void setBit(char bit) {
                this.bit = bit;
            }

            public short getNo() {
                return no;
            }

            public void setNo(short no) {
                this.no = no;
            }

            @Override
            public String toString() {
                return "IO{" +
                        "adr=" + adr +
                        ", bit=" + bit +
                        ", no=" + no +
                        '}';
            }
        }
        private ALM alm;
        private IO io;

        public ALM getAlm() {
            return alm;
        }

        public void setAlm(ALM alm) {
            this.alm = alm;
        }

        public IO getIo() {
            return io;
        }

        public void setIo(IO io) {
            this.io = io;
        }

        @Override
        public String toString() {
            return "TRG{" +
                    "alm=" + alm +
                    ", io=" + io +
                    '}';
        }
    }
    private TRG trg;
    private int delay;
    private short wv_intrvl;
    private short io_intrvl;
    private short kind1;
    private short kind2;

    public TRG getTrg() {
        return trg;
    }

    public void setTrg(TRG trg) {
        this.trg = trg;
    }

    public int getDelay() {
        return delay;
    }

    public void setDelay(int delay) {
        this.delay = delay;
    }

    public short getWv_intrvl() {
        return wv_intrvl;
    }

    public void setWv_intrvl(short wv_intrvl) {
        this.wv_intrvl = wv_intrvl;
    }

    public short getIo_intrvl() {
        return io_intrvl;
    }

    public void setIo_intrvl(short io_intrvl) {
        this.io_intrvl = io_intrvl;
    }

    public short getKind1() {
        return kind1;
    }

    public void setKind1(short kind1) {
        this.kind1 = kind1;
    }

    public short getKind2() {
        return kind2;
    }

    public void setKind2(short kind2) {
        this.kind2 = kind2;
    }

    public static class SMPL {
        private char adr;
        private char bit;
        private short no;

        public char getAdr() {
            return adr;
        }

        public void setAdr(char adr) {
            this.adr = adr;
        }

        public char getBit() {
            return bit;
        }

        public void setBit(char bit) {
            this.bit = bit;
        }

        public short getNo() {
            return no;
        }

        public void setNo(short no) {
            this.no = no;
        }

        @Override
        public String toString() {
            return "SMPL{" +
                    "adr=" + adr +
                    ", bit=" + bit +
                    ", no=" + no +
                    '}';
        }
    }
    private SMPL smpl;

    public SMPL getSmpl() {
        return smpl;
    }

    public void setSmpl(SMPL smpl) {
        this.smpl = smpl;
    }

    @Override
    public String toString() {
        return "IODBRMTPRM{" +
                "condition=" + condition +
                ", reserve=" + reserve +
                ", trg=" + trg +
                ", delay=" + delay +
                ", wv_intrvl=" + wv_intrvl +
                ", io_intrvl=" + io_intrvl +
                ", kind1=" + kind1 +
                ", kind2=" + kind2 +
                ", smpl=" + smpl +
                '}';
    }
}
