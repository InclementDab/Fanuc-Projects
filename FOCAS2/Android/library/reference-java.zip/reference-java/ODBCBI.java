package jp.co.fanuc.fwlibe1;


public class ODBCBI {
    private short cb_no;
    private ODBNME nme_set;
    private char shp_no;
    private char cd_form;

    public short getCb_no() {
        return cb_no;
    }

    public void setCb_no(short cb_no) {
        this.cb_no = cb_no;
    }

    public ODBNME getNme_set() {
        return nme_set;
    }

    public void setNme_set(ODBNME nme_set) {
        this.nme_set = nme_set;
    }

    public char getShp_no() {
        return shp_no;
    }

    public void setShp_no(char shp_no) {
        this.shp_no = shp_no;
    }

    public char getCd_form() {
        return cd_form;
    }

    public void setCd_form(char cd_form) {
        this.cd_form = cd_form;
    }

    @Override
    public String toString() {
        return "ODBCBI{" +
                "cb_no=" + cb_no +
                ", nme_set=" + nme_set +
                ", shp_no=" + shp_no +
                ", cd_form=" + cd_form +
                '}';
    }
}
