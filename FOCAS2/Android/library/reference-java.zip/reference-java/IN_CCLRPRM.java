package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_CCLRPRM {
    private short           BaudRate;
    private short           ID;
    private short           UseIDCount;
    private short           DataOnAbnormal;
    private PMC_REG         Status;
    private PMC_REG         RY;
    private short           RYSize;
    private char            pad1[];
    private PMC_REG         RX;
    private short           RXSize;
    private char            pad2[];
    private PMC_REG         RWw;
    private short           RWwSize;
    private char            pad3[];
    private PMC_REG         RWr;
    private short           RWrSize;
    private char            pad4[];

    public short getBaudRate() {
        return BaudRate;
    }

    public void setBaudRate(short baudRate) {
        BaudRate = baudRate;
    }

    public short getID() {
        return ID;
    }

    public void setID(short ID) {
        this.ID = ID;
    }

    public short getUseIDCount() {
        return UseIDCount;
    }

    public void setUseIDCount(short useIDCount) {
        UseIDCount = useIDCount;
    }

    public short getDataOnAbnormal() {
        return DataOnAbnormal;
    }

    public void setDataOnAbnormal(short dataOnAbnormal) {
        DataOnAbnormal = dataOnAbnormal;
    }

    public PMC_REG getStatus() {
        return Status;
    }

    public void setStatus(PMC_REG status) {
        Status = status;
    }

    public PMC_REG getRY() {
        return RY;
    }

    public void setRY(PMC_REG RY) {
        this.RY = RY;
    }

    public short getRYSize() {
        return RYSize;
    }

    public void setRYSize(short RYSize) {
        this.RYSize = RYSize;
    }

    public char[] getPad1() {
        return pad1;
    }

    public void setPad1(char[] pad1) {
        this.pad1 = pad1;
    }

    public PMC_REG getRX() {
        return RX;
    }

    public void setRX(PMC_REG RX) {
        this.RX = RX;
    }

    public short getRXSize() {
        return RXSize;
    }

    public void setRXSize(short RXSize) {
        this.RXSize = RXSize;
    }

    public char[] getPad2() {
        return pad2;
    }

    public void setPad2(char[] pad2) {
        this.pad2 = pad2;
    }

    public PMC_REG getRWw() {
        return RWw;
    }

    public void setRWw(PMC_REG RWw) {
        this.RWw = RWw;
    }

    public short getRWwSize() {
        return RWwSize;
    }

    public void setRWwSize(short RWwSize) {
        this.RWwSize = RWwSize;
    }

    public char[] getPad3() {
        return pad3;
    }

    public void setPad3(char[] pad3) {
        this.pad3 = pad3;
    }

    public PMC_REG getRWr() {
        return RWr;
    }

    public void setRWr(PMC_REG RWr) {
        this.RWr = RWr;
    }

    public short getRWrSize() {
        return RWrSize;
    }

    public void setRWrSize(short RWrSize) {
        this.RWrSize = RWrSize;
    }

    public char[] getPad4() {
        return pad4;
    }

    public void setPad4(char[] pad4) {
        this.pad4 = pad4;
    }

    @Override
    public String toString() {
        return "IN_CCLRPRM{" +
                "BaudRate=" + BaudRate +
                ", ID=" + ID +
                ", UseIDCount=" + UseIDCount +
                ", DataOnAbnormal=" + DataOnAbnormal +
                ", Status=" + Status +
                ", RY=" + RY +
                ", RYSize=" + RYSize +
                ", pad1=" + Arrays.toString(pad1) +
                ", RX=" + RX +
                ", RXSize=" + RXSize +
                ", pad2=" + Arrays.toString(pad2) +
                ", RWw=" + RWw +
                ", RWwSize=" + RWwSize +
                ", pad3=" + Arrays.toString(pad3) +
                ", RWr=" + RWr +
                ", RWrSize=" + RWrSize +
                ", pad4=" + Arrays.toString(pad4) +
                '}';
    }
}
