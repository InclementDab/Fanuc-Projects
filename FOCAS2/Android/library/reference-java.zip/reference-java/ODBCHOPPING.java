package jp.co.fanuc.fwlibe1;


public class ODBCHOPPING {
    private REALNUM cur_pos;
    private REALNUM cur_speed;
    private REALNUM real_udp;
    private REALNUM real_ldp;
    private int stroke_cnt;

    public REALNUM getCur_pos() {
        return cur_pos;
    }

    public void setCur_pos(REALNUM cur_pos) {
        this.cur_pos = cur_pos;
    }

    public REALNUM getCur_speed() {
        return cur_speed;
    }

    public void setCur_speed(REALNUM cur_speed) {
        this.cur_speed = cur_speed;
    }

    public REALNUM getReal_udp() {
        return real_udp;
    }

    public void setReal_udp(REALNUM real_udp) {
        this.real_udp = real_udp;
    }

    public REALNUM getReal_ldp() {
        return real_ldp;
    }

    public void setReal_ldp(REALNUM real_ldp) {
        this.real_ldp = real_ldp;
    }

    public int getStroke_cnt() {
        return stroke_cnt;
    }

    public void setStroke_cnt(int stroke_cnt) {
        this.stroke_cnt = stroke_cnt;
    }

    @Override
    public String toString() {
        return "ODBCHOPPING{" +
                "cur_pos=" + cur_pos +
                ", cur_speed=" + cur_speed +
                ", real_udp=" + real_udp +
                ", real_ldp=" + real_ldp +
                ", stroke_cnt=" + stroke_cnt +
                '}';
    }
}
