package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBSIMUELM2 {
    private char    type;
    private char    rot_w;
    private char    type2;
    private char    plane;
    private int    tcode;

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }

    public char getRot_w() {
        return rot_w;
    }

    public void setRot_w(char rot_w) {
        this.rot_w = rot_w;
    }

    public char getType2() {
        return type2;
    }

    public void setType2(char type2) {
        this.type2 = type2;
    }

    public char getPlane() {
        return plane;
    }

    public void setPlane(char plane) {
        this.plane = plane;
    }

    public int getTcode() {
        return tcode;
    }

    public void setTcode(int tcode) {
        this.tcode = tcode;
    }

    public static class  DATA {
        public static class RAPID {
            private int mv_p[];

            public int[] getMv_p() {
                return mv_p;
            }

            public void setMv_p(int[] mv_p) {
                this.mv_p = mv_p;
            }

            @Override
            public String toString() {
                return "RAPID{" +
                        "mv_p=" + Arrays.toString(mv_p) +
                        '}';
            }
        }
        public static class LINE {
            private int mv_p[];

            public int[] getMv_p() {
                return mv_p;
            }

            public void setMv_p(int[] mv_p) {
                this.mv_p = mv_p;
            }

            @Override
            public String toString() {
                return "LINE{" +
                        "mv_p=" + Arrays.toString(mv_p) +
                        '}';
            }
        }
        public static class ARC {
            private int mv_p[];
            private int cnt_p[];

            public int[] getMv_p() {
                return mv_p;
            }

            public void setMv_p(int[] mv_p) {
                this.mv_p = mv_p;
            }

            public int[] getCnt_p() {
                return cnt_p;
            }

            public void setCnt_p(int[] cnt_p) {
                this.cnt_p = cnt_p;
            }

            @Override
            public String toString() {
                return "ARC{" +
                        "mv_p=" + Arrays.toString(mv_p) +
                        ", cnt_p=" + Arrays.toString(cnt_p) +
                        '}';
            }
        }
        public static class THRD1{
            private int mv_p[];
            private int ptch;

            public int[] getMv_p() {
                return mv_p;
            }

            public void setMv_p(int[] mv_p) {
                this.mv_p = mv_p;
            }

            public int getPtch() {
                return ptch;
            }

            public void setPtch(int ptch) {
                this.ptch = ptch;
            }

            @Override
            public String toString() {
                return "THRD1{" +
                        "mv_p=" + Arrays.toString(mv_p) +
                        ", ptch=" + ptch +
                        '}';
            }
        }
        public static class THRD2 {
            private int mv_p[];
            private int ptch;
            private int mv_p2[];

            public int[] getMv_p() {
                return mv_p;
            }

            public void setMv_p(int[] mv_p) {
                this.mv_p = mv_p;
            }

            public int getPtch() {
                return ptch;
            }

            public void setPtch(int ptch) {
                this.ptch = ptch;
            }

            public int[] getMv_p2() {
                return mv_p2;
            }

            public void setMv_p2(int[] mv_p2) {
                this.mv_p2 = mv_p2;
            }

            @Override
            public String toString() {
                return "THRD2{" +
                        "mv_p=" + Arrays.toString(mv_p) +
                        ", ptch=" + ptch +
                        ", mv_p2=" + Arrays.toString(mv_p2) +
                        '}';
            }
        }
        public static class  DUMMY_D {
            private int mv_p[];

            public int[] getMv_p() {
                return mv_p;
            }

            public void setMv_p(int[] mv_p) {
                this.mv_p = mv_p;
            }

            @Override
            public String toString() {
                return "DUMMY_D{" +
                        "mv_p=" + Arrays.toString(mv_p) +
                        '}';
            }
        }
        private RAPID rapid;
        private LINE line;
        private ARC arc;
        private THRD1 thrd1;
        private THRD2 thrd2;
        private DUMMY_D dummy_d;

        public RAPID getRapid() {
            return rapid;
        }

        public void setRapid(RAPID rapid) {
            this.rapid = rapid;
        }

        public LINE getLine() {
            return line;
        }

        public void setLine(LINE line) {
            this.line = line;
        }

        public ARC getArc() {
            return arc;
        }

        public void setArc(ARC arc) {
            this.arc = arc;
        }

        public THRD1 getThrd1() {
            return thrd1;
        }

        public void setThrd1(THRD1 thrd1) {
            this.thrd1 = thrd1;
        }

        public THRD2 getThrd2() {
            return thrd2;
        }

        public void setThrd2(THRD2 thrd2) {
            this.thrd2 = thrd2;
        }

        public DUMMY_D getDummy_d() {
            return dummy_d;
        }

        public void setDummy_d(DUMMY_D dummy_d) {
            this.dummy_d = dummy_d;
        }

        @Override
        public String toString() {
            return "DATA{" +
                    "rapid=" + rapid +
                    ", line=" + line +
                    ", arc=" + arc +
                    ", thrd1=" + thrd1 +
                    ", thrd2=" + thrd2 +
                    ", dummy_d=" + dummy_d +
                    '}';
        }
    }
    private DATA data;
    private char    dm_type;
    private char    cssc_md;
    private int    dm_x[];
    private int    dm_y[];
    private int    dm_z[];
    private int    cnt_x[];
    private int    cord[];
    private char    tlchng;
    private char    fd_type;
    private int    mcode;
    private short   dummy4;
    private int    cylndr;
    private int    aux;
    private int    dcode;
    private int    smax;
    private int    dwell;
    private int    fcode;
    private int    scode;
    private char    nummcd;
    private char    fcddec;
    private int    shift;
    private char    fbsft;
    private char    tilt;
    private short   dummy6;
    private int    mcode2;
    private int    mcode3;
    private int    mcode4;
    private int    mcode5;
    private int    reserve[];

    public DATA getData() {
        return data;
    }

    public void setData(DATA data) {
        this.data = data;
    }

    public char getDm_type() {
        return dm_type;
    }

    public void setDm_type(char dm_type) {
        this.dm_type = dm_type;
    }

    public char getCssc_md() {
        return cssc_md;
    }

    public void setCssc_md(char cssc_md) {
        this.cssc_md = cssc_md;
    }

    public int[] getDm_x() {
        return dm_x;
    }

    public void setDm_x(int[] dm_x) {
        this.dm_x = dm_x;
    }

    public int[] getDm_y() {
        return dm_y;
    }

    public void setDm_y(int[] dm_y) {
        this.dm_y = dm_y;
    }

    public int[] getDm_z() {
        return dm_z;
    }

    public void setDm_z(int[] dm_z) {
        this.dm_z = dm_z;
    }

    public int[] getCnt_x() {
        return cnt_x;
    }

    public void setCnt_x(int[] cnt_x) {
        this.cnt_x = cnt_x;
    }

    public int[] getCord() {
        return cord;
    }

    public void setCord(int[] cord) {
        this.cord = cord;
    }

    public char getTlchng() {
        return tlchng;
    }

    public void setTlchng(char tlchng) {
        this.tlchng = tlchng;
    }

    public char getFd_type() {
        return fd_type;
    }

    public void setFd_type(char fd_type) {
        this.fd_type = fd_type;
    }

    public int getMcode() {
        return mcode;
    }

    public void setMcode(int mcode) {
        this.mcode = mcode;
    }

    public short getDummy4() {
        return dummy4;
    }

    public void setDummy4(short dummy4) {
        this.dummy4 = dummy4;
    }

    public int getCylndr() {
        return cylndr;
    }

    public void setCylndr(int cylndr) {
        this.cylndr = cylndr;
    }

    public int getAux() {
        return aux;
    }

    public void setAux(int aux) {
        this.aux = aux;
    }

    public int getDcode() {
        return dcode;
    }

    public void setDcode(int dcode) {
        this.dcode = dcode;
    }

    public int getSmax() {
        return smax;
    }

    public void setSmax(int smax) {
        this.smax = smax;
    }

    public int getDwell() {
        return dwell;
    }

    public void setDwell(int dwell) {
        this.dwell = dwell;
    }

    public int getFcode() {
        return fcode;
    }

    public void setFcode(int fcode) {
        this.fcode = fcode;
    }

    public int getScode() {
        return scode;
    }

    public void setScode(int scode) {
        this.scode = scode;
    }

    public char getNummcd() {
        return nummcd;
    }

    public void setNummcd(char nummcd) {
        this.nummcd = nummcd;
    }

    public char getFcddec() {
        return fcddec;
    }

    public void setFcddec(char fcddec) {
        this.fcddec = fcddec;
    }

    public int getShift() {
        return shift;
    }

    public void setShift(int shift) {
        this.shift = shift;
    }

    public char getFbsft() {
        return fbsft;
    }

    public void setFbsft(char fbsft) {
        this.fbsft = fbsft;
    }

    public char getTilt() {
        return tilt;
    }

    public void setTilt(char tilt) {
        this.tilt = tilt;
    }

    public short getDummy6() {
        return dummy6;
    }

    public void setDummy6(short dummy6) {
        this.dummy6 = dummy6;
    }

    public int getMcode2() {
        return mcode2;
    }

    public void setMcode2(int mcode2) {
        this.mcode2 = mcode2;
    }

    public int getMcode3() {
        return mcode3;
    }

    public void setMcode3(int mcode3) {
        this.mcode3 = mcode3;
    }

    public int getMcode4() {
        return mcode4;
    }

    public void setMcode4(int mcode4) {
        this.mcode4 = mcode4;
    }

    public int getMcode5() {
        return mcode5;
    }

    public void setMcode5(int mcode5) {
        this.mcode5 = mcode5;
    }

    public int[] getReserve() {
        return reserve;
    }

    public void setReserve(int[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBSIMUELM2{" +
                "type=" + type +
                ", rot_w=" + rot_w +
                ", type2=" + type2 +
                ", plane=" + plane +
                ", tcode=" + tcode +
                ", data=" + data +
                ", dm_type=" + dm_type +
                ", cssc_md=" + cssc_md +
                ", dm_x=" + Arrays.toString(dm_x) +
                ", dm_y=" + Arrays.toString(dm_y) +
                ", dm_z=" + Arrays.toString(dm_z) +
                ", cnt_x=" + Arrays.toString(cnt_x) +
                ", cord=" + Arrays.toString(cord) +
                ", tlchng=" + tlchng +
                ", fd_type=" + fd_type +
                ", mcode=" + mcode +
                ", dummy4=" + dummy4 +
                ", cylndr=" + cylndr +
                ", aux=" + aux +
                ", dcode=" + dcode +
                ", smax=" + smax +
                ", dwell=" + dwell +
                ", fcode=" + fcode +
                ", scode=" + scode +
                ", nummcd=" + nummcd +
                ", fcddec=" + fcddec +
                ", shift=" + shift +
                ", fbsft=" + fbsft +
                ", tilt=" + tilt +
                ", dummy6=" + dummy6 +
                ", mcode2=" + mcode2 +
                ", mcode3=" + mcode3 +
                ", mcode4=" + mcode4 +
                ", mcode5=" + mcode5 +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
