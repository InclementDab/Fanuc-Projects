package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBSIG3 {
    private short datano;
    private short type;

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public static class DATA {
        private short ent_no;
        private short pmc_no;
        private short sig_no;
        private byte sig_name;
        private byte mask_pat;

        public short getEnt_no() {
            return ent_no;
        }

        public void setEnt_no(short ent_no) {
            this.ent_no = ent_no;
        }

        public short getPmc_no() {
            return pmc_no;
        }

        public void setPmc_no(short pmc_no) {
            this.pmc_no = pmc_no;
        }

        public short getSig_no() {
            return sig_no;
        }

        public void setSig_no(short sig_no) {
            this.sig_no = sig_no;
        }

        public byte getSig_name() {
            return sig_name;
        }

        public void setSig_name(byte sig_name) {
            this.sig_name = sig_name;
        }

        public byte getMask_pat() {
            return mask_pat;
        }

        public void setMask_pat(byte mask_pat) {
            this.mask_pat = mask_pat;
        }

        @Override
        public String toString() {
            return "DATA{" +
                    "ent_no=" + ent_no +
                    ", pmc_no=" + pmc_no +
                    ", sig_no=" + sig_no +
                    ", sig_name=" + sig_name +
                    ", mask_pat=" + mask_pat +
                    '}';
        }
    }
    private DATA data[];

    public DATA[] getData() {
        return data;
    }

    public void setData(DATA[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBSIG3{" +
                "datano=" + datano +
                ", type=" + type +
                ", data=" + Arrays.toString(data) +
                '}';
    }

    public void Dispose(){
        data = null;
    }
}
