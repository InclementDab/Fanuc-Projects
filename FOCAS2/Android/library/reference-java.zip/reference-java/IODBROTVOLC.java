package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBROTVOLC {
    private int lin[];
    private int rot[];

    public int[] getLin() {
        return lin;
    }

    public void setLin(int[] lin) {
        this.lin = lin;
    }

    public int[] getRot() {

        return rot;
    }

    public void setRot(int[] rot) {
        this.rot = rot;
    }

    @Override
    public String toString() {
        return "IODBROTVOLC{" +
                "lin=" + Arrays.toString(lin) +
                ", rot=" + Arrays.toString(rot) +
                '}';
    }

    public void Dispose() {
        lin = null;
        rot = null;
    }
}
