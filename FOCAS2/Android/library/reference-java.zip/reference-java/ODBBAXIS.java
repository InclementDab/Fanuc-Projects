package jp.co.fanuc.fwlibe1;


public class ODBBAXIS {
    private short flag;
    private short command;
    private short speed;
    private int sub_data;

    public short getFlag() {
        return flag;
    }

    public void setFlag(short flag) {
        this.flag = flag;
    }

    public short getCommand() {
        return command;
    }

    public void setCommand(short command) {
        this.command = command;
    }

    public short getSpeed() {
        return speed;
    }

    public void setSpeed(short speed) {
        this.speed = speed;
    }

    public int getSub_data() {
        return sub_data;
    }

    public void setSub_data(int sub_data) {
        this.sub_data = sub_data;
    }

    @Override
    public String toString() {
        return "ODBBAXIS{" +
                "flag=" + flag +
                ", command=" + command +
                ", speed=" + speed +
                ", sub_data=" + sub_data +
                '}';
    }
}
