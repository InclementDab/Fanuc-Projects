package jp.co.fanuc.fwlibe1;


public class ODBAXDT {
    private String name;
    private int data;
    private short dec;
    private short unit;
    private short flag;
    private short reserve;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getData() {

        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    public short getDec() {

        return dec;
    }

    public void setDec(short dec) {
        this.dec = dec;
    }

    public short getUnit() {

        return unit;
    }

    public void setUnit(short unit) {
        this.unit = unit;
    }

    public short getFlag() {

        return flag;
    }

    public void setFlag(short flag) {
        this.flag = flag;
    }

    public short getReserve() {

        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "ODBAXDT{" +
                "name=" + name +
                ", data=" + data +
                ", dec=" + dec +
                ", unit=" + unit +
                ", flag=" + flag +
                ", reserve=" + reserve +
                '}';
    }
}
