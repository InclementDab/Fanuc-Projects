package jp.co.fanuc.fwlibe1;


public class ODBINF {
    private short max_shape_num;
    private short max_tool_num;
    private short max_holder_num;
    private short max_object_num;
    private short max_element_num;
    private short max_holder_shpnum;
    private short max_object_shpnum;
    private short reserve;

    public short getMax_shape_num() {
        return max_shape_num;
    }

    public void setMax_shape_num(short max_shape_num) {
        this.max_shape_num = max_shape_num;
    }

    public short getMax_tool_num() {
        return max_tool_num;
    }

    public void setMax_tool_num(short max_tool_num) {
        this.max_tool_num = max_tool_num;
    }

    public short getMax_holder_num() {
        return max_holder_num;
    }

    public void setMax_holder_num(short max_holder_num) {
        this.max_holder_num = max_holder_num;
    }

    public short getMax_object_num() {
        return max_object_num;
    }

    public void setMax_object_num(short max_object_num) {
        this.max_object_num = max_object_num;
    }

    public short getMax_element_num() {
        return max_element_num;
    }

    public void setMax_element_num(short max_element_num) {
        this.max_element_num = max_element_num;
    }

    public short getMax_holder_shpnum() {
        return max_holder_shpnum;
    }

    public void setMax_holder_shpnum(short max_holder_shpnum) {
        this.max_holder_shpnum = max_holder_shpnum;
    }

    public short getMax_object_shpnum() {
        return max_object_shpnum;
    }

    public void setMax_object_shpnum(short max_object_shpnum) {
        this.max_object_shpnum = max_object_shpnum;
    }

    public short getReserve() {
        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "ODBINF{" +
                "max_shape_num=" + max_shape_num +
                ", max_tool_num=" + max_tool_num +
                ", max_holder_num=" + max_holder_num +
                ", max_object_num=" + max_object_num +
                ", max_element_num=" + max_element_num +
                ", max_holder_shpnum=" + max_holder_shpnum +
                ", max_object_shpnum=" + max_object_shpnum +
                ", reserve=" + reserve +
                '}';
    }
}
