package jp.co.fanuc.fwlibe1;


public class IODBTLMGR_CHECK {
    private int T_code;
    private short tool_num;
    private short reserve;

    public int getT_code() {
        return T_code;
    }

    public void setT_code(int t_code) {
        T_code = t_code;
    }

    public short getTool_num() {
        return tool_num;
    }

    public void setTool_num(short tool_num) {
        this.tool_num = tool_num;
    }

    public short getReserve() {
        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBTLMGR_CHECK{" +
                "T_code=" + T_code +
                ", tool_num=" + tool_num +
                ", reserve=" + reserve +
                '}';
    }
}
