package jp.co.fanuc.fwlibe1;


public class IDBSDTTRG {
    private int seq_no;
    private PMC_DATA pmc_flg;

    public int getSeq_no() {
        return seq_no;
    }

    public void setSeq_no(int seq_no) {
        this.seq_no = seq_no;
    }

    public PMC_DATA getPmc_flg() {
        return pmc_flg;
    }

    public void setPmc_flg(PMC_DATA pmc_flg) {
        this.pmc_flg = pmc_flg;
    }

    @Override
    public String toString() {
        return "IDBSDTTRG{" +
                "seq_no=" + seq_no +
                ", pmc_flg=" + pmc_flg +
                '}';
    }
}
