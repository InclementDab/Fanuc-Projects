package jp.co.fanuc.fwlibe1;


public class IDBTLMGR_ADD_INFO {
    private int dsp_info;
    private short data_kind;

    public int getDsp_info() {
        return dsp_info;
    }

    public void setDsp_info(int dsp_info) {
        this.dsp_info = dsp_info;
    }

    public short getData_kind() {
        return data_kind;
    }

    public void setData_kind(short data_kind) {
        this.data_kind = data_kind;
    }

    @Override
    public String toString() {
        return "IDBTLMGR_ADD_INFO{" +
                "dsp_info=" + dsp_info +
                ", data_kind=" + data_kind +
                '}';
    }
}
