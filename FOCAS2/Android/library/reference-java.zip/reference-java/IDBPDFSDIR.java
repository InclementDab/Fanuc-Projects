package jp.co.fanuc.fwlibe1;


public class IDBPDFSDIR {
    private String path;
    private short req_num;
    private short dummy;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public short getReq_num() {

        return req_num;
    }

    public void setReq_num(short req_num) {
        this.req_num = req_num;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "IDBPDFSDIR{" +
                "path=" + path +
                ", req_num=" + req_num +
                ", dummy=" + dummy +
                '}';
    }
}
