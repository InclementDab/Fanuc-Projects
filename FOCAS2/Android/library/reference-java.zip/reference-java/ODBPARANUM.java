package jp.co.fanuc.fwlibe1;


public class ODBPARANUM {
    private short para_min;
    private short para_max;
    private short total_no;

    public short getPara_min() {
        return para_min;
    }

    public void setPara_min(short para_min) {
        this.para_min = para_min;
    }

    public short getPara_max() {
        return para_max;
    }

    public void setPara_max(short para_max) {
        this.para_max = para_max;
    }

    public short getTotal_no() {
        return total_no;
    }

    public void setTotal_no(short total_no) {
        this.total_no = total_no;
    }

    @Override
    public String toString() {
        return "ODBPARANUM{" +
                "para_min=" + para_min +
                ", para_max=" + para_max +
                ", total_no=" + total_no +
                '}';
    }
}
