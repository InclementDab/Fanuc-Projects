package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_EIPS_CONN_PRM_FLG {
    private char AssemblyInstance;
    private char Type;
    private char Addr;
    private char Size;
    private char RPI;
    private char TransportType;
    private char HeaderFormat;
    private char Priority;
    private char reserve;
    private char pad[];

    public char getAssemblyInstance() {
        return AssemblyInstance;
    }

    public void setAssemblyInstance(char assemblyInstance) {
        AssemblyInstance = assemblyInstance;
    }

    public char getType() {
        return Type;
    }

    public void setType(char type) {
        Type = type;
    }

    public char getAddr() {
        return Addr;
    }

    public void setAddr(char addr) {
        Addr = addr;
    }

    public char getSize() {
        return Size;
    }

    public void setSize(char size) {
        Size = size;
    }

    public char getRPI() {
        return RPI;
    }

    public void setRPI(char RPI) {
        this.RPI = RPI;
    }

    public char getTransportType() {
        return TransportType;
    }

    public void setTransportType(char transportType) {
        TransportType = transportType;
    }

    public char getHeaderFormat() {
        return HeaderFormat;
    }

    public void setHeaderFormat(char headerFormat) {
        HeaderFormat = headerFormat;
    }

    public char getPriority() {
        return Priority;
    }

    public void setPriority(char priority) {
        Priority = priority;
    }

    public char getReserve() {
        return reserve;
    }

    public void setReserve(char reserve) {
        this.reserve = reserve;
    }

    public char[] getPad() {
        return pad;
    }

    public void setPad(char[] pad) {
        this.pad = pad;
    }

    @Override
    public String toString() {
        return "IN_EIPS_CONN_PRM_FLG{" +
                "AssemblyInstance=" + AssemblyInstance +
                ", Type=" + Type +
                ", Addr=" + Addr +
                ", Size=" + Size +
                ", RPI=" + RPI +
                ", TransportType=" + TransportType +
                ", HeaderFormat=" + HeaderFormat +
                ", Priority=" + Priority +
                ", reserve=" + reserve +
                ", pad=" + Arrays.toString(pad) +
                '}';
    }
}
