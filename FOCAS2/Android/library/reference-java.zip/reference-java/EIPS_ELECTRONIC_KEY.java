package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class EIPS_ELECTRONIC_KEY {
    private short VendorID;
    private short DeviceType;
    private short ProductCode;
    private char MajorRevision;
    private char MinorRevisiom;
    private char Compatibility;
    private char pad[];

    public short getVendorID() {
        return VendorID;
    }

    public void setVendorID(short vendorID) {
        VendorID = vendorID;
    }

    public short getDeviceType() {
        return DeviceType;
    }

    public void setDeviceType(short deviceType) {
        DeviceType = deviceType;
    }

    public short getProductCode() {
        return ProductCode;
    }

    public void setProductCode(short productCode) {
        ProductCode = productCode;
    }

    public char getMajorRevision() {
        return MajorRevision;
    }

    public void setMajorRevision(char majorRevision) {
        MajorRevision = majorRevision;
    }

    public char getMinorRevisiom() {
        return MinorRevisiom;
    }

    public void setMinorRevisiom(char minorRevisiom) {
        MinorRevisiom = minorRevisiom;
    }

    public char getCompatibility() {
        return Compatibility;
    }

    public void setCompatibility(char compatibility) {
        Compatibility = compatibility;
    }

    public char[] getPad() {
        return pad;
    }

    public void setPad(char[] pad) {
        this.pad = pad;
    }

    @Override
    public String toString() {
        return "EIPS_ELECTRONIC_KEY{" +
                "VendorID=" + VendorID +
                ", DeviceType=" + DeviceType +
                ", ProductCode=" + ProductCode +
                ", MajorRevision=" + MajorRevision +
                ", MinorRevisiom=" + MinorRevisiom +
                ", Compatibility=" + Compatibility +
                ", pad=" + Arrays.toString(pad) +
                '}';
    }
}
