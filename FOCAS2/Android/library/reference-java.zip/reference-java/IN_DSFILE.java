package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_DSFILE {
    private String path;
    private int fnum;
    private int offset;
    private short req_num;
    private short size_type;
    private short detail;
    private short dummy;

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getFnum() {

        return fnum;
    }

    public void setFnum(int fnum) {
        this.fnum = fnum;
    }

    public int getOffset() {

        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public short getReq_num() {

        return req_num;
    }

    public void setReq_num(short req_num) {
        this.req_num = req_num;
    }

    public short getSize_type() {

        return size_type;
    }

    public void setSize_type(short size_type) {
        this.size_type = size_type;
    }

    public short getDetail() {

        return detail;
    }

    public void setDetail(short detail) {
        this.detail = detail;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "IN_DSFILE{" +
                "path=" + path +
                ", fnum=" + fnum +
                ", offset=" + offset +
                ", req_num=" + req_num +
                ", size_type=" + size_type +
                ", detail=" + detail +
                ", dummy=" + dummy +
                '}';
    }
}
