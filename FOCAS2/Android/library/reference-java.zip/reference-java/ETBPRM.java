package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ETBPRM {
    private char OwnMACAddress[];
    private short MaximumChannel;
    private short HDDExistence;
    private short NumberOfScreens;

    public char[] getOwnMACAddress() {
        return OwnMACAddress;
    }

    public void setOwnMACAddress(char[] ownMACAddress) {
        OwnMACAddress = ownMACAddress;
    }

    public short getMaximumChannel() {
        return MaximumChannel;
    }

    public void setMaximumChannel(short maximumChannel) {
        MaximumChannel = maximumChannel;
    }

    public short getHDDExistence() {
        return HDDExistence;
    }

    public void setHDDExistence(short HDDExistence) {
        this.HDDExistence = HDDExistence;
    }

    public short getNumberOfScreens() {
        return NumberOfScreens;
    }

    public void setNumberOfScreens(short numberOfScreens) {
        NumberOfScreens = numberOfScreens;
    }

    @Override
    public String toString() {
        return "ETBPRM{" +
                "OwnMACAddress=" + Arrays.toString(OwnMACAddress) +
                ", MaximumChannel=" + MaximumChannel +
                ", HDDExistence=" + HDDExistence +
                ", NumberOfScreens=" + NumberOfScreens +
                '}';
    }
}
