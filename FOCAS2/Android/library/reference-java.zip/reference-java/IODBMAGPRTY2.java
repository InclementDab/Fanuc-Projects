package jp.co.fanuc.fwlibe1;


public class IODBMAGPRTY2 {
    private short mag;
    private short reserve;

    public short getMag() {
        return mag;
    }

    public void setMag(short mag) {
        this.mag = mag;
    }

    public short getReserve() {
        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBMAGPRTY2{" +
                "mag=" + mag +
                ", reserve=" + reserve +
                '}';
    }
}
