package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class DTSVR_PRM {
    private FTP_CLIENT_PRM opposite[];
    private FTP_SERVER_PRM own[];

    public FTP_CLIENT_PRM[] getOpposite() {
        return opposite;
    }

    public void setOpposite(FTP_CLIENT_PRM[] opposite) {
        this.opposite = opposite;
    }

    public FTP_SERVER_PRM[] getOwn() {
        return own;
    }

    public void setOwn(FTP_SERVER_PRM[] own) {
        this.own = own;
    }

    @Override
    public String toString() {
        return "DTSVR_PRM{" +
                "opposite=" + Arrays.toString(opposite) +
                ", own=" + Arrays.toString(own) +
                '}';
    }
}
