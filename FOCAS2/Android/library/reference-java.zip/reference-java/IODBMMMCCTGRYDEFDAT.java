package jp.co.fanuc.fwlibe1;


public class IODBMMMCCTGRYDEFDAT {
    private int cmsg_id;

    public int getCmsg_id() {
        return cmsg_id;
    }

    public void setCmsg_id(int cmsg_id) {
        this.cmsg_id = cmsg_id;
    }

    @Override
    public String toString() {
        return "IODBMMMCCTGRYDEFDAT{" +
                "cmsg_id=" + cmsg_id +
                '}';
    }
}
