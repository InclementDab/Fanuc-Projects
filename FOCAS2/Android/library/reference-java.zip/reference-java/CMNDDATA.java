package jp.co.fanuc.fwlibe1;


public class CMNDDATA {
    private double val;
    private int dec;
    private int dummy;

    public double getVal() {
        return val;
    }

    public void setVal(double val) {
        this.val = val;
    }

    public int getDec() {
        return dec;
    }

    public void setDec(int dec) {
        this.dec = dec;
    }

    public int getDummy() {
        return dummy;
    }

    public void setDummy(int dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "CMNDDATA{" +
                "val=" + val +
                ", dec=" + dec +
                ", dummy=" + dummy +
                '}';
    }
}
