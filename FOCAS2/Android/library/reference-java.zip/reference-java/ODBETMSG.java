package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBETMSG {
    private char title[];
    private char message[][];

    public char[] getTitle() {
        return title;
    }

    public void setTitle(char[] title) {
        this.title = title;
    }

    public char[][] getMessage() {
        return message;
    }

    public void setMessage(char[][] message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "ODBETMSG{" +
                "title=" + Arrays.toString(title) +
                ", message=" + Arrays.toString(message) +
                '}';
    }
}
