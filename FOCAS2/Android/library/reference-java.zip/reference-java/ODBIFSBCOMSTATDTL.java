package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBCOMSTATDTL {
    private int error_inf;
    private int jitter_inf;
    private char n_warning;
    private char j_warning;
    private char reserve[];

    public int getError_inf() {
        return error_inf;
    }

    public void setError_inf(int error_inf) {
        this.error_inf = error_inf;
    }

    public int getJitter_inf() {
        return jitter_inf;
    }

    public void setJitter_inf(int jitter_inf) {
        this.jitter_inf = jitter_inf;
    }

    public char getN_warning() {
        return n_warning;
    }

    public void setN_warning(char n_warning) {
        this.n_warning = n_warning;
    }

    public char getJ_warning() {
        return j_warning;
    }

    public void setJ_warning(char j_warning) {
        this.j_warning = j_warning;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "ODBIFSBCOMSTATDTL{" +
                "error_inf=" + error_inf +
                ", jitter_inf=" + jitter_inf +
                ", n_warning=" + n_warning +
                ", j_warning=" + j_warning +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
