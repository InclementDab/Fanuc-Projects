package jp.co.fanuc.fwlibe1;


public class ODBOMIF {
    private short om_max;
    private short om_sum;
    private short om_char;

    public short getOm_max() {
        return om_max;
    }

    public void setOm_max(short om_max) {
        this.om_max = om_max;
    }

    public short getOm_sum() {
        return om_sum;
    }

    public void setOm_sum(short om_sum) {
        this.om_sum = om_sum;
    }

    public short getOm_char() {
        return om_char;
    }

    public void setOm_char(short om_char) {
        this.om_char = om_char;
    }

    @Override
    public String toString() {
        return "ODBOMIF{" +
                "om_max=" + om_max +
                ", om_sum=" + om_sum +
                ", om_char=" + om_char +
                '}';
    }
}
