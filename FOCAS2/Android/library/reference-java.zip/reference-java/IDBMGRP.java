package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBMGRP {
    private short s_no;
    private short dummy;
    private short num;
    private short group[];

    public short getS_no() {
        return s_no;
    }

    public void setS_no(short s_no) {
        this.s_no = s_no;
    }

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public short getNum() {
        return num;
    }

    public void setNum(short num) {
        this.num = num;
    }

    public short[] getGroup() {
        return group;
    }

    public void setGroup(short[] group) {
        this.group = group;
    }

    @Override
    public String toString() {
        return "IDBMGRP{" +
                "s_no=" + s_no +
                ", dummy=" + dummy +
                ", num=" + num +
                ", group=" + Arrays.toString(group) +
                '}';
    }

    public void Dispose() {
        group = null;
    }
}
