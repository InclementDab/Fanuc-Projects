package jp.co.fanuc.fwlibe1;


public class ODBOFSLEN {
    private int len;
    private int dec;

    public int getLen() {
        return len;
    }

    public void setLen(int len) {
        this.len = len;
    }

    public int getDec() {
        return dec;
    }

    public void setDec(int dec) {
        this.dec = dec;
    }

    @Override
    public String toString() {
        return "ODBOFSLEN{" +
                "len=" + len +
                ", dec=" + dec +
                '}';
    }
}
