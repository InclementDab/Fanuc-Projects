package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBCOORD {
    private int orign[];
    private short vec_x[];
    private short vec_y[];
    private short vec_z[];

    public int[] getOrign() {
        return orign;
    }

    public void setOrign(int[] orign) {
        this.orign = orign;
    }

    public short[] getVec_x() {
        return vec_x;
    }

    public void setVec_x(short[] vec_x) {
        this.vec_x = vec_x;
    }

    public short[] getVec_y() {
        return vec_y;
    }

    public void setVec_y(short[] vec_y) {
        this.vec_y = vec_y;
    }

    public short[] getVec_z() {
        return vec_z;
    }

    public void setVec_z(short[] vec_z) {
        this.vec_z = vec_z;
    }

    @Override
    public String toString() {
        return "ODBCOORD{" +
                "orign=" + Arrays.toString(orign) +
                ", vec_x=" + Arrays.toString(vec_x) +
                ", vec_y=" + Arrays.toString(vec_y) +
                ", vec_z=" + Arrays.toString(vec_z) +
                '}';
    }
}
