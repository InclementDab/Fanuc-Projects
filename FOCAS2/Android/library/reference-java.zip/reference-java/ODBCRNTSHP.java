package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBCRNTSHP {
    private int fig_type;
    private int reserve;

    public int getFig_type() {
        return fig_type;
    }

    public void setFig_type(int fig_type) {
        this.fig_type = fig_type;
    }

    public int getReserve() {
        return reserve;
    }

    public void setReserve(int reserve) {
        this.reserve = reserve;
    }

    public static class FIG {
        public static class PAR {
            private double base_pos[];
            private double vect1[];
            private double vect2[];
            private double vect3[];

            public double[] getBase_pos() {
                return base_pos;
            }

            public void setBase_pos(double[] base_pos) {
                this.base_pos = base_pos;
            }

            public double[] getVect1() {
                return vect1;
            }

            public void setVect1(double[] vect1) {
                this.vect1 = vect1;
            }

            public double[] getVect2() {
                return vect2;
            }

            public void setVect2(double[] vect2) {
                this.vect2 = vect2;
            }

            public double[] getVect3() {
                return vect3;
            }

            public void setVect3(double[] vect3) {
                this.vect3 = vect3;
            }

            @Override
            public String toString() {
                return "PAR{" +
                        "base_pos=" + Arrays.toString(base_pos) +
                        ", vect1=" + Arrays.toString(vect1) +
                        ", vect2=" + Arrays.toString(vect2) +
                        ", vect3=" + Arrays.toString(vect3) +
                        '}';
            }
        }

        public static class CYL {
            private double vect1[];
            private double vect2[];
            private double v;

            public double[] getVect1() {
                return vect1;
            }

            public void setVect1(double[] vect1) {
                this.vect1 = vect1;
            }

            public double[] getVect2() {
                return vect2;
            }

            public void setVect2(double[] vect2) {
                this.vect2 = vect2;
            }

            public double getV() {
                return v;
            }

            public void setV(double v) {
                this.v = v;
            }

            @Override
            public String toString() {
                return "CYL{" +
                        "vect1=" + Arrays.toString(vect1) +
                        ", vect2=" + Arrays.toString(vect2) +
                        ", v=" + v +
                        '}';
            }
        }

        public static class PLN {
            private double point[];
            private double vect[];

            public double[] getPoint() {
                return point;
            }

            public void setPoint(double[] point) {
                this.point = point;
            }

            public double[] getVect() {
                return vect;
            }

            public void setVect(double[] vect) {
                this.vect = vect;
            }

            @Override
            public String toString() {
                return "PLN{" +
                        "point=" + Arrays.toString(point) +
                        ", vect=" + Arrays.toString(vect) +
                        '}';
            }
        }

        private PAR par;
        private CYL cyl;
        private PLN pln;

        public PAR getPar() {
            return par;
        }

        public void setPar(PAR par) {
            this.par = par;
        }

        public CYL getCyl() {
            return cyl;
        }

        public void setCyl(CYL cyl) {
            this.cyl = cyl;
        }

        public PLN getPln() {
            return pln;
        }

        public void setPln(PLN pln) {
            this.pln = pln;
        }

        @Override
        public String toString() {
            return "FIG{" +
                    "par=" + par +
                    ", cyl=" + cyl +
                    ", pln=" + pln +
                    '}';
        }
    }

    private FIG fig;

    public FIG getFig() {
        return fig;
    }

    public void setFig(FIG fig) {
        this.fig = fig;
    }

    private char cb_form;
    private char reserve2[];

    public char getCb_form() {
        return cb_form;
    }

    public void setCb_form(char cb_form) {
        this.cb_form = cb_form;
    }

    public char[] getReserve2() {
        return reserve2;
    }

    public void setReserve2(char[] reserve2) {
        this.reserve2 = reserve2;
    }

    @Override
    public String toString() {
        return "ODBCRNTSHP{" +
                "fig_type=" + fig_type +
                ", reserve=" + reserve +
                ", fig=" + fig +
                ", cb_form=" + cb_form +
                ", reserve2=" + Arrays.toString(reserve2) +
                '}';
    }
}
