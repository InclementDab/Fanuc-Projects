package jp.co.fanuc.fwlibe1;


public class IODBTLMGR_PAGE {
    public static class INFO {
        IODBTLMGR_EDG edg;

        public IODBTLMGR_EDG getEdg() {
            return edg;
        }

        public void setEdg(IODBTLMGR_EDG edg) {
            this.edg = edg;
        }

        public static class PAGE {
            private IODBTLMGR_EDG s_edg;
            private IODBTLMGR_EDG e_edg;

            public IODBTLMGR_EDG getS_edg() {
                return s_edg;
            }

            public void setS_edg(IODBTLMGR_EDG s_edg) {
                this.s_edg = s_edg;
            }

            public IODBTLMGR_EDG getE_edg() {
                return e_edg;
            }

            public void setE_edg(IODBTLMGR_EDG e_edg) {
                this.e_edg = e_edg;
            }

            @Override
            public String toString() {
                return "PAGE{" +
                        "s_edg=" + s_edg +
                        ", e_edg=" + e_edg +
                        '}';
            }
        }
        private PAGE page;

        public PAGE getPage() {
            return page;
        }

        public void setPage(PAGE page) {
            this.page = page;
        }

        @Override
        public String toString() {
            return "INFO{" +
                    "edg=" + edg +
                    ", page=" + page +
                    '}';
        }
    }
    private INFO info;

    public INFO getInfo() {
        return info;
    }

    public void setInfo(INFO info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "IODBTLMGR_PAGE{" +
                "info=" + info +
                '}';
    }
}
