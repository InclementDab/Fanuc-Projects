package jp.co.fanuc.fwlibe1;


public class IDBCHAN {
    private char chno;
    private char axis;
    private int datanum;
    private short datainf;
    private short dataadr;

    public char getChno() {
        return chno;
    }

    public void setChno(char chno) {
        this.chno = chno;
    }

    public char getAxis() {
        return axis;
    }

    public void setAxis(char axis) {
        this.axis = axis;
    }

    public int getDatanum() {
        return datanum;
    }

    public void setDatanum(int datanum) {
        this.datanum = datanum;
    }

    public short getDatainf() {
        return datainf;
    }

    public void setDatainf(short datainf) {
        this.datainf = datainf;
    }

    public short getDataadr() {
        return dataadr;
    }

    public void setDataadr(short dataadr) {
        this.dataadr = dataadr;
    }

    @Override
    public String toString() {
        return "IDBCHAN{" +
                "chno=" + chno +
                ", axis=" + axis +
                ", datanum=" + datanum +
                ", datainf=" + datainf +
                ", dataadr=" + dataadr +
                '}';
    }
}
