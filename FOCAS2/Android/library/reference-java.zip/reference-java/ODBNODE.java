package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBNODE {
    private int node_no;
    private int io_base;
    private int status;
    private int cnc_type;
    private char node_name[];

    public int getNode_no() {
        return node_no;
    }

    public void setNode_no(int node_no) {
        this.node_no = node_no;
    }

    public int getIo_base() {
        return io_base;
    }

    public void setIo_base(int io_base) {
        this.io_base = io_base;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getCnc_type() {
        return cnc_type;
    }

    public void setCnc_type(int cnc_type) {
        this.cnc_type = cnc_type;
    }

    public char[] getNode_name() {
        return node_name;
    }

    public void setNode_name(char[] node_name) {
        this.node_name = node_name;
    }

    @Override
    public String toString() {
        return "ODBNODE{" +
                "node_no=" + node_no +
                ", io_base=" + io_base +
                ", status=" + status +
                ", cnc_type=" + cnc_type +
                ", node_name=" + Arrays.toString(node_name) +
                '}';
    }
}
