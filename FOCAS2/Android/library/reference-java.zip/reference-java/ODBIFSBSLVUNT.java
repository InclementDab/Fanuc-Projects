package jp.co.fanuc.fwlibe1;


public class ODBIFSBSLVUNT {
    private short slv_unt_num;
    private char kind;
    private char attrb;

    public short getSlv_unt_num() {
        return slv_unt_num;
    }

    public void setSlv_unt_num(short slv_unt_num) {
        this.slv_unt_num = slv_unt_num;
    }

    public char getKind() {
        return kind;
    }

    public void setKind(char kind) {
        this.kind = kind;
    }

    public char getAttrb() {
        return attrb;
    }

    public void setAttrb(char attrb) {
        this.attrb = attrb;
    }

    @Override
    public String toString() {
        return "ODBIFSBSLVUNT{" +
                "slv_unt_num=" + slv_unt_num +
                ", kind=" + kind +
                ", attrb=" + attrb +
                '}';
    }
}
