package jp.co.fanuc.fwlibe1;


public class IN_PND_PARAM {
    private PND_PARAM_FLG           flg;
    private PND_PARAM               prm;

    public PND_PARAM_FLG getFlg() {
        return flg;
    }

    public void setFlg(PND_PARAM_FLG flg) {
        this.flg = flg;
    }

    public PND_PARAM getPrm() {
        return prm;
    }

    public void setPrm(PND_PARAM prm) {
        this.prm = prm;
    }

    @Override
    public String toString() {
        return "IN_PND_PARAM{" +
                "flg=" + flg +
                ", prm=" + prm +
                '}';
    }
}
