package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBAHIS {
    private short s_no;
    private short type;
    private short e_no;

    public short getS_no() {
        return s_no;
    }

    public void setS_no(short s_no) {
        this.s_no = s_no;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getE_no() {
        return e_no;
    }

    public void setE_no(short e_no) {
        this.e_no = e_no;
    }

    public static class ALM_HIS {
        private short dummy;
        private short alm_grp;
        private short alm_no;
        private char axis_no;
        private char year;
        private char month;
        private char day;
        private char hour;
        private char minute;
        private char second;
        private char dummy2;
        private short lem_msg;
        private char alm_msg[];

        public short getDummy() {
            return dummy;
        }

        public void setDummy(short dummy) {
            this.dummy = dummy;
        }

        public short getAlm_grp() {
            return alm_grp;
        }

        public void setAlm_grp(short alm_grp) {
            this.alm_grp = alm_grp;
        }

        public short getAlm_no() {
            return alm_no;
        }

        public void setAlm_no(short alm_no) {
            this.alm_no = alm_no;
        }

        public char getAxis_no() {
            return axis_no;
        }

        public void setAxis_no(char axis_no) {
            this.axis_no = axis_no;
        }

        public char getYear() {
            return year;
        }

        public void setYear(char year) {
            this.year = year;
        }

        public char getMonth() {
            return month;
        }

        public void setMonth(char month) {
            this.month = month;
        }

        public char getDay() {
            return day;
        }

        public void setDay(char day) {
            this.day = day;
        }

        public char getHour() {
            return hour;
        }

        public void setHour(char hour) {
            this.hour = hour;
        }

        public char getMinute() {
            return minute;
        }

        public void setMinute(char minute) {
            this.minute = minute;
        }

        public char getSecond() {
            return second;
        }

        public void setSecond(char second) {
            this.second = second;
        }

        public char getDummy2() {
            return dummy2;
        }

        public void setDummy2(char dummy2) {
            this.dummy2 = dummy2;
        }

        public short getLem_msg() {
            return lem_msg;
        }

        public void setLem_msg(short lem_msg) {
            this.lem_msg = lem_msg;
        }

        public char[] getAlm_msg() {
            return alm_msg;
        }

        public void setAlm_msg(char[] alm_msg) {
            this.alm_msg = alm_msg;
        }

        @Override
        public String toString() {
            return "ALM_HIS{" +
                    "dummy=" + dummy +
                    ", alm_grp=" + alm_grp +
                    ", alm_no=" + alm_no +
                    ", axis_no=" + axis_no +
                    ", year=" + year +
                    ", month=" + month +
                    ", day=" + day +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", dummy2=" + dummy2 +
                    ", lem_msg=" + lem_msg +
                    ", alm_msg=" + Arrays.toString(alm_msg) +
                    '}';
        }
    }
    private ALM_HIS alm_his[];

    public ALM_HIS[] getAlm_his() {
        return alm_his;
    }

    public void setAlm_his(ALM_HIS[] alm_his) {
        this.alm_his = alm_his;
    }

    @Override
    public String toString() {
        return "ODBAHIS{" +
                "s_no=" + s_no +
                ", type=" + type +
                ", e_no=" + e_no +
                ", alm_his=" + Arrays.toString(alm_his) +
                '}';
    }
}
