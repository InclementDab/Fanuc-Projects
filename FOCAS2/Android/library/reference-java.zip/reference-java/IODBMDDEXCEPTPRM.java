package jp.co.fanuc.fwlibe1;


public class IODBMDDEXCEPTPRM {
    private int sno;
    private int eno;

    public int getSno() {
        return sno;
    }

    public void setSno(int sno) {
        this.sno = sno;
    }

    public int getEno() {
        return eno;
    }

    public void setEno(int eno) {
        this.eno = eno;
    }

    @Override
    public String toString() {
        return "IODBMDDEXCEPTPRM{" +
                "sno=" + sno +
                ", eno=" + eno +
                '}';
    }
}
