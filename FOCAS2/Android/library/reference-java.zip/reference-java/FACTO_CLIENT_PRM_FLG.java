package jp.co.fanuc.fwlibe1;


public class FACTO_CLIENT_PRM_FLG {
    private char HostName;
    private char Port;

    public char getHostName() {
        return HostName;
    }

    public void setHostName(char hostName) {
        HostName = hostName;
    }

    public char getPort() {
        return Port;
    }

    public void setPort(char port) {
        Port = port;
    }

    @Override
    public String toString() {
        return "FACTO_CLIENT_PRM_FLG{" +
                "HostName=" + HostName +
                ", Port=" + Port +
                '}';
    }
}
