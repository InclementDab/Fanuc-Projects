package jp.co.fanuc.fwlibe1;


public class ODBMDGDT {
    private ODBMDGVAL dt;
    private short fp;
    private short reserved;

    public ODBMDGVAL getDt() {
        return dt;
    }

    public void setDt(ODBMDGVAL dt) {
        this.dt = dt;
    }

    public short getFp() {
        return fp;
    }

    public void setFp(short fp) {
        this.fp = fp;
    }

    public short getReserved() {
        return reserved;
    }

    public void setReserved(short reserved) {
        this.reserved = reserved;
    }

    @Override
    public String toString() {
        return "ODBMDGDT{" +
                "dt=" + dt +
                ", fp=" + fp +
                ", reserved=" + reserved +
                '}';
    }
}
