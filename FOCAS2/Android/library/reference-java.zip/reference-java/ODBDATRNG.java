package jp.co.fanuc.fwlibe1;


public class ODBDATRNG {
    private int data_min;
    private int data_max;
    private int status;

    public int getData_min() {
        return data_min;
    }

    public void setData_min(int data_min) {
        this.data_min = data_min;
    }

    public int getData_max() {

        return data_max;
    }

    public void setData_max(int data_max) {
        this.data_max = data_max;
    }

    public int getStatus() {

        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "ODBDATRNG{" +
                "data_min=" + data_min +
                ", data_max=" + data_max +
                ", status=" + status +
                '}';
    }
}
