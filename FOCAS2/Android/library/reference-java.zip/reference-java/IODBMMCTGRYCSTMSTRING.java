package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBMMCTGRYCSTMSTRING {
    private char string[];
    private char reserve[];

    public char[] getString() {
        return string;
    }

    public void setString(char[] string) {
        this.string = string;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBMMCTGRYCSTMSTRING{" +
                "string=" + Arrays.toString(string) +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
