package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class DTSVR_PRM_FLG {
    private FTP_CLIENT_PRM_FLG opposite[];
    private FTP_SERVER_PRM_FLG own;

    public FTP_CLIENT_PRM_FLG[] getOpposite() {
        return opposite;
    }

    public void setOpposite(FTP_CLIENT_PRM_FLG[] opposite) {
        this.opposite = opposite;
    }

    public FTP_SERVER_PRM_FLG getOwn() {
        return own;
    }

    public void setOwn(FTP_SERVER_PRM_FLG own) {
        this.own = own;
    }

    @Override
    public String toString() {
        return "DTSVR_PRM_FLG{" +
                "opposite=" + Arrays.toString(opposite) +
                ", own=" + own +
                '}';
    }
}
