package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODB3DTO {
    private short mode;
    private short ofs_axes[];
    private int ofsvct[];

    public short getMode() {
        return mode;
    }

    public void setMode(short mode) {
        this.mode = mode;
    }

    public short[] getOfs_axes() {
        return ofs_axes;
    }

    public void setOfs_axes(short[] ofs_axes) {
        this.ofs_axes = ofs_axes;
    }

    public int[] getOfsvct() {
        return ofsvct;
    }

    public void setOfsvct(int[] ofsvct) {
        this.ofsvct = ofsvct;
    }

    @Override
    public String toString() {
        return "ODB3DTO{" +
                "mode=" + mode +
                ", ofs_axes=" + Arrays.toString(ofs_axes) +
                ", ofsvct=" + Arrays.toString(ofsvct) +
                '}';
    }
}
