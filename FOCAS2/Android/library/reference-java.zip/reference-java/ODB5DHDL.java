package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODB5DHDL {
    private char name[];
    private int data;
    private short dec;
    private short flag;
    private short axis;

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    public short getDec() {
        return dec;
    }

    public void setDec(short dec) {
        this.dec = dec;
    }

    public short getFlag() {
        return flag;
    }

    public void setFlag(short flag) {
        this.flag = flag;
    }

    public short getAxis() {
        return axis;
    }

    public void setAxis(short axis) {
        this.axis = axis;
    }

    @Override
    public String toString() {
        return "ODB5DHDL{" +
                "name=" + Arrays.toString(name) +
                ", data=" + data +
                ", dec=" + dec +
                ", flag=" + flag +
                ", axis=" + axis +
                '}';
    }
}
