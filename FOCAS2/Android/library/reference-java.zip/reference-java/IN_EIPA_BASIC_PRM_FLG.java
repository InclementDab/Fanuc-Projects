package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_EIPA_BASIC_PRM_FLG {
    private IN_EIP_COMMON_PRM_FLG Common;
    private char Option2;
    private char pad[];
    private char Status;
    private char StatusSize;

    public IN_EIP_COMMON_PRM_FLG getCommon() {
        return Common;
    }

    public void setCommon(IN_EIP_COMMON_PRM_FLG common) {
        Common = common;
    }

    public char getOption2() {
        return Option2;
    }

    public void setOption2(char option2) {
        Option2 = option2;
    }

    public char[] getPad() {
        return pad;
    }

    public void setPad(char[] pad) {
        this.pad = pad;
    }

    public char getStatus() {
        return Status;
    }

    public void setStatus(char status) {
        Status = status;
    }

    public char getStatusSize() {
        return StatusSize;
    }

    public void setStatusSize(char statusSize) {
        StatusSize = statusSize;
    }

    @Override
    public String toString() {
        return "IN_EIPA_BASIC_PRM_FLG{" +
                "Common=" + Common +
                ", Option2=" + Option2 +
                ", pad=" + Arrays.toString(pad) +
                ", Status=" + Status +
                ", StatusSize=" + StatusSize +
                '}';
    }
}
