package jp.co.fanuc.fwlibe1;


public class MBSVR_AREA_PRM_FLG {
    private char DatSize;
    private char DatModAddr;
    private char DatPmcAddr;
    private char dummy;

    public char getDatSize() {
        return DatSize;
    }

    public void setDatSize(char datSize) {
        DatSize = datSize;
    }

    public char getDatModAddr() {
        return DatModAddr;
    }

    public void setDatModAddr(char datModAddr) {
        DatModAddr = datModAddr;
    }

    public char getDatPmcAddr() {
        return DatPmcAddr;
    }

    public void setDatPmcAddr(char datPmcAddr) {
        DatPmcAddr = datPmcAddr;
    }

    public char getDummy() {
        return dummy;
    }

    public void setDummy(char dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "MBSVR_AREA_PRM_FLG{" +
                "DatSize=" + DatSize +
                ", DatModAddr=" + DatModAddr +
                ", DatPmcAddr=" + DatPmcAddr +
                ", dummy=" + dummy +
                '}';
    }
}
