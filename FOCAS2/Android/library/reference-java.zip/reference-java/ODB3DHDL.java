package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODB3DHDL {
    private short axes[];
    private int data[];

    public short[] getAxes() {
        return axes;
    }

    public void setAxes(short[] axes) {
        this.axes = axes;
    }

    public int[] getData() {
        return data;
    }

    public void setData(int[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ODB3DHDL{" +
                "axes=" + Arrays.toString(axes) +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
