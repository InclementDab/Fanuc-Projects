package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBJOGCMDSCODE {
    private char adrs[];
    private int num;

    public char[] getAdrs() {
        return adrs;
    }

    public void setAdrs(char[] adrs) {
        this.adrs = adrs;
    }

    public int getNum() {

        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    @Override
    public String toString() {
        return "ODBJOGCMDSCODE{" +
                "adrs=" + Arrays.toString(adrs) +
                ", num=" + num +
                '}';
    }
}
