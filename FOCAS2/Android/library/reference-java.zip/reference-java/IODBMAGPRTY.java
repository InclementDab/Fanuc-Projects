package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBMAGPRTY {
    private short mag;
    private short reserve_s;
    private byte mag_info;
    private byte reserve[];
    private short mt_line;
    private short mt_row;
    private int cstm[];

    public short getMag() {
        return mag;
    }

    public void setMag(short mag) {
        this.mag = mag;
    }

    public short getReserve_s() {
        return reserve_s;
    }

    public void setReserve_s(short reserve_s) {
        this.reserve_s = reserve_s;
    }

    public byte getMag_info() {
        return mag_info;
    }

    public void setMag_info(byte mag_info) {
        this.mag_info = mag_info;
    }

    public byte[] getReserve() {
        return reserve;
    }

    public void setReserve(byte[] reserve) {
        this.reserve = reserve;
    }

    public short getMt_line() {
        return mt_line;
    }

    public void setMt_line(short mt_line) {
        this.mt_line = mt_line;
    }

    public short getMt_row() {
        return mt_row;
    }

    public void setMt_row(short mt_row) {
        this.mt_row = mt_row;
    }

    public int[] getCstm() {
        return cstm;
    }

    public void setCstm(int[] cstm) {
        this.cstm = cstm;
    }

    @Override
    public String toString() {
        return "IODBMAGPRTY{" +
                "mag=" + mag +
                ", reserve_s=" + reserve_s +
                ", mag_info=" + mag_info +
                ", reserve=" + Arrays.toString(reserve) +
                ", mt_line=" + mt_line +
                ", mt_row=" + mt_row +
                ", cstm=" + Arrays.toString(cstm) +
                '}';
    }

    public void Dispose(){
        reserve = null;
        cstm = null;
    }
}
