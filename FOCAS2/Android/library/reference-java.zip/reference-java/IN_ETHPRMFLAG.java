package jp.co.fanuc.fwlibe1;


public class IN_ETHPRMFLAG {
    public static class FLG {
        private COMMON_PRM_FLG common;
        private FOCAS2_PRM_FLG focas2;
        private FTPTRANS_PRM_FLG ftpTrans;
        private DTSVR_PRM_FLG dataServer;
        private RMTDIAG_PRM_FLG remoteDiag;
        private FACTO_PRM_FLG factolink;
        private MAINTAIN_PRM_FLG maintain;
        private NETSRV_PRM_FLG netservice;
        private UNSOLICMSG_PRM_FLG unsolicmsg;
        private MBSVR_PRM_FLG mbsvr;
        private HTTPSVR_PRM_FLG httpsvr;
        private STSNTF_PRM_FLG stsntf;

        public COMMON_PRM_FLG getCommon() {
            return common;
        }

        public void setCommon(COMMON_PRM_FLG common) {
            this.common = common;
        }

        public FOCAS2_PRM_FLG getFocas2() {
            return focas2;
        }

        public void setFocas2(FOCAS2_PRM_FLG focas2) {
            this.focas2 = focas2;
        }

        public FTPTRANS_PRM_FLG getFtpTrans() {
            return ftpTrans;
        }

        public void setFtpTrans(FTPTRANS_PRM_FLG ftpTrans) {
            this.ftpTrans = ftpTrans;
        }

        public DTSVR_PRM_FLG getDataServer() {
            return dataServer;
        }

        public void setDataServer(DTSVR_PRM_FLG dataServer) {
            this.dataServer = dataServer;
        }

        public RMTDIAG_PRM_FLG getRemoteDiag() {
            return remoteDiag;
        }

        public void setRemoteDiag(RMTDIAG_PRM_FLG remoteDiag) {
            this.remoteDiag = remoteDiag;
        }

        public FACTO_PRM_FLG getFactolink() {
            return factolink;
        }

        public void setFactolink(FACTO_PRM_FLG factolink) {
            this.factolink = factolink;
        }

        public MAINTAIN_PRM_FLG getMaintain() {
            return maintain;
        }

        public void setMaintain(MAINTAIN_PRM_FLG maintain) {
            this.maintain = maintain;
        }

        public NETSRV_PRM_FLG getNetservice() {
            return netservice;
        }

        public void setNetservice(NETSRV_PRM_FLG netservice) {
            this.netservice = netservice;
        }

        public UNSOLICMSG_PRM_FLG getUnsolicmsg() {
            return unsolicmsg;
        }

        public void setUnsolicmsg(UNSOLICMSG_PRM_FLG unsolicmsg) {
            this.unsolicmsg = unsolicmsg;
        }

        public MBSVR_PRM_FLG getMbsvr() {
            return mbsvr;
        }

        public void setMbsvr(MBSVR_PRM_FLG mbsvr) {
            this.mbsvr = mbsvr;
        }

        public HTTPSVR_PRM_FLG getHttpsvr() {
            return httpsvr;
        }

        public void setHttpsvr(HTTPSVR_PRM_FLG httpsvr) {
            this.httpsvr = httpsvr;
        }

        public STSNTF_PRM_FLG getStsntf() {
            return stsntf;
        }

        public void setStsntf(STSNTF_PRM_FLG stsntf) {
            this.stsntf = stsntf;
        }

        @Override
        public String toString() {
            return "FLG{" +
                    "common=" + common +
                    ", focas2=" + focas2 +
                    ", ftpTrans=" + ftpTrans +
                    ", dataServer=" + dataServer +
                    ", remoteDiag=" + remoteDiag +
                    ", factolink=" + factolink +
                    ", maintain=" + maintain +
                    ", netservice=" + netservice +
                    ", unsolicmsg=" + unsolicmsg +
                    ", mbsvr=" + mbsvr +
                    ", httpsvr=" + httpsvr +
                    ", stsntf=" + stsntf +
                    '}';
        }
    }
    private FLG flg;

    public FLG getFlg() {
        return flg;
    }

    public void setFlg(FLG flg) {
        this.flg = flg;
    }

    @Override
    public String toString() {
        return "IN_ETHPRMFLAG{" +
                "flg=" + flg +
                '}';
    }
}
