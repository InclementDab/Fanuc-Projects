package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBLSTATE {
    private int    cmd_feed;
    private int    act_feed;
    private short   cmd_power;
    private short   cmd_freq;
    private short   cmd_duty;
    private char    beam;
    private char    beam_lock;
    private char    cw_mode;
    private char    pulse_mode;
    private char    cmd_feed_dec;
    private char    act_feed_dec;
    private char    reserve[];

    public int getCmd_feed() {
        return cmd_feed;
    }

    public void setCmd_feed(int cmd_feed) {
        this.cmd_feed = cmd_feed;
    }

    public int getAct_feed() {
        return act_feed;
    }

    public void setAct_feed(int act_feed) {
        this.act_feed = act_feed;
    }

    public short getCmd_power() {
        return cmd_power;
    }

    public void setCmd_power(short cmd_power) {
        this.cmd_power = cmd_power;
    }

    public short getCmd_freq() {
        return cmd_freq;
    }

    public void setCmd_freq(short cmd_freq) {
        this.cmd_freq = cmd_freq;
    }

    public short getCmd_duty() {
        return cmd_duty;
    }

    public void setCmd_duty(short cmd_duty) {
        this.cmd_duty = cmd_duty;
    }

    public char getBeam() {
        return beam;
    }

    public void setBeam(char beam) {
        this.beam = beam;
    }

    public char getBeam_lock() {
        return beam_lock;
    }

    public void setBeam_lock(char beam_lock) {
        this.beam_lock = beam_lock;
    }

    public char getCw_mode() {
        return cw_mode;
    }

    public void setCw_mode(char cw_mode) {
        this.cw_mode = cw_mode;
    }

    public char getPulse_mode() {
        return pulse_mode;
    }

    public void setPulse_mode(char pulse_mode) {
        this.pulse_mode = pulse_mode;
    }

    public char getCmd_feed_dec() {
        return cmd_feed_dec;
    }

    public void setCmd_feed_dec(char cmd_feed_dec) {
        this.cmd_feed_dec = cmd_feed_dec;
    }

    public char getAct_feed_dec() {
        return act_feed_dec;
    }

    public void setAct_feed_dec(char act_feed_dec) {
        this.act_feed_dec = act_feed_dec;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "ODBLSTATE{" +
                "cmd_feed=" + cmd_feed +
                ", act_feed=" + act_feed +
                ", cmd_power=" + cmd_power +
                ", cmd_freq=" + cmd_freq +
                ", cmd_duty=" + cmd_duty +
                ", beam=" + beam +
                ", beam_lock=" + beam_lock +
                ", cw_mode=" + cw_mode +
                ", pulse_mode=" + pulse_mode +
                ", cmd_feed_dec=" + cmd_feed_dec +
                ", act_feed_dec=" + act_feed_dec +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
