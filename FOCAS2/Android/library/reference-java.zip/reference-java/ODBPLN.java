package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBPLN {
    private int point[];
    private int vect[];
    private char n_unit;
    private char cb_form;

    public int[] getPoint() {
        return point;
    }

    public void setPoint(int[] point) {
        this.point = point;
    }

    public int[] getVect() {
        return vect;
    }

    public void setVect(int[] vect) {
        this.vect = vect;
    }

    public char getN_unit() {
        return n_unit;
    }

    public void setN_unit(char n_unit) {
        this.n_unit = n_unit;
    }

    public char getCb_form() {
        return cb_form;
    }

    public void setCb_form(char cb_form) {
        this.cb_form = cb_form;
    }

    @Override
    public String toString() {
        return "ODBPLN{" +
                "point=" + Arrays.toString(point) +
                ", vect=" + Arrays.toString(vect) +
                ", n_unit=" + n_unit +
                ", cb_form=" + cb_form +
                '}';
    }
}
