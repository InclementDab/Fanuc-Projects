package jp.co.fanuc.fwlibe1;


public class DCSMCC {
    public static class TIME {
        private int hour;
        private int minute;
        private int second;

        public int getHour() {
            return hour;
        }

        public void setHour(int hour) {
            this.hour = hour;
        }

        public int getMinute() {
            return minute;
        }

        public void setMinute(int minute) {
            this.minute = minute;
        }

        public int getSecond() {
            return second;
        }

        public void setSecond(int second) {
            this.second = second;
        }

        @Override
        public String toString() {
            return "TIME{" +
                    "hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    '}';
        }
    }
    private TIME time;
    private int testno;
    private int sign;

    public TIME getTime() {
        return time;
    }

    public void setTime(TIME time) {
        this.time = time;
    }

    public int getTestno() {
        return testno;
    }

    public void setTestno(int testno) {
        this.testno = testno;
    }

    public int getSign() {
        return sign;
    }

    public void setSign(int sign) {
        this.sign = sign;
    }

    @Override
    public String toString() {
        return "DCSMCC{" +
                "time=" + time +
                ", testno=" + testno +
                ", sign=" + sign +
                '}';
    }
}
