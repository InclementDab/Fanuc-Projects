package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBMMICONCSTMSTRING {
    private ODBMMSCRNINF    scrninf;
    private char            string[];
    private char            reserve[];

    public ODBMMSCRNINF getScrninf() {
        return scrninf;
    }

    public void setScrninf(ODBMMSCRNINF scrninf) {
        this.scrninf = scrninf;
    }

    public char[] getString() {
        return string;
    }

    public void setString(char[] string) {
        this.string = string;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBMMICONCSTMSTRING{" +
                "scrninf=" + scrninf +
                ", string=" + Arrays.toString(string) +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
