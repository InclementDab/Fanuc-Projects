package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMSRNCDAT {
    private short sv_num;
    private short sp_num;
    private ODBAXDT mcn[];
    private ODBAXDT abs[];
    private ODBAXDT spdl[];
    private ODBAXDT actf;
    private char ex_prg_name;
    private int ex_blk;
    private short aut;
    private short tmmode;
    private ODBCMD m_mdl[];
    private ODBCMD s_mdl;
    private ODBCMD t_mdl;
    private ODBCMD b_mdl;

    public short getSv_num() {
        return sv_num;
    }

    public void setSv_num(short sv_num) {
        this.sv_num = sv_num;
    }

    public short getSp_num() {
        return sp_num;
    }

    public void setSp_num(short sp_num) {
        this.sp_num = sp_num;
    }

    public ODBAXDT[] getMcn() {
        return mcn;
    }

    public void setMcn(ODBAXDT[] mcn) {
        this.mcn = mcn;
    }

    public ODBAXDT[] getAbs() {
        return abs;
    }

    public void setAbs(ODBAXDT[] abs) {
        this.abs = abs;
    }

    public ODBAXDT[] getSpdl() {
        return spdl;
    }

    public void setSpdl(ODBAXDT[] spdl) {
        this.spdl = spdl;
    }

    public ODBAXDT getActf() {
        return actf;
    }

    public void setActf(ODBAXDT actf) {
        this.actf = actf;
    }

    public char getEx_prg_name() {
        return ex_prg_name;
    }

    public void setEx_prg_name(char ex_prg_name) {
        this.ex_prg_name = ex_prg_name;
    }

    public int getEx_blk() {
        return ex_blk;
    }

    public void setEx_blk(int ex_blk) {
        this.ex_blk = ex_blk;
    }

    public short getAut() {
        return aut;
    }

    public void setAut(short aut) {
        this.aut = aut;
    }

    public short getTmmode() {
        return tmmode;
    }

    public void setTmmode(short tmmode) {
        this.tmmode = tmmode;
    }

    public ODBCMD[] getM_mdl() {
        return m_mdl;
    }

    public void setM_mdl(ODBCMD[] m_mdl) {
        this.m_mdl = m_mdl;
    }

    public ODBCMD getS_mdl() {
        return s_mdl;
    }

    public void setS_mdl(ODBCMD s_mdl) {
        this.s_mdl = s_mdl;
    }

    public ODBCMD getT_mdl() {
        return t_mdl;
    }

    public void setT_mdl(ODBCMD t_mdl) {
        this.t_mdl = t_mdl;
    }

    public ODBCMD getB_mdl() {
        return b_mdl;
    }

    public void setB_mdl(ODBCMD b_mdl) {
        this.b_mdl = b_mdl;
    }

    @Override
    public String toString() {
        return "ODBMSRNCDAT{" +
                "sv_num=" + sv_num +
                ", sp_num=" + sp_num +
                ", mcn=" + Arrays.toString(mcn) +
                ", abs=" + Arrays.toString(abs) +
                ", spdl=" + Arrays.toString(spdl) +
                ", actf=" + actf +
                ", ex_prg_name=" + ex_prg_name +
                ", ex_blk=" + ex_blk +
                ", aut=" + aut +
                ", tmmode=" + tmmode +
                ", m_mdl=" + Arrays.toString(m_mdl) +
                ", s_mdl=" + s_mdl +
                ", t_mdl=" + t_mdl +
                ", b_mdl=" + b_mdl +
                '}';
    }
}
