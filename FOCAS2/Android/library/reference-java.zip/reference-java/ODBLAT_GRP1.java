package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBLAT_GRP1 {
    private int nnum;
    private char prog[];
    private char year;
    private char mon;
    private char day;
    private char hour;
    private char min;
    private char sec;
    private char reserved[];

    public int getNnum() {
        return nnum;
    }

    public void setNnum(int nnum) {
        this.nnum = nnum;
    }

    public char[] getProg() {
        return prog;
    }

    public void setProg(char[] prog) {
        this.prog = prog;
    }

    public char getYear() {
        return year;
    }

    public void setYear(char year) {
        this.year = year;
    }

    public char getMon() {
        return mon;
    }

    public void setMon(char mon) {
        this.mon = mon;
    }

    public char getDay() {
        return day;
    }

    public void setDay(char day) {
        this.day = day;
    }

    public char getHour() {
        return hour;
    }

    public void setHour(char hour) {
        this.hour = hour;
    }

    public char getMin() {
        return min;
    }

    public void setMin(char min) {
        this.min = min;
    }

    public char getSec() {
        return sec;
    }

    public void setSec(char sec) {
        this.sec = sec;
    }

    public char[] getReserved() {
        return reserved;
    }

    public void setReserved(char[] reserved) {
        this.reserved = reserved;
    }

    @Override
    public String toString() {
        return "ODBLAT_GRP1{" +
                "nnum=" + nnum +
                ", prog=" + Arrays.toString(prog) +
                ", year=" + year +
                ", mon=" + mon +
                ", day=" + day +
                ", hour=" + hour +
                ", min=" + min +
                ", sec=" + sec +
                ", reserved=" + Arrays.toString(reserved) +
                '}';
    }
}
