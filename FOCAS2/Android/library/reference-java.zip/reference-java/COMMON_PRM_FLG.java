package jp.co.fanuc.fwlibe1;


public class COMMON_PRM_FLG {
    private char OwnIpAddress;
    private char SubNetmask;
    private char RouterIpAddress;
    private char DnsServer1IpAddress;
    private char DnsServer2IpAddress;
    private char OwnHostName;
    private char OwnDomain;

    public char getOwnIpAddress() {
        return OwnIpAddress;
    }

    public void setOwnIpAddress(char ownIpAddress) {
        OwnIpAddress = ownIpAddress;
    }

    public char getSubNetmask() {
        return SubNetmask;
    }

    public void setSubNetmask(char subNetmask) {
        SubNetmask = subNetmask;
    }

    public char getRouterIpAddress() {
        return RouterIpAddress;
    }

    public void setRouterIpAddress(char routerIpAddress) {
        RouterIpAddress = routerIpAddress;
    }

    public char getDnsServer1IpAddress() {
        return DnsServer1IpAddress;
    }

    public void setDnsServer1IpAddress(char dnsServer1IpAddress) {
        DnsServer1IpAddress = dnsServer1IpAddress;
    }

    public char getDnsServer2IpAddress() {
        return DnsServer2IpAddress;
    }

    public void setDnsServer2IpAddress(char dnsServer2IpAddress) {
        DnsServer2IpAddress = dnsServer2IpAddress;
    }

    public char getOwnHostName() {
        return OwnHostName;
    }

    public void setOwnHostName(char ownHostName) {
        OwnHostName = ownHostName;
    }

    public char getOwnDomain() {
        return OwnDomain;
    }

    public void setOwnDomain(char ownDomain) {
        OwnDomain = ownDomain;
    }

    @Override
    public String toString() {
        return "COMMON_PRM_FLG{" +
                "OwnIpAddress=" + OwnIpAddress +
                ", SubNetmask=" + SubNetmask +
                ", RouterIpAddress=" + RouterIpAddress +
                ", DnsServer1IpAddress=" + DnsServer1IpAddress +
                ", DnsServer2IpAddress=" + DnsServer2IpAddress +
                ", OwnHostName=" + OwnHostName +
                ", OwnDomain=" + OwnDomain +
                '}';
    }
}
