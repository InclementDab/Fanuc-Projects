package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBSPAMP {
    private short slave_num;
    private char name[];
    private char series[];
    private char pwr[];
    private short as_spdl_num;
    private char as_spdl_name[];

    public short getSlave_num() {
        return slave_num;
    }

    public void setSlave_num(short slave_num) {
        this.slave_num = slave_num;
    }

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public char[] getSeries() {
        return series;
    }

    public void setSeries(char[] series) {
        this.series = series;
    }

    public char[] getPwr() {
        return pwr;
    }

    public void setPwr(char[] pwr) {
        this.pwr = pwr;
    }

    public short getAs_spdl_num() {
        return as_spdl_num;
    }

    public void setAs_spdl_num(short as_spdl_num) {
        this.as_spdl_num = as_spdl_num;
    }

    public char[] getAs_spdl_name() {
        return as_spdl_name;
    }

    public void setAs_spdl_name(char[] as_spdl_name) {
        this.as_spdl_name = as_spdl_name;
    }

    @Override
    public String toString() {
        return "ODBIFSBSPAMP{" +
                "slave_num=" + slave_num +
                ", name=" + Arrays.toString(name) +
                ", series=" + Arrays.toString(series) +
                ", pwr=" + Arrays.toString(pwr) +
                ", as_spdl_num=" + as_spdl_num +
                ", as_spdl_name=" + Arrays.toString(as_spdl_name) +
                '}';
    }
}
