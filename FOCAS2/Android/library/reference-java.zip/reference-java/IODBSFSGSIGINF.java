package jp.co.fanuc.fwlibe1;


public class IODBSFSGSIGINF {
    private int     unittype;
    private int     number;
    private short    adr_type;
    private short    bit;

    public int getUnittype() {
        return unittype;
    }

    public void setUnittype(int unittype) {
        this.unittype = unittype;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public short getAdr_type() {
        return adr_type;
    }

    public void setAdr_type(short adr_type) {
        this.adr_type = adr_type;
    }

    public short getBit() {
        return bit;
    }

    public void setBit(short bit) {
        this.bit = bit;
    }

    @Override
    public String toString() {
        return "IODBSFSGSIGINF{" +
                "unittype=" + unittype +
                ", number=" + number +
                ", adr_type=" + adr_type +
                ", bit=" + bit +
                '}';
    }
}
