package jp.co.fanuc.fwlibe1;


public class ODBIFSBWARNHSTMSG {
    private short year;
    private char month;
    private char day;
    private char hour;
    private char minute;
    private char second;
    private char dummy;
    private ODBIFSBWARNINGMSG msg_dat;

    public short getYear() {
        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public char getMonth() {
        return month;
    }

    public void setMonth(char month) {
        this.month = month;
    }

    public char getDay() {
        return day;
    }

    public void setDay(char day) {
        this.day = day;
    }

    public char getHour() {
        return hour;
    }

    public void setHour(char hour) {
        this.hour = hour;
    }

    public char getMinute() {
        return minute;
    }

    public void setMinute(char minute) {
        this.minute = minute;
    }

    public char getSecond() {
        return second;
    }

    public void setSecond(char second) {
        this.second = second;
    }

    public char getDummy() {
        return dummy;
    }

    public void setDummy(char dummy) {
        this.dummy = dummy;
    }

    public ODBIFSBWARNINGMSG getMsg_dat() {
        return msg_dat;
    }

    public void setMsg_dat(ODBIFSBWARNINGMSG msg_dat) {
        this.msg_dat = msg_dat;
    }

    @Override
    public String toString() {
        return "ODBIFSBWARNHSTMSG{" +
                "year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", hour=" + hour +
                ", minute=" + minute +
                ", second=" + second +
                ", dummy=" + dummy +
                ", msg_dat=" + msg_dat +
                '}';
    }
}
