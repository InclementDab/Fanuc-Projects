package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class HOSTPRM {
    private short DataServerPort;
    private char DataServerIPAddress;
    private char DataServerUserName[];
    private char DataServerPassword[];
    private char DataServerLoginDirectory[];

    public short getDataServerPort() {
        return DataServerPort;
    }

    public void setDataServerPort(short dataServerPort) {
        DataServerPort = dataServerPort;
    }

    public char getDataServerIPAddress() {
        return DataServerIPAddress;
    }

    public void setDataServerIPAddress(char dataServerIPAddress) {
        DataServerIPAddress = dataServerIPAddress;
    }

    public char[] getDataServerUserName() {
        return DataServerUserName;
    }

    public void setDataServerUserName(char[] dataServerUserName) {
        DataServerUserName = dataServerUserName;
    }

    public char[] getDataServerPassword() {
        return DataServerPassword;
    }

    public void setDataServerPassword(char[] dataServerPassword) {
        DataServerPassword = dataServerPassword;
    }

    public char[] getDataServerLoginDirectory() {
        return DataServerLoginDirectory;
    }

    public void setDataServerLoginDirectory(char[] dataServerLoginDirectory) {
        DataServerLoginDirectory = dataServerLoginDirectory;
    }

    @Override
    public String toString() {
        return "HOSTPRM{" +
                "DataServerPort=" + DataServerPort +
                ", DataServerIPAddress=" + DataServerIPAddress +
                ", DataServerUserName=" + Arrays.toString(DataServerUserName) +
                ", DataServerPassword=" + Arrays.toString(DataServerPassword) +
                ", DataServerLoginDirectory=" + Arrays.toString(DataServerLoginDirectory) +
                '}';
    }
}
