package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class FLINKPRMW {
    private char IPAddress[];
    private short Port;

    public char[] getIPAddress() {
        return IPAddress;
    }

    public void setIPAddress(char[] IPAddress) {
        this.IPAddress = IPAddress;
    }

    public short getPort() {
        return Port;
    }

    public void setPort(short port) {
        Port = port;
    }

    @Override
    public String toString() {
        return "FLINKPRMW{" +
                "IPAddress=" + Arrays.toString(IPAddress) +
                ", Port=" + Port +
                '}';
    }
}
