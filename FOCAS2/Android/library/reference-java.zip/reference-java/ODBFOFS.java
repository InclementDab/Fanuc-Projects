package jp.co.fanuc.fwlibe1;


public class ODBFOFS {
    private int mcrval;
    private short decval;

    public int getMcrval() {
        return mcrval;
    }

    public void setMcrval(int mcrval) {
        this.mcrval = mcrval;
    }

    public short getDecval() {

        return decval;
    }

    public void setDecval(short decval) {
        this.decval = decval;
    }

    @Override
    public String toString() {
        return "ODBFOFS{" +
                "mcrval=" + mcrval +
                ", decval=" + decval +
                '}';
    }
}
