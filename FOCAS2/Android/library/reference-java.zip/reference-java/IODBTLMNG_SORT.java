package jp.co.fanuc.fwlibe1;


public class IODBTLMNG_SORT {
    private short tl_num;
    private short reserve;
    private IODBTLMNG_F2 data;

    public short getTl_num() {
        return tl_num;
    }

    public void setTl_num(short tl_num) {
        this.tl_num = tl_num;
    }

    public short getReserve() {
        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    public IODBTLMNG_F2 getData() {
        return data;
    }

    public void setData(IODBTLMNG_F2 data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBTLMNG_SORT{" +
                "tl_num=" + tl_num +
                ", reserve=" + reserve +
                ", data=" + data +
                '}';
    }
}
