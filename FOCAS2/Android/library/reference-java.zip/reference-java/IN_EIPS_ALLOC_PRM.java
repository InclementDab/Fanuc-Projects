package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_EIPS_ALLOC_PRM {
    private char IpAddress[];
    private char Option1;
    private char Option2;
    private char DataUnit;
    private char Endian;
    private int ConfigInstance;
    private EIPS_CONN_PRM ConnT2O;
    private EIPS_CONN_PRM ConnO2T;
    private EIP_PMC_ADDR reserve1;
    private EIP_PMC_ADDR reserve2;
    private char ProductTrigger;
    private char Timeout;
    private char Reconnect;
    private char pad;
    private EIPS_ELECTRONIC_KEY Electronickey;
    private int DataPerSec;
    private int DataPerSecTotal;

    public char[] getIpAddress() {
        return IpAddress;
    }

    public void setIpAddress(char[] ipAddress) {
        IpAddress = ipAddress;
    }

    public char getOption1() {
        return Option1;
    }

    public void setOption1(char option1) {
        Option1 = option1;
    }

    public char getOption2() {
        return Option2;
    }

    public void setOption2(char option2) {
        Option2 = option2;
    }

    public char getDataUnit() {
        return DataUnit;
    }

    public void setDataUnit(char dataUnit) {
        DataUnit = dataUnit;
    }

    public char getEndian() {
        return Endian;
    }

    public void setEndian(char endian) {
        Endian = endian;
    }

    public int getConfigInstance() {
        return ConfigInstance;
    }

    public void setConfigInstance(int configInstance) {
        ConfigInstance = configInstance;
    }

    public EIPS_CONN_PRM getConnT2O() {
        return ConnT2O;
    }

    public void setConnT2O(EIPS_CONN_PRM connT2O) {
        ConnT2O = connT2O;
    }

    public EIPS_CONN_PRM getConnO2T() {
        return ConnO2T;
    }

    public void setConnO2T(EIPS_CONN_PRM connO2T) {
        ConnO2T = connO2T;
    }

    public EIP_PMC_ADDR getReserve1() {
        return reserve1;
    }

    public void setReserve1(EIP_PMC_ADDR reserve1) {
        this.reserve1 = reserve1;
    }

    public EIP_PMC_ADDR getReserve2() {
        return reserve2;
    }

    public void setReserve2(EIP_PMC_ADDR reserve2) {
        this.reserve2 = reserve2;
    }

    public char getProductTrigger() {
        return ProductTrigger;
    }

    public void setProductTrigger(char productTrigger) {
        ProductTrigger = productTrigger;
    }

    public char getTimeout() {
        return Timeout;
    }

    public void setTimeout(char timeout) {
        Timeout = timeout;
    }

    public char getReconnect() {
        return Reconnect;
    }

    public void setReconnect(char reconnect) {
        Reconnect = reconnect;
    }

    public char getPad() {
        return pad;
    }

    public void setPad(char pad) {
        this.pad = pad;
    }

    public EIPS_ELECTRONIC_KEY getElectronickey() {
        return Electronickey;
    }

    public void setElectronickey(EIPS_ELECTRONIC_KEY electronickey) {
        Electronickey = electronickey;
    }

    public int getDataPerSec() {
        return DataPerSec;
    }

    public void setDataPerSec(int dataPerSec) {
        DataPerSec = dataPerSec;
    }

    public int getDataPerSecTotal() {
        return DataPerSecTotal;
    }

    public void setDataPerSecTotal(int dataPerSecTotal) {
        DataPerSecTotal = dataPerSecTotal;
    }

    @Override
    public String toString() {
        return "IN_EIPS_ALLOC_PRM{" +
                "IpAddress=" + Arrays.toString(IpAddress) +
                ", Option1=" + Option1 +
                ", Option2=" + Option2 +
                ", DataUnit=" + DataUnit +
                ", Endian=" + Endian +
                ", ConfigInstance=" + ConfigInstance +
                ", ConnT2O=" + ConnT2O +
                ", ConnO2T=" + ConnO2T +
                ", reserve1=" + reserve1 +
                ", reserve2=" + reserve2 +
                ", ProductTrigger=" + ProductTrigger +
                ", Timeout=" + Timeout +
                ", Reconnect=" + Reconnect +
                ", pad=" + pad +
                ", Electronickey=" + Electronickey +
                ", DataPerSec=" + DataPerSec +
                ", DataPerSecTotal=" + DataPerSecTotal +
                '}';
    }
}
