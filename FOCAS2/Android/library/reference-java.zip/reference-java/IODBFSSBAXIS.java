package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBFSSBAXIS {
    private short axis_num;
    private short reserve1;
    private char axis_name[];
    private char amp_name[];
    private short m1;
    private short m2;
    private short m3;
    private short m4;
    private short dsp1;
    private short cs;
    private short tndm;
    private short reserve2;

    public short getAxis_num() {
        return axis_num;
    }

    public void setAxis_num(short axis_num) {
        this.axis_num = axis_num;
    }

    public short getReserve1() {
        return reserve1;
    }

    public void setReserve1(short reserve1) {
        this.reserve1 = reserve1;
    }

    public char[] getAxis_name() {
        return axis_name;
    }

    public void setAxis_name(char[] axis_name) {
        this.axis_name = axis_name;
    }

    public char[] getAmp_name() {
        return amp_name;
    }

    public void setAmp_name(char[] amp_name) {
        this.amp_name = amp_name;
    }

    public short getM1() {
        return m1;
    }

    public void setM1(short m1) {
        this.m1 = m1;
    }

    public short getM2() {
        return m2;
    }

    public void setM2(short m2) {
        this.m2 = m2;
    }

    public short getM3() {
        return m3;
    }

    public void setM3(short m3) {
        this.m3 = m3;
    }

    public short getM4() {
        return m4;
    }

    public void setM4(short m4) {
        this.m4 = m4;
    }

    public short getDsp1() {
        return dsp1;
    }

    public void setDsp1(short dsp1) {
        this.dsp1 = dsp1;
    }

    public short getCs() {
        return cs;
    }

    public void setCs(short cs) {
        this.cs = cs;
    }

    public short getTndm() {
        return tndm;
    }

    public void setTndm(short tndm) {
        this.tndm = tndm;
    }

    public short getReserve2() {
        return reserve2;
    }

    public void setReserve2(short reserve2) {
        this.reserve2 = reserve2;
    }

    @Override
    public String toString() {
        return "IODBFSSBAXIS{" +
                "axis_num=" + axis_num +
                ", reserve1=" + reserve1 +
                ", axis_name=" + Arrays.toString(axis_name) +
                ", amp_name=" + Arrays.toString(amp_name) +
                ", m1=" + m1 +
                ", m2=" + m2 +
                ", m3=" + m3 +
                ", m4=" + m4 +
                ", dsp1=" + dsp1 +
                ", cs=" + cs +
                ", tndm=" + tndm +
                ", reserve2=" + reserve2 +
                '}';
    }
}
