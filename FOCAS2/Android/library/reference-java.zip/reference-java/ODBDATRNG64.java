package jp.co.fanuc.fwlibe1;


public class ODBDATRNG64 {
    private double data_min;
    private double data_max;
    private int dec;
    private int status;

    public double getData_min() {
        return data_min;
    }

    public void setData_min(double data_min) {
        this.data_min = data_min;
    }

    public double getData_max() {
        return data_max;
    }

    public void setData_max(double data_max) {
        this.data_max = data_max;
    }

    public int getDec() {
        return dec;
    }

    public void setDec(int dec) {
        this.dec = dec;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "ODBDATRNG64{" +
                "data_min=" + data_min +
                ", data_max=" + data_max +
                ", dec=" + dec +
                ", status=" + status +
                '}';
    }
}
