package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class MBSVR_PRM_FLG {
    private char TcpPort;
    private char Option1;
    private char Option2;
    private char StsPmcAddr;
    private MBSVR_AREA_PRM_FLG AreaPrm[];

    public char getTcpPort() {
        return TcpPort;
    }

    public void setTcpPort(char tcpPort) {
        TcpPort = tcpPort;
    }

    public char getOption1() {
        return Option1;
    }

    public void setOption1(char option1) {
        Option1 = option1;
    }

    public char getOption2() {
        return Option2;
    }

    public void setOption2(char option2) {
        Option2 = option2;
    }

    public char getStsPmcAddr() {
        return StsPmcAddr;
    }

    public void setStsPmcAddr(char stsPmcAddr) {
        StsPmcAddr = stsPmcAddr;
    }

    public MBSVR_AREA_PRM_FLG[] getAreaPrm() {
        return AreaPrm;
    }

    public void setAreaPrm(MBSVR_AREA_PRM_FLG[] areaPrm) {
        AreaPrm = areaPrm;
    }

    @Override
    public String toString() {
        return "MBSVR_PRM_FLG{" +
                "TcpPort=" + TcpPort +
                ", Option1=" + Option1 +
                ", Option2=" + Option2 +
                ", StsPmcAddr=" + StsPmcAddr +
                ", AreaPrm=" + Arrays.toString(AreaPrm) +
                '}';
    }
}
