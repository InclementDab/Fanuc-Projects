package jp.co.fanuc.fwlibe1;


public class IN_PNC_PARAM {
    private PNC_PARAM_FLG           flg;
    private PNC_PARAM_W             prm;

    public PNC_PARAM_FLG getFlg() {
        return flg;
    }

    public void setFlg(PNC_PARAM_FLG flg) {
        this.flg = flg;
    }

    public PNC_PARAM_W getPrm() {
        return prm;
    }

    public void setPrm(PNC_PARAM_W prm) {
        this.prm = prm;
    }

    @Override
    public String toString() {
        return "IN_PNC_PARAM{" +
                "flg=" + flg +
                ", prm=" + prm +
                '}';
    }
}
