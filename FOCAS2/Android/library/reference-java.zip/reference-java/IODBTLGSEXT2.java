package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTLGSEXT2 {
    private int data1;
    private int data2;
    private int data3;
    private int data4;
    private int data5;
    private int data6;
    private int data7;
    private int data8;
    private int data9;
    private int data10;
    private char tooltype;
    private char install;
    private char holder;
    private char toolname[];

    public int getData1() {
        return data1;
    }

    public void setData1(int data1) {
        this.data1 = data1;
    }

    public int getData2() {

        return data2;
    }

    public void setData2(int data2) {
        this.data2 = data2;
    }

    public int getData3() {

        return data3;
    }

    public void setData3(int data3) {
        this.data3 = data3;
    }

    public int getData4() {

        return data4;
    }

    public void setData4(int data4) {
        this.data4 = data4;
    }

    public int getData5() {

        return data5;
    }

    public void setData5(int data5) {
        this.data5 = data5;
    }

    public int getData6() {

        return data6;
    }

    public void setData6(int data6) {
        this.data6 = data6;
    }

    public int getData7() {

        return data7;
    }

    public void setData7(int data7) {
        this.data7 = data7;
    }

    public int getData8() {

        return data8;
    }

    public void setData8(int data8) {
        this.data8 = data8;
    }

    public int getData9() {

        return data9;
    }

    public void setData9(int data9) {
        this.data9 = data9;
    }

    public int getData10() {

        return data10;
    }

    public void setData10(int data10) {
        this.data10 = data10;
    }

    public char getTooltype() {

        return tooltype;
    }

    public void setTooltype(char tooltype) {
        this.tooltype = tooltype;
    }

    public char getInstall() {

        return install;
    }

    public void setInstall(char install) {
        this.install = install;
    }

    public char getHolder() {

        return holder;
    }

    public void setHolder(char holder) {
        this.holder = holder;
    }

    public char[] getToolname() {

        return toolname;
    }

    public void setToolname(char[] toolname) {
        this.toolname = toolname;
    }

    @Override
    public String toString() {
        return "IODBTLGSEXT2{" +
                "data1=" + data1 +
                ", data2=" + data2 +
                ", data3=" + data3 +
                ", data4=" + data4 +
                ", data5=" + data5 +
                ", data6=" + data6 +
                ", data7=" + data7 +
                ", data8=" + data8 +
                ", data9=" + data9 +
                ", data10=" + data10 +
                ", tooltype=" + tooltype +
                ", install=" + install +
                ", holder=" + holder +
                ", toolname=" + Arrays.toString(toolname) +
                '}';
    }
}
