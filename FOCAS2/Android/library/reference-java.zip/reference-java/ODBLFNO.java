package jp.co.fanuc.fwlibe1;


public class ODBLFNO {
    private short datano;
    private short type;
    private short data;

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {

        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getData() {

        return data;
    }

    public void setData(short data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ODBLFNO{" +
                "datano=" + datano +
                ", type=" + type +
                ", data=" + data +
                '}';
    }
}
