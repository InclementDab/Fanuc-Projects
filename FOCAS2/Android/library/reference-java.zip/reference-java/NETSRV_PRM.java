package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class NETSRV_PRM {
    private char HostName[];
    private int Port;
    private int TimeInterval;
    private int UdpPeriod;
    private char MachineNumber[];
    private char dummy1[];
    private char AcceptanceReply[];
    private char dummy2[];
    private char ErrorReply[];
    private char dummy3[];

    public char[] getDummy1() {
        return dummy1;
    }

    public void setDummy1(char[] dummy1) {
        this.dummy1 = dummy1;
    }

    public char[] getHostName() {
        return HostName;
    }

    public void setHostName(char[] hostName) {
        HostName = hostName;
    }

    public int getPort() {
        return Port;
    }

    public void setPort(int port) {
        Port = port;
    }

    public int getTimeInterval() {
        return TimeInterval;
    }

    public void setTimeInterval(int timeInterval) {
        TimeInterval = timeInterval;
    }

    public int getUdpPeriod() {
        return UdpPeriod;
    }

    public void setUdpPeriod(int udpPeriod) {
        UdpPeriod = udpPeriod;
    }

    public char[] getMachineNumber() {
        return MachineNumber;
    }

    public void setMachineNumber(char[] machineNumber) {
        MachineNumber = machineNumber;
    }


    public char[] getAcceptanceReply() {
        return AcceptanceReply;
    }

    public void setAcceptanceReply(char[] acceptanceReply) {
        AcceptanceReply = acceptanceReply;
    }

    public char[] getDummy2() {
        return dummy2;
    }

    public void setDummy2(char[] dummy2) {
        this.dummy2 = dummy2;
    }

    public char[] getErrorReply() {
        return ErrorReply;
    }

    public void setErrorReply(char[] errorReply) {
        ErrorReply = errorReply;
    }

    public char[] getDummy3() {
        return dummy3;
    }

    public void setDummy3(char[] dummy3) {
        this.dummy3 = dummy3;
    }

    @Override
    public String toString() {
        return "NETSRV_PRM{" +
                "HostName=" + Arrays.toString(HostName) +
                ", Port=" + Port +
                ", TimeInterval=" + TimeInterval +
                ", UdpPeriod=" + UdpPeriod +
                ", MachineNumber=" + Arrays.toString(MachineNumber) +
                ", dummy1=" + Arrays.toString(dummy1) +
                ", AcceptanceReply=" + Arrays.toString(AcceptanceReply) +
                ", dummy2=" + Arrays.toString(dummy2) +
                ", ErrorReply=" + Arrays.toString(ErrorReply) +
                ", dummy3=" + Arrays.toString(dummy3) +
                '}';
    }
}
