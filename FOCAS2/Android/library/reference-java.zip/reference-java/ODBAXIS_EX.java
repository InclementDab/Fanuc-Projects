package jp.co.fanuc.fwlibe1;

import java.util.Arrays;


public class ODBAXIS_EX {
    private short counter;
    private short type;
    private int data[];

    public short getCounter() {
        return counter;
    }

    public void setCounter(short counter) {
        this.counter = counter;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public int[] getData() {
        return data;
    }

    public void setData(int[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ODBAXIS_EX{" +
                "counter=" + counter +
                ", type=" + type +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
