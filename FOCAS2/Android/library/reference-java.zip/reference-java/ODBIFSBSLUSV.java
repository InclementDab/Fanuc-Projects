package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBSLUSV {
    private short slave_num;
    private short axis_num;
    private char axis_name[];
    private char tndm;
    private char reserve[];

    public short getSlave_num() {
        return slave_num;
    }

    public void setSlave_num(short slave_num) {
        this.slave_num = slave_num;
    }

    public short getAxis_num() {
        return axis_num;
    }

    public void setAxis_num(short axis_num) {
        this.axis_num = axis_num;
    }

    public char[] getAxis_name() {
        return axis_name;
    }

    public void setAxis_name(char[] axis_name) {
        this.axis_name = axis_name;
    }

    public char getTndm() {
        return tndm;
    }

    public void setTndm(char tndm) {
        this.tndm = tndm;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "ODBIFSBSLUSV{" +
                "slave_num=" + slave_num +
                ", axis_num=" + axis_num +
                ", axis_name=" + Arrays.toString(axis_name) +
                ", tndm=" + tndm +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
