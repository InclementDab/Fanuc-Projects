package jp.co.fanuc.fwlibe1;


public class DCSMCA {
    private int mgrp_no;
    private DCSMCC mcc_test_inf;

    public int getMgrp_no() {
        return mgrp_no;
    }

    public void setMgrp_no(int mgrp_no) {
        this.mgrp_no = mgrp_no;
    }

    public DCSMCC getMcc_test_inf() {
        return mcc_test_inf;
    }

    public void setMcc_test_inf(DCSMCC mcc_test_inf) {
        this.mcc_test_inf = mcc_test_inf;
    }

    @Override
    public String toString() {
        return "DCSMCA{" +
                "mgrp_no=" + mgrp_no +
                ", mcc_test_inf=" + mcc_test_inf +
                '}';
    }
}
