package jp.co.fanuc.fwlibe1;


public class ODBCSS {
    private int srpm;
    private int sspm;
    private int smax;

    public int getSrpm() {
        return srpm;
    }

    public void setSrpm(int srpm) {
        this.srpm = srpm;
    }

    public int getSspm() {

        return sspm;
    }

    public void setSspm(int sspm) {
        this.sspm = sspm;
    }

    public int getSmax() {

        return smax;
    }

    public void setSmax(int smax) {
        this.smax = smax;
    }

    @Override
    public String toString() {
        return "ODBCSS{" +
                "srpm=" + srpm +
                ", sspm=" + sspm +
                ", smax=" + smax +
                '}';
    }
}
