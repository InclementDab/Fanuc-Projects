package jp.co.fanuc.fwlibe1;

import java.util.Arrays;


public class ODBAXDT64 {
    private char name[];
    private char dummy[];
    private double data;
    private short dec;
    private short unit;
    private short flag;
    private short reserve;

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public char[] getDummy() {

        return dummy;
    }

    public void setDummy(char[] dummy) {
        this.dummy = dummy;
    }

    public double getData() {

        return data;
    }

    public void setData(double data) {
        this.data = data;
    }

    public short getDec() {

        return dec;
    }

    public void setDec(short dec) {
        this.dec = dec;
    }

    public short getUnit() {

        return unit;
    }

    public void setUnit(short unit) {
        this.unit = unit;
    }

    public short getFlag() {

        return flag;
    }

    public void setFlag(short flag) {
        this.flag = flag;
    }

    public short getReserve() {

        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "ODBAXDT64{" +
                "name=" + Arrays.toString(name) +
                ", dummy=" + Arrays.toString(dummy) +
                ", data=" + data +
                ", dec=" + dec +
                ", unit=" + unit +
                ", flag=" + flag +
                ", reserve=" + reserve +
                '}';
    }
}
