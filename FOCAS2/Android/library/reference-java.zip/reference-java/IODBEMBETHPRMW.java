package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBEMBETHPRMW {
    public static class EMBETHPRM {
        private EMBTCPPRMW tcpip;
        private FWLIBPRMW fwlib;
        private FLINKPRMW flink;
        private char MACAddress[];

        public EMBTCPPRMW getTcpip() {
            return tcpip;
        }

        public void setTcpip(EMBTCPPRMW tcpip) {
            this.tcpip = tcpip;
        }

        public FWLIBPRMW getFwlib() {
            return fwlib;
        }

        public void setFwlib(FWLIBPRMW fwlib) {
            this.fwlib = fwlib;
        }

        public FLINKPRMW getFlink() {
            return flink;
        }

        public void setFlink(FLINKPRMW flink) {
            this.flink = flink;
        }

        public char[] getMACAddress() {
            return MACAddress;
        }

        public void setMACAddress(char[] MACAddress) {
            this.MACAddress = MACAddress;
        }

        @Override
        public String toString() {
            return "EMBETHPRM{" +
                    "tcpip=" + tcpip +
                    ", fwlib=" + fwlib +
                    ", flink=" + flink +
                    ", MACAddress=" + Arrays.toString(MACAddress) +
                    '}';
        }
    }
    private EMBETHPRM embethprm;

    public EMBETHPRM getEmbethprm() {
        return embethprm;
    }

    public void setEmbethprm(EMBETHPRM embethprm) {
        this.embethprm = embethprm;
    }

    @Override
    public String toString() {
        return "IODBEMBETHPRMW{" +
                "embethprm=" + embethprm +
                '}';
    }
}
