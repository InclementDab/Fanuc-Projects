package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBCYL {
    private int sta_pnt[];
    private int end_pnt[];
    private int radius;
    private char n_unit;
    private char cb_form;

    public int[] getSta_pnt() {
        return sta_pnt;
    }

    public void setSta_pnt(int[] sta_pnt) {
        this.sta_pnt = sta_pnt;
    }

    public int[] getEnd_pnt() {
        return end_pnt;
    }

    public void setEnd_pnt(int[] end_pnt) {
        this.end_pnt = end_pnt;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public char getN_unit() {
        return n_unit;
    }

    public void setN_unit(char n_unit) {
        this.n_unit = n_unit;
    }

    public char getCb_form() {
        return cb_form;
    }

    public void setCb_form(char cb_form) {
        this.cb_form = cb_form;
    }

    @Override
    public String toString() {
        return "ODBCYL{" +
                "sta_pnt=" + Arrays.toString(sta_pnt) +
                ", end_pnt=" + Arrays.toString(end_pnt) +
                ", radius=" + radius +
                ", n_unit=" + n_unit +
                ", cb_form=" + cb_form +
                '}';
    }
}
