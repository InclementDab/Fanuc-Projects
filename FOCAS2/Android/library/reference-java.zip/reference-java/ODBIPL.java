package jp.co.fanuc.fwlibe1;


public class ODBIPL {
    private char outpt;
    private char ipltp;
    private char mv;
    private char inp;

    public char getOutpt() {
        return outpt;
    }

    public void setOutpt(char outpt) {
        this.outpt = outpt;
    }

    public char getIpltp() {
        return ipltp;
    }

    public void setIpltp(char ipltp) {
        this.ipltp = ipltp;
    }

    public char getMv() {
        return mv;
    }

    public void setMv(char mv) {
        this.mv = mv;
    }

    public char getInp() {
        return inp;
    }

    public void setInp(char inp) {
        this.inp = inp;
    }

    @Override
    public String toString() {
        return "ODBIPL{" +
                "outpt=" + outpt +
                ", ipltp=" + ipltp +
                ", mv=" + mv +
                ", inp=" + inp +
                '}';
    }
}
