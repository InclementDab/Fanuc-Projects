package jp.co.fanuc.fwlibe1;


public class IODBRCT_GRPPTN {
    private short grp_num;
    private short ptn_num;

    public short getGrp_num() {
        return grp_num;
    }

    public void setGrp_num(short grp_num) {
        this.grp_num = grp_num;
    }

    public short getPtn_num() {
        return ptn_num;
    }

    public void setPtn_num(short ptn_num) {
        this.ptn_num = ptn_num;
    }

    @Override
    public String toString() {
        return "IODBRCT_GRPPTN{" +
                "grp_num=" + grp_num +
                ", ptn_num=" + ptn_num +
                '}';
    }
}
