package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBPI {
    private short datano_s;
    private short dummy;
    private short datano_e;
    private byte data[];

    public short getDatano_s() {
        return datano_s;
    }

    public void setDatano_s(short datano_s) {
        this.datano_s = datano_s;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public short getDatano_e() {

        return datano_e;
    }

    public void setDatano_e(short datano_e) {
        this.datano_e = datano_e;
    }

    public byte[] getData() {

        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBPI{" +
                "datano_s=" + datano_s +
                ", dummy=" + dummy +
                ", datano_e=" + datano_e +
                ", data=" + Arrays.toString(data) +
                '}';
    }

    public void Dispose(){
        data = null;
    }
}
