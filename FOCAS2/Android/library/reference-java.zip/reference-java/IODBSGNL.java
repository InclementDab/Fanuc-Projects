package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBSGNL {
    private short datano;
    private short type;
    private short mode;
    private short hndl_ax;
    private short hndl_mv;
    private short rpd_ovrd;
    private short jog_ovrd;
    private short feed_ovrd;
    private short spdl_ovrd;
    private short blck_del;
    private short sngl_blck;
    private short machn_lock;
    private short dry_run;
    private short mem_prtct;
    private short feed_hold;
    private short manual_rpd;
    private short dummy[];

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getMode() {
        return mode;
    }

    public void setMode(short mode) {
        this.mode = mode;
    }

    public short getHndl_ax() {
        return hndl_ax;
    }

    public void setHndl_ax(short hndl_ax) {
        this.hndl_ax = hndl_ax;
    }

    public short getHndl_mv() {
        return hndl_mv;
    }

    public void setHndl_mv(short hndl_mv) {
        this.hndl_mv = hndl_mv;
    }

    public short getRpd_ovrd() {
        return rpd_ovrd;
    }

    public void setRpd_ovrd(short rpd_ovrd) {
        this.rpd_ovrd = rpd_ovrd;
    }

    public short getJog_ovrd() {
        return jog_ovrd;
    }

    public void setJog_ovrd(short jog_ovrd) {
        this.jog_ovrd = jog_ovrd;
    }

    public short getFeed_ovrd() {
        return feed_ovrd;
    }

    public void setFeed_ovrd(short feed_ovrd) {
        this.feed_ovrd = feed_ovrd;
    }

    public short getSpdl_ovrd() {
        return spdl_ovrd;
    }

    public void setSpdl_ovrd(short spdl_ovrd) {
        this.spdl_ovrd = spdl_ovrd;
    }

    public short getBlck_del() {
        return blck_del;
    }

    public void setBlck_del(short blck_del) {
        this.blck_del = blck_del;
    }

    public short getSngl_blck() {
        return sngl_blck;
    }

    public void setSngl_blck(short sngl_blck) {
        this.sngl_blck = sngl_blck;
    }

    public short getMachn_lock() {
        return machn_lock;
    }

    public void setMachn_lock(short machn_lock) {
        this.machn_lock = machn_lock;
    }

    public short getDry_run() {
        return dry_run;
    }

    public void setDry_run(short dry_run) {
        this.dry_run = dry_run;
    }

    public short getMem_prtct() {
        return mem_prtct;
    }

    public void setMem_prtct(short mem_prtct) {
        this.mem_prtct = mem_prtct;
    }

    public short getFeed_hold() {
        return feed_hold;
    }

    public void setFeed_hold(short feed_hold) {
        this.feed_hold = feed_hold;
    }

    public short getManual_rpd() {
        return manual_rpd;
    }

    public void setManual_rpd(short manual_rpd) {
        this.manual_rpd = manual_rpd;
    }

    public short[] getDummy() {
        return dummy;
    }

    public void setDummy(short[] dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "IODBSGNL{" +
                "datano=" + datano +
                ", type=" + type +
                ", mode=" + mode +
                ", hndl_ax=" + hndl_ax +
                ", hndl_mv=" + hndl_mv +
                ", rpd_ovrd=" + rpd_ovrd +
                ", jog_ovrd=" + jog_ovrd +
                ", feed_ovrd=" + feed_ovrd +
                ", spdl_ovrd=" + spdl_ovrd +
                ", blck_del=" + blck_del +
                ", sngl_blck=" + sngl_blck +
                ", machn_lock=" + machn_lock +
                ", dry_run=" + dry_run +
                ", mem_prtct=" + mem_prtct +
                ", feed_hold=" + feed_hold +
                ", manual_rpd=" + manual_rpd +
                ", dummy=" + Arrays.toString(dummy) +
                '}';
    }
}
