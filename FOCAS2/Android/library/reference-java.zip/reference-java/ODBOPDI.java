package jp.co.fanuc.fwlibe1;


public class ODBOPDI {
    private short axis;

    public short getAxis() {
        return axis;
    }

    public void setAxis(short axis) {
        this.axis = axis;
    }

    private char cdata;
    private short idata;
    private int ldata;

    public char getCdata() {
        return cdata;
    }

    public void setCdata(char cdata) {
        this.cdata = cdata;
    }

    public short getIdata() {
        return idata;
    }

    public void setIdata(short idata) {
        this.idata = idata;
    }

    public int getLdata() {
        return ldata;
    }

    public void setLdata(int ldata) {
        this.ldata = ldata;
    }

    @Override
    public String toString() {
        return "ODBOPDI{" +
                "axis=" + axis +
                ", cdata=" + cdata +
                ", idata=" + idata +
                ", ldata=" + ldata +
                '}';
    }
}
