package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_CCLRPRMFLAG {
    private char            BaudRate;
    private char            ID;
    private char            UseIDCount;
    private char            DataOnAbnormal;
    private char            Status;
    private char            RY;
    private char            RYSize;
    private char            RX;
    private char            RXSize;
    private char            RWw;
    private char            RWwSize;
    private char            RWr;
    private char            RWrSize;
    private char            pad[];

    public char getBaudRate() {
        return BaudRate;
    }

    public void setBaudRate(char baudRate) {
        BaudRate = baudRate;
    }

    public char getID() {
        return ID;
    }

    public void setID(char ID) {
        this.ID = ID;
    }

    public char getUseIDCount() {
        return UseIDCount;
    }

    public void setUseIDCount(char useIDCount) {
        UseIDCount = useIDCount;
    }

    public char getDataOnAbnormal() {
        return DataOnAbnormal;
    }

    public void setDataOnAbnormal(char dataOnAbnormal) {
        DataOnAbnormal = dataOnAbnormal;
    }

    public char getStatus() {
        return Status;
    }

    public void setStatus(char status) {
        Status = status;
    }

    public char getRY() {
        return RY;
    }

    public void setRY(char RY) {
        this.RY = RY;
    }

    public char getRYSize() {
        return RYSize;
    }

    public void setRYSize(char RYSize) {
        this.RYSize = RYSize;
    }

    public char getRX() {
        return RX;
    }

    public void setRX(char RX) {
        this.RX = RX;
    }

    public char getRXSize() {
        return RXSize;
    }

    public void setRXSize(char RXSize) {
        this.RXSize = RXSize;
    }

    public char getRWw() {
        return RWw;
    }

    public void setRWw(char RWw) {
        this.RWw = RWw;
    }

    public char getRWwSize() {
        return RWwSize;
    }

    public void setRWwSize(char RWwSize) {
        this.RWwSize = RWwSize;
    }

    public char getRWr() {
        return RWr;
    }

    public void setRWr(char RWr) {
        this.RWr = RWr;
    }

    public char getRWrSize() {
        return RWrSize;
    }

    public void setRWrSize(char RWrSize) {
        this.RWrSize = RWrSize;
    }

    public char[] getPad() {
        return pad;
    }

    public void setPad(char[] pad) {
        this.pad = pad;
    }

    @Override
    public String toString() {
        return "IN_CCLRPRMFLAG{" +
                "BaudRate=" + BaudRate +
                ", ID=" + ID +
                ", UseIDCount=" + UseIDCount +
                ", DataOnAbnormal=" + DataOnAbnormal +
                ", Status=" + Status +
                ", RY=" + RY +
                ", RYSize=" + RYSize +
                ", RX=" + RX +
                ", RXSize=" + RXSize +
                ", RWw=" + RWw +
                ", RWwSize=" + RWwSize +
                ", RWr=" + RWr +
                ", RWrSize=" + RWrSize +
                ", pad=" + Arrays.toString(pad) +
                '}';
    }
}
