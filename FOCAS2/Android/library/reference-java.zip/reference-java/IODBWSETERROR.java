package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBWSETERROR {
    private int d_no;
    private int data_act[];
    private int dp_act[];
    private int dsp_ix[];
    private REALWSET data[][];

    public int getD_no() {
        return d_no;
    }

    public void setD_no(int d_no) {
        this.d_no = d_no;
    }

    public int[] getData_act() {
        return data_act;
    }

    public void setData_act(int[] data_act) {
        this.data_act = data_act;
    }

    public int[] getDp_act() {
        return dp_act;
    }

    public void setDp_act(int[] dp_act) {
        this.dp_act = dp_act;
    }

    public int[] getDsp_ix() {
        return dsp_ix;
    }

    public void setDsp_ix(int[] dsp_ix) {
        this.dsp_ix = dsp_ix;
    }

    public REALWSET[][] getData() {
        return data;
    }

    public void setData(REALWSET[][] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBWSETERROR{" +
                "d_no=" + d_no +
                ", data_act=" + Arrays.toString(data_act) +
                ", dp_act=" + Arrays.toString(dp_act) +
                ", dsp_ix=" + Arrays.toString(dsp_ix) +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
