package jp.co.fanuc.fwlibe1;


public class IDBPMMGTI {
    private int top;
    private int num;

    public int getTop() {
        return top;
    }

    public void setTop(int top) {
        this.top = top;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    @Override
    public String toString() {
        return "IDBPMMGTI{" +
                "top=" + top +
                ", num=" + num +
                '}';
    }
}
