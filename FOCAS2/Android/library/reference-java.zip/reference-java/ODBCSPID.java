package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBCSPID {
    private char mt_spc[];
    private char mt_srn[];
    private char sbmt_spc[];
    private char sbmt_srn[];
    private char spm_spc[];
    private char spm_srn[];
    private char psm_spc[];
    private char psm_srn[];

    public char[] getMt_spc() {
        return mt_spc;
    }

    public void setMt_spc(char[] mt_spc) {
        this.mt_spc = mt_spc;
    }

    public char[] getMt_srn() {
        return mt_srn;
    }

    public void setMt_srn(char[] mt_srn) {
        this.mt_srn = mt_srn;
    }

    public char[] getSbmt_spc() {
        return sbmt_spc;
    }

    public void setSbmt_spc(char[] sbmt_spc) {
        this.sbmt_spc = sbmt_spc;
    }

    public char[] getSbmt_srn() {
        return sbmt_srn;
    }

    public void setSbmt_srn(char[] sbmt_srn) {
        this.sbmt_srn = sbmt_srn;
    }

    public char[] getSpm_spc() {
        return spm_spc;
    }

    public void setSpm_spc(char[] spm_spc) {
        this.spm_spc = spm_spc;
    }

    public char[] getSpm_srn() {
        return spm_srn;
    }

    public void setSpm_srn(char[] spm_srn) {
        this.spm_srn = spm_srn;
    }

    public char[] getPsm_spc() {
        return psm_spc;
    }

    public void setPsm_spc(char[] psm_spc) {
        this.psm_spc = psm_spc;
    }

    public char[] getPsm_srn() {
        return psm_srn;
    }

    public void setPsm_srn(char[] psm_srn) {
        this.psm_srn = psm_srn;
    }

    @Override
    public String toString() {
        return "ODBCSPID{" +
                "mt_spc=" + Arrays.toString(mt_spc) +
                ", mt_srn=" + Arrays.toString(mt_srn) +
                ", sbmt_spc=" + Arrays.toString(sbmt_spc) +
                ", sbmt_srn=" + Arrays.toString(sbmt_srn) +
                ", spm_spc=" + Arrays.toString(spm_spc) +
                ", spm_srn=" + Arrays.toString(spm_srn) +
                ", psm_spc=" + Arrays.toString(psm_spc) +
                ", psm_srn=" + Arrays.toString(psm_srn) +
                '}';
    }
}
