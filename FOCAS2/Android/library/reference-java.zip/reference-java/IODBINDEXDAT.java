package jp.co.fanuc.fwlibe1;


public class IODBINDEXDAT {
    private int            pos;
    private int            inp_width;
    private short          speed;
    private char            f_flg;
    private char            dummy;

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public int getInp_width() {
        return inp_width;
    }

    public void setInp_width(int inp_width) {
        this.inp_width = inp_width;
    }

    public short getSpeed() {
        return speed;
    }

    public void setSpeed(short speed) {
        this.speed = speed;
    }

    public char getF_flg() {
        return f_flg;
    }

    public void setF_flg(char f_flg) {
        this.f_flg = f_flg;
    }

    public char getDummy() {
        return dummy;
    }

    public void setDummy(char dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "IODBINDEXDAT{" +
                "pos=" + pos +
                ", inp_width=" + inp_width +
                ", speed=" + speed +
                ", f_flg=" + f_flg +
                ", dummy=" + dummy +
                '}';
    }
}
