package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBFIG {
    private int fig_type;

    public int getFig_type() {
        return fig_type;
    }

    public void setFig_type(int fig_type) {
        this.fig_type = fig_type;
    }

    public static class FIG {
        public static class PAR {
            private int ref_vtx[];
            private int adj_vtx1[];
            private int adj_vtx2[];
            private int adj_vtx3[];

            public int[] getRef_vtx() {
                return ref_vtx;
            }

            public void setRef_vtx(int[] ref_vtx) {
                this.ref_vtx = ref_vtx;
            }

            public int[] getAdj_vtx1() {
                return adj_vtx1;
            }

            public void setAdj_vtx1(int[] adj_vtx1) {
                this.adj_vtx1 = adj_vtx1;
            }

            public int[] getAdj_vtx2() {
                return adj_vtx2;
            }

            public void setAdj_vtx2(int[] adj_vtx2) {
                this.adj_vtx2 = adj_vtx2;
            }

            public int[] getAdj_vtx3() {
                return adj_vtx3;
            }

            public void setAdj_vtx3(int[] adj_vtx3) {
                this.adj_vtx3 = adj_vtx3;
            }

            @Override
            public String toString() {
                return "PAR{" +
                        "ref_vtx=" + Arrays.toString(ref_vtx) +
                        ", adj_vtx1=" + Arrays.toString(adj_vtx1) +
                        ", adj_vtx2=" + Arrays.toString(adj_vtx2) +
                        ", adj_vtx3=" + Arrays.toString(adj_vtx3) +
                        '}';
            }
        }
        public static class CYL {
            private int sta_pnt[];
            private int end_pnt[];
            private int radius[];

            public int[] getSta_pnt() {
                return sta_pnt;
            }

            public void setSta_pnt(int[] sta_pnt) {
                this.sta_pnt = sta_pnt;
            }

            public int[] getEnd_pnt() {
                return end_pnt;
            }

            public void setEnd_pnt(int[] end_pnt) {
                this.end_pnt = end_pnt;
            }

            public int[] getRadius() {
                return radius;
            }

            public void setRadius(int[] radius) {
                this.radius = radius;
            }

            @Override
            public String toString() {
                return "CYL{" +
                        "sta_pnt=" + Arrays.toString(sta_pnt) +
                        ", end_pnt=" + Arrays.toString(end_pnt) +
                        ", radius=" + Arrays.toString(radius) +
                        '}';
            }
        }
        public static class PLN {
            private int point[];
            private int vect[];

            public int[] getPoint() {
                return point;
            }

            public void setPoint(int[] point) {
                this.point = point;
            }

            public int[] getVect() {
                return vect;
            }

            public void setVect(int[] vect) {
                this.vect = vect;
            }

            @Override
            public String toString() {
                return "PLN{" +
                        "point=" + Arrays.toString(point) +
                        ", vect=" + Arrays.toString(vect) +
                        '}';
            }
        }
        private PAR par;
        private CYL cyl;
        private PLN pln;

        public PAR getPar() {
            return par;
        }

        public void setPar(PAR par) {
            this.par = par;
        }

        public CYL getCyl() {
            return cyl;
        }

        public void setCyl(CYL cyl) {
            this.cyl = cyl;
        }

        public PLN getPln() {
            return pln;
        }

        public void setPln(PLN pln) {
            this.pln = pln;
        }

        @Override
        public String toString() {
            return "FIG{" +
                    "par=" + par +
                    ", cyl=" + cyl +
                    ", pln=" + pln +
                    '}';
        }
    }
    private FIG fig;

    public FIG getFig() {
        return fig;
    }

    public void setFig(FIG fig) {
        this.fig = fig;
    }

    private short fig_no;
    private char n_unit;
    private char cb_form;

    public short getFig_no() {
        return fig_no;
    }

    public void setFig_no(short fig_no) {
        this.fig_no = fig_no;
    }

    public char getN_unit() {
        return n_unit;
    }

    public void setN_unit(char n_unit) {
        this.n_unit = n_unit;
    }

    public char getCb_form() {
        return cb_form;
    }

    public void setCb_form(char cb_form) {
        this.cb_form = cb_form;
    }

    @Override
    public String toString() {
        return "ODBFIG{" +
                "fig_type=" + fig_type +
                ", fig=" + fig +
                ", fig_no=" + fig_no +
                ", n_unit=" + n_unit +
                ", cb_form=" + cb_form +
                '}';
    }
}
