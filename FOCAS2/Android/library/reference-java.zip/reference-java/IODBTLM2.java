package jp.co.fanuc.fwlibe1;


public class IODBTLM2 {
    private short number;
    private short reserve;

    public short getNumber() {
        return number;
    }

    public void setNumber(short number) {
        this.number = number;
    }

    public short getReserve() {
        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    public static class ITEM {
        private char data1;
        private short data2;
        private int data4;

        public char getData1() {
            return data1;
        }

        public void setData1(char data1) {
            this.data1 = data1;
        }

        public short getData2() {
            return data2;
        }

        public void setData2(short data2) {
            this.data2 = data2;
        }

        public int getData4() {
            return data4;
        }

        public void setData4(int data4) {
            this.data4 = data4;
        }

        @Override
        public String toString() {
            return "ITEM{" +
                    "data1=" + data1 +
                    ", data2=" + data2 +
                    ", data4=" + data4 +
                    '}';
        }
    }
    private ITEM item;

    public ITEM getItem() {
        return item;
    }

    public void setItem(ITEM item) {
        this.item = item;
    }

    @Override
    public String toString() {
        return "IODBTLM2{" +
                "number=" + number +
                ", reserve=" + reserve +
                ", item=" + item +
                '}';
    }
}
