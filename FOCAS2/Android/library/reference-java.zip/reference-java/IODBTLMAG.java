package jp.co.fanuc.fwlibe1;


public class IODBTLMAG {
    private short magazine;
    private short pot;
    private short tool_index;

    public short getMagazine() {
        return magazine;
    }

    public void setMagazine(short magazine) {
        this.magazine = magazine;
    }

    public short getPot() {
        return pot;
    }

    public void setPot(short pot) {
        this.pot = pot;
    }

    public short getTool_index() {
        return tool_index;
    }

    public void setTool_index(short tool_index) {
        this.tool_index = tool_index;
    }

    @Override
    public String toString() {
        return "IODBTLMAG{" +
                "magazine=" + magazine +
                ", pot=" + pot +
                ", tool_index=" + tool_index +
                '}';
    }
}
