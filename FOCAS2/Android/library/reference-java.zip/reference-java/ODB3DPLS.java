package jp.co.fanuc.fwlibe1;


public class ODB3DPLS {
    private int right_angle_x;
    private int right_angle_y;
    private int tool_axis;
    private int tool_tip_a_b;
    private int tool_tip_c;

    public int getRight_angle_x() {
        return right_angle_x;
    }

    public void setRight_angle_x(int right_angle_x) {
        this.right_angle_x = right_angle_x;
    }

    public int getRight_angle_y() {
        return right_angle_y;
    }

    public void setRight_angle_y(int right_angle_y) {
        this.right_angle_y = right_angle_y;
    }

    public int getTool_axis() {
        return tool_axis;
    }

    public void setTool_axis(int tool_axis) {
        this.tool_axis = tool_axis;
    }

    public int getTool_tip_a_b() {
        return tool_tip_a_b;
    }

    public void setTool_tip_a_b(int tool_tip_a_b) {
        this.tool_tip_a_b = tool_tip_a_b;
    }

    public int getTool_tip_c() {
        return tool_tip_c;
    }

    public void setTool_tip_c(int tool_tip_c) {
        this.tool_tip_c = tool_tip_c;
    }

    @Override
    public String toString() {
        return "ODB3DPLS{" +
                "right_angle_x=" + right_angle_x +
                ", right_angle_y=" + right_angle_y +
                ", tool_axis=" + tool_axis +
                ", tool_tip_a_b=" + tool_tip_a_b +
                ", tool_tip_c=" + tool_tip_c +
                '}';
    }
}
