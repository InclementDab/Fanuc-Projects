package jp.co.fanuc.fwlibe1;


public class ODBACTPTW {
    private int mprgno;
    private int mblkno;
    private int sprgno;
    private int sblkno;

    public int getMprgno() {
        return mprgno;
    }

    public void setMprgno(int mprgno) {
        this.mprgno = mprgno;
    }

    public int getMblkno() {

        return mblkno;
    }

    public void setMblkno(int mblkno) {
        this.mblkno = mblkno;
    }

    public int getSprgno() {

        return sprgno;
    }

    public void setSprgno(int sprgno) {
        this.sprgno = sprgno;
    }

    public int getSblkno() {

        return sblkno;
    }

    public void setSblkno(int sblkno) {
        this.sblkno = sblkno;
    }

    @Override
    public String toString() {
        return "ODBACTPTW{" +
                "mprgno=" + mprgno +
                ", mblkno=" + mblkno +
                ", sprgno=" + sprgno +
                ", sblkno=" + sblkno +
                '}';
    }
}
