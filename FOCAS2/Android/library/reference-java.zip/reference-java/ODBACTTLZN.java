package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBACTTLZN {
    private short act_no;
    private int data[];

    public short getAct_no() {
        return act_no;
    }

    public void setAct_no(short act_no) {
        this.act_no = act_no;
    }

    public int[] getData() {
        return data;
    }

    public void setData(int[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ODBACTTLZN{" +
                "act_no=" + act_no +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
