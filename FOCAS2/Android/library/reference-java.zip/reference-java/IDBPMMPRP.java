package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBPMMPRP {
    private int chanl;
    private int group;
    private char folder[];
    private int warn;

    public int getChanl() {
        return chanl;
    }

    public void setChanl(int chanl) {
        this.chanl = chanl;
    }

    public int getGroup() {
        return group;
    }

    public void setGroup(int group) {
        this.group = group;
    }

    public char[] getFolder() {
        return folder;
    }

    public void setFolder(char[] folder) {
        this.folder = folder;
    }

    public int getWarn() {
        return warn;
    }

    public void setWarn(int warn) {
        this.warn = warn;
    }

    @Override
    public String toString() {
        return "IDBPMMPRP{" +
                "chanl=" + chanl +
                ", group=" + group +
                ", folder=" + Arrays.toString(folder) +
                ", warn=" + warn +
                '}';
    }
}
