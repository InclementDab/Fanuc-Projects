package jp.co.fanuc.fwlibe1;


public class IODBETP {
    private short ParameterType;

    public short getParameterType() {
        return ParameterType;
    }

    public void setParameterType(short parameterType) {
        ParameterType = parameterType;
    }
    public static class PRM{
        private TCPPRM tcp;
        private HOSTPRM host;
        private FTPPRM ftp;
        private ETBPRM etb;

        public TCPPRM getTcp() {
            return tcp;
        }

        public void setTcp(TCPPRM tcp) {
            this.tcp = tcp;
        }

        public HOSTPRM getHost() {
            return host;
        }

        public void setHost(HOSTPRM host) {
            this.host = host;
        }

        public FTPPRM getFtp() {
            return ftp;
        }

        public void setFtp(FTPPRM ftp) {
            this.ftp = ftp;
        }

        public ETBPRM getEtb() {
            return etb;
        }

        public void setEtb(ETBPRM etb) {
            this.etb = etb;
        }

        @Override
        public String toString() {
            return "PRM{" +
                    "tcp=" + tcp +
                    ", host=" + host +
                    ", ftp=" + ftp +
                    ", etb=" + etb +
                    '}';
        }
    }
    private PRM prm;

    public PRM getPrm() {
        return prm;
    }

    public void setPrm(PRM prm) {
        this.prm = prm;
    }

    @Override
    public String toString() {
        return "IODBETP{" +
                "ParameterType=" + ParameterType +
                ", prm=" + prm +
                '}';
    }
}
