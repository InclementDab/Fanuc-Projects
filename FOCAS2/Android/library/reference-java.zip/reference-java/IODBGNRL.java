package jp.co.fanuc.fwlibe1;


public class IODBGNRL {
    private short datano;
    private short type;
    private byte sgnal;

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public byte getSgnal() {
        return sgnal;
    }

    public void setSgnal(byte sgnal) {
        this.sgnal = sgnal;
    }

    @Override
    public String toString() {
        return "IODBGNRL{" +
                "datano=" + datano +
                ", type=" + type +
                ", sgnal=" + sgnal +
                '}';
    }
}
