package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBPSCD2 {
    private int slct;
    private int feed;
    private short power;
    private short freq;
    private short duty;
    private short g_press;
    private short g_kind;
    private short g_ready_t;
    private short displace;
    private int supple;
    private short edge_slt;
    private short appr_slt;
    private short pwr_ctrl;
    private int displace2;
    private char gap_axis;
    private char feed_dec;
    private char supple_dec;
    private char dsp2_dec;
    private short pb_power;
    private short reserve[];

    public int getSlct() {
        return slct;
    }

    public void setSlct(int slct) {
        this.slct = slct;
    }

    public int getFeed() {
        return feed;
    }

    public void setFeed(int feed) {
        this.feed = feed;
    }

    public short getPower() {
        return power;
    }

    public void setPower(short power) {
        this.power = power;
    }

    public short getFreq() {
        return freq;
    }

    public void setFreq(short freq) {
        this.freq = freq;
    }

    public short getDuty() {
        return duty;
    }

    public void setDuty(short duty) {
        this.duty = duty;
    }

    public short getG_press() {
        return g_press;
    }

    public void setG_press(short g_press) {
        this.g_press = g_press;
    }

    public short getG_kind() {
        return g_kind;
    }

    public void setG_kind(short g_kind) {
        this.g_kind = g_kind;
    }

    public short getG_ready_t() {
        return g_ready_t;
    }

    public void setG_ready_t(short g_ready_t) {
        this.g_ready_t = g_ready_t;
    }

    public short getDisplace() {
        return displace;
    }

    public void setDisplace(short displace) {
        this.displace = displace;
    }

    public int getSupple() {
        return supple;
    }

    public void setSupple(int supple) {
        this.supple = supple;
    }

    public short getEdge_slt() {
        return edge_slt;
    }

    public void setEdge_slt(short edge_slt) {
        this.edge_slt = edge_slt;
    }

    public short getAppr_slt() {
        return appr_slt;
    }

    public void setAppr_slt(short appr_slt) {
        this.appr_slt = appr_slt;
    }

    public short getPwr_ctrl() {
        return pwr_ctrl;
    }

    public void setPwr_ctrl(short pwr_ctrl) {
        this.pwr_ctrl = pwr_ctrl;
    }

    public int getDisplace2() {
        return displace2;
    }

    public void setDisplace2(int displace2) {
        this.displace2 = displace2;
    }

    public char getGap_axis() {
        return gap_axis;
    }

    public void setGap_axis(char gap_axis) {
        this.gap_axis = gap_axis;
    }

    public char getFeed_dec() {
        return feed_dec;
    }

    public void setFeed_dec(char feed_dec) {
        this.feed_dec = feed_dec;
    }

    public char getSupple_dec() {
        return supple_dec;
    }

    public void setSupple_dec(char supple_dec) {
        this.supple_dec = supple_dec;
    }

    public char getDsp2_dec() {
        return dsp2_dec;
    }

    public void setDsp2_dec(char dsp2_dec) {
        this.dsp2_dec = dsp2_dec;
    }

    public short getPb_power() {
        return pb_power;
    }

    public void setPb_power(short pb_power) {
        this.pb_power = pb_power;
    }

    public short[] getReserve() {
        return reserve;
    }

    public void setReserve(short[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBPSCD2{" +
                "slct=" + slct +
                ", feed=" + feed +
                ", power=" + power +
                ", freq=" + freq +
                ", duty=" + duty +
                ", g_press=" + g_press +
                ", g_kind=" + g_kind +
                ", g_ready_t=" + g_ready_t +
                ", displace=" + displace +
                ", supple=" + supple +
                ", edge_slt=" + edge_slt +
                ", appr_slt=" + appr_slt +
                ", pwr_ctrl=" + pwr_ctrl +
                ", displace2=" + displace2 +
                ", gap_axis=" + gap_axis +
                ", feed_dec=" + feed_dec +
                ", supple_dec=" + supple_dec +
                ", dsp2_dec=" + dsp2_dec +
                ", pb_power=" + pb_power +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
