package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_EIPA_ALLOC_PRM_FLG {
    private char State;
    private char Option;
    private char pad[];
    private IN_EIP_TYPE_PRM_FLG DI;
    private IN_EIP_TYPE_PRM_FLG DO;

    public char getState() {
        return State;
    }

    public void setState(char state) {
        State = state;
    }

    public char getOption() {
        return Option;
    }

    public void setOption(char option) {
        Option = option;
    }

    public char[] getPad() {
        return pad;
    }

    public void setPad(char[] pad) {
        this.pad = pad;
    }

    public IN_EIP_TYPE_PRM_FLG getDI() {
        return DI;
    }

    public void setDI(IN_EIP_TYPE_PRM_FLG DI) {
        this.DI = DI;
    }

    public IN_EIP_TYPE_PRM_FLG getDO() {
        return DO;
    }

    public void setDO(IN_EIP_TYPE_PRM_FLG DO) {
        this.DO = DO;
    }

    @Override
    public String toString() {
        return "IN_EIPA_ALLOC_PRM_FLG{" +
                "State=" + State +
                ", Option=" + Option +
                ", pad=" + Arrays.toString(pad) +
                ", DI=" + DI +
                ", DO=" + DO +
                '}';
    }
}
