package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBTPCMD {
    private int cmd_id;
    private int integer[];

    public int getCmd_id() {
        return cmd_id;
    }

    public void setCmd_id(int cmd_id) {
        this.cmd_id = cmd_id;
    }

    public int[] getInteger() {
        return integer;
    }

    public void setInteger(int[] integer) {
        this.integer = integer;
    }

    public static class  VAL {
        private int val;
        private int dec;

        public int getVal() {
            return val;
        }

        public void setVal(int val) {
            this.val = val;
        }

        public int getDec() {
            return dec;
        }

        public void setDec(int dec) {
            this.dec = dec;
        }

        @Override
        public String toString() {
            return "VAL{" +
                    "val=" + val +
                    ", dec=" + dec +
                    '}';
        }
    }
    private VAL val[];
    private char text[];

    public VAL[] getVal() {
        return val;
    }

    public void setVal(VAL[] val) {
        this.val = val;
    }

    public char[] getText() {
        return text;
    }

    public void setText(char[] text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return "IDBTPCMD{" +
                "cmd_id=" + cmd_id +
                ", integer=" + Arrays.toString(integer) +
                ", val=" + Arrays.toString(val) +
                ", text=" + Arrays.toString(text) +
                '}';
    }
}
