package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class FTPPRM {
    private char FTPServerUserName[];
    private char FTPServerPassword[];
    private char FTPServerLoginDirectory[];

    public char[] getFTPServerUserName() {
        return FTPServerUserName;
    }

    public void setFTPServerUserName(char[] FTPServerUserName) {
        this.FTPServerUserName = FTPServerUserName;
    }

    public char[] getFTPServerPassword() {
        return FTPServerPassword;
    }

    public void setFTPServerPassword(char[] FTPServerPassword) {
        this.FTPServerPassword = FTPServerPassword;
    }

    public char[] getFTPServerLoginDirectory() {
        return FTPServerLoginDirectory;
    }

    public void setFTPServerLoginDirectory(char[] FTPServerLoginDirectory) {
        this.FTPServerLoginDirectory = FTPServerLoginDirectory;
    }

    @Override
    public String toString() {
        return "FTPPRM{" +
                "FTPServerUserName=" + Arrays.toString(FTPServerUserName) +
                ", FTPServerPassword=" + Arrays.toString(FTPServerPassword) +
                ", FTPServerLoginDirectory=" + Arrays.toString(FTPServerLoginDirectory) +
                '}';
    }
}
