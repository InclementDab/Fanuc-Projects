package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class EIP_COMMON_PRM {
    private short TcpPort;
    private short UdpPort;
    private char DiDataOnAbnormal;
    private char Option1;
    private char pad[];

    public short getTcpPort() {
        return TcpPort;
    }

    public void setTcpPort(short tcpPort) {
        TcpPort = tcpPort;
    }

    public short getUdpPort() {
        return UdpPort;
    }

    public void setUdpPort(short udpPort) {
        UdpPort = udpPort;
    }

    public char getDiDataOnAbnormal() {
        return DiDataOnAbnormal;
    }

    public void setDiDataOnAbnormal(char diDataOnAbnormal) {
        DiDataOnAbnormal = diDataOnAbnormal;
    }

    public char getOption1() {
        return Option1;
    }

    public void setOption1(char option1) {
        Option1 = option1;
    }

    public char[] getPad() {
        return pad;
    }

    public void setPad(char[] pad) {
        this.pad = pad;
    }

    @Override
    public String toString() {
        return "EIP_COMMON_PRM{" +
                "TcpPort=" + TcpPort +
                ", UdpPort=" + UdpPort +
                ", DiDataOnAbnormal=" + DiDataOnAbnormal +
                ", Option1=" + Option1 +
                ", pad=" + Arrays.toString(pad) +
                '}';
    }
}
