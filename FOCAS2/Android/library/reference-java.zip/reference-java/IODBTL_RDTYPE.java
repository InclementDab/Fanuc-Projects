package jp.co.fanuc.fwlibe1;


public class IODBTL_RDTYPE {
    private char type;
    private char data_type;
    private char renew;
    private char reserve;

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }

    public char getData_type() {
        return data_type;
    }

    public void setData_type(char data_type) {
        this.data_type = data_type;
    }

    public char getRenew() {
        return renew;
    }

    public void setRenew(char renew) {
        this.renew = renew;
    }

    public char getReserve() {
        return reserve;
    }

    public void setReserve(char reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBTL_RDTYPE{" +
                "type=" + type +
                ", data_type=" + data_type +
                ", renew=" + renew +
                ", reserve=" + reserve +
                '}';
    }
}
