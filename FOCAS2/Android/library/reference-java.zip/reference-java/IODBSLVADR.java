package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBSLVADR {
    private char slave_no;
    private char di_size;
    private char di_type;
    private short di_addr;
    private char do_size;
    private char do_type;
    private short do_addr;
    private char reserve[];

    public char getSlave_no() {
        return slave_no;
    }

    public void setSlave_no(char slave_no) {
        this.slave_no = slave_no;
    }

    public char getDi_size() {
        return di_size;
    }

    public void setDi_size(char di_size) {
        this.di_size = di_size;
    }

    public char getDi_type() {
        return di_type;
    }

    public void setDi_type(char di_type) {
        this.di_type = di_type;
    }

    public short getDi_addr() {
        return di_addr;
    }

    public void setDi_addr(short di_addr) {
        this.di_addr = di_addr;
    }

    public char getDo_size() {
        return do_size;
    }

    public void setDo_size(char do_size) {
        this.do_size = do_size;
    }

    public char getDo_type() {
        return do_type;
    }

    public void setDo_type(char do_type) {
        this.do_type = do_type;
    }

    public short getDo_addr() {
        return do_addr;
    }

    public void setDo_addr(short do_addr) {
        this.do_addr = do_addr;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBSLVADR{" +
                "slave_no=" + slave_no +
                ", di_size=" + di_size +
                ", di_type=" + di_type +
                ", di_addr=" + di_addr +
                ", do_size=" + do_size +
                ", do_type=" + do_type +
                ", do_addr=" + do_addr +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
