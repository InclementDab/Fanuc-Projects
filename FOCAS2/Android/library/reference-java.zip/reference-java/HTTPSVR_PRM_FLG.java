package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class HTTPSVR_PRM_FLG {
    private char TcpPort;
    private char Timeout;
    private USER_ACCOUNT_PRM_FLG UserAccount[];

    public char getTcpPort() {
        return TcpPort;
    }

    public void setTcpPort(char tcpPort) {
        TcpPort = tcpPort;
    }

    public char getTimeout() {
        return Timeout;
    }

    public void setTimeout(char timeout) {
        Timeout = timeout;
    }

    public USER_ACCOUNT_PRM_FLG[] getUserAccount() {
        return UserAccount;
    }

    public void setUserAccount(USER_ACCOUNT_PRM_FLG[] userAccount) {
        UserAccount = userAccount;
    }

    @Override
    public String toString() {
        return "HTTPSVR_PRM_FLG{" +
                "TcpPort=" + TcpPort +
                ", Timeout=" + Timeout +
                ", UserAccount=" + Arrays.toString(UserAccount) +
                '}';
    }
}
