package jp.co.fanuc.fwlibe1;


public class ODBCMD64 {
    private char adrs;
    private char num;
    private short flag;
    private int dec_val;
    private double cmd_val;

    public char getAdrs() {
        return adrs;
    }

    public void setAdrs(char adrs) {
        this.adrs = adrs;
    }

    public char getNum() {
        return num;
    }

    public void setNum(char num) {
        this.num = num;
    }

    public short getFlag() {
        return flag;
    }

    public void setFlag(short flag) {
        this.flag = flag;
    }

    public int getDec_val() {
        return dec_val;
    }

    public void setDec_val(int dec_val) {
        this.dec_val = dec_val;
    }

    public double getCmd_val() {
        return cmd_val;
    }

    public void setCmd_val(double cmd_val) {
        this.cmd_val = cmd_val;
    }

    @Override
    public String toString() {
        return "ODBCMD64{" +
                "adrs=" + adrs +
                ", num=" + num +
                ", flag=" + flag +
                ", dec_val=" + dec_val +
                ", cmd_val=" + cmd_val +
                '}';
    }
}
