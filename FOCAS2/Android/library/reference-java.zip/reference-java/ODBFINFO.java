package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBFINFO {
    private char slotname[];
    private int fromnum;

    public char[] getSlotname() {
        return slotname;
    }

    public void setSlotname(char[] slotname) {
        this.slotname = slotname;
    }

    public int getFromnum() {
        return fromnum;
    }

    public void setFromnum(int fromnum) {
        this.fromnum = fromnum;
    }

    public static class  INFO{
        private char sysname[];
        private int fromsize;

        public char[] getSysname() {
            return sysname;
        }

        public void setSysname(char[] sysname) {
            this.sysname = sysname;
        }

        public int getFromsize() {
            return fromsize;
        }

        public void setFromsize(int fromsize) {
            this.fromsize = fromsize;
        }

        @Override
        public String toString() {
            return "INFO{" +
                    "sysname=" + Arrays.toString(sysname) +
                    ", fromsize=" + fromsize +
                    '}';
        }
    }
    private INFO info[];

    public INFO[] getInfo() {
        return info;
    }

    public void setInfo(INFO[] info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "ODBFINFO{" +
                "slotname=" + Arrays.toString(slotname) +
                ", fromnum=" + fromnum +
                ", info=" + Arrays.toString(info) +
                '}';
    }
}
