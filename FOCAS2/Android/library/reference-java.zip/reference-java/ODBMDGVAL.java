package jp.co.fanuc.fwlibe1;


public class ODBMDGVAL {
    private int lval;
    private int ulval;
    private short sval;
    private short usval;
    private char cval;
    private char ucval;

    public int getLval() {
        return lval;
    }

    public void setLval(int lval) {
        this.lval = lval;
    }

    public int getUlval() {
        return ulval;
    }

    public void setUlval(int ulval) {
        this.ulval = ulval;
    }

    public short getSval() {
        return sval;
    }

    public void setSval(short sval) {
        this.sval = sval;
    }

    public short getUsval() {
        return usval;
    }

    public void setUsval(short usval) {
        this.usval = usval;
    }

    public char getCval() {
        return cval;
    }

    public void setCval(char cval) {
        this.cval = cval;
    }

    public char getUcval() {
        return ucval;
    }

    public void setUcval(char ucval) {
        this.ucval = ucval;
    }

    @Override
    public String toString() {
        return "ODBMDGVAL{" +
                "lval=" + lval +
                ", ulval=" + ulval +
                ", sval=" + sval +
                ", usval=" + usval +
                ", cval=" + cval +
                ", ucval=" + ucval +
                '}';
    }
}
