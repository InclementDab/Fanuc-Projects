package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBBINFO {
    private short iochno;
    private short grpno;
    private short axis;
    private char name;
    private char suff;
    private short reserve[];

    public short getIochno() {
        return iochno;
    }

    public void setIochno(short iochno) {
        this.iochno = iochno;
    }

    public short getGrpno() {
        return grpno;
    }

    public void setGrpno(short grpno) {
        this.grpno = grpno;
    }

    public short getAxis() {
        return axis;
    }

    public void setAxis(short axis) {
        this.axis = axis;
    }

    public char getName() {
        return name;
    }

    public void setName(char name) {
        this.name = name;
    }

    public char getSuff() {
        return suff;
    }

    public void setSuff(char suff) {
        this.suff = suff;
    }

    public short[] getReserve() {
        return reserve;
    }

    public void setReserve(short[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "ODBBINFO{" +
                "iochno=" + iochno +
                ", grpno=" + grpno +
                ", axis=" + axis +
                ", name=" + name +
                ", suff=" + suff +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
