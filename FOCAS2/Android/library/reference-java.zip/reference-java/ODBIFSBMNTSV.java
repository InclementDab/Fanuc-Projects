package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBMNTSV {
    private short axis_num;
    private char axis_name[];
    private short line;
    private char amp_name[];
    private char amp_series[];
    private char amp_cur[];
    private char amp_edt[];
    private short amp_axis_num;
    private char amp_spec_num[];
    private char amp_serial_num[];

    public short getAxis_num() {
        return axis_num;
    }

    public void setAxis_num(short axis_num) {
        this.axis_num = axis_num;
    }

    public char[] getAxis_name() {
        return axis_name;
    }

    public void setAxis_name(char[] axis_name) {
        this.axis_name = axis_name;
    }

    public short getLine() {
        return line;
    }

    public void setLine(short line) {
        this.line = line;
    }

    public char[] getAmp_name() {
        return amp_name;
    }

    public void setAmp_name(char[] amp_name) {
        this.amp_name = amp_name;
    }

    public char[] getAmp_series() {
        return amp_series;
    }

    public void setAmp_series(char[] amp_series) {
        this.amp_series = amp_series;
    }

    public char[] getAmp_cur() {
        return amp_cur;
    }

    public void setAmp_cur(char[] amp_cur) {
        this.amp_cur = amp_cur;
    }

    public char[] getAmp_edt() {
        return amp_edt;
    }

    public void setAmp_edt(char[] amp_edt) {
        this.amp_edt = amp_edt;
    }

    public short getAmp_axis_num() {
        return amp_axis_num;
    }

    public void setAmp_axis_num(short amp_axis_num) {
        this.amp_axis_num = amp_axis_num;
    }

    public char[] getAmp_spec_num() {
        return amp_spec_num;
    }

    public void setAmp_spec_num(char[] amp_spec_num) {
        this.amp_spec_num = amp_spec_num;
    }

    public char[] getAmp_serial_num() {
        return amp_serial_num;
    }

    public void setAmp_serial_num(char[] amp_serial_num) {
        this.amp_serial_num = amp_serial_num;
    }

    @Override
    public String toString() {
        return "ODBIFSBMNTSV{" +
                "axis_num=" + axis_num +
                ", axis_name=" + Arrays.toString(axis_name) +
                ", line=" + line +
                ", amp_name=" + Arrays.toString(amp_name) +
                ", amp_series=" + Arrays.toString(amp_series) +
                ", amp_cur=" + Arrays.toString(amp_cur) +
                ", amp_edt=" + Arrays.toString(amp_edt) +
                ", amp_axis_num=" + amp_axis_num +
                ", amp_spec_num=" + Arrays.toString(amp_spec_num) +
                ", amp_serial_num=" + Arrays.toString(amp_serial_num) +
                '}';
    }
}
