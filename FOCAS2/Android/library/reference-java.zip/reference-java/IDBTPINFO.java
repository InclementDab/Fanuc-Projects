package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBTPINFO {
    private char			prg_name[];
    private char			comment[];
    private int        	axis;
    private char			out_nc_prg[];
    private int 			reserve[];

    public char[] getPrg_name() {
        return prg_name;
    }

    public void setPrg_name(char[] prg_name) {
        this.prg_name = prg_name;
    }

    public char[] getComment() {
        return comment;
    }

    public void setComment(char[] comment) {
        this.comment = comment;
    }

    public int getAxis() {
        return axis;
    }

    public void setAxis(int axis) {
        this.axis = axis;
    }

    public char[] getOut_nc_prg() {
        return out_nc_prg;
    }

    public void setOut_nc_prg(char[] out_nc_prg) {
        this.out_nc_prg = out_nc_prg;
    }

    public int[] getReserve() {
        return reserve;
    }

    public void setReserve(int[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IDBTPINFO{" +
                "prg_name=" + Arrays.toString(prg_name) +
                ", comment=" + Arrays.toString(comment) +
                ", axis=" + axis +
                ", out_nc_prg=" + Arrays.toString(out_nc_prg) +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
