package jp.co.fanuc.fwlibe1;


public class IODBRBSUMMARY {
    private char signal_type;
    private char reserve;
    private short no;

    public char getSignal_type() {
        return signal_type;
    }

    public void setSignal_type(char signal_type) {
        this.signal_type = signal_type;
    }

    public char getReserve() {
        return reserve;
    }

    public void setReserve(char reserve) {
        this.reserve = reserve;
    }

    public short getNo() {
        return no;
    }

    public void setNo(short no) {
        this.no = no;
    }

    @Override
    public String toString() {
        return "IODBRBSUMMARY{" +
                "signal_type=" + signal_type +
                ", reserve=" + reserve +
                ", no=" + no +
                '}';
    }
}
