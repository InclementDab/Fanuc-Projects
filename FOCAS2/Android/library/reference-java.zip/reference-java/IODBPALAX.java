package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBPALAX {
    private int max_pal;
    private int data[];

    public int getMax_pal() {
        return max_pal;
    }

    public void setMax_pal(int max_pal) {
        this.max_pal = max_pal;
    }

    public int[] getData() {
        return data;
    }

    public void setData(int[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBPALAX{" +
                "max_pal=" + max_pal +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
