package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBHPST {
    private short slct;
    private short hpcc;
    private short multi;
    private short ovr1;
    private short ign_f;
    private short foward;
    private int max_f;
    private short ovr2;
    private short ovr3;
    private short ovr4;
    private int reserve[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getHpcc() {
        return hpcc;
    }

    public void setHpcc(short hpcc) {
        this.hpcc = hpcc;
    }

    public short getMulti() {
        return multi;
    }

    public void setMulti(short multi) {
        this.multi = multi;
    }

    public short getOvr1() {
        return ovr1;
    }

    public void setOvr1(short ovr1) {
        this.ovr1 = ovr1;
    }

    public short getIgn_f() {
        return ign_f;
    }

    public void setIgn_f(short ign_f) {
        this.ign_f = ign_f;
    }

    public short getFoward() {
        return foward;
    }

    public void setFoward(short foward) {
        this.foward = foward;
    }

    public int getMax_f() {
        return max_f;
    }

    public void setMax_f(int max_f) {
        this.max_f = max_f;
    }

    public short getOvr2() {
        return ovr2;
    }

    public void setOvr2(short ovr2) {
        this.ovr2 = ovr2;
    }

    public short getOvr3() {
        return ovr3;
    }

    public void setOvr3(short ovr3) {
        this.ovr3 = ovr3;
    }

    public short getOvr4() {
        return ovr4;
    }

    public void setOvr4(short ovr4) {
        this.ovr4 = ovr4;
    }

    public int[] getReserve() {
        return reserve;
    }

    public void setReserve(int[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBHPST{" +
                "slct=" + slct +
                ", hpcc=" + hpcc +
                ", multi=" + multi +
                ", ovr1=" + ovr1 +
                ", ign_f=" + ign_f +
                ", foward=" + foward +
                ", max_f=" + max_f +
                ", ovr2=" + ovr2 +
                ", ovr3=" + ovr3 +
                ", ovr4=" + ovr4 +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
