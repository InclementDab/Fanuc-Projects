package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBINDEXPOSDAT {
    private int            min_value;
    private int            max_value;
    private char            setting;
    private char            dummy[];

    public int getMin_value() {
        return min_value;
    }

    public void setMin_value(int min_value) {
        this.min_value = min_value;
    }

    public int getMax_value() {
        return max_value;
    }

    public void setMax_value(int max_value) {
        this.max_value = max_value;
    }

    public char getSetting() {
        return setting;
    }

    public void setSetting(char setting) {
        this.setting = setting;
    }

    public char[] getDummy() {
        return dummy;
    }

    public void setDummy(char[] dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "IODBINDEXPOSDAT{" +
                "min_value=" + min_value +
                ", max_value=" + max_value +
                ", setting=" + setting +
                ", dummy=" + Arrays.toString(dummy) +
                '}';
    }
}
