package jp.co.fanuc.fwlibe1;


public class MAINTAIN_PRM_FLG {
    private PING_PRM_FLG opposite;

    public PING_PRM_FLG getOpposite() {
        return opposite;
    }

    public void setOpposite(PING_PRM_FLG opposite) {
        this.opposite = opposite;
    }

    @Override
    public String toString() {
        return "MAINTAIN_PRM_FLG{" +
                "opposite=" + opposite +
                '}';
    }
}
