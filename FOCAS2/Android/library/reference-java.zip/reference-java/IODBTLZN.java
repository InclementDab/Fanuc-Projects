package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTLZN {
    private short act_slct;
    private int data[];

    public short getAct_slct() {
        return act_slct;
    }

    public void setAct_slct(short act_slct) {
        this.act_slct = act_slct;
    }

    public int[] getData() {
        return data;
    }

    public void setData(int[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBTLZN{" +
                "act_slct=" + act_slct +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
