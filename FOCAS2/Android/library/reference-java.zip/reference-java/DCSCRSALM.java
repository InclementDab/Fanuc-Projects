package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class DCSCRSALM {
    private int existFlag;
    private int pmc_no;

    public int getExistFlag() {
        return existFlag;
    }

    public void setExistFlag(int existFlag) {
        this.existFlag = existFlag;
    }

    public int getPmc_no() {
        return pmc_no;
    }

    public void setPmc_no(int pmc_no) {
        this.pmc_no = pmc_no;
    }

    public static class PMC {
        private char pmc_adr[];
        private int pmc_data[];
        private char dcs_adr[];
        private int dcs_data[];

        public char[] getPmc_adr() {
            return pmc_adr;
        }

        public void setPmc_adr(char[] pmc_adr) {
            this.pmc_adr = pmc_adr;
        }

        public int[] getPmc_data() {
            return pmc_data;
        }

        public void setPmc_data(int[] pmc_data) {
            this.pmc_data = pmc_data;
        }

        public char[] getDcs_adr() {
            return dcs_adr;
        }

        public void setDcs_adr(char[] dcs_adr) {
            this.dcs_adr = dcs_adr;
        }

        public int[] getDcs_data() {
            return dcs_data;
        }

        public void setDcs_data(int[] dcs_data) {
            this.dcs_data = dcs_data;
        }

        @Override
        public String toString() {
            return "PMC{" +
                    "pmc_adr=" + Arrays.toString(pmc_adr) +
                    ", pmc_data=" + Arrays.toString(pmc_data) +
                    ", dcs_adr=" + Arrays.toString(dcs_adr) +
                    ", dcs_data=" + Arrays.toString(dcs_data) +
                    '}';
        }
    }
    public static class DCSPMC {
        private char pmc_adr[];
        private int pmc_data[];
        private char dcs_adr[];
        private int dcs_data[];

        public char[] getPmc_adr() {
            return pmc_adr;
        }

        public void setPmc_adr(char[] pmc_adr) {
            this.pmc_adr = pmc_adr;
        }

        public int[] getPmc_data() {
            return pmc_data;
        }

        public void setPmc_data(int[] pmc_data) {
            this.pmc_data = pmc_data;
        }

        public char[] getDcs_adr() {
            return dcs_adr;
        }

        public void setDcs_adr(char[] dcs_adr) {
            this.dcs_adr = dcs_adr;
        }

        public int[] getDcs_data() {
            return dcs_data;
        }

        public void setDcs_data(int[] dcs_data) {
            this.dcs_data = dcs_data;
        }

        @Override
        public String toString() {
            return "DCSPMC{" +
                    "pmc_adr=" + Arrays.toString(pmc_adr) +
                    ", pmc_data=" + Arrays.toString(pmc_data) +
                    ", dcs_adr=" + Arrays.toString(dcs_adr) +
                    ", dcs_data=" + Arrays.toString(dcs_data) +
                    '}';
        }
    }
    private PMC pmc;
    private DCSPMC dcspmc;

    public PMC getPmc() {
        return pmc;
    }

    public void setPmc(PMC pmc) {
        this.pmc = pmc;
    }

    public DCSPMC getDcspmc() {
        return dcspmc;
    }

    public void setDcspmc(DCSPMC dcspmc) {
        this.dcspmc = dcspmc;
    }

    @Override
    public String toString() {
        return "DCSCRSALM{" +
                "existFlag=" + existFlag +
                ", pmc_no=" + pmc_no +
                ", pmc=" + pmc +
                ", dcspmc=" + dcspmc +
                '}';
    }
}
