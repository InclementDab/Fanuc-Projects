package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class COMMON_PRM {
    private char OwnMacAddress[];
    private char OwnIpAddress[];
    private char SubNetmask[];
    private char RouterIpAddress[];
    private char DnsServer1IpAddress[];
    private char DnsServer2IpAddress[];
    private char OwnHostName[];
    private char OwnDomain[];

    public char[] getOwnMacAddress() {
        return OwnMacAddress;
    }

    public void setOwnMacAddress(char[] ownMacAddress) {
        OwnMacAddress = ownMacAddress;
    }

    public char[] getOwnIpAddress() {
        return OwnIpAddress;
    }

    public void setOwnIpAddress(char[] ownIpAddress) {
        OwnIpAddress = ownIpAddress;
    }

    public char[] getSubNetmask() {
        return SubNetmask;
    }

    public void setSubNetmask(char[] subNetmask) {
        SubNetmask = subNetmask;
    }

    public char[] getRouterIpAddress() {
        return RouterIpAddress;
    }

    public void setRouterIpAddress(char[] routerIpAddress) {
        RouterIpAddress = routerIpAddress;
    }

    public char[] getDnsServer1IpAddress() {
        return DnsServer1IpAddress;
    }

    public void setDnsServer1IpAddress(char[] dnsServer1IpAddress) {
        DnsServer1IpAddress = dnsServer1IpAddress;
    }

    public char[] getDnsServer2IpAddress() {
        return DnsServer2IpAddress;
    }

    public void setDnsServer2IpAddress(char[] dnsServer2IpAddress) {
        DnsServer2IpAddress = dnsServer2IpAddress;
    }

    public char[] getOwnHostName() {
        return OwnHostName;
    }

    public void setOwnHostName(char[] ownHostName) {
        OwnHostName = ownHostName;
    }

    public char[] getOwnDomain() {
        return OwnDomain;
    }

    public void setOwnDomain(char[] ownDomain) {
        OwnDomain = ownDomain;
    }

    @Override
    public String toString() {
        return "COMMON_PRM{" +
                "OwnMacAddress=" + Arrays.toString(OwnMacAddress) +
                ", OwnIpAddress=" + Arrays.toString(OwnIpAddress) +
                ", SubNetmask=" + Arrays.toString(SubNetmask) +
                ", RouterIpAddress=" + Arrays.toString(RouterIpAddress) +
                ", DnsServer1IpAddress=" + Arrays.toString(DnsServer1IpAddress) +
                ", DnsServer2IpAddress=" + Arrays.toString(DnsServer2IpAddress) +
                ", OwnHostName=" + Arrays.toString(OwnHostName) +
                ", OwnDomain=" + Arrays.toString(OwnDomain) +
                '}';
    }
}
