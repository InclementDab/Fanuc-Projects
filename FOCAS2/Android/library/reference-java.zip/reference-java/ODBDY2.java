package jp.co.fanuc.fwlibe1;

import java.util.Arrays;


public class ODBDY2 {
    private short dummy;
    private short axis;
    private int alarm;
    private int prgnum;
    private int prgmnum;
    private int seqnum;
    private int actf;
    private int acts;
    private FAXIS faxis;
    private OAXIS oaxis;

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public short getAxis() {

        return axis;
    }

    public void setAxis(short axis) {
        this.axis = axis;
    }

    public int getAlarm() {

        return alarm;
    }

    public void setAlarm(int alarm) {
        this.alarm = alarm;
    }

    public int getPrgnum() {

        return prgnum;
    }

    public void setPrgnum(int prgnum) {
        this.prgnum = prgnum;
    }

    public int getPrgmnum() {

        return prgmnum;
    }

    public void setPrgmnum(int prgmnum) {
        this.prgmnum = prgmnum;
    }

    public int getSeqnum() {

        return seqnum;
    }

    public void setSeqnum(int seqnum) {
        this.seqnum = seqnum;
    }

    public int getActf() {

        return actf;
    }

    public void setActf(int actf) {
        this.actf = actf;
    }

    public int getActs() {

        return acts;
    }

    public void setActs(int acts) {
        this.acts = acts;
    }


    public FAXIS getFaxis() {
        return faxis;
    }

    public void setFaxis(FAXIS faxis) {
        this.faxis = faxis;
    }

    public OAXIS getOaxis() {

        return oaxis;
    }

    public void setOaxis(OAXIS oaxis) {
        this.oaxis = oaxis;
    }

    @Override
    public String toString() {
        return "ODBDY2{" +
                "dummy=" + dummy +
                ", axis=" + axis +
                ", alarm=" + alarm +
                ", prgnum=" + prgnum +
                ", prgmnum=" + prgmnum +
                ", seqnum=" + seqnum +
                ", actf=" + actf +
                ", acts=" + acts +
                ", faxis=" + faxis +
                ", oaxis=" + oaxis +
                '}';
    }

    public static class FAXIS {
        private int absolute[];
        private int machine[];
        private int relative[];
        private int distance[];

        public int[] getAbsolute() {
            return absolute;
        }

        public void setAbsolute(int[] absolute) {
            this.absolute = absolute;
        }

        public int[] getMachine() {

            return machine;
        }

        public void setMachine(int[] machine) {
            this.machine = machine;
        }

        public int[] getRelative() {

            return relative;
        }

        public void setRelative(int[] relative) {
            this.relative = relative;
        }

        public int[] getDistance() {

            return distance;
        }

        public void setDistance(int[] distance) {
            this.distance = distance;
        }

        @Override
        public String toString() {
            return "FAXIS{" +
                    "absolute=" + Arrays.toString(absolute) +
                    ", machine=" + Arrays.toString(machine) +
                    ", relative=" + Arrays.toString(relative) +
                    ", distance=" + Arrays.toString(distance) +
                    '}';
        }
    }

    public static class OAXIS {
        private int absolute;
        private int machine;
        private int relative;
        private int distance;

        public int getAbsolute() {
            return absolute;
        }

        public void setAbsolute(int absolute) {
            this.absolute = absolute;
        }

        public int getMachine() {

            return machine;
        }

        public void setMachine(int machine) {
            this.machine = machine;
        }

        public int getRelative() {

            return relative;
        }

        public void setRelative(int relative) {
            this.relative = relative;
        }

        public int getDistance() {

            return distance;
        }

        public void setDistance(int distance) {
            this.distance = distance;
        }

        @Override
        public String toString() {
            return "OAXIS{" +
                    "absolute=" + absolute +
                    ", machine=" + machine +
                    ", relative=" + relative +
                    ", distance=" + distance +
                    '}';
        }
    }


}
