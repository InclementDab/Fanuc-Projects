package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBUNSOLIC2 {
    private char ipaddr[];
    private int port;
    private short retry;
    private short timeout;
    private short alivetime;
    private char dummy1[];
    private UNSOLICMSG_TYPE_PRM cntrl;
    private short transnum;
    private char dummy2[];
    private UNSOLICMSG_TYPE_PRM trans[];

    public char[] getIpaddr() {
        return ipaddr;
    }

    public void setIpaddr(char[] ipaddr) {
        this.ipaddr = ipaddr;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public short getRetry() {
        return retry;
    }

    public void setRetry(short retry) {
        this.retry = retry;
    }

    public short getTimeout() {
        return timeout;
    }

    public void setTimeout(short timeout) {
        this.timeout = timeout;
    }

    public short getAlivetime() {
        return alivetime;
    }

    public void setAlivetime(short alivetime) {
        this.alivetime = alivetime;
    }

    public char[] getDummy1() {
        return dummy1;
    }

    public void setDummy1(char[] dummy1) {
        this.dummy1 = dummy1;
    }

    public UNSOLICMSG_TYPE_PRM getCntrl() {
        return cntrl;
    }

    public void setCntrl(UNSOLICMSG_TYPE_PRM cntrl) {
        this.cntrl = cntrl;
    }

    public short getTransnum() {
        return transnum;
    }

    public void setTransnum(short transnum) {
        this.transnum = transnum;
    }

    public char[] getDummy2() {
        return dummy2;
    }

    public void setDummy2(char[] dummy2) {
        this.dummy2 = dummy2;
    }

    public UNSOLICMSG_TYPE_PRM[] getTrans() {
        return trans;
    }

    public void setTrans(UNSOLICMSG_TYPE_PRM[] trans) {
        this.trans = trans;
    }

    @Override
    public String toString() {
        return "IODBUNSOLIC2{" +
                "ipaddr=" + Arrays.toString(ipaddr) +
                ", port=" + port +
                ", retry=" + retry +
                ", timeout=" + timeout +
                ", alivetime=" + alivetime +
                ", dummy1=" + Arrays.toString(dummy1) +
                ", cntrl=" + cntrl +
                ", transnum=" + transnum +
                ", dummy2=" + Arrays.toString(dummy2) +
                ", trans=" + Arrays.toString(trans) +
                '}';
    }
}
