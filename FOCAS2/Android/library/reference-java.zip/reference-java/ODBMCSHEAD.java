package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMCSHEAD {
    private char    layout     ;
    private char    string1[];
    private char    string2[];

    public char getLayout() {
        return layout;
    }

    public void setLayout(char layout) {
        this.layout = layout;
    }

    public char[] getString1() {
        return string1;
    }

    public void setString1(char[] string1) {
        this.string1 = string1;
    }

    public char[] getString2() {
        return string2;
    }

    public void setString2(char[] string2) {
        this.string2 = string2;
    }

    @Override
    public String toString() {
        return "ODBMCSHEAD{" +
                "layout=" + layout +
                ", string1=" + Arrays.toString(string1) +
                ", string2=" + Arrays.toString(string2) +
                '}';
    }
}
