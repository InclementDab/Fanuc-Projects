package jp.co.fanuc.fwlibe1;


public class CEXEINFO {
    private int cond;
    private int cycle;
    private int count;
    private int time;
    private int dummy1;
    private int dummy2;
    private int dummy3;
    private int dummy4;

    public int getCond() {
        return cond;
    }

    public void setCond(int cond) {
        this.cond = cond;
    }

    public int getCycle() {
        return cycle;
    }

    public void setCycle(int cycle) {
        this.cycle = cycle;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public int getDummy1() {
        return dummy1;
    }

    public void setDummy1(int dummy1) {
        this.dummy1 = dummy1;
    }

    public int getDummy2() {
        return dummy2;
    }

    public void setDummy2(int dummy2) {
        this.dummy2 = dummy2;
    }

    public int getDummy3() {
        return dummy3;
    }

    public void setDummy3(int dummy3) {
        this.dummy3 = dummy3;
    }

    public int getDummy4() {
        return dummy4;
    }

    public void setDummy4(int dummy4) {
        this.dummy4 = dummy4;
    }

    @Override
    public String toString() {
        return "CEXEINFO{" +
                "cond=" + cond +
                ", cycle=" + cycle +
                ", count=" + count +
                ", time=" + time +
                ", dummy1=" + dummy1 +
                ", dummy2=" + dummy2 +
                ", dummy3=" + dummy3 +
                ", dummy4=" + dummy4 +
                '}';
    }
}
