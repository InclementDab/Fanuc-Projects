package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_EIPS_ALLOC_PRM_FLG {
    private char IpAddress;
    private char Option1;
    private char Option2;
    private char DataUnit;
    private char Endian;
    private char ConfigInstance;
    private char pad1[];
    private IN_EIPS_CONN_PRM_FLG ConnT2O;
    private IN_EIPS_CONN_PRM_FLG ConnO2T;
    private char reserve1;
    private char reserve2;
    private char ProductTrigger;
    private char Timeout;
    private char Reconnect;
    private char VendorID;
    private char DeviceType;
    private char ProductCode;
    private char MajorRevision;
    private char MinorRevision;
    private char Compatibility;
    private char pad2;

    public char getIpAddress() {
        return IpAddress;
    }

    public void setIpAddress(char ipAddress) {
        IpAddress = ipAddress;
    }

    public char getOption1() {
        return Option1;
    }

    public void setOption1(char option1) {
        Option1 = option1;
    }

    public char getOption2() {
        return Option2;
    }

    public void setOption2(char option2) {
        Option2 = option2;
    }

    public char getDataUnit() {
        return DataUnit;
    }

    public void setDataUnit(char dataUnit) {
        DataUnit = dataUnit;
    }

    public char getEndian() {
        return Endian;
    }

    public void setEndian(char endian) {
        Endian = endian;
    }

    public char getConfigInstance() {
        return ConfigInstance;
    }

    public void setConfigInstance(char configInstance) {
        ConfigInstance = configInstance;
    }

    public char[] getPad1() {
        return pad1;
    }

    public void setPad1(char[] pad1) {
        this.pad1 = pad1;
    }

    public IN_EIPS_CONN_PRM_FLG getConnT2O() {
        return ConnT2O;
    }

    public void setConnT2O(IN_EIPS_CONN_PRM_FLG connT2O) {
        ConnT2O = connT2O;
    }

    public IN_EIPS_CONN_PRM_FLG getConnO2T() {
        return ConnO2T;
    }

    public void setConnO2T(IN_EIPS_CONN_PRM_FLG connO2T) {
        ConnO2T = connO2T;
    }

    public char getReserve1() {
        return reserve1;
    }

    public void setReserve1(char reserve1) {
        this.reserve1 = reserve1;
    }

    public char getReserve2() {
        return reserve2;
    }

    public void setReserve2(char reserve2) {
        this.reserve2 = reserve2;
    }

    public char getProductTrigger() {
        return ProductTrigger;
    }

    public void setProductTrigger(char productTrigger) {
        ProductTrigger = productTrigger;
    }

    public char getTimeout() {
        return Timeout;
    }

    public void setTimeout(char timeout) {
        Timeout = timeout;
    }

    public char getReconnect() {
        return Reconnect;
    }

    public void setReconnect(char reconnect) {
        Reconnect = reconnect;
    }

    public char getVendorID() {
        return VendorID;
    }

    public void setVendorID(char vendorID) {
        VendorID = vendorID;
    }

    public char getDeviceType() {
        return DeviceType;
    }

    public void setDeviceType(char deviceType) {
        DeviceType = deviceType;
    }

    public char getProductCode() {
        return ProductCode;
    }

    public void setProductCode(char productCode) {
        ProductCode = productCode;
    }

    public char getMajorRevision() {
        return MajorRevision;
    }

    public void setMajorRevision(char majorRevision) {
        MajorRevision = majorRevision;
    }

    public char getMinorRevision() {
        return MinorRevision;
    }

    public void setMinorRevision(char minorRevision) {
        MinorRevision = minorRevision;
    }

    public char getCompatibility() {
        return Compatibility;
    }

    public void setCompatibility(char compatibility) {
        Compatibility = compatibility;
    }

    public char getPad2() {
        return pad2;
    }

    public void setPad2(char pad2) {
        this.pad2 = pad2;
    }

    @Override
    public String toString() {
        return "IN_EIPS_ALLOC_PRM_FLG{" +
                "IpAddress=" + IpAddress +
                ", Option1=" + Option1 +
                ", Option2=" + Option2 +
                ", DataUnit=" + DataUnit +
                ", Endian=" + Endian +
                ", ConfigInstance=" + ConfigInstance +
                ", pad1=" + Arrays.toString(pad1) +
                ", ConnT2O=" + ConnT2O +
                ", ConnO2T=" + ConnO2T +
                ", reserve1=" + reserve1 +
                ", reserve2=" + reserve2 +
                ", ProductTrigger=" + ProductTrigger +
                ", Timeout=" + Timeout +
                ", Reconnect=" + Reconnect +
                ", VendorID=" + VendorID +
                ", DeviceType=" + DeviceType +
                ", ProductCode=" + ProductCode +
                ", MajorRevision=" + MajorRevision +
                ", MinorRevision=" + MinorRevision +
                ", Compatibility=" + Compatibility +
                ", pad2=" + pad2 +
                '}';
    }
}
