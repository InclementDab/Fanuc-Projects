package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBPITCHBLK {

    private short group_num;

    public short getGroup_num() {
        return group_num;
    }

    public void setGroup_num(short group_num) {
        this.group_num = group_num;
    }

    public static class  PGINF {
        private int s_no;
        private int e_no;
        private short attr;

        public int getS_no() {
            return s_no;
        }

        public void setS_no(int s_no) {
            this.s_no = s_no;
        }

        public int getE_no() {

            return e_no;
        }

        public void setE_no(int e_no) {
            this.e_no = e_no;
        }

        public short getAttr() {

            return attr;
        }

        public void setAttr(short attr) {
            this.attr = attr;
        }

        @Override
        public String toString() {
            return "PGINF{" +
                    "s_no=" + s_no +
                    ", e_no=" + e_no +
                    ", attr=" + attr +
                    '}';
        }
    }
    private PGINF pginf[];

    public PGINF[] getPginf() {
        return pginf;
    }

    public void setPginf(PGINF[] pginf) {
        this.pginf = pginf;
    }

    @Override
    public String toString() {
        return "IODBPITCHBLK{" +
                "group_num=" + group_num +
                ", pginf=" + Arrays.toString(pginf) +
                '}';
    }
}
