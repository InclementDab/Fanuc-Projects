package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBBTO {
    private short datano_s;
    private short type;
    private short datano_e;
    private int ofs[];

    public short getDatano_s() {
        return datano_s;
    }

    public void setDatano_s(short datano_s) {
        this.datano_s = datano_s;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getDatano_e() {
        return datano_e;
    }

    public void setDatano_e(short datano_e) {
        this.datano_e = datano_e;
    }

    public int[] getOfs() {
        return ofs;
    }

    public void setOfs(int[] ofs) {
        this.ofs = ofs;
    }

    @Override
    public String toString() {
        return "IODBBTO{" +
                "datano_s=" + datano_s +
                ", type=" + type +
                ", datano_e=" + datano_e +
                ", ofs=" + Arrays.toString(ofs) +
                '}';
    }
}
