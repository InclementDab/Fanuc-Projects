package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBBUSPRM {
    private char fdl_add;
    private char baudrate;
    private short tsl;
    private short min_tsdr;
    private short max_tsdr;
    private char tqui;
    private char tset;
    private int ttr;
    private char gap;
    private char hsa;
    private char max_retry;
    private char bp_flag;
    private short min_slv_int;
    private short poll_tout;
    private short data_cntl;
    private char reserve1[];
    private char cls2_name[];
    private short user_dlen;
    private char user_data[];
    private char reserve2[];

    public char getFdl_add() {
        return fdl_add;
    }

    public void setFdl_add(char fdl_add) {
        this.fdl_add = fdl_add;
    }

    public char getBaudrate() {
        return baudrate;
    }

    public void setBaudrate(char baudrate) {
        this.baudrate = baudrate;
    }

    public short getTsl() {
        return tsl;
    }

    public void setTsl(short tsl) {
        this.tsl = tsl;
    }

    public short getMin_tsdr() {
        return min_tsdr;
    }

    public void setMin_tsdr(short min_tsdr) {
        this.min_tsdr = min_tsdr;
    }

    public short getMax_tsdr() {
        return max_tsdr;
    }

    public void setMax_tsdr(short max_tsdr) {
        this.max_tsdr = max_tsdr;
    }

    public char getTqui() {
        return tqui;
    }

    public void setTqui(char tqui) {
        this.tqui = tqui;
    }

    public char getTset() {
        return tset;
    }

    public void setTset(char tset) {
        this.tset = tset;
    }

    public int getTtr() {
        return ttr;
    }

    public void setTtr(int ttr) {
        this.ttr = ttr;
    }

    public char getGap() {
        return gap;
    }

    public void setGap(char gap) {
        this.gap = gap;
    }

    public char getHsa() {
        return hsa;
    }

    public void setHsa(char hsa) {
        this.hsa = hsa;
    }

    public char getMax_retry() {
        return max_retry;
    }

    public void setMax_retry(char max_retry) {
        this.max_retry = max_retry;
    }

    public char getBp_flag() {
        return bp_flag;
    }

    public void setBp_flag(char bp_flag) {
        this.bp_flag = bp_flag;
    }

    public short getMin_slv_int() {
        return min_slv_int;
    }

    public void setMin_slv_int(short min_slv_int) {
        this.min_slv_int = min_slv_int;
    }

    public short getPoll_tout() {
        return poll_tout;
    }

    public void setPoll_tout(short poll_tout) {
        this.poll_tout = poll_tout;
    }

    public short getData_cntl() {
        return data_cntl;
    }

    public void setData_cntl(short data_cntl) {
        this.data_cntl = data_cntl;
    }

    public char[] getReserve1() {
        return reserve1;
    }

    public void setReserve1(char[] reserve1) {
        this.reserve1 = reserve1;
    }

    public char[] getCls2_name() {
        return cls2_name;
    }

    public void setCls2_name(char[] cls2_name) {
        this.cls2_name = cls2_name;
    }

    public short getUser_dlen() {
        return user_dlen;
    }

    public void setUser_dlen(short user_dlen) {
        this.user_dlen = user_dlen;
    }

    public char[] getUser_data() {
        return user_data;
    }

    public void setUser_data(char[] user_data) {
        this.user_data = user_data;
    }

    public char[] getReserve2() {
        return reserve2;
    }

    public void setReserve2(char[] reserve2) {
        this.reserve2 = reserve2;
    }

    @Override
    public String toString() {
        return "IODBBUSPRM{" +
                "fdl_add=" + fdl_add +
                ", baudrate=" + baudrate +
                ", tsl=" + tsl +
                ", min_tsdr=" + min_tsdr +
                ", max_tsdr=" + max_tsdr +
                ", tqui=" + tqui +
                ", tset=" + tset +
                ", ttr=" + ttr +
                ", gap=" + gap +
                ", hsa=" + hsa +
                ", max_retry=" + max_retry +
                ", bp_flag=" + bp_flag +
                ", min_slv_int=" + min_slv_int +
                ", poll_tout=" + poll_tout +
                ", data_cntl=" + data_cntl +
                ", reserve1=" + Arrays.toString(reserve1) +
                ", cls2_name=" + Arrays.toString(cls2_name) +
                ", user_dlen=" + user_dlen +
                ", user_data=" + Arrays.toString(user_data) +
                ", reserve2=" + Arrays.toString(reserve2) +
                '}';
    }
}
