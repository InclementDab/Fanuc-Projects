package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class FL_DEVTYPE {
    private short Kind1;
    private char pad1[];
    private int FunctionFLnet1;
    private short Kind2;
    private char pad2[];
    private int FunctionFLnet2;

    public short getKind1() {
        return Kind1;
    }

    public void setKind1(short Kind1) {
        this.Kind1 = Kind1;
    }

    public char[] getPad1() {
        return pad1;
    }

    public void setPad1(char[] pad1) {
        this.pad1 = pad1;
    }

    public int getFunctionFLnet1() {
        return FunctionFLnet1;
    }

    public void setFunctionFLnet1(int functionFLnet1) {
        FunctionFLnet1 = functionFLnet1;
    }

    public short getKind2() {
        return Kind2;
    }

    public void setKind2(short Kind2) {
        this.Kind2 = Kind2;
    }

    public char[] getPad2() {
        return pad2;
    }

    public void setPad2(char[] pad2) {
        this.pad2 = pad2;
    }

    public int getFunctionFLnet2() {
        return FunctionFLnet2;
    }

    public void setFunctionFLnet2(int functionFLnet2) {
        FunctionFLnet2 = functionFLnet2;
    }

    @Override
    public String toString() {
        return "FL_DEVTYPE{" +
                "Kind1=" + Kind1 +
                ", pad1=" + Arrays.toString(pad1) +
                ", FunctionFLnet1=" + FunctionFLnet1 +
                ", Kind2=" + Kind2 +
                ", pad2=" + Arrays.toString(pad2) +
                ", FunctionFLnet2=" + FunctionFLnet2 +
                '}';
    }
}
