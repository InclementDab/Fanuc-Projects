package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBFIX {
    private short mode;
    private short pln_axes[];
    private short drl_axes;
    private int i_pos;
    private int r_pos;
    private int z_pos;
    private int cmd_cnt;
    private int act_cnt;
    private int cut;
    private int shift[];

    public short getMode() {
        return mode;
    }

    public void setMode(short mode) {
        this.mode = mode;
    }

    public short[] getPln_axes() {
        return pln_axes;
    }

    public void setPln_axes(short[] pln_axes) {
        this.pln_axes = pln_axes;
    }

    public short getDrl_axes() {
        return drl_axes;
    }

    public void setDrl_axes(short drl_axes) {
        this.drl_axes = drl_axes;
    }

    public int getI_pos() {
        return i_pos;
    }

    public void setI_pos(int i_pos) {
        this.i_pos = i_pos;
    }

    public int getR_pos() {
        return r_pos;
    }

    public void setR_pos(int r_pos) {
        this.r_pos = r_pos;
    }

    public int getZ_pos() {
        return z_pos;
    }

    public void setZ_pos(int z_pos) {
        this.z_pos = z_pos;
    }

    public int getCmd_cnt() {
        return cmd_cnt;
    }

    public void setCmd_cnt(int cmd_cnt) {
        this.cmd_cnt = cmd_cnt;
    }

    public int getAct_cnt() {
        return act_cnt;
    }

    public void setAct_cnt(int act_cnt) {
        this.act_cnt = act_cnt;
    }

    public int getCut() {
        return cut;
    }

    public void setCut(int cut) {
        this.cut = cut;
    }

    public int[] getShift() {
        return shift;
    }

    public void setShift(int[] shift) {
        this.shift = shift;
    }

    @Override
    public String toString() {
        return "ODBFIX{" +
                "mode=" + mode +
                ", pln_axes=" + Arrays.toString(pln_axes) +
                ", drl_axes=" + drl_axes +
                ", i_pos=" + i_pos +
                ", r_pos=" + r_pos +
                ", z_pos=" + z_pos +
                ", cmd_cnt=" + cmd_cnt +
                ", act_cnt=" + act_cnt +
                ", cut=" + cut +
                ", shift=" + Arrays.toString(shift) +
                '}';
    }
}
