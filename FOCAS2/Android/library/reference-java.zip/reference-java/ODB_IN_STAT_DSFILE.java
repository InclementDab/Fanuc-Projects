package jp.co.fanuc.fwlibe1;


public class ODB_IN_STAT_DSFILE {
    private short req_num;
    private short size_type;

    public short getReq_num() {
        return req_num;
    }

    public void setReq_num(short req_num) {
        this.req_num = req_num;
    }

    public short getSize_type() {

        return size_type;
    }

    public void setSize_type(short size_type) {
        this.size_type = size_type;
    }

    @Override
    public String toString() {
        return "ODB_IN_STAT_DSFILE{" +
                "req_num=" + req_num +
                ", size_type=" + size_type +
                '}';
    }
}
