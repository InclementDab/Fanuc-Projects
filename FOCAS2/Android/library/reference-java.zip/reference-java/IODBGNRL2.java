package jp.co.fanuc.fwlibe1;


public class IODBGNRL2 {
    private short datano;
    private short type;
    private short sgnal;

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getSgnal() {
        return sgnal;
    }

    public void setSgnal(short sgnal) {
        this.sgnal = sgnal;
    }

    @Override
    public String toString() {
        return "IODBGNRL2{" +
                "datano=" + datano +
                ", type=" + type +
                ", sgnal=" + sgnal +
                '}';
    }
}
