package jp.co.fanuc.fwlibe1;


public class IODBTLMAG2 {
    private short magazine;
    private short pot;

    public short getMagazine() {
        return magazine;
    }

    public void setMagazine(short magazine) {
        this.magazine = magazine;
    }

    public short getPot() {
        return pot;
    }

    public void setPot(short pot) {
        this.pot = pot;
    }

    @Override
    public String toString() {
        return "IODBTLMAG2{" +
                "magazine=" + magazine +
                ", pot=" + pot +
                '}';
    }
}
