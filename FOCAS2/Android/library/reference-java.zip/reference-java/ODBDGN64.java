package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBDGN64 {
    private short datano;
    private short type;
    private short axis;
    private short dummy;

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {

        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getAxis() {

        return axis;
    }

    public void setAxis(short axis) {
        this.axis = axis;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    private char cdata;
    private short idata;
    private int ldata;
    private REALDATA rdata;
    private char cdatas[];
    private short idatas[];
    private int ldatas[];
    private REALDATA rdatas[];

    public char getCdata() {
        return cdata;
    }

    public void setCdata(char cdata) {
        this.cdata = cdata;
    }

    public short getIdata() {

        return idata;
    }

    public void setIdata(short idata) {
        this.idata = idata;
    }

    public int getLdata() {

        return ldata;
    }

    public void setLdata(int ldata) {
        this.ldata = ldata;
    }

    public REALDATA getRdata() {

        return rdata;
    }

    public void setRdata(REALDATA rdata) {
        this.rdata = rdata;
    }

    public char[] getCdatas() {

        return cdatas;
    }

    public void setCdatas(char[] cdatas) {
        this.cdatas = cdatas;
    }

    public short[] getIdatas() {

        return idatas;
    }

    public void setIdatas(short[] idatas) {
        this.idatas = idatas;
    }

    public int[] getLdatas() {

        return ldatas;
    }

    public void setLdatas(int[] ldatas) {
        this.ldatas = ldatas;
    }

    public REALDATA[] getRdatas() {

        return rdatas;
    }

    public void setRdatas(REALDATA[] rdatas) {
        this.rdatas = rdatas;
    }

    @Override
    public String toString() {
        return "ODBDGN64{" +
                "datano=" + datano +
                ", type=" + type +
                ", axis=" + axis +
                ", dummy=" + dummy +
                ", cdata=" + cdata +
                ", idata=" + idata +
                ", ldata=" + ldata +
                ", rdata=" + rdata +
                ", cdatas=" + Arrays.toString(cdatas) +
                ", idatas=" + Arrays.toString(idatas) +
                ", ldatas=" + Arrays.toString(ldatas) +
                ", rdatas=" + Arrays.toString(rdatas) +
                '}';
    }
}
