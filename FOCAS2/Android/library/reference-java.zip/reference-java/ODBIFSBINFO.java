package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBINFO {
    private char fssb_line_mnt_st;
    private char reserve;
    private short card_num;
    private ODBIFSBINFO line_info[];

    public char getFssb_line_mnt_st() {
        return fssb_line_mnt_st;
    }

    public void setFssb_line_mnt_st(char fssb_line_mnt_st) {
        this.fssb_line_mnt_st = fssb_line_mnt_st;
    }

    public char getReserve() {
        return reserve;
    }

    public void setReserve(char reserve) {
        this.reserve = reserve;
    }

    public short getCard_num() {
        return card_num;
    }

    public void setCard_num(short card_num) {
        this.card_num = card_num;
    }

    public ODBIFSBINFO[] getLine_info() {
        return line_info;
    }

    public void setLine_info(ODBIFSBINFO[] line_info) {
        this.line_info = line_info;
    }

    @Override
    public String toString() {
        return "ODBIFSBINFO{" +
                "fssb_line_mnt_st=" + fssb_line_mnt_st +
                ", reserve=" + reserve +
                ", card_num=" + card_num +
                ", line_info=" + Arrays.toString(line_info) +
                '}';
    }
}
