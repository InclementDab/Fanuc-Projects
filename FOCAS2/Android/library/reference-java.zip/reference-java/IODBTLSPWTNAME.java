package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTLSPWTNAME {
    public static class SP_NAME {
        private char sp_pos1[];
        private char sp_pos2[];
        private char sp_pos3[];
        private char sp_pos4[];

        public char[] getSp_pos1() {
            return sp_pos1;
        }

        public void setSp_pos1(char[] sp_pos1) {
            this.sp_pos1 = sp_pos1;
        }

        public char[] getSp_pos2() {
            return sp_pos2;
        }

        public void setSp_pos2(char[] sp_pos2) {
            this.sp_pos2 = sp_pos2;
        }

        public char[] getSp_pos3() {
            return sp_pos3;
        }

        public void setSp_pos3(char[] sp_pos3) {
            this.sp_pos3 = sp_pos3;
        }

        public char[] getSp_pos4() {
            return sp_pos4;
        }

        public void setSp_pos4(char[] sp_pos4) {
            this.sp_pos4 = sp_pos4;
        }

        @Override
        public String toString() {
            return "SP_NAME{" +
                    "sp_pos1=" + Arrays.toString(sp_pos1) +
                    ", sp_pos2=" + Arrays.toString(sp_pos2) +
                    ", sp_pos3=" + Arrays.toString(sp_pos3) +
                    ", sp_pos4=" + Arrays.toString(sp_pos4) +
                    '}';
        }
    }
    public static class WT_NAME {
        private char wt_pos1[];
        private char wt_pos2[];
        private char wt_pos3[];
        private char wt_pos4[];

        public char[] getWt_pos1() {
            return wt_pos1;
        }

        public void setWt_pos1(char[] wt_pos1) {
            this.wt_pos1 = wt_pos1;
        }

        public char[] getWt_pos2() {
            return wt_pos2;
        }

        public void setWt_pos2(char[] wt_pos2) {
            this.wt_pos2 = wt_pos2;
        }

        public char[] getWt_pos3() {
            return wt_pos3;
        }

        public void setWt_pos3(char[] wt_pos3) {
            this.wt_pos3 = wt_pos3;
        }

        public char[] getWt_pos4() {
            return wt_pos4;
        }

        public void setWt_pos4(char[] wt_pos4) {
            this.wt_pos4 = wt_pos4;
        }

        @Override
        public String toString() {
            return "WT_NAME{" +
                    "wt_pos1=" + Arrays.toString(wt_pos1) +
                    ", wt_pos2=" + Arrays.toString(wt_pos2) +
                    ", wt_pos3=" + Arrays.toString(wt_pos3) +
                    ", wt_pos4=" + Arrays.toString(wt_pos4) +
                    '}';
        }
    }
    private SP_NAME sp_name;
    private WT_NAME wt_name;

    public SP_NAME getSp_name() {
        return sp_name;
    }

    public void setSp_name(SP_NAME sp_name) {
        this.sp_name = sp_name;
    }

    public WT_NAME getWt_name() {
        return wt_name;
    }

    public void setWt_name(WT_NAME wt_name) {
        this.wt_name = wt_name;
    }

    @Override
    public String toString() {
        return "IODBTLSPWTNAME{" +
                "sp_name=" + sp_name +
                ", wt_name=" + wt_name +
                '}';
    }
}
