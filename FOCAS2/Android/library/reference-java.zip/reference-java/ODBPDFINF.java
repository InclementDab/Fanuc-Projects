package jp.co.fanuc.fwlibe1;


public class ODBPDFINF {
    private int used_page;
    private int all_page;
    private int used_dir;
    private int all_dir;

    public int getUsed_page() {
        return used_page;
    }

    public void setUsed_page(int used_page) {
        this.used_page = used_page;
    }

    public int getAll_page() {

        return all_page;
    }

    public void setAll_page(int all_page) {
        this.all_page = all_page;
    }

    public int getUsed_dir() {

        return used_dir;
    }

    public void setUsed_dir(int used_dir) {
        this.used_dir = used_dir;
    }

    public int getAll_dir() {

        return all_dir;
    }

    public void setAll_dir(int all_dir) {
        this.all_dir = all_dir;
    }

    @Override
    public String toString() {
        return "ODBPDFINF{" +
                "used_page=" + used_page +
                ", all_page=" + all_page +
                ", used_dir=" + used_dir +
                ", all_dir=" + all_dir +
                '}';
    }
}
