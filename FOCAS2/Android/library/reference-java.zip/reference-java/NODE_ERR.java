package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class NODE_ERR {
    private EACH_ERR eachErr[];

    public EACH_ERR[] getEachErr() {
        return eachErr;
    }

    public void setEachErr(EACH_ERR[] eachErr) {
        this.eachErr = eachErr;
    }

    @Override
    public String toString() {
        return "NODE_ERR{" +
                "eachErr=" + Arrays.toString(eachErr) +
                '}';
    }
}
