package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class CFILEINFO {
    private char fname[];
    private int file_size;
    private int file_attr;
    private short year;
    private short month;
    private short day;
    private short hour;
    private short minute;
    private short second;

    public char[] getFname() {
        return fname;
    }

    public void setFname(char[] fname) {
        this.fname = fname;
    }

    public int getFile_size() {
        return file_size;
    }

    public void setFile_size(int file_size) {
        this.file_size = file_size;
    }

    public int getFile_attr() {
        return file_attr;
    }

    public void setFile_attr(int file_attr) {
        this.file_attr = file_attr;
    }

    public short getYear() {
        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public short getMonth() {
        return month;
    }

    public void setMonth(short month) {
        this.month = month;
    }

    public short getDay() {
        return day;
    }

    public void setDay(short day) {
        this.day = day;
    }

    public short getHour() {
        return hour;
    }

    public void setHour(short hour) {
        this.hour = hour;
    }

    public short getMinute() {
        return minute;
    }

    public void setMinute(short minute) {
        this.minute = minute;
    }

    public short getSecond() {
        return second;
    }

    public void setSecond(short second) {
        this.second = second;
    }

    @Override
    public String toString() {
        return "CFILEINFO{" +
                "fname=" + Arrays.toString(fname) +
                ", file_size=" + file_size +
                ", file_attr=" + file_attr +
                ", year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", hour=" + hour +
                ", minute=" + minute +
                ", second=" + second +
                '}';
    }
}
