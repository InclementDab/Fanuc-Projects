package jp.co.fanuc.fwlibe1;


public class IODBSFSGDSPSTAT {
    private short   extract;
    private short   symbol;
    private short   extend;

    public short getExtract() {
        return extract;
    }

    public void setExtract(short extract) {
        this.extract = extract;
    }

    public short getSymbol() {
        return symbol;
    }

    public void setSymbol(short symbol) {
        this.symbol = symbol;
    }

    public short getExtend() {
        return extend;
    }

    public void setExtend(short extend) {
        this.extend = extend;
    }

    @Override
    public String toString() {
        return "IODBSFSGDSPSTAT{" +
                "extract=" + extract +
                ", symbol=" + symbol +
                ", extend=" + extend +
                '}';
    }
}
