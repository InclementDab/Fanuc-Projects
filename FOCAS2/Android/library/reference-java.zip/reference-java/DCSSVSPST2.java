package jp.co.fanuc.fwlibe1;


public class DCSSVSPST2 {
    private double limit_dt_p;
    private double limit_dt_m;
    private short axissts;
    private short unittype;
    private char axissts2;
    private char level;
    private char alm_lvl;
    private char add_info;

    public double getLimit_dt_p() {
        return limit_dt_p;
    }

    public void setLimit_dt_p(double limit_dt_p) {
        this.limit_dt_p = limit_dt_p;
    }

    public double getLimit_dt_m() {
        return limit_dt_m;
    }

    public void setLimit_dt_m(double limit_dt_m) {
        this.limit_dt_m = limit_dt_m;
    }

    public short getAxissts() {
        return axissts;
    }

    public void setAxissts(short axissts) {
        this.axissts = axissts;
    }

    public short getUnittype() {
        return unittype;
    }

    public void setUnittype(short unittype) {
        this.unittype = unittype;
    }

    public char getAxissts2() {
        return axissts2;
    }

    public void setAxissts2(char axissts2) {
        this.axissts2 = axissts2;
    }

    public char getLevel() {
        return level;
    }

    public void setLevel(char level) {
        this.level = level;
    }

    public char getAlm_lvl() {
        return alm_lvl;
    }

    public void setAlm_lvl(char alm_lvl) {
        this.alm_lvl = alm_lvl;
    }

    public char getAdd_info() {
        return add_info;
    }

    public void setAdd_info(char add_info) {
        this.add_info = add_info;
    }

    @Override
    public String toString() {
        return "DCSSVSPST2{" +
                "limit_dt_p=" + limit_dt_p +
                ", limit_dt_m=" + limit_dt_m +
                ", axissts=" + axissts +
                ", unittype=" + unittype +
                ", axissts2=" + axissts2 +
                ", level=" + level +
                ", alm_lvl=" + alm_lvl +
                ", add_info=" + add_info +
                '}';
    }
}
