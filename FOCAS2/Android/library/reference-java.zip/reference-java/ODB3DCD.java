package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODB3DCD {
    private short mode;
    private short dno;
    private short cd_axes[];
    private int center[][];
    private int direct[][];
    private int angle[];

    public short getMode() {
        return mode;
    }

    public void setMode(short mode) {
        this.mode = mode;
    }

    public short getDno() {
        return dno;
    }

    public void setDno(short dno) {
        this.dno = dno;
    }

    public short[] getCd_axes() {
        return cd_axes;
    }

    public void setCd_axes(short[] cd_axes) {
        this.cd_axes = cd_axes;
    }

    public int[][] getCenter() {
        return center;
    }

    public void setCenter(int[][] center) {
        this.center = center;
    }

    public int[][] getDirect() {
        return direct;
    }

    public void setDirect(int[][] direct) {
        this.direct = direct;
    }

    public int[] getAngle() {
        return angle;
    }

    public void setAngle(int[] angle) {
        this.angle = angle;
    }

    @Override
    public String toString() {
        return "ODB3DCD{" +
                "mode=" + mode +
                ", dno=" + dno +
                ", cd_axes=" + Arrays.toString(cd_axes) +
                ", center=" + Arrays.toString(center) +
                ", direct=" + Arrays.toString(direct) +
                ", angle=" + Arrays.toString(angle) +
                '}';
    }
}
