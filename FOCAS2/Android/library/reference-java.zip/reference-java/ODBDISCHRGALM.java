package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBDISCHRGALM {
    private short year;
    private short month;
    private short day;
    private short hour;
    private short minute;
    private short second;
    private int almnum;
    private int psec;
    private short hpc;
    private short hfq;
    private short hdt;
    private short hpa;
    private int hce;
    private short asq;
    private short psu;
    private short aps;
    private short dummy;
    private int rfi[];
    private int rfv[];
    private int dci[];
    private int dcv[];
    private int dcw[];
    private short almcd[];

    public short getYear() {
        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public short getMonth() {
        return month;
    }

    public void setMonth(short month) {
        this.month = month;
    }

    public short getDay() {
        return day;
    }

    public void setDay(short day) {
        this.day = day;
    }

    public short getHour() {
        return hour;
    }

    public void setHour(short hour) {
        this.hour = hour;
    }

    public short getMinute() {
        return minute;
    }

    public void setMinute(short minute) {
        this.minute = minute;
    }

    public short getSecond() {
        return second;
    }

    public void setSecond(short second) {
        this.second = second;
    }

    public int getAlmnum() {
        return almnum;
    }

    public void setAlmnum(int almnum) {
        this.almnum = almnum;
    }

    public int getPsec() {
        return psec;
    }

    public void setPsec(int psec) {
        this.psec = psec;
    }

    public short getHpc() {
        return hpc;
    }

    public void setHpc(short hpc) {
        this.hpc = hpc;
    }

    public short getHfq() {
        return hfq;
    }

    public void setHfq(short hfq) {
        this.hfq = hfq;
    }

    public short getHdt() {
        return hdt;
    }

    public void setHdt(short hdt) {
        this.hdt = hdt;
    }

    public short getHpa() {
        return hpa;
    }

    public void setHpa(short hpa) {
        this.hpa = hpa;
    }

    public int getHce() {
        return hce;
    }

    public void setHce(int hce) {
        this.hce = hce;
    }

    public short getAsq() {
        return asq;
    }

    public void setAsq(short asq) {
        this.asq = asq;
    }

    public short getPsu() {
        return psu;
    }

    public void setPsu(short psu) {
        this.psu = psu;
    }

    public short getAps() {
        return aps;
    }

    public void setAps(short aps) {
        this.aps = aps;
    }

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public int[] getRfi() {
        return rfi;
    }

    public void setRfi(int[] rfi) {
        this.rfi = rfi;
    }

    public int[] getRfv() {
        return rfv;
    }

    public void setRfv(int[] rfv) {
        this.rfv = rfv;
    }

    public int[] getDci() {
        return dci;
    }

    public void setDci(int[] dci) {
        this.dci = dci;
    }

    public int[] getDcv() {
        return dcv;
    }

    public void setDcv(int[] dcv) {
        this.dcv = dcv;
    }

    public int[] getDcw() {
        return dcw;
    }

    public void setDcw(int[] dcw) {
        this.dcw = dcw;
    }

    public short[] getAlmcd() {
        return almcd;
    }

    public void setAlmcd(short[] almcd) {
        this.almcd = almcd;
    }

    @Override
    public String toString() {
        return "ODBDISCHRGALM{" +
                "year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", hour=" + hour +
                ", minute=" + minute +
                ", second=" + second +
                ", almnum=" + almnum +
                ", psec=" + psec +
                ", hpc=" + hpc +
                ", hfq=" + hfq +
                ", hdt=" + hdt +
                ", hpa=" + hpa +
                ", hce=" + hce +
                ", asq=" + asq +
                ", psu=" + psu +
                ", aps=" + aps +
                ", dummy=" + dummy +
                ", rfi=" + Arrays.toString(rfi) +
                ", rfv=" + Arrays.toString(rfv) +
                ", dci=" + Arrays.toString(dci) +
                ", dcv=" + Arrays.toString(dcv) +
                ", dcw=" + Arrays.toString(dcw) +
                ", almcd=" + Arrays.toString(almcd) +
                '}';
    }
}
