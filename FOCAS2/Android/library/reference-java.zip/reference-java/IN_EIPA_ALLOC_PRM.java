package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_EIPA_ALLOC_PRM {
    private char State;
    private char Option;
    private char pad[];
    private EIP_TYPE_PRM DI;
    private EIP_TYPE_PRM DO;

    public char getState() {
        return State;
    }

    public void setState(char state) {
        State = state;
    }

    public char getOption() {
        return Option;
    }

    public void setOption(char option) {
        Option = option;
    }

    public char[] getPad() {
        return pad;
    }

    public void setPad(char[] pad) {
        this.pad = pad;
    }

    public EIP_TYPE_PRM getDI() {
        return DI;
    }

    public void setDI(EIP_TYPE_PRM DI) {
        this.DI = DI;
    }

    public EIP_TYPE_PRM getDO() {
        return DO;
    }

    public void setDO(EIP_TYPE_PRM DO) {
        this.DO = DO;
    }

    @Override
    public String toString() {
        return "IN_EIPA_ALLOC_PRM{" +
                "State=" + State +
                ", Option=" + Option +
                ", pad=" + Arrays.toString(pad) +
                ", DI=" + DI +
                ", DO=" + DO +
                '}';
    }
}
