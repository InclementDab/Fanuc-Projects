package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBLOFS {
    private short mode;
    private int ofsvct[];

    public short getMode() {
        return mode;
    }

    public void setMode(short mode) {
        this.mode = mode;
    }

    public int[] getOfsvct() {
        return ofsvct;
    }

    public void setOfsvct(int[] ofsvct) {
        this.ofsvct = ofsvct;
    }

    @Override
    public String toString() {
        return "ODBLOFS{" +
                "mode=" + mode +
                ", ofsvct=" + Arrays.toString(ofsvct) +
                '}';
    }
}
