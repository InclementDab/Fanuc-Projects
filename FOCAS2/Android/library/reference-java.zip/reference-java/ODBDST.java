package jp.co.fanuc.fwlibe1;


public class ODBDST {
    private short ob_type;
    private short obj_no;
    private char shp_disp;
    private char mva_disp;

    public short getOb_type() {
        return ob_type;
    }

    public void setOb_type(short ob_type) {
        this.ob_type = ob_type;
    }

    public short getObj_no() {
        return obj_no;
    }

    public void setObj_no(short obj_no) {
        this.obj_no = obj_no;
    }

    public char getShp_disp() {
        return shp_disp;
    }

    public void setShp_disp(char shp_disp) {
        this.shp_disp = shp_disp;
    }

    public char getMva_disp() {
        return mva_disp;
    }

    public void setMva_disp(char mva_disp) {
        this.mva_disp = mva_disp;
    }

    @Override
    public String toString() {
        return "ODBDST{" +
                "ob_type=" + ob_type +
                ", obj_no=" + obj_no +
                ", shp_disp=" + shp_disp +
                ", mva_disp=" + mva_disp +
                '}';
    }
}
