package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBPWRCTL {
    private short    slct;
    private short    power_min;
    private short    pwr_sp_zr;
    private short    freq_min;
    private short    freq_sp_zr;
    private short    duty_min;
    private short    duty_sp_zr;
    private char     feed_r_dec;
    private char     reserve;
    private int     feed_r;
    private short    ag_press_min ;
    private short    ag_press_sp_zr ;
    private short    pb_power_min ;
    private short    pb_pwr_sp_zr ;
    private short    reserves[] ;

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getPower_min() {
        return power_min;
    }

    public void setPower_min(short power_min) {
        this.power_min = power_min;
    }

    public short getPwr_sp_zr() {
        return pwr_sp_zr;
    }

    public void setPwr_sp_zr(short pwr_sp_zr) {
        this.pwr_sp_zr = pwr_sp_zr;
    }

    public short getFreq_min() {
        return freq_min;
    }

    public void setFreq_min(short freq_min) {
        this.freq_min = freq_min;
    }

    public short getFreq_sp_zr() {
        return freq_sp_zr;
    }

    public void setFreq_sp_zr(short freq_sp_zr) {
        this.freq_sp_zr = freq_sp_zr;
    }

    public short getDuty_min() {
        return duty_min;
    }

    public void setDuty_min(short duty_min) {
        this.duty_min = duty_min;
    }

    public short getDuty_sp_zr() {
        return duty_sp_zr;
    }

    public void setDuty_sp_zr(short duty_sp_zr) {
        this.duty_sp_zr = duty_sp_zr;
    }

    public char getFeed_r_dec() {
        return feed_r_dec;
    }

    public void setFeed_r_dec(char feed_r_dec) {
        this.feed_r_dec = feed_r_dec;
    }

    public char getReserve() {
        return reserve;
    }

    public void setReserve(char reserve) {
        this.reserve = reserve;
    }

    public int getFeed_r() {
        return feed_r;
    }

    public void setFeed_r(int feed_r) {
        this.feed_r = feed_r;
    }

    public short getAg_press_min() {
        return ag_press_min;
    }

    public void setAg_press_min(short ag_press_min) {
        this.ag_press_min = ag_press_min;
    }

    public short getAg_press_sp_zr() {
        return ag_press_sp_zr;
    }

    public void setAg_press_sp_zr(short ag_press_sp_zr) {
        this.ag_press_sp_zr = ag_press_sp_zr;
    }

    public short getPb_power_min() {
        return pb_power_min;
    }

    public void setPb_power_min(short pb_power_min) {
        this.pb_power_min = pb_power_min;
    }

    public short getPb_pwr_sp_zr() {
        return pb_pwr_sp_zr;
    }

    public void setPb_pwr_sp_zr(short pb_pwr_sp_zr) {
        this.pb_pwr_sp_zr = pb_pwr_sp_zr;
    }

    public short[] getReserves() {
        return reserves;
    }

    public void setReserves(short[] reserves) {
        this.reserves = reserves;
    }

    @Override
    public String toString() {
        return "IODBPWRCTL{" +
                "slct=" + slct +
                ", power_min=" + power_min +
                ", pwr_sp_zr=" + pwr_sp_zr +
                ", freq_min=" + freq_min +
                ", freq_sp_zr=" + freq_sp_zr +
                ", duty_min=" + duty_min +
                ", duty_sp_zr=" + duty_sp_zr +
                ", feed_r_dec=" + feed_r_dec +
                ", reserve=" + reserve +
                ", feed_r=" + feed_r +
                ", ag_press_min=" + ag_press_min +
                ", ag_press_sp_zr=" + ag_press_sp_zr +
                ", pb_power_min=" + pb_power_min +
                ", pb_pwr_sp_zr=" + pb_pwr_sp_zr +
                ", reserves=" + Arrays.toString(reserves) +
                '}';
    }
}
