package jp.co.fanuc.fwlibe1;


public class ODBMDIP {
    private short mdiprog;
    private int mdipntr;
    private short crntprog;
    private int crntpntr;

    public short getMdiprog() {
        return mdiprog;
    }

    public void setMdiprog(short mdiprog) {
        this.mdiprog = mdiprog;
    }

    public int getMdipntr() {

        return mdipntr;
    }

    public void setMdipntr(int mdipntr) {
        this.mdipntr = mdipntr;
    }

    public short getCrntprog() {

        return crntprog;
    }

    public void setCrntprog(short crntprog) {
        this.crntprog = crntprog;
    }

    public int getCrntpntr() {

        return crntpntr;
    }

    public void setCrntpntr(int crntpntr) {
        this.crntpntr = crntpntr;
    }

    @Override
    public String toString() {
        return "ODBMDIP{" +
                "mdiprog=" + mdiprog +
                ", mdipntr=" + mdipntr +
                ", crntprog=" + crntprog +
                ", crntpntr=" + crntpntr +
                '}';
    }
}
