package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_DNMPRMFLAG_SLAVE {
    private char            Communication;
    private char            DetailStatus;
    private char            Di;
    private char            DiSize;
    private char            Do;
    private char            DoSize;
    private char            reserved[];

    public char getCommunication() {
        return Communication;
    }

    public void setCommunication(char communication) {
        Communication = communication;
    }

    public char getDetailStatus() {
        return DetailStatus;
    }

    public void setDetailStatus(char detailStatus) {
        DetailStatus = detailStatus;
    }

    public char getDi() {
        return Di;
    }

    public void setDi(char di) {
        Di = di;
    }

    public char getDiSize() {
        return DiSize;
    }

    public void setDiSize(char diSize) {
        DiSize = diSize;
    }

    public char getDo() {
        return Do;
    }

    public void setDo(char aDo) {
        Do = aDo;
    }

    public char getDoSize() {
        return DoSize;
    }

    public void setDoSize(char doSize) {
        DoSize = doSize;
    }

    public char[] getReserved() {
        return reserved;
    }

    public void setReserved(char[] reserved) {
        this.reserved = reserved;
    }

    @Override
    public String toString() {
        return "IN_DNMPRMFLAG_SLAVE{" +
                "Communication=" + Communication +
                ", DetailStatus=" + DetailStatus +
                ", Di=" + Di +
                ", DiSize=" + DiSize +
                ", Do=" + Do +
                ", DoSize=" + DoSize +
                ", reserved=" + Arrays.toString(reserved) +
                '}';
    }
}
