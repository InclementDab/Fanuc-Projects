package jp.co.fanuc.fwlibe1;


public class ODBP_FTRQ_PRM_INF {
    private char smpl_enbl;
    private char cycle;
    private char axis_num;
    private char dummy1;

    public char getSmpl_enbl() {
        return smpl_enbl;
    }

    public void setSmpl_enbl(char smpl_enbl) {
        this.smpl_enbl = smpl_enbl;
    }

    public char getCycle() {
        return cycle;
    }

    public void setCycle(char cycle) {
        this.cycle = cycle;
    }

    public char getAxis_num() {
        return axis_num;
    }

    public void setAxis_num(char axis_num) {
        this.axis_num = axis_num;
    }

    public char getDummy1() {
        return dummy1;
    }

    public void setDummy1(char dummy1) {
        this.dummy1 = dummy1;
    }

    @Override
    public String toString() {
        return "ODBP_FTRQ_PRM_INF{" +
                "smpl_enbl=" + smpl_enbl +
                ", cycle=" + cycle +
                ", axis_num=" + axis_num +
                ", dummy1=" + dummy1 +
                '}';
    }
}
