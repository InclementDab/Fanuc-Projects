package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBCUB {
    private int ref_vtx[];
    private int adj_vtx1[];
    private int adj_vtx2[];
    private int adj_vtx3[];
    private char n_unit;
    private char cb_form;

    public int[] getRef_vtx() {
        return ref_vtx;
    }

    public void setRef_vtx(int[] ref_vtx) {
        this.ref_vtx = ref_vtx;
    }

    public int[] getAdj_vtx1() {
        return adj_vtx1;
    }

    public void setAdj_vtx1(int[] adj_vtx1) {
        this.adj_vtx1 = adj_vtx1;
    }

    public int[] getAdj_vtx2() {
        return adj_vtx2;
    }

    public void setAdj_vtx2(int[] adj_vtx2) {
        this.adj_vtx2 = adj_vtx2;
    }

    public int[] getAdj_vtx3() {
        return adj_vtx3;
    }

    public void setAdj_vtx3(int[] adj_vtx3) {
        this.adj_vtx3 = adj_vtx3;
    }

    public char getN_unit() {
        return n_unit;
    }

    public void setN_unit(char n_unit) {
        this.n_unit = n_unit;
    }

    public char getCb_form() {
        return cb_form;
    }

    public void setCb_form(char cb_form) {
        this.cb_form = cb_form;
    }

    @Override
    public String toString() {
        return "ODBCUB{" +
                "ref_vtx=" + Arrays.toString(ref_vtx) +
                ", adj_vtx1=" + Arrays.toString(adj_vtx1) +
                ", adj_vtx2=" + Arrays.toString(adj_vtx2) +
                ", adj_vtx3=" + Arrays.toString(adj_vtx3) +
                ", n_unit=" + n_unit +
                ", cb_form=" + cb_form +
                '}';
    }
}
