package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class DNS_STATUS_INFO {
     private char   Status;
     private char   MpuStatus;
     private char   MpuState;
     private char   MpuAlarmCode;
     private char   MpuVerInfo;
     private char   pad[];

    public char getStatus() {
        return Status;
    }

    public void setStatus(char status) {
        Status = status;
    }

    public char getMpuStatus() {
        return MpuStatus;
    }

    public void setMpuStatus(char mpuStatus) {
        MpuStatus = mpuStatus;
    }

    public char getMpuState() {
        return MpuState;
    }

    public void setMpuState(char mpuState) {
        MpuState = mpuState;
    }

    public char getMpuAlarmCode() {
        return MpuAlarmCode;
    }

    public void setMpuAlarmCode(char mpuAlarmCode) {
        MpuAlarmCode = mpuAlarmCode;
    }

    public char getMpuVerInfo() {
        return MpuVerInfo;
    }

    public void setMpuVerInfo(char mpuVerInfo) {
        MpuVerInfo = mpuVerInfo;
    }

    public char[] getPad() {
        return pad;
    }

    public void setPad(char[] pad) {
        this.pad = pad;
    }

    @Override
    public String toString() {
        return "DNS_STATUS_INFO{" +
                "Status=" + Status +
                ", MpuStatus=" + MpuStatus +
                ", MpuState=" + MpuState +
                ", MpuAlarmCode=" + MpuAlarmCode +
                ", MpuVerInfo=" + MpuVerInfo +
                ", pad=" + Arrays.toString(pad) +
                '}';
    }
}
