package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMDGDTMSG {
    private char message[];
    private int imgid;

    public char[] getMessage() {
        return message;
    }

    public void setMessage(char[] message) {
        this.message = message;
    }

    public int getImgid() {
        return imgid;
    }

    public void setImgid(int imgid) {
        this.imgid = imgid;
    }

    @Override
    public String toString() {
        return "ODBMDGDTMSG{" +
                "message=" + Arrays.toString(message) +
                ", imgid=" + imgid +
                '}';
    }
}
