package jp.co.fanuc.fwlibe1;

import java.util.Arrays;


public class ODBACT {
    private short dummy[];
    private int data;

    public short[] getDummy() {
        return dummy;
    }

    public void setDummy(short[] dummy) {
        this.dummy = dummy;
    }

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ODBACT{" +
                "dummy=" + Arrays.toString(dummy) +
                ", data=" + data +
                '}';
    }
}
