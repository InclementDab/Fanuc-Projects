package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class FTPTRANS_PRM {
    private FTP_CLIENT_PRM opposite[];

    public FTP_CLIENT_PRM[] getOpposite() {
        return opposite;
    }

    public void setOpposite(FTP_CLIENT_PRM[] opposite) {
        this.opposite = opposite;
    }

    @Override
    public String toString() {
        return "FTPTRANS_PRM{" +
                "opposite=" + Arrays.toString(opposite) +
                '}';
    }
}
