package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBMTAP {
    private short slct;
    private int tool_no;
    private int x_axis_ofs;
    private int y_axis_ofs;
    private int punch_count;
    private int tool_life;
    private int reserve[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public int getTool_no() {
        return tool_no;
    }

    public void setTool_no(int tool_no) {
        this.tool_no = tool_no;
    }

    public int getX_axis_ofs() {
        return x_axis_ofs;
    }

    public void setX_axis_ofs(int x_axis_ofs) {
        this.x_axis_ofs = x_axis_ofs;
    }

    public int getY_axis_ofs() {
        return y_axis_ofs;
    }

    public void setY_axis_ofs(int y_axis_ofs) {
        this.y_axis_ofs = y_axis_ofs;
    }

    public int getPunch_count() {
        return punch_count;
    }

    public void setPunch_count(int punch_count) {
        this.punch_count = punch_count;
    }

    public int getTool_life() {
        return tool_life;
    }

    public void setTool_life(int tool_life) {
        this.tool_life = tool_life;
    }

    public int[] getReserve() {
        return reserve;
    }

    public void setReserve(int[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBMTAP{" +
                "slct=" + slct +
                ", tool_no=" + tool_no +
                ", x_axis_ofs=" + x_axis_ofs +
                ", y_axis_ofs=" + y_axis_ofs +
                ", punch_count=" + punch_count +
                ", tool_life=" + tool_life +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
