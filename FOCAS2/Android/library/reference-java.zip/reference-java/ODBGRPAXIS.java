package jp.co.fanuc.fwlibe1;


public class ODBGRPAXIS {
    private short path_num;
    private short draw_num;

    public short getPath_num() {
        return path_num;
    }

    public void setPath_num(short path_num) {
        this.path_num = path_num;
    }

    public short getDraw_num() {
        return draw_num;
    }

    public void setDraw_num(short draw_num) {
        this.draw_num = draw_num;
    }

    @Override
    public String toString() {
        return "ODBGRPAXIS{" +
                "path_num=" + path_num +
                ", draw_num=" + draw_num +
                '}';
    }
}
