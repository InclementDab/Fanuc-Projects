package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMVA {
    private short sync_obj;
    private short path;

    public short getSync_obj() {
        return sync_obj;
    }

    public void setSync_obj(short sync_obj) {
        this.sync_obj = sync_obj;
    }

    public short getPath() {
        return path;
    }

    public void setPath(short path) {
        this.path = path;
    }

    public static class LIN_AX {
        private short axis_no;
        private short mov_dir;

        public short getAxis_no() {
            return axis_no;
        }

        public void setAxis_no(short axis_no) {
            this.axis_no = axis_no;
        }

        public short getMov_dir() {
            return mov_dir;
        }

        public void setMov_dir(short mov_dir) {
            this.mov_dir = mov_dir;
        }

        @Override
        public String toString() {
            return "LIN_AX{" +
                    "axis_no=" + axis_no +
                    ", mov_dir=" + mov_dir +
                    '}';
        }
    }
    public static class ROT_AX {
        private short axis_no;
        private short c_ax_dir;
        private int c_pos;
        private int inc_ang;
        private short rot_dir;
        private short reserve;

        public short getAxis_no() {
            return axis_no;
        }

        public void setAxis_no(short axis_no) {
            this.axis_no = axis_no;
        }

        public short getC_ax_dir() {
            return c_ax_dir;
        }

        public void setC_ax_dir(short c_ax_dir) {
            this.c_ax_dir = c_ax_dir;
        }

        public int getC_pos() {
            return c_pos;
        }

        public void setC_pos(int c_pos) {
            this.c_pos = c_pos;
        }

        public int getInc_ang() {
            return inc_ang;
        }

        public void setInc_ang(int inc_ang) {
            this.inc_ang = inc_ang;
        }

        public short getRot_dir() {
            return rot_dir;
        }

        public void setRot_dir(short rot_dir) {
            this.rot_dir = rot_dir;
        }

        public short getReserve() {
            return reserve;
        }

        public void setReserve(short reserve) {
            this.reserve = reserve;
        }

        @Override
        public String toString() {
            return "ROT_AX{" +
                    "axis_no=" + axis_no +
                    ", c_ax_dir=" + c_ax_dir +
                    ", c_pos=" + c_pos +
                    ", inc_ang=" + inc_ang +
                    ", rot_dir=" + rot_dir +
                    ", reserve=" + reserve +
                    '}';
        }
    }
    public static class ROT_ELE {
        private short master;
        private short slave;

        public short getMaster() {
            return master;
        }

        public void setMaster(short master) {
            this.master = master;
        }

        public short getSlave() {
            return slave;
        }

        public void setSlave(short slave) {
            this.slave = slave;
        }

        @Override
        public String toString() {
            return "ROT_ELE{" +
                    "master=" + master +
                    ", slave=" + slave +
                    '}';
        }
    }
    private LIN_AX lin_ax[];
    private ROT_AX rot_ax[];
    private ROT_ELE rot_ele[];

    public LIN_AX[] getLin_ax() {
        return lin_ax;
    }

    public void setLin_ax(LIN_AX[] lin_ax) {
        this.lin_ax = lin_ax;
    }

    public ROT_AX[] getRot_ax() {
        return rot_ax;
    }

    public void setRot_ax(ROT_AX[] rot_ax) {
        this.rot_ax = rot_ax;
    }

    public ROT_ELE[] getRot_ele() {
        return rot_ele;
    }

    public void setRot_ele(ROT_ELE[] rot_ele) {
        this.rot_ele = rot_ele;
    }

    @Override
    public String toString() {
        return "ODBMVA{" +
                "sync_obj=" + sync_obj +
                ", path=" + path +
                ", lin_ax=" + Arrays.toString(lin_ax) +
                ", rot_ax=" + Arrays.toString(rot_ax) +
                ", rot_ele=" + Arrays.toString(rot_ele) +
                '}';
    }
}
