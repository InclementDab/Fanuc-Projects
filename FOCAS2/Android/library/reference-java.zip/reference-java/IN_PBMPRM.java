package jp.co.fanuc.fwlibe1;


public class IN_PBMPRM {
    private T_BUS_PARA bus_para;
    private T_MODE_ADDR_ALLOC mode_addr_alloc;
    private T_SLAVE_SUB_PARA slv_sub_para;
    private T_SLAVE_PARA slv_para;
    private T_DGN_ADDR_ALLOC dgn_addr_alloc;
    private T_MODULE_DATA module_data;
    private T_DIDO_ADDR_ALLOC dido_addr_alloc;

    public T_BUS_PARA getBus_para() {
        return bus_para;
    }

    public void setBus_para(T_BUS_PARA bus_para) {
        this.bus_para = bus_para;
    }

    public T_MODE_ADDR_ALLOC getMode_addr_alloc() {
        return mode_addr_alloc;
    }

    public void setMode_addr_alloc(T_MODE_ADDR_ALLOC mode_addr_alloc) {
        this.mode_addr_alloc = mode_addr_alloc;
    }

    public T_SLAVE_SUB_PARA getSlv_sub_para() {
        return slv_sub_para;
    }

    public void setSlv_sub_para(T_SLAVE_SUB_PARA slv_sub_para) {
        this.slv_sub_para = slv_sub_para;
    }

    public T_SLAVE_PARA getSlv_para() {
        return slv_para;
    }

    public void setSlv_para(T_SLAVE_PARA slv_para) {
        this.slv_para = slv_para;
    }

    public T_DGN_ADDR_ALLOC getDgn_addr_alloc() {
        return dgn_addr_alloc;
    }

    public void setDgn_addr_alloc(T_DGN_ADDR_ALLOC dgn_addr_alloc) {
        this.dgn_addr_alloc = dgn_addr_alloc;
    }

    public T_MODULE_DATA getModule_data() {
        return module_data;
    }

    public void setModule_data(T_MODULE_DATA module_data) {
        this.module_data = module_data;
    }

    public T_DIDO_ADDR_ALLOC getDido_addr_alloc() {
        return dido_addr_alloc;
    }

    public void setDido_addr_alloc(T_DIDO_ADDR_ALLOC dido_addr_alloc) {
        this.dido_addr_alloc = dido_addr_alloc;
    }


    @Override
    public String toString() {
        return "IN_PBMPRM{" +
                "bus_para=" + bus_para +
                ", mode_addr_alloc=" + mode_addr_alloc +
                ", slv_sub_para=" + slv_sub_para +
                ", slv_para=" + slv_para +
                ", dgn_addr_alloc=" + dgn_addr_alloc +
                ", module_data=" + module_data +
                ", dido_addr_alloc=" + dido_addr_alloc +
                '}';
    }

    public void Dispose() {
        if (bus_para != null) {
            bus_para.Dispose();
            bus_para = null;
        }

        mode_addr_alloc = null;

        if (slv_sub_para != null) {
            slv_sub_para.Dispose();
            slv_sub_para = null;
        }

        if (slv_para != null) {
            slv_para.Dispose();
            slv_para = null;
        }

        if (dgn_addr_alloc != null) {
            dgn_addr_alloc.Dispose();
            dgn_addr_alloc = null;
        }

        if (module_data != null) {
            module_data.Dispose();
            module_data = null;
        }

        if (dido_addr_alloc != null) {
            dido_addr_alloc.Dispose();
            dido_addr_alloc = null;
        }
    }
}
