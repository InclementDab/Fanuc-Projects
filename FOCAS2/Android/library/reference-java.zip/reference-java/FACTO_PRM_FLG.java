package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class FACTO_PRM_FLG {
    private FACTO_CLIENT_PRM_FLG opposite[];

    public FACTO_CLIENT_PRM_FLG[] getOpposite() {
        return opposite;
    }

    public void setOpposite(FACTO_CLIENT_PRM_FLG[] opposite) {
        this.opposite = opposite;
    }

    @Override
    public String toString() {
        return "FACTO_PRM_FLG{" +
                "opposite=" + Arrays.toString(opposite) +
                '}';
    }
}
