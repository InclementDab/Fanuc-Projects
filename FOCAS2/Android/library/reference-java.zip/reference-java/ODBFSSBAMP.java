package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBFSSBAMP {
    private short ln_num;
    private short slave_num;
    private char name[];
    private char seires[];
    private char unit[];
    private char cur[];
    private short axis_num;
    private char axis_name[];

    public short getLn_num() {
        return ln_num;
    }

    public void setLn_num(short ln_num) {
        this.ln_num = ln_num;
    }

    public short getSlave_num() {
        return slave_num;
    }

    public void setSlave_num(short slave_num) {
        this.slave_num = slave_num;
    }

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public char[] getSeires() {
        return seires;
    }

    public void setSeires(char[] seires) {
        this.seires = seires;
    }

    public char[] getUnit() {
        return unit;
    }

    public void setUnit(char[] unit) {
        this.unit = unit;
    }

    public char[] getCur() {
        return cur;
    }

    public void setCur(char[] cur) {
        this.cur = cur;
    }

    public short getAxis_num() {
        return axis_num;
    }

    public void setAxis_num(short axis_num) {
        this.axis_num = axis_num;
    }

    public char[] getAxis_name() {
        return axis_name;
    }

    public void setAxis_name(char[] axis_name) {
        this.axis_name = axis_name;
    }

    @Override
    public String toString() {
        return "ODBFSSBAMP{" +
                "ln_num=" + ln_num +
                ", slave_num=" + slave_num +
                ", name=" + Arrays.toString(name) +
                ", seires=" + Arrays.toString(seires) +
                ", unit=" + Arrays.toString(unit) +
                ", cur=" + Arrays.toString(cur) +
                ", axis_num=" + axis_num +
                ", axis_name=" + Arrays.toString(axis_name) +
                '}';
    }
}
