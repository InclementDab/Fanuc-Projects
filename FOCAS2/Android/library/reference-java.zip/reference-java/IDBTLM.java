package jp.co.fanuc.fwlibe1;


public class IDBTLM {
    private short data_id;
    private byte data1;
    private short data2;
    private int data4;

    public short getData_id() {
        return data_id;
    }

    public void setData_id(short data_id) {
        this.data_id = data_id;
    }

    public byte getData1() {
        return data1;
    }

    public void setData1(byte data1) {
        this.data1 = data1;
    }

    public short getData2() {
        return data2;
    }

    public void setData2(short data2) {
        this.data2 = data2;
    }

    public int getData4() {
        return data4;
    }

    public void setData4(int data4) {
        this.data4 = data4;
    }

    @Override
    public String toString() {
        return "IDBTLM{" +
                "data_id=" + data_id +
                ", data1=" + data1 +
                ", data2=" + data2 +
                ", data4=" + data4 +
                '}';
    }
}
