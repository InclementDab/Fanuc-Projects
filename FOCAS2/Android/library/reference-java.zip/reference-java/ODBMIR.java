package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMIR {
    private short mode;
    private int mir_flag;
    private int mir_pos[];

    public short getMode() {
        return mode;
    }

    public void setMode(short mode) {
        this.mode = mode;
    }

    public int getMir_flag() {
        return mir_flag;
    }

    public void setMir_flag(int mir_flag) {
        this.mir_flag = mir_flag;
    }

    public int[] getMir_pos() {
        return mir_pos;
    }

    public void setMir_pos(int[] mir_pos) {
        this.mir_pos = mir_pos;
    }

    @Override
    public String toString() {
        return "ODBMIR{" +
                "mode=" + mode +
                ", mir_flag=" + mir_flag +
                ", mir_pos=" + Arrays.toString(mir_pos) +
                '}';
    }
}
