package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBWVPRM3 {
    private short condition;
    private short trg_unittype;
    private char trg_adr;
    private char trg_bit;
    private short trg_no;
    private short alm_kind;
    private short alm_no;
    private short alm_axis;
    private short reserve1;
    private int delay;
    private int t_range;
    private short wav_cycle;
    private short dio_cycle;

    public short getCondition() {

        return condition;
    }

    public void setCondition(short condition) {
        this.condition = condition;
    }

    public short getTrg_unittype() {
        return trg_unittype;
    }

    public void setTrg_unittype(short trg_unittype) {
        this.trg_unittype = trg_unittype;
    }

    public char getTrg_adr() {
        return trg_adr;
    }

    public void setTrg_adr(char trg_adr) {
        this.trg_adr = trg_adr;
    }

    public char getTrg_bit() {
        return trg_bit;
    }

    public void setTrg_bit(char trg_bit) {
        this.trg_bit = trg_bit;
    }

    public short getTrg_no() {
        return trg_no;
    }

    public void setTrg_no(short trg_no) {
        this.trg_no = trg_no;
    }

    public short getAlm_kind() {
        return alm_kind;
    }

    public void setAlm_kind(short alm_kind) {
        this.alm_kind = alm_kind;
    }

    public short getAlm_no() {
        return alm_no;
    }

    public void setAlm_no(short alm_no) {
        this.alm_no = alm_no;
    }

    public short getAlm_axis() {
        return alm_axis;
    }

    public void setAlm_axis(short alm_axis) {
        this.alm_axis = alm_axis;
    }

    public short getReserve1() {
        return reserve1;
    }

    public void setReserve1(short reserve1) {
        this.reserve1 = reserve1;
    }

    public int getDelay() {
        return delay;
    }

    public void setDelay(int delay) {
        this.delay = delay;
    }

    public int getT_range() {
        return t_range;
    }

    public void setT_range(int t_range) {
        this.t_range = t_range;
    }

    public short getWav_cycle() {
        return wav_cycle;
    }

    public void setWav_cycle(short wav_cycle) {
        this.wav_cycle = wav_cycle;
    }

    public short getDio_cycle() {
        return dio_cycle;
    }

    public void setDio_cycle(short dio_cycle) {
        this.dio_cycle = dio_cycle;
    }

    public static class CH {
        private short kind;
        private short reserve2;

        public short getKind() {
            return kind;
        }

        public void setKind(short kind) {
            this.kind = kind;
        }

        public short getReserve2() {
            return reserve2;
        }

        public void setReserve2(short reserve2) {
            this.reserve2 = reserve2;
        }

        public static class AX {
            private int axis;
            private int reserve3;

            public int getAxis() {
                return axis;
            }

            public void setAxis(int axis) {
                this.axis = axis;
            }

            public int getReserve3() {
                return reserve3;
            }

            public void setReserve3(int reserve3) {
                this.reserve3 = reserve3;
            }

            @Override
            public String toString() {
                return "AX{" +
                        "axis=" + axis +
                        ", reserve3=" + reserve3 +
                        '}';
            }
        }

        public static class IO {
            private short unittype;
            private char adr;
            private char bit;
            private short no;
            private short reserve3;

            public short getUnittype() {
                return unittype;
            }

            public void setUnittype(short unittype) {
                this.unittype = unittype;
            }

            public char getAdr() {
                return adr;
            }

            public void setAdr(char adr) {
                this.adr = adr;
            }

            public char getBit() {
                return bit;
            }

            public void setBit(char bit) {
                this.bit = bit;
            }

            public short getNo() {
                return no;
            }

            public void setNo(short no) {
                this.no = no;
            }

            public short getReserve3() {
                return reserve3;
            }

            public void setReserve3(short reserve3) {
                this.reserve3 = reserve3;
            }

            @Override
            public String toString() {
                return "IO{" +
                        "unittype=" + unittype +
                        ", adr=" + adr +
                        ", bit=" + bit +
                        ", no=" + no +
                        ", reserve3=" + reserve3 +
                        '}';
            }
        }

        private AX ax;
        private IO io;

        public AX getAx() {
            return ax;
        }

        public void setAx(AX ax) {
            this.ax = ax;
        }

        public IO getIo() {
            return io;
        }

        public void setIo(IO io) {
            this.io = io;
        }

        @Override
        public String toString() {
            return "CH{" +
                    "kind=" + kind +
                    ", reserve2=" + reserve2 +
                    ", ax=" + ax +
                    ", io=" + io +
                    '}';
        }
    }

    private CH ch[];

    public CH[] getCh() {
        return ch;
    }

    public void setCh(CH[] ch) {
        this.ch = ch;
    }

    @Override
    public String toString() {
        return "IODBWVPRM3{" +
                "condition=" + condition +
                ", trg_unittype=" + trg_unittype +
                ", trg_adr=" + trg_adr +
                ", trg_bit=" + trg_bit +
                ", trg_no=" + trg_no +
                ", alm_kind=" + alm_kind +
                ", alm_no=" + alm_no +
                ", alm_axis=" + alm_axis +
                ", reserve1=" + reserve1 +
                ", delay=" + delay +
                ", t_range=" + t_range +
                ", wav_cycle=" + wav_cycle +
                ", dio_cycle=" + dio_cycle +
                ", ch=" + Arrays.toString(ch) +
                '}';
    }
}
