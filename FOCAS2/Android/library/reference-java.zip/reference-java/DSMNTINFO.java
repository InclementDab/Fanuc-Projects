package jp.co.fanuc.fwlibe1;


public class DSMNTINFO {
    private short empty_cnt;
    private int total_size;
    private short ReadPtr;
    private short WritePtr;

    public short getEmpty_cnt() {
        return empty_cnt;
    }

    public void setEmpty_cnt(short empty_cnt) {
        this.empty_cnt = empty_cnt;
    }

    public int getTotal_size() {
        return total_size;
    }

    public void setTotal_size(int total_size) {
        this.total_size = total_size;
    }

    public short getReadPtr() {
        return ReadPtr;
    }

    public void setReadPtr(short readPtr) {
        ReadPtr = readPtr;
    }

    public short getWritePtr() {
        return WritePtr;
    }

    public void setWritePtr(short writePtr) {
        WritePtr = writePtr;
    }

    @Override
    public String toString() {
        return "DSMNTINFO{" +
                "empty_cnt=" + empty_cnt +
                ", total_size=" + total_size +
                ", ReadPtr=" + ReadPtr +
                ", WritePtr=" + WritePtr +
                '}';
    }
}
