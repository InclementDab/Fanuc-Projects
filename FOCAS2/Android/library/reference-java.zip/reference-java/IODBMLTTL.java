package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBMLTTL {
    private short slct;
    private short m_tl_no;
    private int m_tl_radius;
    private int m_tl_angle;
    private int x_axis_ofs;
    private int y_axis_ofs;
    private char tl_shape;
    private int tl_size_i;
    private int tl_size_j;
    private int tl_angle;
    private char m_radius_dec;
    private char m_angle_dec;
    private char x_axis_dec;
    private char y_axis_dec;
    private char tl_size_i_dec;
    private char tl_size_j_dec;
    private char tl_angle_dec;
    private char reserve[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getM_tl_no() {
        return m_tl_no;
    }

    public void setM_tl_no(short m_tl_no) {
        this.m_tl_no = m_tl_no;
    }

    public int getM_tl_radius() {
        return m_tl_radius;
    }

    public void setM_tl_radius(int m_tl_radius) {
        this.m_tl_radius = m_tl_radius;
    }

    public int getM_tl_angle() {
        return m_tl_angle;
    }

    public void setM_tl_angle(int m_tl_angle) {
        this.m_tl_angle = m_tl_angle;
    }

    public int getX_axis_ofs() {
        return x_axis_ofs;
    }

    public void setX_axis_ofs(int x_axis_ofs) {
        this.x_axis_ofs = x_axis_ofs;
    }

    public int getY_axis_ofs() {
        return y_axis_ofs;
    }

    public void setY_axis_ofs(int y_axis_ofs) {
        this.y_axis_ofs = y_axis_ofs;
    }

    public char getTl_shape() {
        return tl_shape;
    }

    public void setTl_shape(char tl_shape) {
        this.tl_shape = tl_shape;
    }

    public int getTl_size_i() {
        return tl_size_i;
    }

    public void setTl_size_i(int tl_size_i) {
        this.tl_size_i = tl_size_i;
    }

    public int getTl_size_j() {
        return tl_size_j;
    }

    public void setTl_size_j(int tl_size_j) {
        this.tl_size_j = tl_size_j;
    }

    public int getTl_angle() {
        return tl_angle;
    }

    public void setTl_angle(int tl_angle) {
        this.tl_angle = tl_angle;
    }

    public char getM_radius_dec() {
        return m_radius_dec;
    }

    public void setM_radius_dec(char m_radius_dec) {
        this.m_radius_dec = m_radius_dec;
    }

    public char getM_angle_dec() {
        return m_angle_dec;
    }

    public void setM_angle_dec(char m_angle_dec) {
        this.m_angle_dec = m_angle_dec;
    }

    public char getX_axis_dec() {
        return x_axis_dec;
    }

    public void setX_axis_dec(char x_axis_dec) {
        this.x_axis_dec = x_axis_dec;
    }

    public char getY_axis_dec() {
        return y_axis_dec;
    }

    public void setY_axis_dec(char y_axis_dec) {
        this.y_axis_dec = y_axis_dec;
    }

    public char getTl_size_i_dec() {
        return tl_size_i_dec;
    }

    public void setTl_size_i_dec(char tl_size_i_dec) {
        this.tl_size_i_dec = tl_size_i_dec;
    }

    public char getTl_size_j_dec() {
        return tl_size_j_dec;
    }

    public void setTl_size_j_dec(char tl_size_j_dec) {
        this.tl_size_j_dec = tl_size_j_dec;
    }

    public char getTl_angle_dec() {
        return tl_angle_dec;
    }

    public void setTl_angle_dec(char tl_angle_dec) {
        this.tl_angle_dec = tl_angle_dec;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBMLTTL{" +
                "slct=" + slct +
                ", m_tl_no=" + m_tl_no +
                ", m_tl_radius=" + m_tl_radius +
                ", m_tl_angle=" + m_tl_angle +
                ", x_axis_ofs=" + x_axis_ofs +
                ", y_axis_ofs=" + y_axis_ofs +
                ", tl_shape=" + tl_shape +
                ", tl_size_i=" + tl_size_i +
                ", tl_size_j=" + tl_size_j +
                ", tl_angle=" + tl_angle +
                ", m_radius_dec=" + m_radius_dec +
                ", m_angle_dec=" + m_angle_dec +
                ", x_axis_dec=" + x_axis_dec +
                ", y_axis_dec=" + y_axis_dec +
                ", tl_size_i_dec=" + tl_size_i_dec +
                ", tl_size_j_dec=" + tl_size_j_dec +
                ", tl_angle_dec=" + tl_angle_dec +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
