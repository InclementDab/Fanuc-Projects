package jp.co.fanuc.fwlibe1;


public class ODBHND {
    private POSELM input;
    private POSELM output;

    public POSELM getInput() {
        return input;
    }

    public void setInput(POSELM input) {
        this.input = input;
    }

    public POSELM getOutput() {

        return output;
    }

    public void setOutput(POSELM output) {
        this.output = output;
    }

    @Override
    public String toString() {
        return "ODBHND{" +
                "input=" + input +
                ", output=" + output +
                '}';
    }
}
