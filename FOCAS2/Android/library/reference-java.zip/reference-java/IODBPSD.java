package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBPSD {
    private short datano;
    private short type;

    private byte cdata;
    private short idata;
    private int ldata;
    private REALPRM rdata;
    private byte cdatas[];
    private short idatas[];
    private int ldatas[];
    private REALPRM rdatas[];

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {

        return type;
    }

    public void setType(short type) {
        this.type = type;
    }


    public byte getCdata() {
        return cdata;
    }

    public void setCdata(byte cdata) {
        this.cdata = cdata;
    }

    public short getIdata() {

        return idata;
    }

    public void setIdata(short idata) {
        this.idata = idata;
    }

    public int getLdata() {
        return ldata;
    }

    public void setLdata(int ldata) {
        this.ldata = ldata;
    }

    public REALPRM getRdata() {

        return rdata;
    }

    public void setRdata(REALPRM rdata) {
        this.rdata = rdata;
    }

    public byte[] getCdatas() {

        return cdatas;
    }

    public void setCdatas(byte[] cdatas) {
        this.cdatas = cdatas;
    }

    public short[] getIdatas() {

        return idatas;
    }

    public void setIdatas(short[] idatas) {
        this.idatas = idatas;
    }

    public int[] getLdatas() {

        return ldatas;
    }

    public void setLdatas(int[] ldatas) {
        this.ldatas = ldatas;
    }

    public REALPRM[] getRdatas() {

        return rdatas;
    }

    public void setRdatas(REALPRM[] rdatas) {
        this.rdatas = rdatas;
    }

    @Override
    public String toString() {
        return "IODBPSD{" +
                "datano=" + datano +
                ", type=" + type +
                ", cdata=" + cdata +
                ", idata=" + idata +
                ", ldata=" + ldata +
                ", rdata=" + rdata +
                ", cdatas=" + Arrays.toString(cdatas) +
                ", idatas=" + Arrays.toString(idatas) +
                ", ldatas=" + Arrays.toString(ldatas) +
                ", rdatas=" + Arrays.toString(rdatas) +
                '}';
    }

    public void Dispose() {
        rdata = null;
        cdatas = null;
        idatas = null;
        ldatas = null;
        rdatas = null;
    }
}
