package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBLPWDT {
    private short slct;
    private short dty_const;
    private short dty_min;
    private short reserve[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getDty_const() {
        return dty_const;
    }

    public void setDty_const(short dty_const) {
        this.dty_const = dty_const;
    }

    public short getDty_min() {
        return dty_min;
    }

    public void setDty_min(short dty_min) {
        this.dty_min = dty_min;
    }

    public short[] getReserve() {
        return reserve;
    }

    public void setReserve(short[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBLPWDT{" +
                "slct=" + slct +
                ", dty_const=" + dty_const +
                ", dty_min=" + dty_min +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
