package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class EIPS_CONN_PRM {
    private int AssemblyInstance;
    private short Type;
    private char pad1[];
    private EIP_MULTI_ADDR Addr;
    private int Size;
    private int RPI;
    private short TransportType;
    private short HeaderFormat;
    private short Priority;
    private char pad2[];
    private char reserve[];
    private char pad3[];

    public int getAssemblyInstance() {
        return AssemblyInstance;
    }

    public void setAssemblyInstance(int assemblyInstance) {
        AssemblyInstance = assemblyInstance;
    }

    public short getType() {
        return Type;
    }

    public void setType(short type) {
        Type = type;
    }

    public char[] getPad1() {
        return pad1;
    }

    public void setPad1(char[] pad1) {
        this.pad1 = pad1;
    }

    public EIP_MULTI_ADDR getAddr() {
        return Addr;
    }

    public void setAddr(EIP_MULTI_ADDR addr) {
        Addr = addr;
    }

    public int getSize() {
        return Size;
    }

    public void setSize(int size) {
        Size = size;
    }

    public int getRPI() {
        return RPI;
    }

    public void setRPI(int RPI) {
        this.RPI = RPI;
    }

    public short getTransportType() {
        return TransportType;
    }

    public void setTransportType(short transportType) {
        TransportType = transportType;
    }

    public short getHeaderFormat() {
        return HeaderFormat;
    }

    public void setHeaderFormat(short headerFormat) {
        HeaderFormat = headerFormat;
    }

    public short getPriority() {
        return Priority;
    }

    public void setPriority(short priority) {
        Priority = priority;
    }

    public char[] getPad2() {
        return pad2;
    }

    public void setPad2(char[] pad2) {
        this.pad2 = pad2;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    public char[] getPad3() {
        return pad3;
    }

    public void setPad3(char[] pad3) {
        this.pad3 = pad3;
    }

    @Override
    public String toString() {
        return "EIPS_CONN_PRM{" +
                "AssemblyInstance=" + AssemblyInstance +
                ", Type=" + Type +
                ", pad1=" + Arrays.toString(pad1) +
                ", Addr=" + Addr +
                ", Size=" + Size +
                ", RPI=" + RPI +
                ", TransportType=" + TransportType +
                ", HeaderFormat=" + HeaderFormat +
                ", Priority=" + Priority +
                ", pad2=" + Arrays.toString(pad2) +
                ", reserve=" + Arrays.toString(reserve) +
                ", pad3=" + Arrays.toString(pad3) +
                '}';
    }
}
