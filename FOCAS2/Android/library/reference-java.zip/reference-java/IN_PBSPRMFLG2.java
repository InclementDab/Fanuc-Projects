package jp.co.fanuc.fwlibe1;


public class IN_PBSPRMFLG2 {
    private char slave_no;
    private char pad1;
    private char di_size;
    private char do_size;
    private char di_path;
    private char do_path;
    private char di_kind;
    private char do_kind;
    private char di_top_address;
    private char do_top_address;
    private char sts_path;
    private char sts_kind;
    private char sts_top_address;
    private char pad2;

    public char getSlave_no() {
        return slave_no;
    }

    public void setSlave_no(char slave_no) {
        this.slave_no = slave_no;
    }

    public char getPad1() {
        return pad1;
    }

    public void setPad1(char pad1) {
        this.pad1 = pad1;
    }

    public char getDi_size() {
        return di_size;
    }

    public void setDi_size(char di_size) {
        this.di_size = di_size;
    }

    public char getDo_size() {
        return do_size;
    }

    public void setDo_size(char do_size) {
        this.do_size = do_size;
    }

    public char getDi_path() {
        return di_path;
    }

    public void setDi_path(char di_path) {
        this.di_path = di_path;
    }

    public char getDo_path() {
        return do_path;
    }

    public void setDo_path(char do_path) {
        this.do_path = do_path;
    }

    public char getDi_kind() {
        return di_kind;
    }

    public void setDi_kind(char di_kind) {
        this.di_kind = di_kind;
    }

    public char getDo_kind() {
        return do_kind;
    }

    public void setDo_kind(char do_kind) {
        this.do_kind = do_kind;
    }

    public char getDi_top_address() {
        return di_top_address;
    }

    public void setDi_top_address(char di_top_address) {
        this.di_top_address = di_top_address;
    }

    public char getDo_top_address() {
        return do_top_address;
    }

    public void setDo_top_address(char do_top_address) {
        this.do_top_address = do_top_address;
    }

    public char getSts_path() {
        return sts_path;
    }

    public void setSts_path(char sts_path) {
        this.sts_path = sts_path;
    }

    public char getSts_kind() {
        return sts_kind;
    }

    public void setSts_kind(char sts_kind) {
        this.sts_kind = sts_kind;
    }

    public char getSts_top_address() {
        return sts_top_address;
    }

    public void setSts_top_address(char sts_top_address) {
        this.sts_top_address = sts_top_address;
    }

    public char getPad2() {
        return pad2;
    }

    public void setPad2(char pad2) {
        this.pad2 = pad2;
    }

    @Override
    public String toString() {
        return "IN_PBSPRMFLG2{" +
                "slave_no=" + slave_no +
                ", pad1=" + pad1 +
                ", di_size=" + di_size +
                ", do_size=" + do_size +
                ", di_path=" + di_path +
                ", do_path=" + do_path +
                ", di_kind=" + di_kind +
                ", do_kind=" + do_kind +
                ", di_top_address=" + di_top_address +
                ", do_top_address=" + do_top_address +
                ", sts_path=" + sts_path +
                ", sts_kind=" + sts_kind +
                ", sts_top_address=" + sts_top_address +
                ", pad2=" + pad2 +
                '}';
    }
}
