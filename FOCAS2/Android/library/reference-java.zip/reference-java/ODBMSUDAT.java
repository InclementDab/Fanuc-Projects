package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMSUDAT {
    private ODBMSUINF inf;
    private ODBMSUXTERM x_term[];
    private ODBMSUYTERM y_term[];

    public ODBMSUINF getInf() {
        return inf;
    }

    public void setInf(ODBMSUINF inf) {
        this.inf = inf;
    }

    public ODBMSUXTERM[] getX_term() {
        return x_term;
    }

    public void setX_term(ODBMSUXTERM[] x_term) {
        this.x_term = x_term;
    }

    public ODBMSUYTERM[] getY_term() {
        return y_term;
    }

    public void setY_term(ODBMSUYTERM[] y_term) {
        this.y_term = y_term;
    }

    @Override
    public String toString() {
        return "ODBMSUDAT{" +
                "inf=" + inf +
                ", x_term=" + Arrays.toString(x_term) +
                ", y_term=" + Arrays.toString(y_term) +
                '}';
    }
}
