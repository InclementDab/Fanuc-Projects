package jp.co.fanuc.fwlibe1;


public class IODBTLMAG_SRCHINFO {
    private IODBTLMAG2 startInfo;
    private IODBTLMAG result;

    public IODBTLMAG2 getStartInfo() {
        return startInfo;
    }

    public void setStartInfo(IODBTLMAG2 startInfo) {
        this.startInfo = startInfo;
    }

    public IODBTLMAG getResult() {
        return result;
    }

    public void setResult(IODBTLMAG result) {
        this.result = result;
    }

    @Override
    public String toString() {
        return "IODBTLMAG_SRCHINFO{" +
                "startInfo=" + startInfo +
                ", result=" + result +
                '}';
    }
}
