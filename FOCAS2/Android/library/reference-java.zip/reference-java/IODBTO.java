package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTO {
    private short datano_s;
    private short type;
    private short datano_e;

    private int m_ofs[];
    private int m_ofs_a[];
    private int m_ofs_b[];
    private int m_ofs_c[];
    private short t_tip[];
    private int t_ofs[];
    private int t_ofs_2g[];
    private int m_ofs_cnr[];
    private M_OFS_AT m_ofs_at[];
    private M_OFS_BT m_ofs_bt[];
    private M_OFS_CT m_ofs_ct[];
    private T_OFS_A t_ofs_a[];
    private T_OFS_B t_ofs_b[];
    private T_OFS_EX t_ofs_ex[];

    public short getDatano_s() {
        return datano_s;
    }

    public void setDatano_s(short datano_s) {
        this.datano_s = datano_s;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getDatano_e() {
        return datano_e;
    }

    public void setDatano_e(short datano_e) {
        this.datano_e = datano_e;
    }

    public int[] getM_ofs() {
        return m_ofs;
    }

    public void setM_ofs(int[] m_ofs) {
        this.m_ofs = m_ofs;
    }

    public int[] getM_ofs_a() {
        return m_ofs_a;
    }

    public void setM_ofs_a(int[] m_ofs_a) {
        this.m_ofs_a = m_ofs_a;
    }

    public int[] getM_ofs_b() {
        return m_ofs_b;
    }

    public void setM_ofs_b(int[] m_ofs_b) {
        this.m_ofs_b = m_ofs_b;
    }

    public int[] getM_ofs_c() {
        return m_ofs_c;
    }

    public void setM_ofs_c(int[] m_ofs_c) {
        this.m_ofs_c = m_ofs_c;
    }

    public short[] getT_tip() {
        return t_tip;
    }

    public void setT_tip(short[] t_tip) {
        this.t_tip = t_tip;
    }

    public int[] getT_ofs() {
        return t_ofs;
    }

    public void setT_ofs(int[] t_ofs) {
        this.t_ofs = t_ofs;
    }

    public int[] getT_ofs_2g() {
        return t_ofs_2g;
    }

    public void setT_ofs_2g(int[] t_ofs_2g) {
        this.t_ofs_2g = t_ofs_2g;
    }

    public int[] getM_ofs_cnr() {
        return m_ofs_cnr;
    }

    public void setM_ofs_cnr(int[] m_ofs_cnr) {
        this.m_ofs_cnr = m_ofs_cnr;
    }

    public M_OFS_AT[] getM_ofs_at() {
        return m_ofs_at;
    }

    public void setM_ofs_at(M_OFS_AT[] m_ofs_at) {
        this.m_ofs_at = m_ofs_at;
    }

    public M_OFS_BT[] getM_ofs_bt() {
        return m_ofs_bt;
    }

    public void setM_ofs_bt(M_OFS_BT[] m_ofs_bt) {
        this.m_ofs_bt = m_ofs_bt;
    }

    public M_OFS_CT[] getM_ofs_ct() {
        return m_ofs_ct;
    }

    public void setM_ofs_ct(M_OFS_CT[] m_ofs_ct) {
        this.m_ofs_ct = m_ofs_ct;
    }

    public T_OFS_A[] getT_ofs_a() {
        return t_ofs_a;
    }

    public void setT_ofs_a(T_OFS_A[] t_ofs_a) {
        this.t_ofs_a = t_ofs_a;
    }

    public T_OFS_B[] getT_ofs_b() {
        return t_ofs_b;
    }

    public void setT_ofs_b(T_OFS_B[] t_ofs_b) {
        this.t_ofs_b = t_ofs_b;
    }

    public T_OFS_EX[] getT_ofs_ex() {
        return t_ofs_ex;
    }

    public void setT_ofs_ex(T_OFS_EX[] t_ofs_ex) {
        this.t_ofs_ex = t_ofs_ex;
    }

    public static class M_OFS_AT {
        private short tip;
        private int data[];

        public short getTip() {
            return tip;
        }

        public void setTip(short tip) {
            this.tip = tip;
        }

        public int[] getData() {

            return data;
        }

        public void setData(int[] data) {
            this.data = data;
        }

        @Override
        public String toString() {
            return "M_OFS_AT{" +
                    "tip=" + tip +
                    ", data=" + Arrays.toString(data) +
                    '}';
        }
    }

    public static class M_OFS_BT {
        private short tip;
        private int data[];

        public short getTip() {
            return tip;
        }

        public void setTip(short tip) {
            this.tip = tip;
        }

        public int[] getData() {
            return data;
        }

        public void setData(int[] data) {
            this.data = data;
        }

        @Override
        public String toString() {
            return "M_OFS_BT{" +
                    "tip=" + tip +
                    ", data=" + Arrays.toString(data) +
                    '}';
        }
    }

    public static class M_OFS_CT {
        private short tip;
        private int data[];

        public short getTip() {
            return tip;
        }

        public void setTip(short tip) {
            this.tip = tip;
        }

        public int[] getData() {

            return data;
        }

        public void setData(int[] data) {
            this.data = data;
        }

        @Override
        public String toString() {
            return "M_OFS_CT{" +
                    "tip=" + tip +
                    ", data=" + Arrays.toString(data) +
                    '}';
        }
    }

    public static class T_OFS_A {
        private short tip;
        private int data[];

        public short getTip() {
            return tip;
        }

        public void setTip(short tip) {
            this.tip = tip;
        }

        public int[] getData() {

            return data;
        }

        public void setData(int[] data) {
            this.data = data;
        }

        @Override
        public String toString() {
            return "T_OFS_A{" +
                    "tip=" + tip +
                    ", data=" + Arrays.toString(data) +
                    '}';
        }
    }

    public static class T_OFS_B {
        private short tip;
        private int data[];

        public short getTip() {
            return tip;
        }

        public void setTip(short tip) {
            this.tip = tip;
        }

        public int[] getData() {

            return data;
        }

        public void setData(int[] data) {
            this.data = data;
        }

        @Override
        public String toString() {
            return "T_OFS_B{" +
                    "tip=" + tip +
                    ", data=" + Arrays.toString(data) +
                    '}';
        }
    }

    public static class T_OFS_EX {
        private int data[];

        public int[] getData() {
            return data;
        }

        public void setData(int[] data) {
            this.data = data;
        }

        @Override
        public String toString() {
            return "T_OFS_EX{" +
                    "data=" + Arrays.toString(data) +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "IODBTO{" +
                "datano_s=" + datano_s +
                ", type=" + type +
                ", datano_e=" + datano_e +
                ", m_ofs=" + Arrays.toString(m_ofs) +
                ", m_ofs_a=" + Arrays.toString(m_ofs_a) +
                ", m_ofs_b=" + Arrays.toString(m_ofs_b) +
                ", m_ofs_c=" + Arrays.toString(m_ofs_c) +
                ", t_tip=" + Arrays.toString(t_tip) +
                ", t_ofs=" + Arrays.toString(t_ofs) +
                ", t_ofs_2g=" + Arrays.toString(t_ofs_2g) +
                ", m_ofs_cnr=" + Arrays.toString(m_ofs_cnr) +
                ", m_ofs_at=" + Arrays.toString(m_ofs_at) +
                ", m_ofs_bt=" + Arrays.toString(m_ofs_bt) +
                ", m_ofs_ct=" + Arrays.toString(m_ofs_ct) +
                ", t_ofs_a=" + Arrays.toString(t_ofs_a) +
                ", t_ofs_b=" + Arrays.toString(t_ofs_b) +
                ", t_ofs_ex=" + Arrays.toString(t_ofs_ex) +
                '}';
    }
}
