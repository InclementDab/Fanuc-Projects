package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class HSPDATAM {
    private char cdata[];
    private short idata[];
    private int ldata[];
    private REALPRM rdata[];

    public char[] getCdata() {
        return cdata;
    }

    public void setCdata(char[] cdata) {
        this.cdata = cdata;
    }

    public short[] getIdata() {

        return idata;
    }

    public void setIdata(short[] idata) {
        this.idata = idata;
    }

    public int[] getLdata() {

        return ldata;
    }

    public void setLdata(int[] ldata) {
        this.ldata = ldata;
    }

    public REALPRM[] getRdata() {

        return rdata;
    }

    public void setRdata(REALPRM[] rdata) {
        this.rdata = rdata;
    }

    @Override
    public String toString() {
        return "HSPDATAM{" +
                "cdata=" + Arrays.toString(cdata) +
                ", idata=" + Arrays.toString(idata) +
                ", ldata=" + Arrays.toString(ldata) +
                ", rdata=" + Arrays.toString(rdata) +
                '}';
    }
}
