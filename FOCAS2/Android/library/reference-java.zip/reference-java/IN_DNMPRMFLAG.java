package jp.co.fanuc.fwlibe1;


public class IN_DNMPRMFLAG {
    public static class  FLG {
        private IN_DNMPRMFLAG_BUS bus;
        private IN_DNMPRMFLAG_SLAVE slave;

        public IN_DNMPRMFLAG_BUS getBus() {
            return bus;
        }

        public void setBus(IN_DNMPRMFLAG_BUS bus) {
            this.bus = bus;
        }

        public IN_DNMPRMFLAG_SLAVE getSlave() {
            return slave;
        }

        public void setSlave(IN_DNMPRMFLAG_SLAVE slave) {
            this.slave = slave;
        }

        @Override
        public String toString() {
            return "FLG{" +
                    "bus=" + bus +
                    ", slave=" + slave +
                    '}';
        }
    }
    private FLG flg;

    public FLG getFlg() {
        return flg;
    }

    public void setFlg(FLG flg) {
        this.flg = flg;
    }

    @Override
    public String toString() {
        return "IN_DNMPRMFLAG{" +
                "flg=" + flg +
                '}';
    }
}
