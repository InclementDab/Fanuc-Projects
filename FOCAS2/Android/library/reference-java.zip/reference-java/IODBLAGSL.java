package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBLAGSL {
    private short slct;
    private short ag_slt;
    private short agflow_slt;
    private short ag_press;
    private short ag_ready_t;
    private short reserve[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getAg_slt() {
        return ag_slt;
    }

    public void setAg_slt(short ag_slt) {
        this.ag_slt = ag_slt;
    }

    public short getAgflow_slt() {
        return agflow_slt;
    }

    public void setAgflow_slt(short agflow_slt) {
        this.agflow_slt = agflow_slt;
    }

    public short getAg_press() {
        return ag_press;
    }

    public void setAg_press(short ag_press) {
        this.ag_press = ag_press;
    }

    public short getAg_ready_t() {
        return ag_ready_t;
    }

    public void setAg_ready_t(short ag_ready_t) {
        this.ag_ready_t = ag_ready_t;
    }

    public short[] getReserve() {
        return reserve;
    }

    public void setReserve(short[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBLAGSL{" +
                "slct=" + slct +
                ", ag_slt=" + ag_slt +
                ", agflow_slt=" + agflow_slt +
                ", ag_press=" + ag_press +
                ", ag_ready_t=" + ag_ready_t +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
