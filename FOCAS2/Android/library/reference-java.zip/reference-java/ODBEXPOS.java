package jp.co.fanuc.fwlibe1;


public class ODBEXPOS {
    private double data;
    private int dec;
    private int digit;

    public double getData() {
        return data;
    }

    public void setData(double data) {
        this.data = data;
    }

    public int getDec() {
        return dec;
    }

    public void setDec(int dec) {
        this.dec = dec;
    }

    public int getDigit() {
        return digit;
    }

    public void setDigit(int digit) {
        this.digit = digit;
    }

    @Override
    public String toString() {
        return "ODBEXPOS{" +
                "data=" + data +
                ", dec=" + dec +
                ", digit=" + digit +
                '}';
    }
}
