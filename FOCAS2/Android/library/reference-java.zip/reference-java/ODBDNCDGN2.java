package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBDNCDGN2 {
    private short ctrl_word;
    private short can_word;
    private char nc_file[];
    private short read_ptr;
    private short write_ptr;
    private short empty_cnt;
    private int total_size;

    public short getCtrl_word() {
        return ctrl_word;
    }

    public void setCtrl_word(short ctrl_word) {
        this.ctrl_word = ctrl_word;
    }

    public short getCan_word() {

        return can_word;
    }

    public void setCan_word(short can_word) {
        this.can_word = can_word;
    }

    public char[] getNc_file() {

        return nc_file;
    }

    public void setNc_file(char[] nc_file) {
        this.nc_file = nc_file;
    }

    public short getRead_ptr() {

        return read_ptr;
    }

    public void setRead_ptr(short read_ptr) {
        this.read_ptr = read_ptr;
    }

    public short getWrite_ptr() {

        return write_ptr;
    }

    public void setWrite_ptr(short write_ptr) {
        this.write_ptr = write_ptr;
    }

    public short getEmpty_cnt() {

        return empty_cnt;
    }

    public void setEmpty_cnt(short empty_cnt) {
        this.empty_cnt = empty_cnt;
    }

    public int getTotal_size() {

        return total_size;
    }

    public void setTotal_size(int total_size) {
        this.total_size = total_size;
    }

    @Override
    public String toString() {
        return "ODBDNCDGN2{" +
                "ctrl_word=" + ctrl_word +
                ", can_word=" + can_word +
                ", nc_file=" + Arrays.toString(nc_file) +
                ", read_ptr=" + read_ptr +
                ", write_ptr=" + write_ptr +
                ", empty_cnt=" + empty_cnt +
                ", total_size=" + total_size +
                '}';
    }
}
