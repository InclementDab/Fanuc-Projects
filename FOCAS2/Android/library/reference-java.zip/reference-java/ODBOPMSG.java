package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBOPMSG {
    private short msg_kind;
    private char msg[];

    public short getMsg_kind() {
        return msg_kind;
    }

    public void setMsg_kind(short msg_kind) {
        this.msg_kind = msg_kind;
    }

    public char[] getMsg() {
        return msg;
    }

    public void setMsg(char[] msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "ODBOPMSG{" +
                "msg_kind=" + msg_kind +
                ", msg=" + Arrays.toString(msg) +
                '}';
    }
}
