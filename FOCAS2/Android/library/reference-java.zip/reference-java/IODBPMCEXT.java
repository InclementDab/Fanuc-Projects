package jp.co.fanuc.fwlibe1;


import java.nio.ByteBuffer;

public class IODBPMCEXT {
    private short type_a;
    private short type_d;
    private short datano_s;
    private short datano_e;
    private short err_code;
    private short reserved;
    private ByteBuffer data;

    public short getType_a() {
        return type_a;
    }

    public void setType_a(short type_a) {
        this.type_a = type_a;
    }

    public short getType_d() {
        return type_d;
    }

    public void setType_d(short type_d) {
        this.type_d = type_d;
    }

    public short getDatano_s() {
        return datano_s;
    }

    public void setDatano_s(short datano_s) {
        this.datano_s = datano_s;
    }

    public short getDatano_e() {
        return datano_e;
    }

    public void setDatano_e(short datano_e) {
        this.datano_e = datano_e;
    }

    public short getErr_code() {
        return err_code;
    }

    public void setErr_code(short err_code) {
        this.err_code = err_code;
    }

    public short getReserved() {
        return reserved;
    }

    public void setReserved(short reserved) {
        this.reserved = reserved;
    }

    public ByteBuffer getData() {
        return data;
    }

    public void setData(ByteBuffer data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBPMCEXT{" +
                "type_a=" + type_a +
                ", type_d=" + type_d +
                ", datano_s=" + datano_s +
                ", datano_e=" + datano_e +
                ", err_code=" + err_code +
                ", reserved=" + reserved +
                ", data=" + data +
                '}';
    }
}
