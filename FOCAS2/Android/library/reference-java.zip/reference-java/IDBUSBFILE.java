package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBUSBFILE {
    private char             path[];
    private int    offset;
    private short            req_num;
    private short   req_attrib;
    private char             sort;
    private char             req_comment;
    private char			 req_total;
    private char			 dummy;

    public char[] getPath() {
        return path;
    }

    public void setPath(char[] path) {
        this.path = path;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public short getReq_num() {
        return req_num;
    }

    public void setReq_num(short req_num) {
        this.req_num = req_num;
    }

    public short getReq_attrib() {
        return req_attrib;
    }

    public void setReq_attrib(short req_attrib) {
        this.req_attrib = req_attrib;
    }

    public char getSort() {
        return sort;
    }

    public void setSort(char sort) {
        this.sort = sort;
    }

    public char getReq_comment() {
        return req_comment;
    }

    public void setReq_comment(char req_comment) {
        this.req_comment = req_comment;
    }

    public char getReq_total() {
        return req_total;
    }

    public void setReq_total(char req_total) {
        this.req_total = req_total;
    }

    public char getDummy() {
        return dummy;
    }

    public void setDummy(char dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "IDBUSBFILE{" +
                "path=" + Arrays.toString(path) +
                ", offset=" + offset +
                ", req_num=" + req_num +
                ", req_attrib=" + req_attrib +
                ", sort=" + sort +
                ", req_comment=" + req_comment +
                ", req_total=" + req_total +
                ", dummy=" + dummy +
                '}';
    }
}
