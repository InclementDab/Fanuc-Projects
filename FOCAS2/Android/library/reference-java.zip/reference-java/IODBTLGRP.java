package jp.co.fanuc.fwlibe1;


public class IODBTLGRP {
    private int ntool;
    private int nfree;
    private int life;
    private int count;
    private int use_tool;
    private int opt_grpno;
    private int life_rest;
    private short rest_sig;
    private short count_type;

    public int getNtool() {
        return ntool;
    }

    public void setNtool(int ntool) {
        this.ntool = ntool;
    }

    public int getNfree() {

        return nfree;
    }

    public void setNfree(int nfree) {
        this.nfree = nfree;
    }

    public int getLife() {

        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }

    public int getCount() {

        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getUse_tool() {

        return use_tool;
    }

    public void setUse_tool(int use_tool) {
        this.use_tool = use_tool;
    }

    public int getOpt_grpno() {

        return opt_grpno;
    }

    public void setOpt_grpno(int opt_grpno) {
        this.opt_grpno = opt_grpno;
    }

    public int getLife_rest() {

        return life_rest;
    }

    public void setLife_rest(int life_rest) {
        this.life_rest = life_rest;
    }

    public short getRest_sig() {

        return rest_sig;
    }

    public void setRest_sig(short rest_sig) {
        this.rest_sig = rest_sig;
    }

    public short getCount_type() {

        return count_type;
    }

    public void setCount_type(short count_type) {
        this.count_type = count_type;
    }

    @Override
    public String toString() {
        return "IODBTLGRP{" +
                "ntool=" + ntool +
                ", nfree=" + nfree +
                ", life=" + life +
                ", count=" + count +
                ", use_tool=" + use_tool +
                ", opt_grpno=" + opt_grpno +
                ", life_rest=" + life_rest +
                ", rest_sig=" + rest_sig +
                ", count_type=" + count_type +
                '}';
    }
}
