package jp.co.fanuc.fwlibe1;


public class ODBEMBEDFINF {
    private int used_page;
    private int all_page;

    public int getUsed_page() {
        return used_page;
    }

    public void setUsed_page(int used_page) {
        this.used_page = used_page;
    }

    public int getAll_page() {

        return all_page;
    }

    public void setAll_page(int all_page) {
        this.all_page = all_page;
    }

    @Override
    public String toString() {
        return "ODBEMBEDFINF{" +
                "used_page=" + used_page +
                ", all_page=" + all_page +
                '}';
    }
}
