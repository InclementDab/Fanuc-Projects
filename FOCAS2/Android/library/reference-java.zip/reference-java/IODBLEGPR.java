package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBLEGPR {
    private short slct;
    private short power;
    private short freq;
    private short duty;
    private short reserve[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getPower() {
        return power;
    }

    public void setPower(short power) {
        this.power = power;
    }

    public short getFreq() {
        return freq;
    }

    public void setFreq(short freq) {
        this.freq = freq;
    }

    public short getDuty() {
        return duty;
    }

    public void setDuty(short duty) {
        this.duty = duty;
    }

    public short[] getReserve() {
        return reserve;
    }

    public void setReserve(short[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBLEGPR{" +
                "slct=" + slct +
                ", power=" + power +
                ", freq=" + freq +
                ", duty=" + duty +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
