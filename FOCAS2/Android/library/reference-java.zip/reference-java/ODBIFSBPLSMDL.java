package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBPLSMDL {
    private short slave_num;
    private char name[];
    private char type[];
    private short pcd_id;
    private char info[];

    public short getSlave_num() {
        return slave_num;
    }

    public void setSlave_num(short slave_num) {
        this.slave_num = slave_num;
    }

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public char[] getType() {
        return type;
    }

    public void setType(char[] type) {
        this.type = type;
    }

    public short getPcd_id() {
        return pcd_id;
    }

    public void setPcd_id(short pcd_id) {
        this.pcd_id = pcd_id;
    }

    public char[] getInfo() {
        return info;
    }

    public void setInfo(char[] info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "ODBIFSBPLSMDL{" +
                "slave_num=" + slave_num +
                ", name=" + Arrays.toString(name) +
                ", type=" + Arrays.toString(type) +
                ", pcd_id=" + pcd_id +
                ", info=" + Arrays.toString(info) +
                '}';
    }
}
