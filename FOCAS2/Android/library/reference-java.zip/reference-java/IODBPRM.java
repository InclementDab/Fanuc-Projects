package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBPRM {
    private int datano;
    private short type;
    private short axis;
    private short info;
    private short unit;
    private DATA data[];

    public int getDatano() {
        return datano;
    }

    public void setDatano(int datano) {
        this.datano = datano;
    }

    public short getType() {

        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getAxis() {

        return axis;
    }

    public void setAxis(short axis) {
        this.axis = axis;
    }

    public short getInfo() {

        return info;
    }

    public void setInfo(short info) {
        this.info = info;
    }

    public short getUnit() {

        return unit;
    }

    public void setUnit(short unit) {
        this.unit = unit;
    }

    public static class DATA {
        private int prm_val;
        private int dec_val;

        public int getPrm_val() {
            return prm_val;
        }

        public void setPrm_val(int prm_val) {
            this.prm_val = prm_val;
        }

        public int getDec_val() {

            return dec_val;
        }

        public void setDec_val(int dec_val) {
            this.dec_val = dec_val;
        }

        @Override
        public String toString() {
            return "DATA{" +
                    "prm_val=" + prm_val +
                    ", dec_val=" + dec_val +
                    '}';
        }
    }

    public DATA[] getData() {
        return data;
    }

    public void setData(DATA[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBPRM{" +
                "datano=" + datano +
                ", type=" + type +
                ", axis=" + axis +
                ", info=" + info +
                ", unit=" + unit +
                ", data=" + Arrays.toString(data) +
                '}';
    }

    public void Dispose() {
        data = null;
    }
}
