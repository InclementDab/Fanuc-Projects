package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBCSVID2 {
    private String   mt_spc;
    private String   mt_srn;
    private String   plc_spc;
    private String   plc_srn;
    private String   svm_spc;
    private String   svm_srn;
    private String   psm_spc;
    private String   psm_srn;
    private String   svs_see;
    private String   pss_see;
    private String   pm1_spc;
    private String   pm1_srn;
    private String   pm2_spc;
    private String   pm2_srn;

    public String getMt_spc() {
        return mt_spc;
    }

    public void setMt_spc(String mt_spc) {
        this.mt_spc = mt_spc;
    }

    public String getMt_srn() {
        return mt_srn;
    }

    public void setMt_srn(String mt_srn) {
        this.mt_srn = mt_srn;
    }

    public String getPlc_spc() {
        return plc_spc;
    }

    public void setPlc_spc(String plc_spc) {
        this.plc_spc = plc_spc;
    }

    public String getPlc_srn() {
        return plc_srn;
    }

    public void setPlc_srn(String plc_srn) {
        this.plc_srn = plc_srn;
    }

    public String getSvm_spc() {
        return svm_spc;
    }

    public void setSvm_spc(String svm_spc) {
        this.svm_spc = svm_spc;
    }

    public String getSvm_srn() {
        return svm_srn;
    }

    public void setSvm_srn(String svm_srn) {
        this.svm_srn = svm_srn;
    }

    public String getPsm_spc() {
        return psm_spc;
    }

    public void setPsm_spc(String psm_spc) {
        this.psm_spc = psm_spc;
    }

    public String getPsm_srn() {
        return psm_srn;
    }

    public void setPsm_srn(String psm_srn) {
        this.psm_srn = psm_srn;
    }

    public String getSvs_see() {
        return svs_see;
    }

    public void setSvs_see(String svs_see) {
        this.svs_see = svs_see;
    }

    public String getPss_see() {
        return pss_see;
    }

    public void setPss_see(String pss_see) {
        this.pss_see = pss_see;
    }

    public String getPm1_spc() {
        return pm1_spc;
    }

    public void setPm1_spc(String pm1_spc) {
        this.pm1_spc = pm1_spc;
    }

    public String getPm1_srn() {
        return pm1_srn;
    }

    public void setPm1_srn(String pm1_srn) {
        this.pm1_srn = pm1_srn;
    }

    public String getPm2_spc() {
        return pm2_spc;
    }

    public void setPm2_spc(String pm2_spc) {
        this.pm2_spc = pm2_spc;
    }

    public String getPm2_srn() {
        return pm2_srn;
    }

    public void setPm2_srn(String pm2_srn) {
        this.pm2_srn = pm2_srn;
    }

    @Override
    public String toString() {
        return "ODBCSVID2{" +
                "mt_spc=" + mt_spc +
                ", mt_srn=" + mt_srn +
                ", plc_spc=" + plc_spc +
                ", plc_srn=" + plc_srn +
                ", svm_spc=" + svm_spc +
                ", svm_srn=" + svm_srn +
                ", psm_spc=" + psm_spc +
                ", psm_srn=" + psm_srn +
                ", svs_see=" + svs_see +
                ", pss_see=" + pss_see +
                ", pm1_spc=" + pm1_spc +
                ", pm1_srn=" + pm1_srn +
                ", pm2_spc=" + pm2_spc +
                ", pm2_srn=" + pm2_srn +
                '}';
    }
}
