package jp.co.fanuc.fwlibe1;


public class IODBWAITMCODE {
    private int mcode;
    private int pathnum;

    public int getMcode() {
        return mcode;
    }

    public void setMcode(int mcode) {
        this.mcode = mcode;
    }

    public int getPathnum() {
        return pathnum;
    }

    public void setPathnum(int pathnum) {
        this.pathnum = pathnum;
    }

    @Override
    public String toString() {
        return "IODBWAITMCODE{" +
                "mcode=" + mcode +
                ", pathnum=" + pathnum +
                '}';
    }
}
