package jp.co.fanuc.fwlibe1;


public class IDBSFBCHAN {
    private char chno;
    private char axis;
    private short shift;

    public char getChno() {
        return chno;
    }

    public void setChno(char chno) {
        this.chno = chno;
    }

    public char getAxis() {
        return axis;
    }

    public void setAxis(char axis) {
        this.axis = axis;
    }

    public short getShift() {
        return shift;
    }

    public void setShift(short shift) {
        this.shift = shift;
    }

    @Override
    public String toString() {
        return "IDBSFBCHAN{" +
                "chno=" + chno +
                ", axis=" + axis +
                ", shift=" + shift +
                '}';
    }
}
