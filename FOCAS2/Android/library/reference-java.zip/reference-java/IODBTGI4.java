package jp.co.fanuc.fwlibe1;


public class IODBTGI4 {
    private short grp_no;
    private int n_tool;
    private int count_value;
    private int counter;
    private int count_type;
    private int opt_grpno;
    private int life_rest;

    public short getGrp_no() {
        return grp_no;
    }

    public void setGrp_no(short grp_no) {
        this.grp_no = grp_no;
    }

    public int getN_tool() {

        return n_tool;
    }

    public void setN_tool(int n_tool) {
        this.n_tool = n_tool;
    }

    public int getCount_value() {

        return count_value;
    }

    public void setCount_value(int count_value) {
        this.count_value = count_value;
    }

    public int getCounter() {

        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    public int getCount_type() {

        return count_type;
    }

    public void setCount_type(int count_type) {
        this.count_type = count_type;
    }

    public int getOpt_grpno() {

        return opt_grpno;
    }

    public void setOpt_grpno(int opt_grpno) {
        this.opt_grpno = opt_grpno;
    }

    public int getLife_rest() {

        return life_rest;
    }

    public void setLife_rest(int life_rest) {
        this.life_rest = life_rest;
    }

    @Override
    public String toString() {
        return "IODBTGI4{" +
                "grp_no=" + grp_no +
                ", n_tool=" + n_tool +
                ", count_value=" + count_value +
                ", counter=" + counter +
                ", count_type=" + count_type +
                ", opt_grpno=" + opt_grpno +
                ", life_rest=" + life_rest +
                '}';
    }
}
