package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBLALMHIS {
    private short s_no;
    private short e_no;

    public short getS_no() {
        return s_no;
    }

    public void setS_no(short s_no) {
        this.s_no = s_no;
    }

    public short getE_no() {
        return e_no;
    }

    public void setE_no(short e_no) {
        this.e_no = e_no;
    }
    public static class ALM_HIS {
        private short   lalm_wrg ;
        private short   alm_grp;
        private short   alm_wrg_no ;
        private short   year ;
        private short   month ;
        private short   day ;
        private short   hour ;
        private short   minute ;
        private short   second ;
        private short   len_msg ;
        private char    alm_msg[] ;
        private short   reserve[] ;

        public short getLalm_wrg() {
            return lalm_wrg;
        }

        public void setLalm_wrg(short lalm_wrg) {
            this.lalm_wrg = lalm_wrg;
        }

        public short getAlm_grp() {
            return alm_grp;
        }

        public void setAlm_grp(short alm_grp) {
            this.alm_grp = alm_grp;
        }

        public short getAlm_wrg_no() {
            return alm_wrg_no;
        }

        public void setAlm_wrg_no(short alm_wrg_no) {
            this.alm_wrg_no = alm_wrg_no;
        }

        public short getYear() {
            return year;
        }

        public void setYear(short year) {
            this.year = year;
        }

        public short getMonth() {
            return month;
        }

        public void setMonth(short month) {
            this.month = month;
        }

        public short getDay() {
            return day;
        }

        public void setDay(short day) {
            this.day = day;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getLen_msg() {
            return len_msg;
        }

        public void setLen_msg(short len_msg) {
            this.len_msg = len_msg;
        }

        public char[] getAlm_msg() {
            return alm_msg;
        }

        public void setAlm_msg(char[] alm_msg) {
            this.alm_msg = alm_msg;
        }

        public short[] getReserve() {
            return reserve;
        }

        public void setReserve(short[] reserve) {
            this.reserve = reserve;
        }

        @Override
        public String toString() {
            return "ALM_HIS{" +
                    "lalm_wrg=" + lalm_wrg +
                    ", alm_grp=" + alm_grp +
                    ", alm_wrg_no=" + alm_wrg_no +
                    ", year=" + year +
                    ", month=" + month +
                    ", day=" + day +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", len_msg=" + len_msg +
                    ", alm_msg=" + Arrays.toString(alm_msg) +
                    ", reserve=" + Arrays.toString(reserve) +
                    '}';
        }
    }
    private ALM_HIS alm_his[];

    public ALM_HIS[] getAlm_his() {
        return alm_his;
    }

    public void setAlm_his(ALM_HIS[] alm_his) {
        this.alm_his = alm_his;
    }

    @Override
    public String toString() {
        return "ODBLALMHIS{" +
                "s_no=" + s_no +
                ", e_no=" + e_no +
                ", alm_his=" + Arrays.toString(alm_his) +
                '}';
    }
}
