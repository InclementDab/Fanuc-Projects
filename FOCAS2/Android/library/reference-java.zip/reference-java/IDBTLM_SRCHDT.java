package jp.co.fanuc.fwlibe1;


public class IDBTLM_SRCHDT {
    private IDBTLM id_info;
    private short srch_cond;
    private  short add_cond;

    public IDBTLM getId_info() {
        return id_info;
    }

    public void setId_info(IDBTLM id_info) {
        this.id_info = id_info;
    }

    public short getSrch_cond() {
        return srch_cond;
    }

    public void setSrch_cond(short srch_cond) {
        this.srch_cond = srch_cond;
    }

    public short getAdd_cond() {
        return add_cond;
    }

    public void setAdd_cond(short add_cond) {
        this.add_cond = add_cond;
    }

    @Override
    public String toString() {
        return "IDBTLM_SRCHDT{" +
                "id_info=" + id_info +
                ", srch_cond=" + srch_cond +
                ", add_cond=" + add_cond +
                '}';
    }
}
