package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBLACTN {
    private short slct;
    private short act_proc;
    private short act_pirce;
    private short act_slop;
    private short reserve[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getAct_proc() {
        return act_proc;
    }

    public void setAct_proc(short act_proc) {
        this.act_proc = act_proc;
    }

    public short getAct_pirce() {
        return act_pirce;
    }

    public void setAct_pirce(short act_pirce) {
        this.act_pirce = act_pirce;
    }

    public short getAct_slop() {
        return act_slop;
    }

    public void setAct_slop(short act_slop) {
        this.act_slop = act_slop;
    }

    public short[] getReserve() {
        return reserve;
    }

    public void setReserve(short[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "ODBLACTN{" +
                "slct=" + slct +
                ", act_proc=" + act_proc +
                ", act_pirce=" + act_pirce +
                ", act_slop=" + act_slop +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
