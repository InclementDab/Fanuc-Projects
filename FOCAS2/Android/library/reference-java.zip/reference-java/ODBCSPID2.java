package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBCSPID2 {
    private String   mt_spc;
    private String   mt_srn;
    private String   sbmt_spc;
    private String   sbmt_srn;
    private String   spm_spc;
    private String   spm_srn;
    private String   psm_spc;
    private String   psm_srn;
    private String   pss_see;

    public String getMt_spc() {
        return mt_spc;
    }

    public void setMt_spc(String mt_spc) {
        this.mt_spc = mt_spc;
    }

    public String getMt_srn() {
        return mt_srn;
    }

    public void setMt_srn(String mt_srn) {
        this.mt_srn = mt_srn;
    }

    public String getSbmt_spc() {
        return sbmt_spc;
    }

    public void setSbmt_spc(String sbmt_spc) {
        this.sbmt_spc = sbmt_spc;
    }

    public String getSbmt_srn() {
        return sbmt_srn;
    }

    public void setSbmt_srn(String sbmt_srn) {
        this.sbmt_srn = sbmt_srn;
    }

    public String getSpm_spc() {
        return spm_spc;
    }

    public void setSpm_spc(String spm_spc) {
        this.spm_spc = spm_spc;
    }

    public String getSpm_srn() {
        return spm_srn;
    }

    public void setSpm_srn(String spm_srn) {
        this.spm_srn = spm_srn;
    }

    public String getPsm_spc() {
        return psm_spc;
    }

    public void setPsm_spc(String psm_spc) {
        this.psm_spc = psm_spc;
    }

    public String getPsm_srn() {
        return psm_srn;
    }

    public void setPsm_srn(String psm_srn) {
        this.psm_srn = psm_srn;
    }

    public String getPss_see() {
        return pss_see;
    }

    public void setPss_see(String pss_see) {
        this.pss_see = pss_see;
    }

    @Override
    public String toString() {
        return "ODBCSPID2{" +
                "mt_spc=" + mt_spc +
                ", mt_srn=" + mt_srn +
                ", sbmt_spc=" + sbmt_spc +
                ", sbmt_srn=" + sbmt_srn +
                ", spm_spc=" + spm_spc +
                ", spm_srn=" + spm_srn +
                ", psm_spc=" + psm_spc +
                ", psm_srn=" + psm_srn +
                ", pss_see=" + pss_see +
                '}';
    }
}

