package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBPR {
    private int datano_s;
    private short dummy;
    private int datano_e;

    public int getDatano_s() {
        return datano_s;
    }

    public void setDatano_s(int datano_s) {
        this.datano_s = datano_s;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public int getDatano_e() {

        return datano_e;
    }

    public void setDatano_e(int datano_e) {
        this.datano_e = datano_e;
    }

    public static class DATA {
        private int mcr_val;
        private short dec_val;

        public int getMcr_val() {
            return mcr_val;
        }

        public void setMcr_val(int mcr_val) {
            this.mcr_val = mcr_val;
        }

        public short getDec_val() {

            return dec_val;
        }

        public void setDec_val(short dec_val) {
            this.dec_val = dec_val;
        }

        @Override
        public String toString() {
            return "DATA{" +
                    "mcr_val=" + mcr_val +
                    ", dec_val=" + dec_val +
                    '}';
        }
    }
    private DATA data[];

    public DATA[] getData() {
        return data;
    }

    public void setData(DATA[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBPR{" +
                "datano_s=" + datano_s +
                ", dummy=" + dummy +
                ", datano_e=" + datano_e +
                ", data=" + Arrays.toString(data) +
                '}';
    }

    public void Dispose() {
        data = null;
    }
}
