package jp.co.fanuc.fwlibe1;


public class ODBMSUYTERM {
    private short data;
    private short dummy;

    public short getData() {
        return data;
    }

    public void setData(short data) {
        this.data = data;
    }

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "ODBMSUYTERM{" +
                "data=" + data +
                ", dummy=" + dummy +
                '}';
    }
}
