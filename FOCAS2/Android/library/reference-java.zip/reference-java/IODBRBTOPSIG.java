package jp.co.fanuc.fwlibe1;


public class IODBRBTOPSIG {
    private char unit_type;
    private char adr_type;
    private short address;

    public char getUnit_type() {
        return unit_type;
    }

    public void setUnit_type(char unit_type) {
        this.unit_type = unit_type;
    }

    public char getAdr_type() {
        return adr_type;
    }

    public void setAdr_type(char adr_type) {
        this.adr_type = adr_type;
    }

    public short getAddress() {
        return address;
    }

    public void setAddress(short address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "IODBRBTOPSIG{" +
                "unit_type=" + unit_type +
                ", adr_type=" + adr_type +
                ", address=" + address +
                '}';
    }
}
