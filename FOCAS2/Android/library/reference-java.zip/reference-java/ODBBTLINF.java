package jp.co.fanuc.fwlibe1;


public class ODBBTLINF {
    private short ofs_type;
    private short use_no;
    private short sub_no;

    public short getOfs_type() {
        return ofs_type;
    }

    public void setOfs_type(short ofs_type) {
        this.ofs_type = ofs_type;
    }

    public short getUse_no() {
        return use_no;
    }

    public void setUse_no(short use_no) {
        this.use_no = use_no;
    }

    public short getSub_no() {
        return sub_no;
    }

    public void setSub_no(short sub_no) {
        this.sub_no = sub_no;
    }

    @Override
    public String toString() {
        return "ODBBTLINF{" +
                "ofs_type=" + ofs_type +
                ", use_no=" + use_no +
                ", sub_no=" + sub_no +
                '}';
    }
}
