package jp.co.fanuc.fwlibe1;


public class ODBMDIPO8 {
    private int mdiprog;
    private int mdipntr;
    private int crntprog;
    private int crntpntr;

    public int getMdiprog() {
        return mdiprog;
    }

    public void setMdiprog(int mdiprog) {
        this.mdiprog = mdiprog;
    }

    public int getMdipntr() {
        return mdipntr;
    }

    public void setMdipntr(int mdipntr) {
        this.mdipntr = mdipntr;
    }

    public int getCrntprog() {
        return crntprog;
    }

    public void setCrntprog(int crntprog) {
        this.crntprog = crntprog;
    }

    public int getCrntpntr() {
        return crntpntr;
    }

    public void setCrntpntr(int crntpntr) {
        this.crntpntr = crntpntr;
    }

    @Override
    public String toString() {
        return "ODBMDIPO8{" +
                "mdiprog=" + mdiprog +
                ", mdipntr=" + mdipntr +
                ", crntprog=" + crntprog +
                ", crntpntr=" + crntpntr +
                '}';
    }
}
