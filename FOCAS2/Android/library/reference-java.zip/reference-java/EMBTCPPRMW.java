package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class EMBTCPPRMW {
    private char IPAddress[];
    private char SubNetMask[];
    private char RouterIPAddress[];

    public char[] getIPAddress() {
        return IPAddress;
    }

    public void setIPAddress(char[] IPAddress) {
        this.IPAddress = IPAddress;
    }

    public char[] getSubNetMask() {
        return SubNetMask;
    }

    public void setSubNetMask(char[] subNetMask) {
        SubNetMask = subNetMask;
    }

    public char[] getRouterIPAddress() {
        return RouterIPAddress;
    }

    public void setRouterIPAddress(char[] routerIPAddress) {
        RouterIPAddress = routerIPAddress;
    }

    @Override
    public String toString() {
        return "EMBTCPPRMW{" +
                "IPAddress=" + Arrays.toString(IPAddress) +
                ", SubNetMask=" + Arrays.toString(SubNetMask) +
                ", RouterIPAddress=" + Arrays.toString(RouterIPAddress) +
                '}';
    }
}
