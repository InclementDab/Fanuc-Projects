package jp.co.fanuc.fwlibe1;


public class ODBDCSFMONI {
    private int data_d;
    private int data_p;

    public int getData_d() {
        return data_d;
    }

    public void setData_d(int data_d) {
        this.data_d = data_d;
    }

    public int getData_p() {
        return data_p;
    }

    public void setData_p(int data_p) {
        this.data_p = data_p;
    }

    @Override
    public String toString() {
        return "ODBDCSFMONI{" +
                "data_d=" + data_d +
                ", data_p=" + data_p +
                '}';
    }
}
