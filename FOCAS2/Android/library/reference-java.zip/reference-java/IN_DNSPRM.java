package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_DNSPRM {
    private short           BaudRate;
    private short           DiDataOnAbnormal;
    private short           OwnMacId;
    private char            pad1[];
    private PMC_REG         Di;
    private short           DiSize;
    private char            pad2[];
    private PMC_REG         Do;
    private short           DoSize;
    private char            pad3[];
    private PMC_REG         Status;
    private short           StatusSize;
    private char            pad4[];

    public short getBaudRate() {
        return BaudRate;
    }

    public void setBaudRate(short baudRate) {
        BaudRate = baudRate;
    }

    public short getDiDataOnAbnormal() {
        return DiDataOnAbnormal;
    }

    public void setDiDataOnAbnormal(short diDataOnAbnormal) {
        DiDataOnAbnormal = diDataOnAbnormal;
    }

    public short getOwnMacId() {
        return OwnMacId;
    }

    public void setOwnMacId(short ownMacId) {
        OwnMacId = ownMacId;
    }

    public char[] getPad1() {
        return pad1;
    }

    public void setPad1(char[] pad1) {
        this.pad1 = pad1;
    }

    public PMC_REG getDi() {
        return Di;
    }

    public void setDi(PMC_REG di) {
        Di = di;
    }

    public short getDiSize() {
        return DiSize;
    }

    public void setDiSize(short diSize) {
        DiSize = diSize;
    }

    public char[] getPad2() {
        return pad2;
    }

    public void setPad2(char[] pad2) {
        this.pad2 = pad2;
    }

    public PMC_REG getDo() {
        return Do;
    }

    public void setDo(PMC_REG aDo) {
        Do = aDo;
    }

    public short getDoSize() {
        return DoSize;
    }

    public void setDoSize(short doSize) {
        DoSize = doSize;
    }

    public char[] getPad3() {
        return pad3;
    }

    public void setPad3(char[] pad3) {
        this.pad3 = pad3;
    }

    public PMC_REG getStatus() {
        return Status;
    }

    public void setStatus(PMC_REG status) {
        Status = status;
    }

    public short getStatusSize() {
        return StatusSize;
    }

    public void setStatusSize(short statusSize) {
        StatusSize = statusSize;
    }

    public char[] getPad4() {
        return pad4;
    }

    public void setPad4(char[] pad4) {
        this.pad4 = pad4;
    }

    @Override
    public String toString() {
        return "IN_DNSPRM{" +
                "BaudRate=" + BaudRate +
                ", DiDataOnAbnormal=" + DiDataOnAbnormal +
                ", OwnMacId=" + OwnMacId +
                ", pad1=" + Arrays.toString(pad1) +
                ", Di=" + Di +
                ", DiSize=" + DiSize +
                ", pad2=" + Arrays.toString(pad2) +
                ", Do=" + Do +
                ", DoSize=" + DoSize +
                ", pad3=" + Arrays.toString(pad3) +
                ", Status=" + Status +
                ", StatusSize=" + StatusSize +
                ", pad4=" + Arrays.toString(pad4) +
                '}';
    }
}
