package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBNESTPDF {
    private int attrib;
    private char comment[];
    private char prog_name[];
    private char dummy[];

    public int getAttrib() {
        return attrib;
    }

    public void setAttrib(int attrib) {
        this.attrib = attrib;
    }

    public char[] getComment() {

        return comment;
    }

    public void setComment(char[] comment) {
        this.comment = comment;
    }

    public char[] getProg_name() {

        return prog_name;
    }

    public void setProg_name(char[] prog_name) {
        this.prog_name = prog_name;
    }

    public char[] getDummy() {

        return dummy;
    }

    public void setDummy(char[] dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "ODBNESTPDF{" +
                "attrib=" + attrib +
                ", comment=" + Arrays.toString(comment) +
                ", prog_name=" + Arrays.toString(prog_name) +
                ", dummy=" + Arrays.toString(dummy) +
                '}';
    }
}
