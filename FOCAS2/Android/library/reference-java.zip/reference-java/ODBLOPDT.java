package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBLOPDT {
    private short slct;
    private short pwr_mon;
    private short pwr_ofs;
    private short pwr_act;
    private int feed_act;
    private char feed_dec;
    private char reserve;
    private short reserves[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getPwr_mon() {
        return pwr_mon;
    }

    public void setPwr_mon(short pwr_mon) {
        this.pwr_mon = pwr_mon;
    }

    public short getPwr_ofs() {
        return pwr_ofs;
    }

    public void setPwr_ofs(short pwr_ofs) {
        this.pwr_ofs = pwr_ofs;
    }

    public short getPwr_act() {
        return pwr_act;
    }

    public void setPwr_act(short pwr_act) {
        this.pwr_act = pwr_act;
    }

    public int getFeed_act() {
        return feed_act;
    }

    public void setFeed_act(int feed_act) {
        this.feed_act = feed_act;
    }

    public char getFeed_dec() {
        return feed_dec;
    }

    public void setFeed_dec(char feed_dec) {
        this.feed_dec = feed_dec;
    }

    public char getReserve() {
        return reserve;
    }

    public void setReserve(char reserve) {
        this.reserve = reserve;
    }

    public short[] getReserves() {
        return reserves;
    }

    public void setReserves(short[] reserves) {
        this.reserves = reserves;
    }

    @Override
    public String toString() {
        return "ODBLOPDT{" +
                "slct=" + slct +
                ", pwr_mon=" + pwr_mon +
                ", pwr_ofs=" + pwr_ofs +
                ", pwr_act=" + pwr_act +
                ", feed_act=" + feed_act +
                ", feed_dec=" + feed_dec +
                ", reserve=" + reserve +
                ", reserves=" + Arrays.toString(reserves) +
                '}';
    }
}
