package jp.co.fanuc.fwlibe1;


public class ODBEXGP {
    private int grp_no;
    private int opt_grpno;

    public int getGrp_no() {
        return grp_no;
    }

    public void setGrp_no(int grp_no) {
        this.grp_no = grp_no;
    }

    public int getOpt_grpno() {

        return opt_grpno;
    }

    public void setOpt_grpno(int opt_grpno) {
        this.opt_grpno = opt_grpno;
    }

    @Override
    public String toString() {
        return "ODBEXGP{" +
                "grp_no=" + grp_no +
                ", opt_grpno=" + opt_grpno +
                '}';
    }
}
