package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBLPPFBDT {
    private short ppower;
    private short dummy;
    private short freq[];
    private short duty[];
    private short rpower[][];

    public short getPpower() {
        return ppower;
    }

    public void setPpower(short ppower) {
        this.ppower = ppower;
    }

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public short[] getFreq() {
        return freq;
    }

    public void setFreq(short[] freq) {
        this.freq = freq;
    }

    public short[] getDuty() {
        return duty;
    }

    public void setDuty(short[] duty) {
        this.duty = duty;
    }

    public short[][] getRpower() {
        return rpower;
    }

    public void setRpower(short[][] rpower) {
        this.rpower = rpower;
    }

    @Override
    public String toString() {
        return "IODBLPPFBDT{" +
                "ppower=" + ppower +
                ", dummy=" + dummy +
                ", freq=" + Arrays.toString(freq) +
                ", duty=" + Arrays.toString(duty) +
                ", rpower=" + Arrays.toString(rpower) +
                '}';
    }
}
