package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTOOL_CAUSENME {
    private char cause1[];
    private char cause2[];
    private char cause3[];
    private char cause4[];
    private char cause5[];

    public char[] getCause1() {
        return cause1;
    }

    public void setCause1(char[] cause1) {
        this.cause1 = cause1;
    }

    public char[] getCause2() {
        return cause2;
    }

    public void setCause2(char[] cause2) {
        this.cause2 = cause2;
    }

    public char[] getCause3() {
        return cause3;
    }

    public void setCause3(char[] cause3) {
        this.cause3 = cause3;
    }

    public char[] getCause4() {
        return cause4;
    }

    public void setCause4(char[] cause4) {
        this.cause4 = cause4;
    }

    public char[] getCause5() {
        return cause5;
    }

    public void setCause5(char[] cause5) {
        this.cause5 = cause5;
    }

    @Override
    public String toString() {
        return "IODBTOOL_CAUSENME{" +
                "cause1=" + Arrays.toString(cause1) +
                ", cause2=" + Arrays.toString(cause2) +
                ", cause3=" + Arrays.toString(cause3) +
                ", cause4=" + Arrays.toString(cause4) +
                ", cause5=" + Arrays.toString(cause5) +
                '}';
    }
}
