package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBLRNINFOL {
    private char axis[];
    private char name[];
    private char comment[];
    private char path;
    private char dummy1;

    public char[] getAxis() {
        return axis;
    }

    public void setAxis(char[] axis) {
        this.axis = axis;
    }

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public char[] getComment() {
        return comment;
    }

    public void setComment(char[] comment) {
        this.comment = comment;
    }

    public char getPath() {
        return path;
    }

    public void setPath(char path) {
        this.path = path;
    }

    public char getDummy1() {
        return dummy1;
    }

    public void setDummy1(char dummy1) {
        this.dummy1 = dummy1;
    }

    @Override
    public String toString() {
        return "ODBLRNINFOL{" +
                "axis=" + Arrays.toString(axis) +
                ", name=" + Arrays.toString(name) +
                ", comment=" + Arrays.toString(comment) +
                ", path=" + path +
                ", dummy1=" + dummy1 +
                '}';
    }
}
