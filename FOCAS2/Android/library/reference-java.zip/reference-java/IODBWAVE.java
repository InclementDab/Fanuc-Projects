package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBWAVE {
    private short condition;
    private char trg_adr;
    private char trg_bit;
    private short trg_no;
    private short delay;
    private short t_range;

    public short getCondition() {
        return condition;
    }

    public void setCondition(short condition) {
        this.condition = condition;
    }

    public char getTrg_adr() {
        return trg_adr;
    }

    public void setTrg_adr(char trg_adr) {
        this.trg_adr = trg_adr;
    }

    public char getTrg_bit() {
        return trg_bit;
    }

    public void setTrg_bit(char trg_bit) {
        this.trg_bit = trg_bit;
    }

    public short getTrg_no() {
        return trg_no;
    }

    public void setTrg_no(short trg_no) {
        this.trg_no = trg_no;
    }

    public short getDelay() {
        return delay;
    }

    public void setDelay(short delay) {
        this.delay = delay;
    }

    public short getT_range() {
        return t_range;
    }

    public void setT_range(short t_range) {
        this.t_range = t_range;
    }

    public static class CH {
        private short kind;

        public short getKind() {
            return kind;
        }

        public void setKind(short kind) {
            this.kind = kind;
        }

        private int axis;

        public int getAxis() {
            return axis;
        }

        public void setAxis(int axis) {
            this.axis = axis;
        }

        public static class IO {
            private char adr;
            private char bit;
            private short no;

            public char getAdr() {
                return adr;
            }

            public void setAdr(char adr) {
                this.adr = adr;
            }

            public char getBit() {
                return bit;
            }

            public void setBit(char bit) {
                this.bit = bit;
            }

            public short getNo() {
                return no;
            }

            public void setNo(short no) {
                this.no = no;
            }

            @Override
            public String toString() {
                return "IO{" +
                        "adr=" + adr +
                        ", bit=" + bit +
                        ", no=" + no +
                        '}';
            }
        }

        private IO io;

        public IO getIo() {
            return io;
        }

        public void setIo(IO io) {
            this.io = io;
        }

        @Override
        public String toString() {
            return "CH{" +
                    "kind=" + kind +
                    ", axis=" + axis +
                    ", io=" + io +
                    '}';
        }
    }

    private CH ch[];

    public CH[] getCh() {
        return ch;
    }

    public void setCh(CH[] ch) {
        this.ch = ch;
    }

    @Override
    public String toString() {
        return "IODBWAVE{" +
                "condition=" + condition +
                ", trg_adr=" + trg_adr +
                ", trg_bit=" + trg_bit +
                ", trg_no=" + trg_no +
                ", delay=" + delay +
                ", t_range=" + t_range +
                ", ch=" + Arrays.toString(ch) +
                '}';
    }
}
