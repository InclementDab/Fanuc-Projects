package jp.co.fanuc.fwlibe1;


public class IN_EIPS_BASIC_PRM_FLG {
    private IN_EIP_COMMON_PRM_FLG Common;
    private char Option2;
    private char StatusAddr;
    private char StatusSize;
    private char pad;

    public IN_EIP_COMMON_PRM_FLG getCommon() {
        return Common;
    }

    public void setCommon(IN_EIP_COMMON_PRM_FLG common) {
        Common = common;
    }

    public char getOption2() {
        return Option2;
    }

    public void setOption2(char option2) {
        Option2 = option2;
    }

    public char getStatusAddr() {
        return StatusAddr;
    }

    public void setStatusAddr(char statusAddr) {
        StatusAddr = statusAddr;
    }

    public char getStatusSize() {
        return StatusSize;
    }

    public void setStatusSize(char statusSize) {
        StatusSize = statusSize;
    }

    public char getPad() {
        return pad;
    }

    public void setPad(char pad) {
        this.pad = pad;
    }

    @Override
    public String toString() {
        return "IN_EIPS_BASIC_PRM_FLG{" +
                "Common=" + Common +
                ", Option2=" + Option2 +
                ", StatusAddr=" + StatusAddr +
                ", StatusSize=" + StatusSize +
                ", pad=" + pad +
                '}';
    }
}
