package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_DNMPRM_BUS {
    private short           Network;
    private short           BaudRate;
    private short           DiDataOnAbnormal;
    private short           OwnMacId;
    private PMC_REG         CommonStatus;
    private short           CommonStatusSize;
    private short           CycleTimeSetting;
    private short           reserved[];

    public short getNetwork() {
        return Network;
    }

    public void setNetwork(short network) {
        Network = network;
    }

    public short getBaudRate() {
        return BaudRate;
    }

    public void setBaudRate(short baudRate) {
        BaudRate = baudRate;
    }

    public short getDiDataOnAbnormal() {
        return DiDataOnAbnormal;
    }

    public void setDiDataOnAbnormal(short diDataOnAbnormal) {
        DiDataOnAbnormal = diDataOnAbnormal;
    }

    public short getOwnMacId() {
        return OwnMacId;
    }

    public void setOwnMacId(short ownMacId) {
        OwnMacId = ownMacId;
    }

    public PMC_REG getCommonStatus() {
        return CommonStatus;
    }

    public void setCommonStatus(PMC_REG commonStatus) {
        CommonStatus = commonStatus;
    }

    public short getCommonStatusSize() {
        return CommonStatusSize;
    }

    public void setCommonStatusSize(short commonStatusSize) {
        CommonStatusSize = commonStatusSize;
    }

    public short getCycleTimeSetting() {
        return CycleTimeSetting;
    }

    public void setCycleTimeSetting(short cycleTimeSetting) {
        CycleTimeSetting = cycleTimeSetting;
    }

    public short[] getReserved() {
        return reserved;
    }

    public void setReserved(short[] reserved) {
        this.reserved = reserved;
    }

    @Override
    public String toString() {
        return "IN_DNMPRM_BUS{" +
                "Network=" + Network +
                ", BaudRate=" + BaudRate +
                ", DiDataOnAbnormal=" + DiDataOnAbnormal +
                ", OwnMacId=" + OwnMacId +
                ", CommonStatus=" + CommonStatus +
                ", CommonStatusSize=" + CommonStatusSize +
                ", CycleTimeSetting=" + CycleTimeSetting +
                ", reserved=" + Arrays.toString(reserved) +
                '}';
    }
}
