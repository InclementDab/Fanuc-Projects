package jp.co.fanuc.fwlibe1;


public class ODBJOGDRUN {
    private SPEEDELM jogdrun;

    public SPEEDELM getJogdrun() {
        return jogdrun;
    }

    public void setJogdrun(SPEEDELM jogdrun) {
        this.jogdrun = jogdrun;
    }

    @Override
    public String toString() {
        return "ODBJOGDRUN{" +
                "jogdrun=" + jogdrun +
                '}';
    }
}
