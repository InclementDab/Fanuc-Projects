package jp.co.fanuc.fwlibe1;


public class ODBMSUXTERM {
    private char kind;
    private char ch;
    private char atrb;
    private char dec;
    private int data;

    public char getKind() {
        return kind;
    }

    public void setKind(char kind) {
        this.kind = kind;
    }

    public char getCh() {
        return ch;
    }

    public void setCh(char ch) {
        this.ch = ch;
    }

    public char getAtrb() {
        return atrb;
    }

    public void setAtrb(char atrb) {
        this.atrb = atrb;
    }

    public char getDec() {
        return dec;
    }

    public void setDec(char dec) {
        this.dec = dec;
    }

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ODBMSUXTERM{" +
                "kind=" + kind +
                ", ch=" + ch +
                ", atrb=" + atrb +
                ", dec=" + dec +
                ", data=" + data +
                '}';
    }
}
