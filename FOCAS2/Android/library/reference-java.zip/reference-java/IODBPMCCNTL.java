package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBPMCCNTL {
    private short datano_s;
    private short dummy;
    private short datano_e;

    public short getDatano_s() {
        return datano_s;
    }

    public void setDatano_s(short datano_s) {
        this.datano_s = datano_s;
    }

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public short getDatano_e() {
        return datano_e;
    }

    public void setDatano_e(short datano_e) {
        this.datano_e = datano_e;
    }

    public static class INFO {
        private byte tbl_prm;
        private byte data_type;
        private short data_size;
        private short data_dsp;
        private short dummy;

        public byte getTbl_prm() {
            return tbl_prm;
        }

        public void setTbl_prm(byte tbl_prm) {
            this.tbl_prm = tbl_prm;
        }

        public byte getData_type() {
            return data_type;
        }

        public void setData_type(byte data_type) {
            this.data_type = data_type;
        }

        public short getData_size() {
            return data_size;
        }

        public void setData_size(short data_size) {
            this.data_size = data_size;
        }

        public short getData_dsp() {
            return data_dsp;
        }

        public void setData_dsp(short data_dsp) {
            this.data_dsp = data_dsp;
        }

        public short getDummy() {
            return dummy;
        }

        public void setDummy(short dummy) {
            this.dummy = dummy;
        }

        @Override
        public String toString() {
            return "INFO{" +
                    "tbl_prm=" + tbl_prm +
                    ", data_type=" + data_type +
                    ", data_size=" + data_size +
                    ", data_dsp=" + data_dsp +
                    ", dummy=" + dummy +
                    '}';
        }
    }
    private INFO info[];

    public INFO[] getInfo() {
        return info;
    }

    public void setInfo(INFO[] info) {
        this.info = info;
    }

    @Override
    public String toString() {
        return "IODBPMCCNTL{" +
                "datano_s=" + datano_s +
                ", dummy=" + dummy +
                ", datano_e=" + datano_e +
                ", info=" + Arrays.toString(info) +
                '}';
    }

    public void Dispose() {
        info = null;
    }

    public IODBPMCCNTL() {
        final int size = 100;
        info = new INFO[size];

        for (int i =0; i< size; i++) {
            info[i] = new INFO();
        }
    }
}
