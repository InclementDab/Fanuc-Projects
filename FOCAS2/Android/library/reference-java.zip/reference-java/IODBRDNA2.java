package jp.co.fanuc.fwlibe1;


public class IODBRDNA2 {
    private short datano;
    private short type;
    private char sgnl1_name[];
    private char sgnl2_name[];
    private char sgnl3_name[];
    private char sgnl4_name[];
    private char sgnl5_name[];
    private char sgnl6_name[];
    private char sgnl7_name[];
    private char sgnl8_name[];
    private char sgnl9_name[];
    private char sgnl10_name[];
    private char sgnl11_name[];
    private char sgnl12_name[];
    private char sgnl13_name[];
    private char sgnl14_name[];
    private char sgnl15_name[];
    private char sgnl16_name[];

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public char[] getSgnl1_name() {
        return sgnl1_name;
    }

    public void setSgnl1_name(char[] sgnl1_name) {
        this.sgnl1_name = sgnl1_name;
    }

    public char[] getSgnl2_name() {
        return sgnl2_name;
    }

    public void setSgnl2_name(char[] sgnl2_name) {
        this.sgnl2_name = sgnl2_name;
    }

    public char[] getSgnl3_name() {
        return sgnl3_name;
    }

    public void setSgnl3_name(char[] sgnl3_name) {
        this.sgnl3_name = sgnl3_name;
    }

    public char[] getSgnl4_name() {
        return sgnl4_name;
    }

    public void setSgnl4_name(char[] sgnl4_name) {
        this.sgnl4_name = sgnl4_name;
    }

    public char[] getSgnl5_name() {
        return sgnl5_name;
    }

    public void setSgnl5_name(char[] sgnl5_name) {
        this.sgnl5_name = sgnl5_name;
    }

    public char[] getSgnl6_name() {
        return sgnl6_name;
    }

    public void setSgnl6_name(char[] sgnl6_name) {
        this.sgnl6_name = sgnl6_name;
    }

    public char[] getSgnl7_name() {
        return sgnl7_name;
    }

    public void setSgnl7_name(char[] sgnl7_name) {
        this.sgnl7_name = sgnl7_name;
    }

    public char[] getSgnl8_name() {
        return sgnl8_name;
    }

    public void setSgnl8_name(char[] sgnl8_name) {
        this.sgnl8_name = sgnl8_name;
    }

    public char[] getSgnl9_name() {
        return sgnl9_name;
    }

    public void setSgnl9_name(char[] sgnl9_name) {
        this.sgnl9_name = sgnl9_name;
    }

    public char[] getSgnl10_name() {
        return sgnl10_name;
    }

    public void setSgnl10_name(char[] sgnl10_name) {
        this.sgnl10_name = sgnl10_name;
    }

    public char[] getSgnl11_name() {
        return sgnl11_name;
    }

    public void setSgnl11_name(char[] sgnl11_name) {
        this.sgnl11_name = sgnl11_name;
    }

    public char[] getSgnl12_name() {
        return sgnl12_name;
    }

    public void setSgnl12_name(char[] sgnl12_name) {
        this.sgnl12_name = sgnl12_name;
    }

    public char[] getSgnl13_name() {
        return sgnl13_name;
    }

    public void setSgnl13_name(char[] sgnl13_name) {
        this.sgnl13_name = sgnl13_name;
    }

    public char[] getSgnl14_name() {
        return sgnl14_name;
    }

    public void setSgnl14_name(char[] sgnl14_name) {
        this.sgnl14_name = sgnl14_name;
    }

    public char[] getSgnl15_name() {
        return sgnl15_name;
    }

    public void setSgnl15_name(char[] sgnl15_name) {
        this.sgnl15_name = sgnl15_name;
    }

    public char[] getSgnl16_name() {
        return sgnl16_name;
    }

    public void setSgnl16_name(char[] sgnl16_name) {
        this.sgnl16_name = sgnl16_name;
    }
}
