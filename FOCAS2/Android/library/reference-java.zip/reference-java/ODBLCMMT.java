package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBLCMMT {
    private char comment[];

    public char[] getComment() {
        return comment;
    }

    public void setComment(char[] comment) {
        this.comment = comment;
    }

    @Override
    public String toString() {
        return "ODBLCMMT{" +
                "comment=" + Arrays.toString(comment) +
                '}';
    }
}
