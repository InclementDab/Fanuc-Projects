package jp.co.fanuc.fwlibe1;

import java.util.Arrays;

public class IODBDSPLC {
    private short   slct;
    private int    dsplc;
    private short   dsplc_dec;
    private char    reserve;
    private short   reserves[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public int getDsplc() {
        return dsplc;
    }

    public void setDsplc(int dsplc) {
        this.dsplc = dsplc;
    }

    public short getDsplc_dec() {
        return dsplc_dec;
    }

    public void setDsplc_dec(short dsplc_dec) {
        this.dsplc_dec = dsplc_dec;
    }

    public char getReserve() {
        return reserve;
    }

    public void setReserve(char reserve) {
        this.reserve = reserve;
    }

    public short[] getReserves() {
        return reserves;
    }

    public void setReserves(short[] reserves) {
        this.reserves = reserves;
    }

    @Override
    public String toString() {
        return "IODBDSPLC{" +
                "slct=" + slct +
                ", dsplc=" + dsplc +
                ", dsplc_dec=" + dsplc_dec +
                ", reserve=" + reserve +
                ", reserves=" + Arrays.toString(reserves) +
                '}';
    }
}
