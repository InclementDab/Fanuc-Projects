package jp.co.fanuc.fwlibe1;


public class IODBTIME {
    private int minute;
    private int msec;

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public int getMsec() {
        return msec;
    }

    public void setMsec(int msec) {
        this.msec = msec;
    }

    @Override
    public String toString() {
        return "IODBTIME{" +
                "minute=" + minute +
                ", msec=" + msec +
                '}';
    }
}
