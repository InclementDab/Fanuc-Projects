package jp.co.fanuc.fwlibe1;

/**
 * Created by honndayu on 2016/06/30.
 */
public class IODBBOOK {
    private short param_no;
    private char axis;
    private char type;

    private char cdata;
    private short idata;
    private int ldata;
    private REALPRM rdata;

    public short getParam_no() {
        return param_no;
    }

    public void setParam_no(short param_no) {
        this.param_no = param_no;
    }

    public char getAxis() {

        return axis;
    }

    public void setAxis(char axis) {
        this.axis = axis;
    }

    public char getType() {

        return type;
    }

    public void setType(char type) {
        this.type = type;
    }


    public char getCdata() {
        return cdata;
    }

    public void setCdata(char cdata) {
        this.cdata = cdata;
    }

    public short getIdata() {

        return idata;
    }

    public void setIdata(short idata) {
        this.idata = idata;
    }

    public int getLdata() {

        return ldata;
    }

    public void setLdata(int ldata) {
        this.ldata = ldata;
    }

    public REALPRM getRdata() {

        return rdata;
    }

    public void setRdata(REALPRM rdata) {
        this.rdata = rdata;
    }

    @Override
    public String toString() {
        return "IODBBOOK{" +
                "param_no=" + param_no +
                ", axis=" + axis +
                ", type=" + type +
                ", cdata=" + cdata +
                ", idata=" + idata +
                ", ldata=" + ldata +
                ", rdata=" + rdata +
                '}';
    }

}
