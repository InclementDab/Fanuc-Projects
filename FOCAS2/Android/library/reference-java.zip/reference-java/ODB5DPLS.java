package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODB5DPLS {
    private char name[];
    private int data;
    private short dec;

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    public short getDec() {
        return dec;
    }

    public void setDec(short dec) {
        this.dec = dec;
    }

    @Override
    public String toString() {
        return "ODB5DPLS{" +
                "name=" + Arrays.toString(name) +
                ", data=" + data +
                ", dec=" + dec +
                '}';
    }
}
