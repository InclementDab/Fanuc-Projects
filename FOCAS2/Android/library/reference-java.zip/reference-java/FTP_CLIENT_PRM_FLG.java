package jp.co.fanuc.fwlibe1;


public class FTP_CLIENT_PRM_FLG {
    private char HostName;
    private char CountrolPort;
    private char dummy;
    private char UserName;
    private char Password;
    private char LoginDirectory;

    public char getHostName() {
        return HostName;
    }

    public void setHostName(char hostName) {
        HostName = hostName;
    }

    public char getCountrolPort() {
        return CountrolPort;
    }

    public void setCountrolPort(char countrolPort) {
        CountrolPort = countrolPort;
    }

    public char getDummy() {
        return dummy;
    }

    public void setDummy(char dummy) {
        this.dummy = dummy;
    }

    public char getUserName() {
        return UserName;
    }

    public void setUserName(char userName) {
        UserName = userName;
    }

    public char getPassword() {
        return Password;
    }

    public void setPassword(char password) {
        Password = password;
    }

    public char getLoginDirectory() {
        return LoginDirectory;
    }

    public void setLoginDirectory(char loginDirectory) {
        LoginDirectory = loginDirectory;
    }

    @Override
    public String toString() {
        return "FTP_CLIENT_PRM_FLG{" +
                "HostName=" + HostName +
                ", CountrolPort=" + CountrolPort +
                ", dummy=" + dummy +
                ", UserName=" + UserName +
                ", Password=" + Password +
                ", LoginDirectory=" + LoginDirectory +
                '}';
    }
}
