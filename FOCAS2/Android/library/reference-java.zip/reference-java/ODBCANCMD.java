package jp.co.fanuc.fwlibe1;


public class ODBCANCMD {
    private CMNDDATA p_data;
    private CMNDDATA q_data;
    private CMNDDATA r_data;
    private CMNDDATA z_data;

    public CMNDDATA getP_data() {
        return p_data;
    }

    public void setP_data(CMNDDATA p_data) {
        this.p_data = p_data;
    }

    public CMNDDATA getQ_data() {
        return q_data;
    }

    public void setQ_data(CMNDDATA q_data) {
        this.q_data = q_data;
    }

    public CMNDDATA getR_data() {
        return r_data;
    }

    public void setR_data(CMNDDATA r_data) {
        this.r_data = r_data;
    }

    public CMNDDATA getZ_data() {
        return z_data;
    }

    public void setZ_data(CMNDDATA z_data) {
        this.z_data = z_data;
    }

    @Override
    public String toString() {
        return "ODBCANCMD{" +
                "p_data=" + p_data +
                ", q_data=" + q_data +
                ", r_data=" + r_data +
                ", z_data=" + z_data +
                '}';
    }
}
