package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTLINTF {
    private short inf_tool[];

    public short[] getInf_tool() {
        return inf_tool;
    }

    public void setInf_tool(short[] inf_tool) {
        this.inf_tool = inf_tool;
    }

    @Override
    public String toString() {
        return "IODBTLINTF{" +
                "inf_tool=" + Arrays.toString(inf_tool) +
                '}';
    }
}
