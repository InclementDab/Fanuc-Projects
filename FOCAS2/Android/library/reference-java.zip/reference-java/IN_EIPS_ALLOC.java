package jp.co.fanuc.fwlibe1;


public class IN_EIPS_ALLOC {
    private IN_EIPS_ALLOC_PRM_FLG flg;
    private IN_EIPS_BASIC_PRM prm;

    public IN_EIPS_ALLOC_PRM_FLG getFlg() {
        return flg;
    }

    public void setFlg(IN_EIPS_ALLOC_PRM_FLG flg) {
        this.flg = flg;
    }

    public IN_EIPS_BASIC_PRM getPrm() {
        return prm;
    }

    public void setPrm(IN_EIPS_BASIC_PRM prm) {
        this.prm = prm;
    }

    @Override
    public String toString() {
        return "IN_EIPS_ALLOC{" +
                "flg=" + flg +
                ", prm=" + prm +
                '}';
    }
}
