package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMSRPMCSGNL {
    private int adrs;
    private char pmc_no;
    private char kind;
    private char data;
    private char mask;
    private char enbl;
    private char dummy[];

    public int getAdrs() {
        return adrs;
    }

    public void setAdrs(int adrs) {
        this.adrs = adrs;
    }

    public char getPmc_no() {
        return pmc_no;
    }

    public void setPmc_no(char pmc_no) {
        this.pmc_no = pmc_no;
    }

    public char getKind() {
        return kind;
    }

    public void setKind(char kind) {
        this.kind = kind;
    }

    public char getData() {
        return data;
    }

    public void setData(char data) {
        this.data = data;
    }

    public char getMask() {
        return mask;
    }

    public void setMask(char mask) {
        this.mask = mask;
    }

    public char getEnbl() {
        return enbl;
    }

    public void setEnbl(char enbl) {
        this.enbl = enbl;
    }

    public char[] getDummy() {
        return dummy;
    }

    public void setDummy(char[] dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "ODBMSRPMCSGNL{" +
                "adrs=" + adrs +
                ", pmc_no=" + pmc_no +
                ", kind=" + kind +
                ", data=" + data +
                ", mask=" + mask +
                ", enbl=" + enbl +
                ", dummy=" + Arrays.toString(dummy) +
                '}';
    }
}
