package jp.co.fanuc.fwlibe1;


public class IODBTLLF {
    private int T_code_sum;
    private int life_count_sum;
    private int rem_life_sum;
    private int max_life_sum;
    private int notice_life_sum;
    private short tools_sum;
    private char notice_stat_sum;
    private char count_type_sum;

    public int getT_code_sum() {
        return T_code_sum;
    }

    public void setT_code_sum(int t_code_sum) {
        T_code_sum = t_code_sum;
    }

    public int getLife_count_sum() {
        return life_count_sum;
    }

    public void setLife_count_sum(int life_count_sum) {
        this.life_count_sum = life_count_sum;
    }

    public int getRem_life_sum() {
        return rem_life_sum;
    }

    public void setRem_life_sum(int rem_life_sum) {
        this.rem_life_sum = rem_life_sum;
    }

    public int getMax_life_sum() {
        return max_life_sum;
    }

    public void setMax_life_sum(int max_life_sum) {
        this.max_life_sum = max_life_sum;
    }

    public int getNotice_life_sum() {
        return notice_life_sum;
    }

    public void setNotice_life_sum(int notice_life_sum) {
        this.notice_life_sum = notice_life_sum;
    }

    public short getTools_sum() {
        return tools_sum;
    }

    public void setTools_sum(short tools_sum) {
        this.tools_sum = tools_sum;
    }

    public char getNotice_stat_sum() {
        return notice_stat_sum;
    }

    public void setNotice_stat_sum(char notice_stat_sum) {
        this.notice_stat_sum = notice_stat_sum;
    }

    public char getCount_type_sum() {
        return count_type_sum;
    }

    public void setCount_type_sum(char count_type_sum) {
        this.count_type_sum = count_type_sum;
    }

    @Override
    public String toString() {
        return "IODBTLLF{" +
                "T_code_sum=" + T_code_sum +
                ", life_count_sum=" + life_count_sum +
                ", rem_life_sum=" + rem_life_sum +
                ", max_life_sum=" + max_life_sum +
                ", notice_life_sum=" + notice_life_sum +
                ", tools_sum=" + tools_sum +
                ", notice_stat_sum=" + notice_stat_sum +
                ", count_type_sum=" + count_type_sum +
                '}';
    }
}
