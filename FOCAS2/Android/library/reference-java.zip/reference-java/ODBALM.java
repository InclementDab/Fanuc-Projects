package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBALM {
    private short dummy[];
    private short data;

    public short[] getDummy() {
        return dummy;
    }

    public void setDummy(short[] dummy) {
        this.dummy = dummy;
    }

    public short getData() {
        return data;
    }

    public void setData(short data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ODBALM{" +
                "dummy=" + Arrays.toString(dummy) +
                ", data=" + data +
                '}';
    }
}
