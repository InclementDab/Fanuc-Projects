package jp.co.fanuc.fwlibe1;


public class IODBTOOL_DATE {
    private short year;
    private short mon;
    private short day;
    private short hour;
    private short min;
    private short sec;

    public short getYear() {
        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public short getMon() {
        return mon;
    }

    public void setMon(short mon) {
        this.mon = mon;
    }

    public short getDay() {
        return day;
    }

    public void setDay(short day) {
        this.day = day;
    }

    public short getHour() {
        return hour;
    }

    public void setHour(short hour) {
        this.hour = hour;
    }

    public short getMin() {
        return min;
    }

    public void setMin(short min) {
        this.min = min;
    }

    public short getSec() {
        return sec;
    }

    public void setSec(short sec) {
        this.sec = sec;
    }

    @Override
    public String toString() {
        return "IODBTOOL_DATE{" +
                "year=" + year +
                ", mon=" + mon +
                ", day=" + day +
                ", hour=" + hour +
                ", min=" + min +
                ", sec=" + sec +
                '}';
    }
}
