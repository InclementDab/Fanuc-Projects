package jp.co.fanuc.fwlibe1;


public class IODBTLLFD {
    private short order;
    private short tool_num;
    private int life_count;
    private int rem_life;
    private int max_life;
    private int notice_life;
    private char life_stat;
    private char count_type;
    private short reserve;

    public short getOrder() {
        return order;
    }

    public void setOrder(short order) {
        this.order = order;
    }

    public short getTool_num() {
        return tool_num;
    }

    public void setTool_num(short tool_num) {
        this.tool_num = tool_num;
    }

    public int getLife_count() {
        return life_count;
    }

    public void setLife_count(int life_count) {
        this.life_count = life_count;
    }

    public int getRem_life() {
        return rem_life;
    }

    public void setRem_life(int rem_life) {
        this.rem_life = rem_life;
    }

    public int getMax_life() {
        return max_life;
    }

    public void setMax_life(int max_life) {
        this.max_life = max_life;
    }

    public int getNotice_life() {
        return notice_life;
    }

    public void setNotice_life(int notice_life) {
        this.notice_life = notice_life;
    }

    public char getLife_stat() {
        return life_stat;
    }

    public void setLife_stat(char life_stat) {
        this.life_stat = life_stat;
    }

    public char getCount_type() {
        return count_type;
    }

    public void setCount_type(char count_type) {
        this.count_type = count_type;
    }

    public short getReserve() {
        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBTLLFD{" +
                "order=" + order +
                ", tool_num=" + tool_num +
                ", life_count=" + life_count +
                ", rem_life=" + rem_life +
                ", max_life=" + max_life +
                ", notice_life=" + notice_life +
                ", life_stat=" + life_stat +
                ", count_type=" + count_type +
                ", reserve=" + reserve +
                '}';
    }
}
