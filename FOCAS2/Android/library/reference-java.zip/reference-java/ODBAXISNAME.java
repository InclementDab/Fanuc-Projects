package jp.co.fanuc.fwlibe1;


public class ODBAXISNAME {
    private char name;
    private char suff;

    public char getName() {
        return name;
    }

    public void setName(char name) {
        this.name = name;
    }

    public char getSuff() {
        return suff;
    }

    public void setSuff(char suff) {
        this.suff = suff;
    }

    @Override
    public String toString() {
        return "ODBAXISNAME{" +
                "name=" + name +
                ", suff=" + suff +
                '}';
    }
}
