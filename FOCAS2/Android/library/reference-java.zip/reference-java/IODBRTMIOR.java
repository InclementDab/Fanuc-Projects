package jp.co.fanuc.fwlibe1;


public class IODBRTMIOR {
    private short adr_type;
    private int adr_attr;
    private int sno;
    private int eno;

    public short getAdr_type() {
        return adr_type;
    }

    public void setAdr_type(short adr_type) {
        this.adr_type = adr_type;
    }

    public int getAdr_attr() {
        return adr_attr;
    }

    public void setAdr_attr(int adr_attr) {
        this.adr_attr = adr_attr;
    }

    public int getSno() {
        return sno;
    }

    public void setSno(int sno) {
        this.sno = sno;
    }

    public int getEno() {
        return eno;
    }

    public void setEno(int eno) {
        this.eno = eno;
    }

    @Override
    public String toString() {
        return "IODBRTMIOR{" +
                "adr_type=" + adr_type +
                ", adr_attr=" + adr_attr +
                ", sno=" + sno +
                ", eno=" + eno +
                '}';
    }
}
