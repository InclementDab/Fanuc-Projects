package jp.co.fanuc.fwlibe1;

public class ODBPDFSDIR {
    private short sub_exist;
    private short dummy;
    private String d_f;

    public short getSub_exist() {
        return sub_exist;
    }

    public void setSub_exist(short sub_exist) {
        this.sub_exist = sub_exist;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public String getD_f() {

        return d_f;
    }

    public void setD_f(String d_f) {
        this.d_f = d_f;
    }

    @Override
    public String toString() {
        return "ODBPDFSDIR{" +
                "sub_exist=" + sub_exist +
                ", dummy=" + dummy +
                ", d_f=" + d_f +
                '}';
    }
}
