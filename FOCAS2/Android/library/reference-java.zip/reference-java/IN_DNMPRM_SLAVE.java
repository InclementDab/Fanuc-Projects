package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_DNMPRM_SLAVE {
    private short           reserved1;
    private short           Communication;
    private short           reserved2[];
    private PMC_REG         DetailStatus;
    private short           reserved3[];
    private PMC_REG         Di;
    private short           DiSize;
    private short           reserved4;
    private PMC_REG         Do;
    private short           DoSize;
    private short           reserved5;

    public short getReserved1() {
        return reserved1;
    }

    public void setReserved1(short reserved1) {
        this.reserved1 = reserved1;
    }

    public short getCommunication() {
        return Communication;
    }

    public void setCommunication(short communication) {
        Communication = communication;
    }

    public short[] getReserved2() {
        return reserved2;
    }

    public void setReserved2(short[] reserved2) {
        this.reserved2 = reserved2;
    }

    public PMC_REG getDetailStatus() {
        return DetailStatus;
    }

    public void setDetailStatus(PMC_REG detailStatus) {
        DetailStatus = detailStatus;
    }

    public short[] getReserved3() {
        return reserved3;
    }

    public void setReserved3(short[] reserved3) {
        this.reserved3 = reserved3;
    }

    public PMC_REG getDi() {
        return Di;
    }

    public void setDi(PMC_REG di) {
        Di = di;
    }

    public short getDiSize() {
        return DiSize;
    }

    public void setDiSize(short diSize) {
        DiSize = diSize;
    }

    public short getReserved4() {
        return reserved4;
    }

    public void setReserved4(short reserved4) {
        this.reserved4 = reserved4;
    }

    public PMC_REG getDo() {
        return Do;
    }

    public void setDo(PMC_REG aDo) {
        Do = aDo;
    }

    public short getDoSize() {
        return DoSize;
    }

    public void setDoSize(short doSize) {
        DoSize = doSize;
    }

    public short getReserved5() {
        return reserved5;
    }

    public void setReserved5(short reserved5) {
        this.reserved5 = reserved5;
    }

    @Override
    public String toString() {
        return "IN_DNMPRM_SLAVE{" +
                "reserved1=" + reserved1 +
                ", Communication=" + Communication +
                ", reserved2=" + Arrays.toString(reserved2) +
                ", DetailStatus=" + DetailStatus +
                ", reserved3=" + Arrays.toString(reserved3) +
                ", Di=" + Di +
                ", DiSize=" + DiSize +
                ", reserved4=" + reserved4 +
                ", Do=" + Do +
                ", DoSize=" + DoSize +
                ", reserved5=" + reserved5 +
                '}';
    }
}
