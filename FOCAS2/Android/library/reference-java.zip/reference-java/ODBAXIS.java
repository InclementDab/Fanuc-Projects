package jp.co.fanuc.fwlibe1;

import java.util.Arrays;


public class ODBAXIS {
    private short dummy;
    private short type;
    private int data[];

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public int[] getData() {
        return data;
    }

    public void setData(int[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ODBAXIS{" +
                "dummy=" + dummy +
                ", type=" + type +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
