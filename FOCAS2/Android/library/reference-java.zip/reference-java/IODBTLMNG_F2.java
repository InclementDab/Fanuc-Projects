package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTLMNG_F2 {
    private int T_code;
    private int life_count;
    private int max_life;
    private int rest_life;
    private byte life_stat;
    private byte cust_bits;
    private short tool_info;
    private short H_code;
    private short D_code;
    private int spindle_speed;
    private int feedrate;
    private short magazine;
    private short pot;
    private short G_code;
    private short W_code;
    private short gno;
    private short grp;
    private short edge;
    private short org_magazine;
    private short org_pot;
    private byte edge_num;
    private byte reserve_c;
    private int reserved[];
    private int custom1;
    private int custom2;
    private int custom3;
    private int custom4;
    private int custom5;
    private int custom6;
    private int custom7;
    private int custom8;
    private int custom9;
    private int custom10;
    private int custom11;
    private int custom12;
    private int custom13;
    private int custom14;
    private int custom15;
    private int custom16;
    private int custom17;
    private int custom18;
    private int custom19;
    private int custom20;
    private int custom21;
    private int custom22;
    private int custom23;
    private int custom24;
    private int custom25;
    private int custom26;
    private int custom27;
    private int custom28;
    private int custom29;
    private int custom30;
    private int custom31;
    private int custom32;
    private int custom33;
    private int custom34;
    private int custom35;
    private int custom36;
    private int custom37;
    private int custom38;
    private int custom39;
    private int custom40;

    public int getT_code() {
        return T_code;
    }

    public void setT_code(int t_code) {
        T_code = t_code;
    }

    public int getLife_count() {
        return life_count;
    }

    public void setLife_count(int life_count) {
        this.life_count = life_count;
    }

    public int getMax_life() {
        return max_life;
    }

    public void setMax_life(int max_life) {
        this.max_life = max_life;
    }

    public int getRest_life() {
        return rest_life;
    }

    public void setRest_life(int rest_life) {
        this.rest_life = rest_life;
    }

    public byte getLife_stat() {
        return life_stat;
    }

    public void setLife_stat(byte life_stat) {
        this.life_stat = life_stat;
    }

    public byte getCust_bits() {
        return cust_bits;
    }

    public void setCust_bits(byte cust_bits) {
        this.cust_bits = cust_bits;
    }

    public short getTool_info() {
        return tool_info;
    }

    public void setTool_info(short tool_info) {
        this.tool_info = tool_info;
    }

    public short getH_code() {
        return H_code;
    }

    public void setH_code(short h_code) {
        H_code = h_code;
    }

    public short getD_code() {
        return D_code;
    }

    public void setD_code(short d_code) {
        D_code = d_code;
    }

    public int getSpindle_speed() {
        return spindle_speed;
    }

    public void setSpindle_speed(int spindle_speed) {
        this.spindle_speed = spindle_speed;
    }

    public int getFeedrate() {
        return feedrate;
    }

    public void setFeedrate(int feedrate) {
        this.feedrate = feedrate;
    }

    public short getMagazine() {
        return magazine;
    }

    public void setMagazine(short magazine) {
        this.magazine = magazine;
    }

    public short getPot() {
        return pot;
    }

    public void setPot(short pot) {
        this.pot = pot;
    }

    public short getG_code() {
        return G_code;
    }

    public void setG_code(short g_code) {
        G_code = g_code;
    }

    public short getW_code() {
        return W_code;
    }

    public void setW_code(short w_code) {
        W_code = w_code;
    }

    public short getGno() {
        return gno;
    }

    public void setGno(short gno) {
        this.gno = gno;
    }

    public short getGrp() {
        return grp;
    }

    public void setGrp(short grp) {
        this.grp = grp;
    }

    public short getEdge() {
        return edge;
    }

    public void setEdge(short edge) {
        this.edge = edge;
    }

    public short getOrg_magazine() {
        return org_magazine;
    }

    public void setOrg_magazine(short org_magazine) {
        this.org_magazine = org_magazine;
    }

    public short getOrg_pot() {
        return org_pot;
    }

    public void setOrg_pot(short org_pot) {
        this.org_pot = org_pot;
    }

    public byte getEdge_num() {
        return edge_num;
    }

    public void setEdge_num(byte edge_num) {
        this.edge_num = edge_num;
    }

    public byte getReserve_c() {
        return reserve_c;
    }

    public void setReserve_c(byte reserve_c) {
        this.reserve_c = reserve_c;
    }

    public int[] getReserved() {
        return reserved;
    }

    public void setReserved(int[] reserved) {
        this.reserved = reserved;
    }

    public int getCustom1() {
        return custom1;
    }

    public void setCustom1(int custom1) {
        this.custom1 = custom1;
    }

    public int getCustom2() {
        return custom2;
    }

    public void setCustom2(int custom2) {
        this.custom2 = custom2;
    }

    public int getCustom3() {
        return custom3;
    }

    public void setCustom3(int custom3) {
        this.custom3 = custom3;
    }

    public int getCustom4() {
        return custom4;
    }

    public void setCustom4(int custom4) {
        this.custom4 = custom4;
    }

    public int getCustom5() {
        return custom5;
    }

    public void setCustom5(int custom5) {
        this.custom5 = custom5;
    }

    public int getCustom6() {
        return custom6;
    }

    public void setCustom6(int custom6) {
        this.custom6 = custom6;
    }

    public int getCustom7() {
        return custom7;
    }

    public void setCustom7(int custom7) {
        this.custom7 = custom7;
    }

    public int getCustom8() {
        return custom8;
    }

    public void setCustom8(int custom8) {
        this.custom8 = custom8;
    }

    public int getCustom9() {
        return custom9;
    }

    public void setCustom9(int custom9) {
        this.custom9 = custom9;
    }

    public int getCustom10() {
        return custom10;
    }

    public void setCustom10(int custom10) {
        this.custom10 = custom10;
    }

    public int getCustom11() {
        return custom11;
    }

    public void setCustom11(int custom11) {
        this.custom11 = custom11;
    }

    public int getCustom12() {
        return custom12;
    }

    public void setCustom12(int custom12) {
        this.custom12 = custom12;
    }

    public int getCustom13() {
        return custom13;
    }

    public void setCustom13(int custom13) {
        this.custom13 = custom13;
    }

    public int getCustom14() {
        return custom14;
    }

    public void setCustom14(int custom14) {
        this.custom14 = custom14;
    }

    public int getCustom15() {
        return custom15;
    }

    public void setCustom15(int custom15) {
        this.custom15 = custom15;
    }

    public int getCustom16() {
        return custom16;
    }

    public void setCustom16(int custom16) {
        this.custom16 = custom16;
    }

    public int getCustom17() {
        return custom17;
    }

    public void setCustom17(int custom17) {
        this.custom17 = custom17;
    }

    public int getCustom18() {
        return custom18;
    }

    public void setCustom18(int custom18) {
        this.custom18 = custom18;
    }

    public int getCustom19() {
        return custom19;
    }

    public void setCustom19(int custom19) {
        this.custom19 = custom19;
    }

    public int getCustom20() {
        return custom20;
    }

    public void setCustom20(int custom20) {
        this.custom20 = custom20;
    }

    public int getCustom21() {
        return custom21;
    }

    public void setCustom21(int custom21) {
        this.custom21 = custom21;
    }

    public int getCustom22() {
        return custom22;
    }

    public void setCustom22(int custom22) {
        this.custom22 = custom22;
    }

    public int getCustom23() {
        return custom23;
    }

    public void setCustom23(int custom23) {
        this.custom23 = custom23;
    }

    public int getCustom24() {
        return custom24;
    }

    public void setCustom24(int custom24) {
        this.custom24 = custom24;
    }

    public int getCustom25() {
        return custom25;
    }

    public void setCustom25(int custom25) {
        this.custom25 = custom25;
    }

    public int getCustom26() {
        return custom26;
    }

    public void setCustom26(int custom26) {
        this.custom26 = custom26;
    }

    public int getCustom27() {
        return custom27;
    }

    public void setCustom27(int custom27) {
        this.custom27 = custom27;
    }

    public int getCustom28() {
        return custom28;
    }

    public void setCustom28(int custom28) {
        this.custom28 = custom28;
    }

    public int getCustom29() {
        return custom29;
    }

    public void setCustom29(int custom29) {
        this.custom29 = custom29;
    }

    public int getCustom30() {
        return custom30;
    }

    public void setCustom30(int custom30) {
        this.custom30 = custom30;
    }

    public int getCustom31() {
        return custom31;
    }

    public void setCustom31(int custom31) {
        this.custom31 = custom31;
    }

    public int getCustom32() {
        return custom32;
    }

    public void setCustom32(int custom32) {
        this.custom32 = custom32;
    }

    public int getCustom33() {
        return custom33;
    }

    public void setCustom33(int custom33) {
        this.custom33 = custom33;
    }

    public int getCustom34() {
        return custom34;
    }

    public void setCustom34(int custom34) {
        this.custom34 = custom34;
    }

    public int getCustom35() {
        return custom35;
    }

    public void setCustom35(int custom35) {
        this.custom35 = custom35;
    }

    public int getCustom36() {
        return custom36;
    }

    public void setCustom36(int custom36) {
        this.custom36 = custom36;
    }

    public int getCustom37() {
        return custom37;
    }

    public void setCustom37(int custom37) {
        this.custom37 = custom37;
    }

    public int getCustom38() {
        return custom38;
    }

    public void setCustom38(int custom38) {
        this.custom38 = custom38;
    }

    public int getCustom39() {
        return custom39;
    }

    public void setCustom39(int custom39) {
        this.custom39 = custom39;
    }

    public int getCustom40() {
        return custom40;
    }

    public void setCustom40(int custom40) {
        this.custom40 = custom40;
    }

    @Override
    public String toString() {
        return "IODBTLMNG_F2{" +
                "T_code=" + T_code +
                ", life_count=" + life_count +
                ", max_life=" + max_life +
                ", rest_life=" + rest_life +
                ", life_stat=" + life_stat +
                ", cust_bits=" + cust_bits +
                ", tool_info=" + tool_info +
                ", H_code=" + H_code +
                ", D_code=" + D_code +
                ", spindle_speed=" + spindle_speed +
                ", feedrate=" + feedrate +
                ", magazine=" + magazine +
                ", pot=" + pot +
                ", G_code=" + G_code +
                ", W_code=" + W_code +
                ", gno=" + gno +
                ", grp=" + grp +
                ", edge=" + edge +
                ", org_magazine=" + org_magazine +
                ", org_pot=" + org_pot +
                ", edge_num=" + edge_num +
                ", reserve_c=" + reserve_c +
                ", reserved=" + Arrays.toString(reserved) +
                ", custom1=" + custom1 +
                ", custom2=" + custom2 +
                ", custom3=" + custom3 +
                ", custom4=" + custom4 +
                ", custom5=" + custom5 +
                ", custom6=" + custom6 +
                ", custom7=" + custom7 +
                ", custom8=" + custom8 +
                ", custom9=" + custom9 +
                ", custom10=" + custom10 +
                ", custom11=" + custom11 +
                ", custom12=" + custom12 +
                ", custom13=" + custom13 +
                ", custom14=" + custom14 +
                ", custom15=" + custom15 +
                ", custom16=" + custom16 +
                ", custom17=" + custom17 +
                ", custom18=" + custom18 +
                ", custom19=" + custom19 +
                ", custom20=" + custom20 +
                ", custom21=" + custom21 +
                ", custom22=" + custom22 +
                ", custom23=" + custom23 +
                ", custom24=" + custom24 +
                ", custom25=" + custom25 +
                ", custom26=" + custom26 +
                ", custom27=" + custom27 +
                ", custom28=" + custom28 +
                ", custom29=" + custom29 +
                ", custom30=" + custom30 +
                ", custom31=" + custom31 +
                ", custom32=" + custom32 +
                ", custom33=" + custom33 +
                ", custom34=" + custom34 +
                ", custom35=" + custom35 +
                ", custom36=" + custom36 +
                ", custom37=" + custom37 +
                ", custom38=" + custom38 +
                ", custom39=" + custom39 +
                ", custom40=" + custom40 +
                '}';
    }

    public void Dispose() {
        reserved = null;
    }
}
