package jp.co.fanuc.fwlibe1;


public class ODBHMPROGSTAT {
    private short   run;
    private short   disp;
    private short   alm_no;
    private short   reserve;
    private int    prog_no;
    private int    block_no;

    public short getRun() {
        return run;
    }

    public void setRun(short run) {
        this.run = run;
    }

    public short getDisp() {
        return disp;
    }

    public void setDisp(short disp) {
        this.disp = disp;
    }

    public short getAlm_no() {
        return alm_no;
    }

    public void setAlm_no(short alm_no) {
        this.alm_no = alm_no;
    }

    public short getReserve() {
        return reserve;
    }

    public void setReserve(short reserve) {
        this.reserve = reserve;
    }

    public int getProg_no() {
        return prog_no;
    }

    public void setProg_no(int prog_no) {
        this.prog_no = prog_no;
    }

    public int getBlock_no() {
        return block_no;
    }

    public void setBlock_no(int block_no) {
        this.block_no = block_no;
    }

    @Override
    public String toString() {
        return "ODBHMPROGSTAT{" +
                "run=" + run +
                ", disp=" + disp +
                ", alm_no=" + alm_no +
                ", reserve=" + reserve +
                ", prog_no=" + prog_no +
                ", block_no=" + block_no +
                '}';
    }
}
