package jp.co.fanuc.fwlibe1;

import java.util.Arrays;


public class IDBWRA64 {
    private short       datano;         /* dummy */
    private short       type;           /* axis number */
    private short       dummy[];       /* dummy2 */
    private REALDATA    data[]; /* preset data */

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short[] getDummy() {
        return dummy;
    }

    public void setDummy(short[] dummy) {
        this.dummy = dummy;
    }

    public REALDATA[] getData() {
        return data;
    }

    public void setData(REALDATA[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IDBWRA64{" +
                "datano=" + datano +
                ", type=" + type +
                ", dummy=" + Arrays.toString(dummy) +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
