package jp.co.fanuc.fwlibe1;

/**
 * Created by honndayu on 2016/07/01.
 */
public class IDBITD2 {
    private short datano;
    private int type;
    private int data;

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public int getType() {

        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getData() {

        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IDBITD2{" +
                "datano=" + datano +
                ", type=" + type +
                ", data=" + data +
                '}';
    }
}
