package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTGI2 {
    private short s_grp;
    private short dummy;
    private short e_grp;
    private int opt_grpno[];

    public short getS_grp() {
        return s_grp;
    }

    public void setS_grp(short s_grp) {
        this.s_grp = s_grp;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public short getE_grp() {

        return e_grp;
    }

    public void setE_grp(short e_grp) {
        this.e_grp = e_grp;
    }

    public int[] getOpt_grpno() {

        return opt_grpno;
    }

    public void setOpt_grpno(int[] opt_grpno) {
        this.opt_grpno = opt_grpno;
    }

    @Override
    public String toString() {
        return "IODBTGI2{" +
                "s_grp=" + s_grp +
                ", dummy=" + dummy +
                ", e_grp=" + e_grp +
                ", opt_grpno=" + Arrays.toString(opt_grpno) +
                '}';
    }

    public void Dispose() {
        opt_grpno = null;
    }
}
