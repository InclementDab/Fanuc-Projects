package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBRDNA {
    private short datano;
    private short type;
    private String sgnl1_name;
    private String sgnl2_name;
    private String sgnl3_name;
    private String sgnl4_name;
    private String sgnl5_name;
    private String sgnl6_name;
    private String sgnl7_name;
    private String sgnl8_name;

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public String getSgnl1_name() {
        return sgnl1_name;
    }

    public void setSgnl1_name(String sgnl1_name) {
        this.sgnl1_name = sgnl1_name;
    }

    public String getSgnl2_name() {
        return sgnl2_name;
    }

    public void setSgnl2_name(String sgnl2_name) {
        this.sgnl2_name = sgnl2_name;
    }

    public String getSgnl3_name() {
        return sgnl3_name;
    }

    public void setSgnl3_name(String sgnl3_name) {
        this.sgnl3_name = sgnl3_name;
    }

    public String getSgnl4_name() {
        return sgnl4_name;
    }

    public void setSgnl4_name(String sgnl4_name) {
        this.sgnl4_name = sgnl4_name;
    }

    public String getSgnl5_name() {
        return sgnl5_name;
    }

    public void setSgnl5_name(String sgnl5_name) {
        this.sgnl5_name = sgnl5_name;
    }

    public String getSgnl6_name() {
        return sgnl6_name;
    }

    public void setSgnl6_name(String sgnl6_name) {
        this.sgnl6_name = sgnl6_name;
    }

    public String getSgnl7_name() {
        return sgnl7_name;
    }

    public void setSgnl7_name(String sgnl7_name) {
        this.sgnl7_name = sgnl7_name;
    }

    public String getSgnl8_name() {
        return sgnl8_name;
    }

    public void setSgnl8_name(String sgnl8_name) {
        this.sgnl8_name = sgnl8_name;
    }

    @Override
    public String toString() {
        return "IODBRDNA{" +
                "datano=" + datano +
                ", type=" + type +
                ", sgnl1_name=" + sgnl1_name +
                ", sgnl2_name=" + sgnl2_name +
                ", sgnl3_name=" + sgnl3_name +
                ", sgnl4_name=" + sgnl4_name +
                ", sgnl5_name=" + sgnl5_name +
                ", sgnl6_name=" + sgnl6_name +
                ", sgnl7_name=" + sgnl7_name +
                ", sgnl8_name=" + sgnl8_name +
                '}';
    }
}
