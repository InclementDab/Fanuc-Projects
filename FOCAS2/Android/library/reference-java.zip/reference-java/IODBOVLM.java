package jp.co.fanuc.fwlibe1;

import java.util.Arrays;


public class IODBOVLM {
    private short datano;
    private short type;
    private int data[][];

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getType() {

        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public int[][] getData() {

        return data;
    }

    public void setData(int[][] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBOVLM{" +
                "datano=" + datano +
                ", type=" + type +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
