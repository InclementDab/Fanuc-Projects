package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMDGFLOW {
    private short msgidx;
    private short yesidx;
    private short noidx;
    private short reserved;
    private char message[];
    private short detail;
    private short operate;

    public short getMsgidx() {
        return msgidx;
    }

    public void setMsgidx(short msgidx) {
        this.msgidx = msgidx;
    }

    public short getYesidx() {
        return yesidx;
    }

    public void setYesidx(short yesidx) {
        this.yesidx = yesidx;
    }

    public short getNoidx() {
        return noidx;
    }

    public void setNoidx(short noidx) {
        this.noidx = noidx;
    }

    public short getReserved() {
        return reserved;
    }

    public void setReserved(short reserved) {
        this.reserved = reserved;
    }

    public char[] getMessage() {
        return message;
    }

    public void setMessage(char[] message) {
        this.message = message;
    }

    public short getDetail() {
        return detail;
    }

    public void setDetail(short detail) {
        this.detail = detail;
    }

    public short getOperate() {
        return operate;
    }

    public void setOperate(short operate) {
        this.operate = operate;
    }

    @Override
    public String toString() {
        return "ODBMDGFLOW{" +
                "msgidx=" + msgidx +
                ", yesidx=" + yesidx +
                ", noidx=" + noidx +
                ", reserved=" + reserved +
                ", message=" + Arrays.toString(message) +
                ", detail=" + detail +
                ", operate=" + operate +
                '}';
    }
}
