package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class FACTOLINK_CLIENT_PRM {
    private char HostName[];
    private int Port;

    public char[] getHostName() {
        return HostName;
    }

    public void setHostName(char[] hostName) {
        HostName = hostName;
    }

    public int getPort() {
        return Port;
    }

    public void setPort(int port) {
        Port = port;
    }

    @Override
    public String toString() {
        return "FACTOLINK_CLIENT_PRM{" +
                "HostName=" + Arrays.toString(HostName) +
                ", Port=" + Port +
                '}';
    }
}
