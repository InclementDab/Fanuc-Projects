package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBLPWOFS {
    private short   pwrofs_set;
    private short   pwrofs_coef;
    private short   pwrofs_upper;
    private short   pwrofs_max;
    private short   pwrofs_min;
    private short   pwrinofs_coef;
    private char    reserve[];

    public short getPwrofs_set() {
        return pwrofs_set;
    }

    public void setPwrofs_set(short pwrofs_set) {
        this.pwrofs_set = pwrofs_set;
    }

    public short getPwrofs_coef() {
        return pwrofs_coef;
    }

    public void setPwrofs_coef(short pwrofs_coef) {
        this.pwrofs_coef = pwrofs_coef;
    }

    public short getPwrofs_upper() {
        return pwrofs_upper;
    }

    public void setPwrofs_upper(short pwrofs_upper) {
        this.pwrofs_upper = pwrofs_upper;
    }

    public short getPwrofs_max() {
        return pwrofs_max;
    }

    public void setPwrofs_max(short pwrofs_max) {
        this.pwrofs_max = pwrofs_max;
    }

    public short getPwrofs_min() {
        return pwrofs_min;
    }

    public void setPwrofs_min(short pwrofs_min) {
        this.pwrofs_min = pwrofs_min;
    }

    public short getPwrinofs_coef() {
        return pwrinofs_coef;
    }

    public void setPwrinofs_coef(short pwrinofs_coef) {
        this.pwrinofs_coef = pwrinofs_coef;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "ODBLPWOFS{" +
                "pwrofs_set=" + pwrofs_set +
                ", pwrofs_coef=" + pwrofs_coef +
                ", pwrofs_upper=" + pwrofs_upper +
                ", pwrofs_max=" + pwrofs_max +
                ", pwrofs_min=" + pwrofs_min +
                ", pwrinofs_coef=" + pwrinofs_coef +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
