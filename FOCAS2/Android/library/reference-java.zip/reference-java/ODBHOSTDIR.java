package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBHOSTDIR {
    private char host_file[];

    public char[] getHost_file() {
        return host_file;
    }

    public void setHost_file(char[] host_file) {
        this.host_file = host_file;
    }

    @Override
    public String toString() {
        return "ODBHOSTDIR{" +
                "host_file=" + Arrays.toString(host_file) +
                '}';
    }
}
