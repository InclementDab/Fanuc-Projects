package jp.co.fanuc.fwlibe1;


public class IODBSLVID {
    private short dis_enb;
    private short slave_no;
    private short nsl;
    private char dgn_size;
    private char dgn_type;
    private short dgn_addr;

    public short getDis_enb() {
        return dis_enb;
    }

    public void setDis_enb(short dis_enb) {
        this.dis_enb = dis_enb;
    }

    public short getSlave_no() {
        return slave_no;
    }

    public void setSlave_no(short slave_no) {
        this.slave_no = slave_no;
    }

    public short getNsl() {
        return nsl;
    }

    public void setNsl(short nsl) {
        this.nsl = nsl;
    }

    public char getDgn_size() {
        return dgn_size;
    }

    public void setDgn_size(char dgn_size) {
        this.dgn_size = dgn_size;
    }

    public char getDgn_type() {
        return dgn_type;
    }

    public void setDgn_type(char dgn_type) {
        this.dgn_type = dgn_type;
    }

    public short getDgn_addr() {
        return dgn_addr;
    }

    public void setDgn_addr(short dgn_addr) {
        this.dgn_addr = dgn_addr;
    }

    @Override
    public String toString() {
        return "IODBSLVID{" +
                "dis_enb=" + dis_enb +
                ", slave_no=" + slave_no +
                ", nsl=" + nsl +
                ", dgn_size=" + dgn_size +
                ", dgn_type=" + dgn_type +
                ", dgn_addr=" + dgn_addr +
                '}';
    }
}
