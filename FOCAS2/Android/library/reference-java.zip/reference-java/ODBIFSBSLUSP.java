package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBSLUSP {
    private short slave_num;
    private short spdl_num;
    private char spdl_name[];

    public short getSlave_num() {
        return slave_num;
    }

    public void setSlave_num(short slave_num) {
        this.slave_num = slave_num;
    }

    public short getSpdl_num() {
        return spdl_num;
    }

    public void setSpdl_num(short spdl_num) {
        this.spdl_num = spdl_num;
    }

    public char[] getSpdl_name() {
        return spdl_name;
    }

    public void setSpdl_name(char[] spdl_name) {
        this.spdl_name = spdl_name;
    }

    @Override
    public String toString() {
        return "ODBIFSBSLUSP{" +
                "slave_num=" + slave_num +
                ", spdl_num=" + spdl_num +
                ", spdl_name=" + Arrays.toString(spdl_name) +
                '}';
    }
}
