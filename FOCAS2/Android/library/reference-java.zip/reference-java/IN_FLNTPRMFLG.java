package jp.co.fanuc.fwlibe1;


public class IN_FLNTPRMFLG {
    private char            OwnIpAddress;
    private char            NodeName;
    private char            Area1CmnMemAddr;
    private char            Area1CmnMemSize;
    private char            Area2CmnMemAddr;
    private char            Area2CmnMemSize;
    private char            TokenWatch;
    private char            MinFrame;
    private char            OwnStatus;
    private char            EntryNode;
    private char            Area1PmcAddr;
    private char            Area1ExchgAddr;
    private char            Area1ExchgSize;
    private char            Area2PmcAddr;
    private char            Area2ExchgAddr;
    private char            Area2ExchgSize;
    private char            Area2PmcDoAddr;
    private char            Area2ExchgDoSize;
    private char            Area2PmcDiAddr;
    private char            Area2ConditionAddr;
    private char            Area2AlterAddr;
    private char            Area2ExchgDiAddr;
    private char            Area2ExchgDiSize;
    private char            ClientMsgAddr;
    private char            ClientMsgSize;
    private char            ServerMsgAddr;
    private char            ServerMsgSize;
    private char            Option1;
    private char            Option2;

    public char getOwnIpAddress() {
        return OwnIpAddress;
    }

    public void setOwnIpAddress(char ownIpAddress) {
        OwnIpAddress = ownIpAddress;
    }

    public char getNodeName() {
        return NodeName;
    }

    public void setNodeName(char nodeName) {
        NodeName = nodeName;
    }

    public char getArea1CmnMemAddr() {
        return Area1CmnMemAddr;
    }

    public void setArea1CmnMemAddr(char area1CmnMemAddr) {
        Area1CmnMemAddr = area1CmnMemAddr;
    }

    public char getArea1CmnMemSize() {
        return Area1CmnMemSize;
    }

    public void setArea1CmnMemSize(char area1CmnMemSize) {
        Area1CmnMemSize = area1CmnMemSize;
    }

    public char getArea2CmnMemAddr() {
        return Area2CmnMemAddr;
    }

    public void setArea2CmnMemAddr(char area2CmnMemAddr) {
        Area2CmnMemAddr = area2CmnMemAddr;
    }

    public char getArea2CmnMemSize() {
        return Area2CmnMemSize;
    }

    public void setArea2CmnMemSize(char area2CmnMemSize) {
        Area2CmnMemSize = area2CmnMemSize;
    }

    public char getTokenWatch() {
        return TokenWatch;
    }

    public void setTokenWatch(char tokenWatch) {
        TokenWatch = tokenWatch;
    }

    public char getMinFrame() {
        return MinFrame;
    }

    public void setMinFrame(char minFrame) {
        MinFrame = minFrame;
    }

    public char getOwnStatus() {
        return OwnStatus;
    }

    public void setOwnStatus(char ownStatus) {
        OwnStatus = ownStatus;
    }

    public char getEntryNode() {
        return EntryNode;
    }

    public void setEntryNode(char entryNode) {
        EntryNode = entryNode;
    }

    public char getArea1PmcAddr() {
        return Area1PmcAddr;
    }

    public void setArea1PmcAddr(char area1PmcAddr) {
        Area1PmcAddr = area1PmcAddr;
    }

    public char getArea1ExchgAddr() {
        return Area1ExchgAddr;
    }

    public void setArea1ExchgAddr(char area1ExchgAddr) {
        Area1ExchgAddr = area1ExchgAddr;
    }

    public char getArea1ExchgSize() {
        return Area1ExchgSize;
    }

    public void setArea1ExchgSize(char area1ExchgSize) {
        Area1ExchgSize = area1ExchgSize;
    }

    public char getArea2PmcAddr() {
        return Area2PmcAddr;
    }

    public void setArea2PmcAddr(char area2PmcAddr) {
        Area2PmcAddr = area2PmcAddr;
    }

    public char getArea2ExchgAddr() {
        return Area2ExchgAddr;
    }

    public void setArea2ExchgAddr(char area2ExchgAddr) {
        Area2ExchgAddr = area2ExchgAddr;
    }

    public char getArea2ExchgSize() {
        return Area2ExchgSize;
    }

    public void setArea2ExchgSize(char area2ExchgSize) {
        Area2ExchgSize = area2ExchgSize;
    }

    public char getArea2PmcDoAddr() {
        return Area2PmcDoAddr;
    }

    public void setArea2PmcDoAddr(char area2PmcDoAddr) {
        Area2PmcDoAddr = area2PmcDoAddr;
    }

    public char getArea2ExchgDoSize() {
        return Area2ExchgDoSize;
    }

    public void setArea2ExchgDoSize(char area2ExchgDoSize) {
        Area2ExchgDoSize = area2ExchgDoSize;
    }

    public char getArea2PmcDiAddr() {
        return Area2PmcDiAddr;
    }

    public void setArea2PmcDiAddr(char area2PmcDiAddr) {
        Area2PmcDiAddr = area2PmcDiAddr;
    }

    public char getArea2ConditionAddr() {
        return Area2ConditionAddr;
    }

    public void setArea2ConditionAddr(char area2ConditionAddr) {
        Area2ConditionAddr = area2ConditionAddr;
    }

    public char getArea2AlterAddr() {
        return Area2AlterAddr;
    }

    public void setArea2AlterAddr(char area2AlterAddr) {
        Area2AlterAddr = area2AlterAddr;
    }

    public char getArea2ExchgDiAddr() {
        return Area2ExchgDiAddr;
    }

    public void setArea2ExchgDiAddr(char area2ExchgDiAddr) {
        Area2ExchgDiAddr = area2ExchgDiAddr;
    }

    public char getArea2ExchgDiSize() {
        return Area2ExchgDiSize;
    }

    public void setArea2ExchgDiSize(char area2ExchgDiSize) {
        Area2ExchgDiSize = area2ExchgDiSize;
    }

    public char getClientMsgAddr() {
        return ClientMsgAddr;
    }

    public void setClientMsgAddr(char clientMsgAddr) {
        ClientMsgAddr = clientMsgAddr;
    }

    public char getClientMsgSize() {
        return ClientMsgSize;
    }

    public void setClientMsgSize(char clientMsgSize) {
        ClientMsgSize = clientMsgSize;
    }

    public char getServerMsgAddr() {
        return ServerMsgAddr;
    }

    public void setServerMsgAddr(char serverMsgAddr) {
        ServerMsgAddr = serverMsgAddr;
    }

    public char getServerMsgSize() {
        return ServerMsgSize;
    }

    public void setServerMsgSize(char serverMsgSize) {
        ServerMsgSize = serverMsgSize;
    }

    public char getOption1() {
        return Option1;
    }

    public void setOption1(char option1) {
        Option1 = option1;
    }

    public char getOption2() {
        return Option2;
    }

    public void setOption2(char option2) {
        Option2 = option2;
    }

    @Override
    public String toString() {
        return "IN_FLNTPRMFLG{" +
                "OwnIpAddress=" + OwnIpAddress +
                ", NodeName=" + NodeName +
                ", Area1CmnMemAddr=" + Area1CmnMemAddr +
                ", Area1CmnMemSize=" + Area1CmnMemSize +
                ", Area2CmnMemAddr=" + Area2CmnMemAddr +
                ", Area2CmnMemSize=" + Area2CmnMemSize +
                ", TokenWatch=" + TokenWatch +
                ", MinFrame=" + MinFrame +
                ", OwnStatus=" + OwnStatus +
                ", EntryNode=" + EntryNode +
                ", Area1PmcAddr=" + Area1PmcAddr +
                ", Area1ExchgAddr=" + Area1ExchgAddr +
                ", Area1ExchgSize=" + Area1ExchgSize +
                ", Area2PmcAddr=" + Area2PmcAddr +
                ", Area2ExchgAddr=" + Area2ExchgAddr +
                ", Area2ExchgSize=" + Area2ExchgSize +
                ", Area2PmcDoAddr=" + Area2PmcDoAddr +
                ", Area2ExchgDoSize=" + Area2ExchgDoSize +
                ", Area2PmcDiAddr=" + Area2PmcDiAddr +
                ", Area2ConditionAddr=" + Area2ConditionAddr +
                ", Area2AlterAddr=" + Area2AlterAddr +
                ", Area2ExchgDiAddr=" + Area2ExchgDiAddr +
                ", Area2ExchgDiSize=" + Area2ExchgDiSize +
                ", ClientMsgAddr=" + ClientMsgAddr +
                ", ClientMsgSize=" + ClientMsgSize +
                ", ServerMsgAddr=" + ServerMsgAddr +
                ", ServerMsgSize=" + ServerMsgSize +
                ", Option1=" + Option1 +
                ", Option2=" + Option2 +
                '}';
    }
}
