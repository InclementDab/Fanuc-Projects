package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBUSBSEARCH {
    private char             path[];
    private char             s_fname[];
    private short   req_attrib;
    private char             sort;
    private char             dummy;

    public char[] getPath() {
        return path;
    }

    public void setPath(char[] path) {
        this.path = path;
    }

    public char[] getS_fname() {
        return s_fname;
    }

    public void setS_fname(char[] s_fname) {
        this.s_fname = s_fname;
    }

    public short getReq_attrib() {
        return req_attrib;
    }

    public void setReq_attrib(short req_attrib) {
        this.req_attrib = req_attrib;
    }

    public char getSort() {
        return sort;
    }

    public void setSort(char sort) {
        this.sort = sort;
    }

    public char getDummy() {
        return dummy;
    }

    public void setDummy(char dummy) {
        this.dummy = dummy;
    }

    @Override
    public String toString() {
        return "IDBUSBSEARCH{" +
                "path=" + Arrays.toString(path) +
                ", s_fname=" + Arrays.toString(s_fname) +
                ", req_attrib=" + req_attrib +
                ", sort=" + sort +
                ", dummy=" + dummy +
                '}';
    }
}
