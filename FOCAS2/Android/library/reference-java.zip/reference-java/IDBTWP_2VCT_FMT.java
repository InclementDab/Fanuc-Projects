package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBTWP_2VCT_FMT {
    private double orign[];
    private double vtr1[];
    private double vtr2[];
    private int   reserve[];

    public double[] getOrign() {
        return orign;
    }

    public void setOrign(double[] orign) {
        this.orign = orign;
    }

    public double[] getVtr1() {
        return vtr1;
    }

    public void setVtr1(double[] vtr1) {
        this.vtr1 = vtr1;
    }

    public double[] getVtr2() {
        return vtr2;
    }

    public void setVtr2(double[] vtr2) {
        this.vtr2 = vtr2;
    }

    public int[] getReserve() {
        return reserve;
    }

    public void setReserve(int[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IDBTWP_2VCT_FMT{" +
                "orign=" + Arrays.toString(orign) +
                ", vtr1=" + Arrays.toString(vtr1) +
                ", vtr2=" + Arrays.toString(vtr2) +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
