package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBPOTPRTY {
    private short tool_no;
    private short pot_type;
    private byte pot_info1;
    private byte pot_info2;
    private byte reserve[];
    private int cstm[];

    public short getTool_no() {
        return tool_no;
    }

    public void setTool_no(short tool_no) {
        this.tool_no = tool_no;
    }

    public short getPot_type() {
        return pot_type;
    }

    public void setPot_type(short pot_type) {
        this.pot_type = pot_type;
    }

    public byte getPot_info1() {
        return pot_info1;
    }

    public void setPot_info1(byte pot_info1) {
        this.pot_info1 = pot_info1;
    }

    public byte getPot_info2() {
        return pot_info2;
    }

    public void setPot_info2(byte pot_info2) {
        this.pot_info2 = pot_info2;
    }

    public byte[] getReserve() {
        return reserve;
    }

    public void setReserve(byte[] reserve) {
        this.reserve = reserve;
    }

    public int[] getCstm() {
        return cstm;
    }

    public void setCstm(int[] cstm) {
        this.cstm = cstm;
    }

    @Override
    public String toString() {
        return "IODBPOTPRTY{" +
                "tool_no=" + tool_no +
                ", pot_type=" + pot_type +
                ", pot_info1=" + pot_info1 +
                ", pot_info2=" + pot_info2 +
                ", reserve=" + Arrays.toString(reserve) +
                ", cstm=" + Arrays.toString(cstm) +
                '}';
    }

    public void Dispose() {
        reserve = null;
        cstm = null;
    }
}
