package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_EIP_TYPE_PRM_FLG {
    private char Type;
    private char pad1[];
    private char Address;
    private char Size;
    private char TagName;
    private char pad2[];

    public char getType() {
        return Type;
    }

    public void setType(char type) {
        Type = type;
    }

    public char[] getPad1() {
        return pad1;
    }

    public void setPad1(char[] pad1) {
        this.pad1 = pad1;
    }

    public char getAddress() {
        return Address;
    }

    public void setAddress(char address) {
        Address = address;
    }

    public char getSize() {
        return Size;
    }

    public void setSize(char size) {
        Size = size;
    }

    public char getTagName() {
        return TagName;
    }

    public void setTagName(char tagName) {
        TagName = tagName;
    }

    public char[] getPad2() {
        return pad2;
    }

    public void setPad2(char[] pad2) {
        this.pad2 = pad2;
    }

    @Override
    public String toString() {
        return "IN_EIP_TYPE_PRM_FLG{" +
                "Type=" + Type +
                ", pad1=" + Arrays.toString(pad1) +
                ", Address=" + Address +
                ", Size=" + Size +
                ", TagName=" + TagName +
                ", pad2=" + Arrays.toString(pad2) +
                '}';
    }
}
