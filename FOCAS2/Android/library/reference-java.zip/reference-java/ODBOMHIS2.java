package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBOMHIS2 {
    private short s_no;
    private short e_no;

    public short getS_no() {
        return s_no;
    }

    public void setS_no(short s_no) {
        this.s_no = s_no;
    }

    public short getE_no() {
        return e_no;
    }

    public void setE_no(short e_no) {
        this.e_no = e_no;
    }
    public static class OPM_HIS {
        private short dsp_flg;
        private short om_no;
        private short year;
        private short month;
        private short day;
        private short hour;
        private short minute;
        private short second;
        private String ope_msg;

        public short getDsp_flg() {
            return dsp_flg;
        }

        public void setDsp_flg(short dsp_flg) {
            this.dsp_flg = dsp_flg;
        }

        public short getOm_no() {
            return om_no;
        }

        public void setOm_no(short om_no) {
            this.om_no = om_no;
        }

        public short getYear() {
            return year;
        }

        public void setYear(short year) {
            this.year = year;
        }

        public short getMonth() {
            return month;
        }

        public void setMonth(short month) {
            this.month = month;
        }

        public short getDay() {
            return day;
        }

        public void setDay(short day) {
            this.day = day;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public String getOpe_msg() {
            return ope_msg;
        }

        public void setOpe_msg(String ope_msg) {
            this.ope_msg = ope_msg;
        }

        @Override
        public String toString() {
            return "OPM_HIS{" +
                    "dsp_flg=" + dsp_flg +
                    ", om_no=" + om_no +
                    ", year=" + year +
                    ", month=" + month +
                    ", day=" + day +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", ope_msg=" + ope_msg +
                    '}';
        }
    }
    private OPM_HIS opm_his[];

    public OPM_HIS[] getOpm_his() {
        return opm_his;
    }

    public void setOpm_his(OPM_HIS[] opm_his) {
        this.opm_his = opm_his;
    }

    @Override
    public String toString() {
        return "ODBOMHIS2{" +
                "s_no=" + s_no +
                ", e_no=" + e_no +
                ", opm_his=" + Arrays.toString(opm_his) +
                '}';
    }

    public void Dispose(){
        opm_his = null;
    }
}
