package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBTWP_3P_FMT {
    private double p1[];
    private double p2[];
    private double p3[];
    private double sft[];
    private double rot;
    private int reserve[];

    public double[] getP1() {
        return p1;
    }

    public void setP1(double[] p1) {
        this.p1 = p1;
    }

    public double[] getP2() {
        return p2;
    }

    public void setP2(double[] p2) {
        this.p2 = p2;
    }

    public double[] getP3() {
        return p3;
    }

    public void setP3(double[] p3) {
        this.p3 = p3;
    }

    public double[] getSft() {
        return sft;
    }

    public void setSft(double[] sft) {
        this.sft = sft;
    }

    public double getRot() {
        return rot;
    }

    public void setRot(double rot) {
        this.rot = rot;
    }

    public int[] getReserve() {
        return reserve;
    }

    public void setReserve(int[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IDBTWP_3P_FMT{" +
                "p1=" + Arrays.toString(p1) +
                ", p2=" + Arrays.toString(p2) +
                ", p3=" + Arrays.toString(p3) +
                ", sft=" + Arrays.toString(sft) +
                ", rot=" + rot +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
