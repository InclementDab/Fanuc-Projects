package jp.co.fanuc.fwlibe1;


public class ODBMDDINFO {
   private short           status;
   private short           prot;
   private short           year;
   private short           month;
   private short           day;
   private short           hour;
   private short           min;
   private short           sec;
    private int   reg_code;
    private int   cur_code;
   private short           modulate;

    public short getStatus() {
        return status;
    }

    public void setStatus(short status) {
        this.status = status;
    }

    public short getProt() {
        return prot;
    }

    public void setProt(short prot) {
        this.prot = prot;
    }

    public short getYear() {
        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public short getMonth() {
        return month;
    }

    public void setMonth(short month) {
        this.month = month;
    }

    public short getDay() {
        return day;
    }

    public void setDay(short day) {
        this.day = day;
    }

    public short getHour() {
        return hour;
    }

    public void setHour(short hour) {
        this.hour = hour;
    }

    public short getMin() {
        return min;
    }

    public void setMin(short min) {
        this.min = min;
    }

    public short getSec() {
        return sec;
    }

    public void setSec(short sec) {
        this.sec = sec;
    }

    public int getReg_code() {
        return reg_code;
    }

    public void setReg_code(int reg_code) {
        this.reg_code = reg_code;
    }

    public int getCur_code() {
        return cur_code;
    }

    public void setCur_code(int cur_code) {
        this.cur_code = cur_code;
    }

    public short getModulate() {
        return modulate;
    }

    public void setModulate(short modulate) {
        this.modulate = modulate;
    }

    @Override
    public String toString() {
        return "ODBMDDINFO{" +
                "status=" + status +
                ", prot=" + prot +
                ", year=" + year +
                ", month=" + month +
                ", day=" + day +
                ", hour=" + hour +
                ", min=" + min +
                ", sec=" + sec +
                ", reg_code=" + reg_code +
                ", cur_code=" + cur_code +
                ", modulate=" + modulate +
                '}';
    }
}
