package jp.co.fanuc.fwlibe1;


public class IN_EIPA_BASIC_PRM {private EIP_COMMON_PRM Common;
    private char Option2;
    private char AllocMax;
    private short ConnectMax;
    private short RPI_Min;
    private short RPI_Max;

    public EIP_COMMON_PRM getCommon() {
        return Common;
    }

    public void setCommon(EIP_COMMON_PRM common) {
        Common = common;
    }

    public char getOption2() {
        return Option2;
    }

    public void setOption2(char option2) {
        Option2 = option2;
    }

    public char getAllocMax() {
        return AllocMax;
    }

    public void setAllocMax(char allocMax) {
        AllocMax = allocMax;
    }

    public short getConnectMax() {
        return ConnectMax;
    }

    public void setConnectMax(short connectMax) {
        ConnectMax = connectMax;
    }

    public short getRPI_Min() {
        return RPI_Min;
    }

    public void setRPI_Min(short RPI_Min) {
        this.RPI_Min = RPI_Min;
    }

    public short getRPI_Max() {
        return RPI_Max;
    }

    public void setRPI_Max(short RPI_Max) {
        this.RPI_Max = RPI_Max;
    }
    public static class STATUS {
        private short Path;
        private short Addr;
        private int No;

        public short getPath() {
            return Path;
        }

        public void setPath(short path) {
            Path = path;
        }

        public short getAddr() {
            return Addr;
        }

        public void setAddr(short addr) {
            Addr = addr;
        }

        public int getNo() {
            return No;
        }

        public void setNo(int no) {
            No = no;
        }

        @Override
        public String toString() {
            return "STATUS{" +
                    "Path=" + Path +
                    ", Addr=" + Addr +
                    ", No=" + No +
                    '}';
        }
    }
    private STATUS Status;
    private int StatusSize;

    public STATUS getStatus() {
        return Status;
    }

    public void setStatus(STATUS status) {
        Status = status;
    }

    public int getStatusSize() {
        return StatusSize;
    }

    public void setStatusSize(int statusSize) {
        StatusSize = statusSize;
    }

    @Override
    public String toString() {
        return "IN_EIPA_BASIC_PRM{" +
                "Common=" + Common +
                ", Option2=" + Option2 +
                ", AllocMax=" + AllocMax +
                ", ConnectMax=" + ConnectMax +
                ", RPI_Min=" + RPI_Min +
                ", RPI_Max=" + RPI_Max +
                ", Status=" + Status +
                ", StatusSize=" + StatusSize +
                '}';
    }
}
