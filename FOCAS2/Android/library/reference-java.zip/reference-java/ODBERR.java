package jp.co.fanuc.fwlibe1;


public class ODBERR {
    private short err_no;
    private short err_dtno;

    public short getErr_no() {
        return err_no;
    }

    public void setErr_no(short err_no) {
        this.err_no = err_no;
    }

    public short getErr_dtno() {
        return err_dtno;
    }

    public void setErr_dtno(short err_dtno) {
        this.err_dtno = err_dtno;
    }

    @Override
    public String toString() {
        return "ODBERR{" +
                "err_no=" + err_no +
                ", err_dtno=" + err_dtno +
                '}';
    }
}
