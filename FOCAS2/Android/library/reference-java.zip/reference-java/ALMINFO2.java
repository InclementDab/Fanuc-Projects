package jp.co.fanuc.fwlibe1;

import java.util.Arrays;

public class ALMINFO2 {
    public static class ALM1 {
        public static class ALM {
            private short axis;
            private short alm_no;

            public short getAxis() {
                return axis;
            }

            public void setAxis(short axis) {
                this.axis = axis;
            }

            public short getAlm_no() {
                return alm_no;
            }

            public void setAlm_no(short alm_no) {
                this.alm_no = alm_no;
            }

            @Override
            public String toString() {
                return "ALM{" +
                        "axis=" + axis +
                        ", alm_no=" + alm_no +
                        '}';
            }
        }

        private ALM alm[];
        private short data_end;

        public ALM[] getAlm() {
            return alm;
        }

        public void setAlm(ALM[] alm) {
            this.alm = alm;
        }

        public short getData_end() {
            return data_end;
        }

        public void setData_end(short data_end) {
            this.data_end = data_end;
        }

        @Override
        public String toString() {
            return "ALM1{" +
                    "alm=" + Arrays.toString(alm) +
                    ", data_end=" + data_end +
                    '}';
        }

        public void Dispose() {
			alm = null;
        }
    }

    private ALM1 alm1;

    public ALM1 getAlm1() {
        return alm1;
    }

    public void setAlm1(ALM1 alm1) {
        this.alm1 = alm1;
    }

    public static class ALM2 {
        public static class ALM {
            private short axis;
            private short alm_no;
            private short msg_len;
            private char alm_msg[];

            public short getAxis() {
                return axis;
            }

            public void setAxis(short axis) {
                this.axis = axis;
            }

            public short getAlm_no() {
                return alm_no;
            }

            public void setAlm_no(short alm_no) {
                this.alm_no = alm_no;
            }

            public short getMsg_len() {
                return msg_len;
            }

            public void setMsg_len(short msg_len) {
                this.msg_len = msg_len;
            }

            public char[] getAlm_msg() {
                return alm_msg;
            }

            public void setAlm_msg(char[] alm_msg) {
                this.alm_msg = alm_msg;
            }

            @Override
            public String toString() {
                return "ALM{" +
                        "axis=" + axis +
                        ", alm_no=" + alm_no +
                        ", msg_len=" + msg_len +
                        ", alm_msg=" + Arrays.toString(alm_msg) +
                        '}';
            }
        }

        private ALM alm[];
        private short data_end;

        public ALM[] getAlm() {
            return alm;
        }

        public void setAlm(ALM[] alm) {
            this.alm = alm;
        }

        public short getData_end() {
            return data_end;
        }

        public void setData_end(short data_end) {
            this.data_end = data_end;
        }

        @Override
        public String toString() {
            return "ALM2{" +
                    "alm=" + Arrays.toString(alm) +
                    ", data_end=" + data_end +
                    '}';
        }

        public void Dispose() {
            alm = null;
        }
    }

    private ALM2 alm2;

    public ALM2 getAlm2() {
        return alm2;
    }

    public void setAlm2(ALM2 alm2) {
        this.alm2 = alm2;
    }

    @Override
    public String toString() {
        return "ALMINFO2{" +
                "alm1=" + alm1 +
                ", alm2=" + alm2 +
                '}';
    }

    public void Dispose(){
		if (alm1 != null) {
        	alm1.Dispose();
        	alm1 = null;
		}
		
		if (alm2 != null) {
        	alm2.Dispose();
        	alm2 = null;
		}
    }
}

