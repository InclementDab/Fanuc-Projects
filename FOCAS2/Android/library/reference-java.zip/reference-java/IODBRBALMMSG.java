package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBRBALMMSG {
    private char msg[];

    public char[] getMsg() {
        return msg;
    }

    public void setMsg(char[] msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "IODBRBALMMSG{" +
                "msg=" + Arrays.toString(msg) +
                '}';
    }
}
