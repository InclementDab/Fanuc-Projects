package jp.co.fanuc.fwlibe1;


public class ODBM {
    private short datano;
    private short dummy;
    private int mcr_val;
    private short dec_val;

    public short getDatano() {
        return datano;
    }

    public void setDatano(short datano) {
        this.datano = datano;
    }

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public int getMcr_val() {

        return mcr_val;
    }

    public void setMcr_val(int mcr_val) {
        this.mcr_val = mcr_val;
    }

    public short getDec_val() {

        return dec_val;
    }

    public void setDec_val(short dec_val) {
        this.dec_val = dec_val;
    }

    @Override
    public String toString() {
        return "ODBM{" +
                "datano=" + datano +
                ", dummy=" + dummy +
                ", mcr_val=" + mcr_val +
                ", dec_val=" + dec_val +
                '}';
    }
}
