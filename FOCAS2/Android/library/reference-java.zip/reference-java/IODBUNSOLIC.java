package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBUNSOLIC {
    private char ipaddr[];
    private short port;
    private short reqaddr;
    private short pmcno;
    private short retry;
    private short timeout;
    private short alivetime;
    private short setno;

    public char[] getIpaddr() {
        return ipaddr;
    }

    public void setIpaddr(char[] ipaddr) {
        this.ipaddr = ipaddr;
    }

    public short getPort() {
        return port;
    }

    public void setPort(short port) {
        this.port = port;
    }

    public short getReqaddr() {
        return reqaddr;
    }

    public void setReqaddr(short reqaddr) {
        this.reqaddr = reqaddr;
    }

    public short getPmcno() {
        return pmcno;
    }

    public void setPmcno(short pmcno) {
        this.pmcno = pmcno;
    }

    public short getRetry() {
        return retry;
    }

    public void setRetry(short retry) {
        this.retry = retry;
    }

    public short getTimeout() {
        return timeout;
    }

    public void setTimeout(short timeout) {
        this.timeout = timeout;
    }

    public short getAlivetime() {
        return alivetime;
    }

    public void setAlivetime(short alivetime) {
        this.alivetime = alivetime;
    }

    public short getSetno() {
        return setno;
    }

    public void setSetno(short setno) {
        this.setno = setno;
    }

    public static class RDDATA {
        public static class PMC {
            private short type;
            private short rdaddr;
            private short rdno;
            private short rdsize;

            public short getType() {
                return type;
            }

            public void setType(short type) {
                this.type = type;
            }

            public short getRdaddr() {
                return rdaddr;
            }

            public void setRdaddr(short rdaddr) {
                this.rdaddr = rdaddr;
            }

            public short getRdno() {
                return rdno;
            }

            public void setRdno(short rdno) {
                this.rdno = rdno;
            }

            public short getRdsize() {
                return rdsize;
            }

            public void setRdsize(short rdsize) {
                this.rdsize = rdsize;
            }

            @Override
            public String toString() {
                return "PMC{" +
                        "type=" + type +
                        ", rdaddr=" + rdaddr +
                        ", rdno=" + rdno +
                        ", rdsize=" + rdsize +
                        '}';
            }
        }
        public static class DMY {
            private short type;
            private int dummy1;
            private short dummy2;

            public short getType() {
                return type;
            }

            public void setType(short type) {
                this.type = type;
            }

            public int getDummy1() {
                return dummy1;
            }

            public void setDummy1(int dummy1) {
                this.dummy1 = dummy1;
            }

            public short getDummy2() {
                return dummy2;
            }

            public void setDummy2(short dummy2) {
                this.dummy2 = dummy2;
            }

            @Override
            public String toString() {
                return "DMY{" +
                        "type=" + type +
                        ", dummy1=" + dummy1 +
                        ", dummy2=" + dummy2 +
                        '}';
            }
        }
        private PMC pmc;
        private DMY dmy;

        public PMC getPmc() {
            return pmc;
        }

        public void setPmc(PMC pmc) {
            this.pmc = pmc;
        }

        public DMY getDmy() {
            return dmy;
        }

        public void setDmy(DMY dmy) {
            this.dmy = dmy;
        }

        @Override
        public String toString() {
            return "RDDATA{" +
                    "pmc=" + pmc +
                    ", dmy=" + dmy +
                    '}';
        }
    }
    private RDDATA rddata[];

    public RDDATA[] getRddata() {
        return rddata;
    }

    public void setRddata(RDDATA[] rddata) {
        this.rddata = rddata;
    }

    @Override
    public String toString() {
        return "IODBUNSOLIC{" +
                "ipaddr=" + Arrays.toString(ipaddr) +
                ", port=" + port +
                ", reqaddr=" + reqaddr +
                ", pmcno=" + pmcno +
                ", retry=" + retry +
                ", timeout=" + timeout +
                ", alivetime=" + alivetime +
                ", setno=" + setno +
                ", rddata=" + Arrays.toString(rddata) +
                '}';
    }
}
