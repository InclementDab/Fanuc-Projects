package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class HSPINFO {
    private char prminfo[][];

    public char[][] getPrminfo() {
        return prminfo;
    }

    public void setPrminfo(char[][] prminfo) {
        this.prminfo = prminfo;
    }

    @Override
    public String toString() {
        return "HSPINFO{" +
                "prminfo=" + Arrays.toString(prminfo) +
                '}';
    }
}
