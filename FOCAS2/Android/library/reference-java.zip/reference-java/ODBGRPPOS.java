package jp.co.fanuc.fwlibe1;


public class ODBGRPPOS {
    private POSVAL ads;
    private POSVAL mcn;
    private short feed_type;
    private short reserved;

    public POSVAL getAds() {
        return ads;
    }

    public void setAds(POSVAL ads) {
        this.ads = ads;
    }

    public POSVAL getMcn() {
        return mcn;
    }

    public void setMcn(POSVAL mcn) {
        this.mcn = mcn;
    }

    public short getFeed_type() {
        return feed_type;
    }

    public void setFeed_type(short feed_type) {
        this.feed_type = feed_type;
    }

    public short getReserved() {
        return reserved;
    }

    public void setReserved(short reserved) {
        this.reserved = reserved;
    }

    @Override
    public String toString() {
        return "ODBGRPPOS{" +
                "ads=" + ads +
                ", mcn=" + mcn +
                ", feed_type=" + feed_type +
                ", reserved=" + reserved +
                '}';
    }
}
