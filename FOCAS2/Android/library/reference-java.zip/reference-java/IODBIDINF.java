package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBIDINF {
    private int id_no;
    private short drv_no;
    private short acc_element;
    private short err_general;
    private short err_id_no;
    private short err_id_name;
    private short err_attr;
    private short err_unit;
    private short err_min_val;
    private short err_max_val;
    private short id_name_len;
    private short id_name_max;
    private char id_name[];
    private int attr;
    private short unit_len;
    private short unit_max;
    private char unit[];
    private int min_val;
    private int max_val;

    public int getId_no() {
        return id_no;
    }

    public void setId_no(int id_no) {
        this.id_no = id_no;
    }

    public short getDrv_no() {
        return drv_no;
    }

    public void setDrv_no(short drv_no) {
        this.drv_no = drv_no;
    }

    public short getAcc_element() {
        return acc_element;
    }

    public void setAcc_element(short acc_element) {
        this.acc_element = acc_element;
    }

    public short getErr_general() {
        return err_general;
    }

    public void setErr_general(short err_general) {
        this.err_general = err_general;
    }

    public short getErr_id_no() {
        return err_id_no;
    }

    public void setErr_id_no(short err_id_no) {
        this.err_id_no = err_id_no;
    }

    public short getErr_id_name() {
        return err_id_name;
    }

    public void setErr_id_name(short err_id_name) {
        this.err_id_name = err_id_name;
    }

    public short getErr_attr() {
        return err_attr;
    }

    public void setErr_attr(short err_attr) {
        this.err_attr = err_attr;
    }

    public short getErr_unit() {
        return err_unit;
    }

    public void setErr_unit(short err_unit) {
        this.err_unit = err_unit;
    }

    public short getErr_min_val() {
        return err_min_val;
    }

    public void setErr_min_val(short err_min_val) {
        this.err_min_val = err_min_val;
    }

    public short getErr_max_val() {
        return err_max_val;
    }

    public void setErr_max_val(short err_max_val) {
        this.err_max_val = err_max_val;
    }

    public short getId_name_len() {
        return id_name_len;
    }

    public void setId_name_len(short id_name_len) {
        this.id_name_len = id_name_len;
    }

    public short getId_name_max() {
        return id_name_max;
    }

    public void setId_name_max(short id_name_max) {
        this.id_name_max = id_name_max;
    }

    public char[] getId_name() {
        return id_name;
    }

    public void setId_name(char[] id_name) {
        this.id_name = id_name;
    }

    public int getAttr() {
        return attr;
    }

    public void setAttr(int attr) {
        this.attr = attr;
    }

    public short getUnit_len() {
        return unit_len;
    }

    public void setUnit_len(short unit_len) {
        this.unit_len = unit_len;
    }

    public short getUnit_max() {
        return unit_max;
    }

    public void setUnit_max(short unit_max) {
        this.unit_max = unit_max;
    }

    public char[] getUnit() {
        return unit;
    }

    public void setUnit(char[] unit) {
        this.unit = unit;
    }

    public int getMin_val() {
        return min_val;
    }

    public void setMin_val(int min_val) {
        this.min_val = min_val;
    }

    public int getMax_val() {
        return max_val;
    }

    public void setMax_val(int max_val) {
        this.max_val = max_val;
    }

    @Override
    public String toString() {
        return "IODBIDINF{" +
                "id_no=" + id_no +
                ", drv_no=" + drv_no +
                ", acc_element=" + acc_element +
                ", err_general=" + err_general +
                ", err_id_no=" + err_id_no +
                ", err_id_name=" + err_id_name +
                ", err_attr=" + err_attr +
                ", err_unit=" + err_unit +
                ", err_min_val=" + err_min_val +
                ", err_max_val=" + err_max_val +
                ", id_name_len=" + id_name_len +
                ", id_name_max=" + id_name_max +
                ", id_name=" + Arrays.toString(id_name) +
                ", attr=" + attr +
                ", unit_len=" + unit_len +
                ", unit_max=" + unit_max +
                ", unit=" + Arrays.toString(unit) +
                ", min_val=" + min_val +
                ", max_val=" + max_val +
                '}';
    }
}
