package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBEDGE {
    private short slct;
    private short angle;
    private short power;
    private short freq;
    private short duty;
    private int pier_t;
    private short g_press;
    private short g_kind;
    private int r_len;
    private short r_feed;
    private short r_freq;
    private short r_duty;
    private short gap;
    private short reserve[];

    public short getSlct() {
        return slct;
    }

    public void setSlct(short slct) {
        this.slct = slct;
    }

    public short getAngle() {
        return angle;
    }

    public void setAngle(short angle) {
        this.angle = angle;
    }

    public short getPower() {
        return power;
    }

    public void setPower(short power) {
        this.power = power;
    }

    public short getFreq() {
        return freq;
    }

    public void setFreq(short freq) {
        this.freq = freq;
    }

    public short getDuty() {
        return duty;
    }

    public void setDuty(short duty) {
        this.duty = duty;
    }

    public int getPier_t() {
        return pier_t;
    }

    public void setPier_t(int pier_t) {
        this.pier_t = pier_t;
    }

    public short getG_press() {
        return g_press;
    }

    public void setG_press(short g_press) {
        this.g_press = g_press;
    }

    public short getG_kind() {
        return g_kind;
    }

    public void setG_kind(short g_kind) {
        this.g_kind = g_kind;
    }

    public int getR_len() {
        return r_len;
    }

    public void setR_len(int r_len) {
        this.r_len = r_len;
    }

    public short getR_feed() {
        return r_feed;
    }

    public void setR_feed(short r_feed) {
        this.r_feed = r_feed;
    }

    public short getR_freq() {
        return r_freq;
    }

    public void setR_freq(short r_freq) {
        this.r_freq = r_freq;
    }

    public short getR_duty() {
        return r_duty;
    }

    public void setR_duty(short r_duty) {
        this.r_duty = r_duty;
    }

    public short getGap() {
        return gap;
    }

    public void setGap(short gap) {
        this.gap = gap;
    }

    public short[] getReserve() {
        return reserve;
    }

    public void setReserve(short[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBEDGE{" +
                "slct=" + slct +
                ", angle=" + angle +
                ", power=" + power +
                ", freq=" + freq +
                ", duty=" + duty +
                ", pier_t=" + pier_t +
                ", g_press=" + g_press +
                ", g_kind=" + g_kind +
                ", r_len=" + r_len +
                ", r_feed=" + r_feed +
                ", r_freq=" + r_freq +
                ", r_duty=" + r_duty +
                ", gap=" + gap +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
