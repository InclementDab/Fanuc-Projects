package jp.co.fanuc.fwlibe1;


public class IODBSIGAD {
    private char adr;
    private char reserve;
    private short no;
    private short size;

    public char getAdr() {
        return adr;
    }

    public void setAdr(char adr) {
        this.adr = adr;
    }

    public char getReserve() {
        return reserve;
    }

    public void setReserve(char reserve) {
        this.reserve = reserve;
    }

    public short getNo() {
        return no;
    }

    public void setNo(short no) {
        this.no = no;
    }

    public short getSize() {
        return size;
    }

    public void setSize(short size) {
        this.size = size;
    }

    @Override
    public String toString() {
        return "IODBSIGAD{" +
                "adr=" + adr +
                ", reserve=" + reserve +
                ", no=" + no +
                ", size=" + size +
                '}';
    }
}
