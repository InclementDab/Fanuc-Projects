package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMDGMSG {
    private int alm_no;
    private short msgidx;
    private short reserved;
    private char type[];
    private char part[];
    private char level[];
    private char add_inf[];
    private char mark[];
    private char message[];
    private char cause[];

    public int getAlm_no() {
        return alm_no;
    }

    public void setAlm_no(int alm_no) {
        this.alm_no = alm_no;
    }

    public short getMsgidx() {
        return msgidx;
    }

    public void setMsgidx(short msgidx) {
        this.msgidx = msgidx;
    }

    public short getReserved() {
        return reserved;
    }

    public void setReserved(short reserved) {
        this.reserved = reserved;
    }

    public char[] getType() {
        return type;
    }

    public void setType(char[] type) {
        this.type = type;
    }

    public char[] getPart() {
        return part;
    }

    public void setPart(char[] part) {
        this.part = part;
    }

    public char[] getLevel() {
        return level;
    }

    public void setLevel(char[] level) {
        this.level = level;
    }

    public char[] getAdd_inf() {
        return add_inf;
    }

    public void setAdd_inf(char[] add_inf) {
        this.add_inf = add_inf;
    }

    public char[] getMark() {
        return mark;
    }

    public void setMark(char[] mark) {
        this.mark = mark;
    }

    public char[] getMessage() {
        return message;
    }

    public void setMessage(char[] message) {
        this.message = message;
    }

    public char[] getCause() {
        return cause;
    }

    public void setCause(char[] cause) {
        this.cause = cause;
    }

    @Override
    public String toString() {
        return "ODBMDGMSG{" +
                "alm_no=" + alm_no +
                ", msgidx=" + msgidx +
                ", reserved=" + reserved +
                ", type=" + Arrays.toString(type) +
                ", part=" + Arrays.toString(part) +
                ", level=" + Arrays.toString(level) +
                ", add_inf=" + Arrays.toString(add_inf) +
                ", mark=" + Arrays.toString(mark) +
                ", message=" + Arrays.toString(message) +
                ", cause=" + Arrays.toString(cause) +
                '}';
    }
}
