package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBFTRMTX {
    private double orgn[];
    private double rot[][];

    public double[] getOrgn() {
        return orgn;
    }

    public void setOrgn(double[] orgn) {
        this.orgn = orgn;
    }

    public double[][] getRot() {
        return rot;
    }

    public void setRot(double[][] rot) {
        this.rot = rot;
    }

    @Override
    public String toString() {
        return "ODBFTRMTX{" +
                "orgn=" + Arrays.toString(orgn) +
                ", rot=" + Arrays.toString(rot) +
                '}';
    }
}
