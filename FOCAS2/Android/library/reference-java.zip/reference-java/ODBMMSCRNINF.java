package jp.co.fanuc.fwlibe1;


public class ODBMMSCRNINF {
    private int scrn_id;

    public int getScrn_id() {
        return scrn_id;
    }

    public void setScrn_id(int scrn_id) {
        this.scrn_id = scrn_id;
    }

    @Override
    public String toString() {
        return "ODBMMSCRNINF{" +
                "scrn_id=" + scrn_id +
                '}';
    }
}
