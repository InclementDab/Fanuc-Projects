package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDB3DMSTOP {
    public static class PATH {
        private int plus;
        private int minus;

        public int getPlus() {
            return plus;
        }

        public void setPlus(int plus) {
            this.plus = plus;
        }

        public int getMinus() {
            return minus;
        }

        public void setMinus(int minus) {
            this.minus = minus;
        }

        @Override
        public String toString() {
            return "PATH{" +
                    "plus=" + plus +
                    ", minus=" + minus +
                    '}';
        }
    }
    private PATH path[];

    public PATH[] getPath() {
        return path;
    }

    public void setPath(PATH[] path) {
        this.path = path;
    }

    @Override
    public String toString() {
        return "IDB3DMSTOP{" +
                "path=" + Arrays.toString(path) +
                '}';
    }
}
