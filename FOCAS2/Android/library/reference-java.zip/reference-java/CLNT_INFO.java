package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class CLNT_INFO {
    private char IpAddress[];
    private int SocketId;
    private int ConnectTima;

    public char[] getIpAddress() {
        return IpAddress;
    }

    public void setIpAddress(char[] ipAddress) {
        IpAddress = ipAddress;
    }

    public int getSocketId() {
        return SocketId;
    }

    public void setSocketId(int socketId) {
        SocketId = socketId;
    }

    public int getConnectTima() {
        return ConnectTima;
    }

    public void setConnectTima(int connectTima) {
        ConnectTima = connectTima;
    }

    @Override
    public String toString() {
        return "CLNT_INFO{" +
                "IpAddress=" + Arrays.toString(IpAddress) +
                ", SocketId=" + SocketId +
                ", ConnectTima=" + ConnectTima +
                '}';
    }
}
