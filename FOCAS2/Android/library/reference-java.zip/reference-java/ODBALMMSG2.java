package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBALMMSG2 {
    private int alm_no;
    private short type;
    private short axis;
    private short dummy;
    private short msg_len;
    private byte[] alm_msg;

    public int getAlm_no() {
        return alm_no;
    }

    public void setAlm_no(int alm_no) {
        this.alm_no = alm_no;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getAxis() {
        return axis;
    }

    public void setAxis(short axis) {
        this.axis = axis;
    }

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public short getMsg_len() {
        return msg_len;
    }

    public void setMsg_len(short msg_len) {
        this.msg_len = msg_len;
    }

    public byte[] getAlm_msg() {
        return alm_msg;
    }

    public void setAlm_msg(byte[] alm_msg) {
        this.alm_msg = alm_msg;
    }

    @Override
    public String toString() {
        return "ODBALMMSG2{" +
                "alm_no=" + alm_no +
                ", type=" + type +
                ", axis=" + axis +
                ", dummy=" + dummy +
                ", msg_len=" + msg_len +
                ", alm_msg=" + Arrays.toString(alm_msg) +
                '}';
    }
}
