package jp.co.fanuc.fwlibe1;


public class IODBRTMIO {
    private short adr_type;
    private short dummy;
    private int no;
    private char bit;

    public short getAdr_type() {
        return adr_type;
    }

    public void setAdr_type(short adr_type) {
        this.adr_type = adr_type;
    }

    public short getDummy() {
        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public char getBit() {
        return bit;
    }

    public void setBit(char bit) {
        this.bit = bit;
    }

    @Override
    public String toString() {
        return "IODBRTMIO{" +
                "adr_type=" + adr_type +
                ", dummy=" + dummy +
                ", no=" + no +
                ", bit=" + bit +
                '}';
    }
}
