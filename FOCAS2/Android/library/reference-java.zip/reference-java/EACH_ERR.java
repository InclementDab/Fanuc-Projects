package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class EACH_ERR {
    private char   ErrFlag;
    private char   ErrNode;
    private char            Reserved[];

    public char getErrFlag() {
        return ErrFlag;
    }

    public void setErrFlag(char errFlag) {
        ErrFlag = errFlag;
    }

    public char getErrNode() {
        return ErrNode;
    }

    public void setErrNode(char errNode) {
        ErrNode = errNode;
    }

    public char[] getReserved() {
        return Reserved;
    }

    public void setReserved(char[] reserved) {
        Reserved = reserved;
    }

    @Override
    public String toString() {
        return "EACH_ERR{" +
                "ErrFlag=" + ErrFlag +
                ", ErrNode=" + ErrNode +
                ", Reserved=" + Arrays.toString(Reserved) +
                '}';
    }
}
