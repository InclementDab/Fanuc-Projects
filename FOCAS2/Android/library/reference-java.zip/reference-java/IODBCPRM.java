package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBCPRM {
    private char NcApli[];
    private char Dummy1;
    private char HostApli[];
    private char Dummy2;
    private int StatPstv;
    private int StatNgtv;
    private int Statmask;
    private int AlarmStat;
    private int PsclHaddr;
    private int PsclLaddr;
    private short SvcMode1;
    private short SvcMode2;
    private int FileTout;
    private int RemTout;

    public char[] getNcApli() {
        return NcApli;
    }

    public void setNcApli(char[] ncApli) {
        NcApli = ncApli;
    }

    public char getDummy1() {
        return Dummy1;
    }

    public void setDummy1(char dummy1) {
        Dummy1 = dummy1;
    }

    public char[] getHostApli() {
        return HostApli;
    }

    public void setHostApli(char[] hostApli) {
        HostApli = hostApli;
    }

    public char getDummy2() {
        return Dummy2;
    }

    public void setDummy2(char dummy2) {
        Dummy2 = dummy2;
    }

    public int getStatPstv() {
        return StatPstv;
    }

    public void setStatPstv(int statPstv) {
        StatPstv = statPstv;
    }

    public int getStatNgtv() {
        return StatNgtv;
    }

    public void setStatNgtv(int statNgtv) {
        StatNgtv = statNgtv;
    }

    public int getStatmask() {
        return Statmask;
    }

    public void setStatmask(int statmask) {
        Statmask = statmask;
    }

    public int getAlarmStat() {
        return AlarmStat;
    }

    public void setAlarmStat(int alarmStat) {
        AlarmStat = alarmStat;
    }

    public int getPsclHaddr() {
        return PsclHaddr;
    }

    public void setPsclHaddr(int psclHaddr) {
        PsclHaddr = psclHaddr;
    }

    public int getPsclLaddr() {
        return PsclLaddr;
    }

    public void setPsclLaddr(int psclLaddr) {
        PsclLaddr = psclLaddr;
    }

    public short getSvcMode1() {
        return SvcMode1;
    }

    public void setSvcMode1(short svcMode1) {
        SvcMode1 = svcMode1;
    }

    public short getSvcMode2() {
        return SvcMode2;
    }

    public void setSvcMode2(short svcMode2) {
        SvcMode2 = svcMode2;
    }

    public int getFileTout() {
        return FileTout;
    }

    public void setFileTout(int fileTout) {
        FileTout = fileTout;
    }

    public int getRemTout() {
        return RemTout;
    }

    public void setRemTout(int remTout) {
        RemTout = remTout;
    }

    @Override
    public String toString() {
        return "IODBCPRM{" +
                "NcApli=" + Arrays.toString(NcApli) +
                ", Dummy1=" + Dummy1 +
                ", HostApli=" + Arrays.toString(HostApli) +
                ", Dummy2=" + Dummy2 +
                ", StatPstv=" + StatPstv +
                ", StatNgtv=" + StatNgtv +
                ", Statmask=" + Statmask +
                ", AlarmStat=" + AlarmStat +
                ", PsclHaddr=" + PsclHaddr +
                ", PsclLaddr=" + PsclLaddr +
                ", SvcMode1=" + SvcMode1 +
                ", SvcMode2=" + SvcMode2 +
                ", FileTout=" + FileTout +
                ", RemTout=" + RemTout +
                '}';
    }
}
