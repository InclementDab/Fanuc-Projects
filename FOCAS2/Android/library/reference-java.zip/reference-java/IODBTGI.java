package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTGI {
    private short s_grp;
    private short dummy;
    private short e_grp;

    public short getS_grp() {
        return s_grp;
    }

    public void setS_grp(short s_grp) {
        this.s_grp = s_grp;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public short getE_grp() {

        return e_grp;
    }

    public void setE_grp(short e_grp) {
        this.e_grp = e_grp;
    }

    public static class DATA {
        private int n_tool;
        private int count_value;
        private int counter;
        private int count_type;

        public int getN_tool() {
            return n_tool;
        }

        public void setN_tool(int n_tool) {
            this.n_tool = n_tool;
        }

        public int getCount_value() {

            return count_value;
        }

        public void setCount_value(int count_value) {
            this.count_value = count_value;
        }

        public int getCounter() {

            return counter;
        }

        public void setCounter(int counter) {
            this.counter = counter;
        }

        public int getCount_type() {

            return count_type;
        }

        public void setCount_type(int count_type) {
            this.count_type = count_type;
        }

        @Override
        public String toString() {
            return "DATA{" +
                    "n_tool=" + n_tool +
                    ", count_value=" + count_value +
                    ", counter=" + counter +
                    ", count_type=" + count_type +
                    '}';
        }
    }
    private DATA data[];

    public DATA[] getData() {
        return data;
    }

    public void setData(DATA[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IODBTGI{" +
                "s_grp=" + s_grp +
                ", dummy=" + dummy +
                ", e_grp=" + e_grp +
                ", data=" + Arrays.toString(data) +
                '}';
    }

    public void Dispose() {
        data = null;
    }
}
