package jp.co.fanuc.fwlibe1;


public class IODBTLGEOM {
    private byte l_pot_num;
    private byte r_pot_num;
    private byte u_pot_num;
    private byte d_pot_num;
    private byte tl_geom_num;

    public byte getL_pot_num() {
        return l_pot_num;
    }

    public void setL_pot_num(byte l_pot_num) {
        this.l_pot_num = l_pot_num;
    }

    public byte getR_pot_num() {
        return r_pot_num;
    }

    public void setR_pot_num(byte r_pot_num) {
        this.r_pot_num = r_pot_num;
    }

    public byte getU_pot_num() {
        return u_pot_num;
    }

    public void setU_pot_num(byte u_pot_num) {
        this.u_pot_num = u_pot_num;
    }

    public byte getD_pot_num() {
        return d_pot_num;
    }

    public void setD_pot_num(byte d_pot_num) {
        this.d_pot_num = d_pot_num;
    }

    public byte getTl_geom_num() {
        return tl_geom_num;
    }

    public void setTl_geom_num(byte tl_geom_num) {
        this.tl_geom_num = tl_geom_num;
    }

    @Override
    public String toString() {
        return "IODBTLGEOM{" +
                "l_pot_num=" + l_pot_num +
                ", r_pot_num=" + r_pot_num +
                ", u_pot_num=" + u_pot_num +
                ", d_pot_num=" + d_pot_num +
                ", tl_geom_num=" + tl_geom_num +
                '}';
    }
}
