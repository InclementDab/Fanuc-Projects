package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBPDFPRG {
    private short year;
    private short mon;
    private short day;
    private short hour;
    private short min;
    private short sec;
    private int size;
    private int attr;
    private String comment;
    private String o_time;

    public short getYear() {
        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public short getMon() {

        return mon;
    }

    public void setMon(short mon) {
        this.mon = mon;
    }

    public short getDay() {

        return day;
    }

    public void setDay(short day) {
        this.day = day;
    }

    public short getHour() {

        return hour;
    }

    public void setHour(short hour) {
        this.hour = hour;
    }

    public short getMin() {

        return min;
    }

    public void setMin(short min) {
        this.min = min;
    }

    public short getSec() {

        return sec;
    }

    public void setSec(short sec) {
        this.sec = sec;
    }

    public int getSize() {

        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getAttr() {

        return attr;
    }

    public void setAttr(int attr) {
        this.attr = attr;
    }

    public String getComment() {

        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getO_time() {

        return o_time;
    }

    public void setO_time(String o_time) {
        this.o_time = o_time;
    }

    @Override
    public String toString() {
        return "ODBPDFPRG{" +
                "year=" + year +
                ", mon=" + mon +
                ", day=" + day +
                ", hour=" + hour +
                ", min=" + min +
                ", sec=" + sec +
                ", size=" + size +
                ", attr=" + attr +
                ", comment=" + comment +
                ", o_time=" + o_time +
                '}';
    }
}
