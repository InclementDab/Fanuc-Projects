package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBPMAINTE {
    private String name;
    private int type;
    private int total;
    private int remain;
    private int stat;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getRemain() {
        return remain;
    }

    public void setRemain(int remain) {
        this.remain = remain;
    }

    public int getStat() {
        return stat;
    }

    public void setStat(int stat) {
        this.stat = stat;
    }

    @Override
    public String toString() {
        return "IODBPMAINTE{" +
                "name=" + name +
                ", type=" + type +
                ", total=" + total +
                ", remain=" + remain +
                ", stat=" + stat +
                '}';
    }
}
