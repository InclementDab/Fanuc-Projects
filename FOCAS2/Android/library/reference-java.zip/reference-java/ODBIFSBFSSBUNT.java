package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBIFSBFSSBUNT {
    private short slv_unt_num;
    private short fssb_unt_num;
    private char name[];

    public short getSlv_unt_num() {
        return slv_unt_num;
    }

    public void setSlv_unt_num(short slv_unt_num) {
        this.slv_unt_num = slv_unt_num;
    }

    public short getFssb_unt_num() {
        return fssb_unt_num;
    }

    public void setFssb_unt_num(short fssb_unt_num) {
        this.fssb_unt_num = fssb_unt_num;
    }

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "ODBIFSBFSSBUNT{" +
                "slv_unt_num=" + slv_unt_num +
                ", fssb_unt_num=" + fssb_unt_num +
                ", name=" + Arrays.toString(name) +
                '}';
    }
}
