package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBBRS {
    private int dest[];
    private int dist[];

    public int[] getDest() {
        return dest;
    }

    public void setDest(int[] dest) {
        this.dest = dest;
    }

    public int[] getDist() {
        return dist;
    }

    public void setDist(int[] dist) {
        this.dist = dist;
    }

    @Override
    public String toString() {
        return "ODBBRS{" +
                "dest=" + Arrays.toString(dest) +
                ", dist=" + Arrays.toString(dist) +
                '}';
    }
}
