package jp.co.fanuc.fwlibe1;


public class IODBTLMGR_EDG {
    private short data_no;
    private short edge_no;

    public short getData_no() {
        return data_no;
    }

    public void setData_no(short data_no) {
        this.data_no = data_no;
    }

    public short getEdge_no() {
        return edge_no;
    }

    public void setEdge_no(short edge_no) {
        this.edge_no = edge_no;
    }

    @Override
    public String toString() {
        return "IODBTLMGR_EDG{" +
                "data_no=" + data_no +
                ", edge_no=" + edge_no +
                '}';
    }
}
