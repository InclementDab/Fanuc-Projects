package jp.co.fanuc.fwlibe1;


public class IODBMMMCSCRNDEFDAT {
    private ODBMMSCRNINF  scrninf;
    private int          icn_id;
    private int          msg_id;

    public ODBMMSCRNINF getScrninf() {
        return scrninf;
    }

    public void setScrninf(ODBMMSCRNINF scrninf) {
        this.scrninf = scrninf;
    }

    public int getIcn_id() {
        return icn_id;
    }

    public void setIcn_id(int icn_id) {
        this.icn_id = icn_id;
    }

    public int getMsg_id() {
        return msg_id;
    }

    public void setMsg_id(int msg_id) {
        this.msg_id = msg_id;
    }

    @Override
    public String toString() {
        return "IODBMMMCSCRNDEFDAT{" +
                "scrninf=" + scrninf +
                ", icn_id=" + icn_id +
                ", msg_id=" + msg_id +
                '}';
    }
}
