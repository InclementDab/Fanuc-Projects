package jp.co.fanuc.fwlibe1;

import java.util.Arrays;


public class IDBWRC {
    private short datano_s;
    private short dummy;
    private short datano_e;

    public short getDatano_s() {
        return datano_s;
    }

    public void setDatano_s(short datano_s) {
        this.datano_s = datano_s;
    }

    public short getDummy() {

        return dummy;
    }

    public void setDummy(short dummy) {
        this.dummy = dummy;
    }

    public short getDatano_e() {

        return datano_e;
    }

    public void setDatano_e(short datano_e) {
        this.datano_e = datano_e;
    }

    public static class DATA {
        private int dummy[];
        private int count;

        public int[] getDummy() {
            return dummy;
        }

        public void setDummy(int[] dummy) {
            this.dummy = dummy;
        }

        public int getCount() {

            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }

        @Override
        public String toString() {
            return "DATA{" +
                    "dummy=" + Arrays.toString(dummy) +
                    ", count=" + count +
                    '}';
        }
    }
    private DATA data[];

    public DATA[] getData() {
        return data;
    }

    public void setData(DATA[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "IDBWRC{" +
                "datano_s=" + datano_s +
                ", dummy=" + dummy +
                ", datano_e=" + datano_e +
                ", data=" + Arrays.toString(data) +
                '}';
    }

    public void Dispose() {
        	data = null;
    }
}
