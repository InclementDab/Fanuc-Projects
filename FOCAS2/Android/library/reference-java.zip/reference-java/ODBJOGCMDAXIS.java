package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBJOGCMDAXIS {
    private char name[];
    private int data;
    private int dec;

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public int getData() {

        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

    public int getDec() {

        return dec;
    }

    public void setDec(int dec) {
        this.dec = dec;
    }

    @Override
    public String toString() {
        return "ODBJOGCMDAXIS{" +
                "name=" + Arrays.toString(name) +
                ", data=" + data +
                ", dec=" + dec +
                '}';
    }
}
