package jp.co.fanuc.fwlibe1;


public class ODBM3 {
    private int datano;
    private int mcr_val;
    private short dec_val;

    public int getDatano() {
        return datano;
    }

    public void setDatano(int datano) {
        this.datano = datano;
    }

    public int getMcr_val() {

        return mcr_val;
    }

    public void setMcr_val(int mcr_val) {
        this.mcr_val = mcr_val;
    }

    public short getDec_val() {

        return dec_val;
    }

    public void setDec_val(short dec_val) {
        this.dec_val = dec_val;
    }

    @Override
    public String toString() {
        return "ODBM3{" +
                "datano=" + datano +
                ", mcr_val=" + mcr_val +
                ", dec_val=" + dec_val +
                '}';
    }
}
