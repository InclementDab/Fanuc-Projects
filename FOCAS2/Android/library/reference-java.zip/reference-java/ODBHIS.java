package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBHIS {
    private short s_no;
    private short type;
    private short e_no;
    private REC_ALM rec_alm[];
    private REC_MDI rec_mdi[];
    private REC_SGN rec_sgn[];
    private REC_DATE rec_date[];
    private REC_TIME rec_time[];

    public short getS_no() {
        return s_no;
    }

    public void setS_no(short s_no) {
        this.s_no = s_no;
    }

    public short getType() {
        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short getE_no() {
        return e_no;
    }

    public void setE_no(short e_no) {
        this.e_no = e_no;
    }

    public REC_ALM[] getRec_alm() {
        return rec_alm;
    }

    public void setRec_alm(REC_ALM[] rec_alm) {
        this.rec_alm = rec_alm;
    }

    public REC_MDI[] getRec_mdi() {
        return rec_mdi;
    }

    public void setRec_mdi(REC_MDI[] rec_mdi) {
        this.rec_mdi = rec_mdi;
    }

    public REC_SGN[] getRec_sgn() {
        return rec_sgn;
    }

    public void setRec_sgn(REC_SGN[] rec_sgn) {
        this.rec_sgn = rec_sgn;
    }

    public REC_DATE[] getRec_date() {
        return rec_date;
    }

    public void setRec_date(REC_DATE[] rec_date) {
        this.rec_date = rec_date;
    }

    public REC_TIME[] getRec_time() {
        return rec_time;
    }

    public void setRec_time(REC_TIME[] rec_time) {
        this.rec_time = rec_time;
    }

    public static class REC_ALM {
        private short rec_type;
        private short alm_grp;
        private short alm_no;
        private char axis_no;
        private char dummy;

        public short getRec_type() {
            return rec_type;
        }

        public void setRec_type(short rec_type) {
            this.rec_type = rec_type;
        }

        public short getAlm_grp() {
            return alm_grp;
        }

        public void setAlm_grp(short alm_grp) {
            this.alm_grp = alm_grp;
        }

        public short getAlm_no() {
            return alm_no;
        }

        public void setAlm_no(short alm_no) {
            this.alm_no = alm_no;
        }

        public char getAxis_no() {
            return axis_no;
        }

        public void setAxis_no(char axis_no) {
            this.axis_no = axis_no;
        }

        public char getDummy() {
            return dummy;
        }

        public void setDummy(char dummy) {
            this.dummy = dummy;
        }

        @Override
        public String toString() {
            return "REC_ALM{" +
                    "rec_type=" + rec_type +
                    ", alm_grp=" + alm_grp +
                    ", alm_no=" + alm_no +
                    ", axis_no=" + axis_no +
                    ", dummy=" + dummy +
                    '}';
        }
    }

    public static class REC_MDI {
        private short rec_type;
        private char key_code;
        private char pw_flag;
        private char dummy[];

        public short getRec_type() {
            return rec_type;
        }

        public void setRec_type(short rec_type) {
            this.rec_type = rec_type;
        }

        public char getKey_code() {
            return key_code;
        }

        public void setKey_code(char key_code) {
            this.key_code = key_code;
        }

        public char getPw_flag() {
            return pw_flag;
        }

        public void setPw_flag(char pw_flag) {
            this.pw_flag = pw_flag;
        }

        public char[] getDummy() {
            return dummy;
        }

        public void setDummy(char[] dummy) {
            this.dummy = dummy;
        }

        @Override
        public String toString() {
            return "REC_MDI{" +
                    "rec_type=" + rec_type +
                    ", key_code=" + key_code +
                    ", pw_flag=" + pw_flag +
                    ", dummy=" + Arrays.toString(dummy) +
                    '}';
        }
    }

    public static class REC_SGN {
        private short rec_type;
        private char sig_name;
        private char sig_old;
        private char sig_new;
        private char dummy;
        private short sig_no;

        public short getRec_type() {
            return rec_type;
        }

        public void setRec_type(short rec_type) {
            this.rec_type = rec_type;
        }

        public char getSig_name() {
            return sig_name;
        }

        public void setSig_name(char sig_name) {
            this.sig_name = sig_name;
        }

        public char getSig_old() {
            return sig_old;
        }

        public void setSig_old(char sig_old) {
            this.sig_old = sig_old;
        }

        public char getSig_new() {
            return sig_new;
        }

        public void setSig_new(char sig_new) {
            this.sig_new = sig_new;
        }

        public char getDummy() {
            return dummy;
        }

        public void setDummy(char dummy) {
            this.dummy = dummy;
        }

        public short getSig_no() {
            return sig_no;
        }

        public void setSig_no(short sig_no) {
            this.sig_no = sig_no;
        }

        @Override
        public String toString() {
            return "REC_SGN{" +
                    "rec_type=" + rec_type +
                    ", sig_name=" + sig_name +
                    ", sig_old=" + sig_old +
                    ", sig_new=" + sig_new +
                    ", dummy=" + dummy +
                    ", sig_no=" + sig_no +
                    '}';
        }
    }

    public static class REC_DATE {
        private short rec_type;
        private char year;
        private char month;
        private char day;
        private char pw_flag;
        private char dummy[];

        public short getRec_type() {
            return rec_type;
        }

        public void setRec_type(short rec_type) {
            this.rec_type = rec_type;
        }

        public char getYear() {
            return year;
        }

        public void setYear(char year) {
            this.year = year;
        }

        public char getMonth() {
            return month;
        }

        public void setMonth(char month) {
            this.month = month;
        }

        public char getDay() {
            return day;
        }

        public void setDay(char day) {
            this.day = day;
        }

        public char getPw_flag() {
            return pw_flag;
        }

        public void setPw_flag(char pw_flag) {
            this.pw_flag = pw_flag;
        }

        public char[] getDummy() {
            return dummy;
        }

        public void setDummy(char[] dummy) {
            this.dummy = dummy;
        }

        @Override
        public String toString() {
            return "REC_DATE{" +
                    "rec_type=" + rec_type +
                    ", year=" + year +
                    ", month=" + month +
                    ", day=" + day +
                    ", pw_flag=" + pw_flag +
                    ", dummy=" + Arrays.toString(dummy) +
                    '}';
        }
    }

    public static class REC_TIME {
        private short rec_type;
        private char hour;
        private char minute;
        private char second;
        private char pw_flag;
        private char dummy[];

        public short getRec_type() {
            return rec_type;
        }

        public void setRec_type(short rec_type) {
            this.rec_type = rec_type;
        }

        public char getHour() {
            return hour;
        }

        public void setHour(char hour) {
            this.hour = hour;
        }

        public char getMinute() {
            return minute;
        }

        public void setMinute(char minute) {
            this.minute = minute;
        }

        public char getSecond() {
            return second;
        }

        public void setSecond(char second) {
            this.second = second;
        }

        public char getPw_flag() {
            return pw_flag;
        }

        public void setPw_flag(char pw_flag) {
            this.pw_flag = pw_flag;
        }

        public char[] getDummy() {
            return dummy;
        }

        public void setDummy(char[] dummy) {
            this.dummy = dummy;
        }

        @Override
        public String toString() {
            return "REC_TIME{" +
                    "rec_type=" + rec_type +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", pw_flag=" + pw_flag +
                    ", dummy=" + Arrays.toString(dummy) +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "ODBHIS{" +
                "s_no=" + s_no +
                ", type=" + type +
                ", e_no=" + e_no +
                ", rec_alm=" + Arrays.toString(rec_alm) +
                ", rec_mdi=" + Arrays.toString(rec_mdi) +
                ", rec_sgn=" + Arrays.toString(rec_sgn) +
                ", rec_date=" + Arrays.toString(rec_date) +
                ", rec_time=" + Arrays.toString(rec_time) +
                '}';
    }
}
