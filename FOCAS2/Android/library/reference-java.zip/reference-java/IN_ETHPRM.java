package jp.co.fanuc.fwlibe1;


public class IN_ETHPRM {
    private short reserve01;
    private short reserve02;
    private short reserve03;
    private short reserve04;
    private short reserve05;
    private short reserve06;

    public short getReserve01() {
        return reserve01;
    }

    public void setReserve01(short reserve01) {
        this.reserve01 = reserve01;
    }

    public short getReserve02() {
        return reserve02;
    }

    public void setReserve02(short reserve02) {
        this.reserve02 = reserve02;
    }

    public short getReserve03() {
        return reserve03;
    }

    public void setReserve03(short reserve03) {
        this.reserve03 = reserve03;
    }

    public short getReserve04() {
        return reserve04;
    }

    public void setReserve04(short reserve04) {
        this.reserve04 = reserve04;
    }

    public short getReserve05() {
        return reserve05;
    }

    public void setReserve05(short reserve05) {
        this.reserve05 = reserve05;
    }

    public short getReserve06() {
        return reserve06;
    }

    public void setReserve06(short reserve06) {
        this.reserve06 = reserve06;
    }
    public static class PRM {
        private COMMON_PRM common;
        private FOCAS2_PRM focas2;
        private FTPTRANS_PRM ftpTrans;
        private DTSVR_PRM dataServer;
        private RMTDIAG_PRM remoteDiag;
        private FACTO_PRM factolink;
        private MAINTAIN_PRM maintain;
        private NETSRV_PRM netservice;
        private UNSOLICMSG_PRM unsolicmsg;
        private MBSVR_PRM mbsvr;
        private HTTPSVR_PRM httpsvr;
        private STSNTF_PRM stsntf;

        public COMMON_PRM getCommon() {
            return common;
        }

        public void setCommon(COMMON_PRM common) {
            this.common = common;
        }

        public FOCAS2_PRM getFocas2() {
            return focas2;
        }

        public void setFocas2(FOCAS2_PRM focas2) {
            this.focas2 = focas2;
        }

        public FTPTRANS_PRM getFtpTrans() {
            return ftpTrans;
        }

        public void setFtpTrans(FTPTRANS_PRM ftpTrans) {
            this.ftpTrans = ftpTrans;
        }

        public DTSVR_PRM getDataServer() {
            return dataServer;
        }

        public void setDataServer(DTSVR_PRM dataServer) {
            this.dataServer = dataServer;
        }

        public RMTDIAG_PRM getRemoteDiag() {
            return remoteDiag;
        }

        public void setRemoteDiag(RMTDIAG_PRM remoteDiag) {
            this.remoteDiag = remoteDiag;
        }

        public FACTO_PRM getFactolink() {
            return factolink;
        }

        public void setFactolink(FACTO_PRM factolink) {
            this.factolink = factolink;
        }

        public MAINTAIN_PRM getMaintain() {
            return maintain;
        }

        public void setMaintain(MAINTAIN_PRM maintain) {
            this.maintain = maintain;
        }

        public NETSRV_PRM getNetservice() {
            return netservice;
        }

        public void setNetservice(NETSRV_PRM netservice) {
            this.netservice = netservice;
        }

        public UNSOLICMSG_PRM getUnsolicmsg() {
            return unsolicmsg;
        }

        public void setUnsolicmsg(UNSOLICMSG_PRM unsolicmsg) {
            this.unsolicmsg = unsolicmsg;
        }

        public MBSVR_PRM getMbsvr() {
            return mbsvr;
        }

        public void setMbsvr(MBSVR_PRM mbsvr) {
            this.mbsvr = mbsvr;
        }

        public HTTPSVR_PRM getHttpsvr() {
            return httpsvr;
        }

        public void setHttpsvr(HTTPSVR_PRM httpsvr) {
            this.httpsvr = httpsvr;
        }

        public STSNTF_PRM getStsntf() {
            return stsntf;
        }

        public void setStsntf(STSNTF_PRM stsntf) {
            this.stsntf = stsntf;
        }

        @Override
        public String toString() {
            return "PRM{" +
                    "common=" + common +
                    ", focas2=" + focas2 +
                    ", ftpTrans=" + ftpTrans +
                    ", dataServer=" + dataServer +
                    ", remoteDiag=" + remoteDiag +
                    ", factolink=" + factolink +
                    ", maintain=" + maintain +
                    ", netservice=" + netservice +
                    ", unsolicmsg=" + unsolicmsg +
                    ", mbsvr=" + mbsvr +
                    ", httpsvr=" + httpsvr +
                    ", stsntf=" + stsntf +
                    '}';
        }
    }
    private PRM prm;

    public PRM getPrm() {
        return prm;
    }

    public void setPrm(PRM prm) {
        this.prm = prm;
    }

    @Override
    public String toString() {
        return "IN_ETHPRM{" +
                "reserve01=" + reserve01 +
                ", reserve02=" + reserve02 +
                ", reserve03=" + reserve03 +
                ", reserve04=" + reserve04 +
                ", reserve05=" + reserve05 +
                ", reserve06=" + reserve06 +
                ", prm=" + prm +
                '}';
    }
}
