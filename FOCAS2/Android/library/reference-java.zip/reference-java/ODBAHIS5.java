package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBAHIS5 {
    private short s_no;
    private short e_no;

    public short getS_no() {
        return s_no;
    }

    public void setS_no(short s_no) {
        this.s_no = s_no;
    }

    public short getE_no() {
        return e_no;
    }

    public void setE_no(short e_no) {
        this.e_no = e_no;
    }
    public static class ALM_HIS {
        private short alm_grp;
        private short alm_no;
        private short axis_no;
        private short year;
        private short month;
        private short day;
        private short hour;
        private short minute;
        private short second;
        private short len_msg;
        private short pth_no;
        private short sys_alm;
        private short dsp_flg;
        private short axis_num;
        private String alm_msg;
        private int g_modal[];
        private String g_dp;
        private short dummy1;
        private int a_modal[];
        private String a_dp;
        private short dummy2;
        private int abs_pos[];
        private String abs_dp;
        private int mcn_pos[];
        private String mcn_dp;

        public short getAlm_grp() {
            return alm_grp;
        }

        public void setAlm_grp(short alm_grp) {
            this.alm_grp = alm_grp;
        }

        public short getAlm_no() {
            return alm_no;
        }

        public void setAlm_no(short alm_no) {
            this.alm_no = alm_no;
        }

        public short getAxis_no() {
            return axis_no;
        }

        public void setAxis_no(short axis_no) {
            this.axis_no = axis_no;
        }

        public short getYear() {
            return year;
        }

        public void setYear(short year) {
            this.year = year;
        }

        public short getMonth() {
            return month;
        }

        public void setMonth(short month) {
            this.month = month;
        }

        public short getDay() {
            return day;
        }

        public void setDay(short day) {
            this.day = day;
        }

        public short getHour() {
            return hour;
        }

        public void setHour(short hour) {
            this.hour = hour;
        }

        public short getMinute() {
            return minute;
        }

        public void setMinute(short minute) {
            this.minute = minute;
        }

        public short getSecond() {
            return second;
        }

        public void setSecond(short second) {
            this.second = second;
        }

        public short getLen_msg() {
            return len_msg;
        }

        public void setLen_msg(short len_msg) {
            this.len_msg = len_msg;
        }

        public short getPth_no() {
            return pth_no;
        }

        public void setPth_no(short pth_no) {
            this.pth_no = pth_no;
        }

        public short getSys_alm() {
            return sys_alm;
        }

        public void setSys_alm(short sys_alm) {
            this.sys_alm = sys_alm;
        }

        public short getDsp_flg() {
            return dsp_flg;
        }

        public void setDsp_flg(short dsp_flg) {
            this.dsp_flg = dsp_flg;
        }

        public short getAxis_num() {
            return axis_num;
        }

        public void setAxis_num(short axis_num) {
            this.axis_num = axis_num;
        }

        public int[] getG_modal() {
            return g_modal;
        }

        public void setG_modal(int[] g_modal) {
            this.g_modal = g_modal;
        }

        public short getDummy1() {
            return dummy1;
        }

        public void setDummy1(short dummy1) {
            this.dummy1 = dummy1;
        }

        public int[] getA_moda() {
            return a_modal;
        }

        public void setA_moda(int[] a_moda) {
            this.a_modal = a_moda;
        }

        public short getDummy2() {
            return dummy2;
        }

        public void setDummy2(short dummy2) {
            this.dummy2 = dummy2;
        }

        public int[] getAbs_pos() {
            return abs_pos;
        }

        public void setAbs_pos(int[] abs_pos) {
            this.abs_pos = abs_pos;
        }

        public int[] getMcn_pos() {
            return mcn_pos;
        }

        public void setMcn_pos(int[] mcn_pos) {
            this.mcn_pos = mcn_pos;
        }

        public String getAlm_msg() {
            return alm_msg;
        }

        public void setAlm_msg(String alm_msg) {
            this.alm_msg = alm_msg;
        }

        public String getG_dp() {
            return g_dp;
        }

        public void setG_dp(String g_dp) {
            this.g_dp = g_dp;
        }

        public String getA_dp() {
            return a_dp;
        }

        public void setA_dp(String a_dp) {
            this.a_dp = a_dp;
        }

        public String getAbs_dp() {
            return abs_dp;
        }

        public void setAbs_dp(String abs_dp) {
            this.abs_dp = abs_dp;
        }

        public String getMcn_dp() {
            return mcn_dp;
        }

        public void setMcn_dp(String mcn_dp) {
            this.mcn_dp = mcn_dp;
        }

        @Override
        public String toString() {
            return "ALM_HIS{" +
                    "alm_grp=" + alm_grp +
                    ", alm_no=" + alm_no +
                    ", axis_no=" + axis_no +
                    ", year=" + year +
                    ", month=" + month +
                    ", day=" + day +
                    ", hour=" + hour +
                    ", minute=" + minute +
                    ", second=" + second +
                    ", len_msg=" + len_msg +
                    ", pth_no=" + pth_no +
                    ", sys_alm=" + sys_alm +
                    ", dsp_flg=" + dsp_flg +
                    ", axis_num=" + axis_num +
                    ", alm_msg='" + alm_msg + '\'' +
                    ", g_modal=" + Arrays.toString(g_modal) +
                    ", g_dp='" + g_dp + '\'' +
                    ", dummy1=" + dummy1 +
                    ", a_modal=" + Arrays.toString(a_modal) +
                    ", a_dp='" + a_dp + '\'' +
                    ", dummy2=" + dummy2 +
                    ", abs_pos=" + Arrays.toString(abs_pos) +
                    ", abs_dp='" + abs_dp + '\'' +
                    ", mcn_pos=" + Arrays.toString(mcn_pos) +
                    ", mcn_dp='" + mcn_dp + '\'' +
                    '}';
        }

        public void Dispose(){
            g_modal = null;
            a_modal = null;
            abs_pos = null;
            mcn_pos = null;
        }
    }
    private ALM_HIS alm_his[];

    public ALM_HIS[] getAlm_his() {
        return alm_his;
    }

    public void setAlm_his(ALM_HIS[] alm_his) {
        this.alm_his = alm_his;
    }

    @Override
    public String toString() {
        return "ODBAHIS5{" +
                "s_no=" + s_no +
                ", e_no=" + e_no +
                ", alm_his=" + Arrays.toString(alm_his) +
                '}';
    }

    public void Dispose() {
        if (alm_his != null) {
            for (ALM_HIS a : alm_his) {
                if (a != null) {
                    a.Dispose();
                }
            }
            alm_his = null;
        }
    }
}
