package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMDLC {
    private short from;
    private short dram;
    private short sram;
    private short pmc;
    private short crtc;
    private short servo12;
    private short servo34;
    private short servo56;
    private short servo78;
    private short sic;
    private short pos_lsi;
    private short hi_aio;
    private short reserve[];
    private short drmmrc;
    private short drmarc;
    private short pmcmrc;
    private short dmaarc;
    private short iopt;
    private short hdiio;
    private short gm2gr1;
    private short crtgr2;
    private short gm1gr2;
    private short gm2gr2;
    private short cmmrb;
    private short sv5axs;
    private short sv7axs;
    private short sicaxs;
    private short posaxs;
    private short hamaxs;
    private short romr64;
    private short srmr64;
    private short dr1r64;
    private short dr2r64;
    private short iopio2;
    private short hdiio2;
    private short cmmrb2;
    private short romfap;
    private short srmfap;
    private short drmfap;
    private short drmare;
    private short pmcmre;
    private short dmaare;
    private short frmbgg;
    private short drmbgg;
    private short asrbgg;
    private short edtpsc;
    private short slcpsc;
    private short reserve2[];

    public short getFrom() {
        return from;
    }

    public void setFrom(short from) {
        this.from = from;
    }

    public short getDram() {
        return dram;
    }

    public void setDram(short dram) {
        this.dram = dram;
    }

    public short getSram() {
        return sram;
    }

    public void setSram(short sram) {
        this.sram = sram;
    }

    public short getPmc() {
        return pmc;
    }

    public void setPmc(short pmc) {
        this.pmc = pmc;
    }

    public short getCrtc() {
        return crtc;
    }

    public void setCrtc(short crtc) {
        this.crtc = crtc;
    }

    public short getServo12() {
        return servo12;
    }

    public void setServo12(short servo12) {
        this.servo12 = servo12;
    }

    public short getServo34() {
        return servo34;
    }

    public void setServo34(short servo34) {
        this.servo34 = servo34;
    }

    public short getServo56() {
        return servo56;
    }

    public void setServo56(short servo56) {
        this.servo56 = servo56;
    }

    public short getServo78() {
        return servo78;
    }

    public void setServo78(short servo78) {
        this.servo78 = servo78;
    }

    public short getSic() {
        return sic;
    }

    public void setSic(short sic) {
        this.sic = sic;
    }

    public short getPos_lsi() {
        return pos_lsi;
    }

    public void setPos_lsi(short pos_lsi) {
        this.pos_lsi = pos_lsi;
    }

    public short getHi_aio() {
        return hi_aio;
    }

    public void setHi_aio(short hi_aio) {
        this.hi_aio = hi_aio;
    }

    public short[] getReserve() {
        return reserve;
    }

    public void setReserve(short[] reserve) {
        this.reserve = reserve;
    }

    public short getDrmmrc() {
        return drmmrc;
    }

    public void setDrmmrc(short drmmrc) {
        this.drmmrc = drmmrc;
    }

    public short getDrmarc() {
        return drmarc;
    }

    public void setDrmarc(short drmarc) {
        this.drmarc = drmarc;
    }

    public short getPmcmrc() {
        return pmcmrc;
    }

    public void setPmcmrc(short pmcmrc) {
        this.pmcmrc = pmcmrc;
    }

    public short getDmaarc() {
        return dmaarc;
    }

    public void setDmaarc(short dmaarc) {
        this.dmaarc = dmaarc;
    }

    public short getIopt() {
        return iopt;
    }

    public void setIopt(short iopt) {
        this.iopt = iopt;
    }

    public short getHdiio() {
        return hdiio;
    }

    public void setHdiio(short hdiio) {
        this.hdiio = hdiio;
    }

    public short getGm2gr1() {
        return gm2gr1;
    }

    public void setGm2gr1(short gm2gr1) {
        this.gm2gr1 = gm2gr1;
    }

    public short getCrtgr2() {
        return crtgr2;
    }

    public void setCrtgr2(short crtgr2) {
        this.crtgr2 = crtgr2;
    }

    public short getGm1gr2() {
        return gm1gr2;
    }

    public void setGm1gr2(short gm1gr2) {
        this.gm1gr2 = gm1gr2;
    }

    public short getGm2gr2() {
        return gm2gr2;
    }

    public void setGm2gr2(short gm2gr2) {
        this.gm2gr2 = gm2gr2;
    }

    public short getCmmrb() {
        return cmmrb;
    }

    public void setCmmrb(short cmmrb) {
        this.cmmrb = cmmrb;
    }

    public short getSv5axs() {
        return sv5axs;
    }

    public void setSv5axs(short sv5axs) {
        this.sv5axs = sv5axs;
    }

    public short getSv7axs() {
        return sv7axs;
    }

    public void setSv7axs(short sv7axs) {
        this.sv7axs = sv7axs;
    }

    public short getSicaxs() {
        return sicaxs;
    }

    public void setSicaxs(short sicaxs) {
        this.sicaxs = sicaxs;
    }

    public short getPosaxs() {
        return posaxs;
    }

    public void setPosaxs(short posaxs) {
        this.posaxs = posaxs;
    }

    public short getHamaxs() {
        return hamaxs;
    }

    public void setHamaxs(short hamaxs) {
        this.hamaxs = hamaxs;
    }

    public short getRomr64() {
        return romr64;
    }

    public void setRomr64(short romr64) {
        this.romr64 = romr64;
    }

    public short getSrmr64() {
        return srmr64;
    }

    public void setSrmr64(short srmr64) {
        this.srmr64 = srmr64;
    }

    public short getDr1r64() {
        return dr1r64;
    }

    public void setDr1r64(short dr1r64) {
        this.dr1r64 = dr1r64;
    }

    public short getDr2r64() {
        return dr2r64;
    }

    public void setDr2r64(short dr2r64) {
        this.dr2r64 = dr2r64;
    }

    public short getIopio2() {
        return iopio2;
    }

    public void setIopio2(short iopio2) {
        this.iopio2 = iopio2;
    }

    public short getHdiio2() {
        return hdiio2;
    }

    public void setHdiio2(short hdiio2) {
        this.hdiio2 = hdiio2;
    }

    public short getCmmrb2() {
        return cmmrb2;
    }

    public void setCmmrb2(short cmmrb2) {
        this.cmmrb2 = cmmrb2;
    }

    public short getRomfap() {
        return romfap;
    }

    public void setRomfap(short romfap) {
        this.romfap = romfap;
    }

    public short getSrmfap() {
        return srmfap;
    }

    public void setSrmfap(short srmfap) {
        this.srmfap = srmfap;
    }

    public short getDrmfap() {
        return drmfap;
    }

    public void setDrmfap(short drmfap) {
        this.drmfap = drmfap;
    }

    public short getDrmare() {
        return drmare;
    }

    public void setDrmare(short drmare) {
        this.drmare = drmare;
    }

    public short getPmcmre() {
        return pmcmre;
    }

    public void setPmcmre(short pmcmre) {
        this.pmcmre = pmcmre;
    }

    public short getDmaare() {
        return dmaare;
    }

    public void setDmaare(short dmaare) {
        this.dmaare = dmaare;
    }

    public short getFrmbgg() {
        return frmbgg;
    }

    public void setFrmbgg(short frmbgg) {
        this.frmbgg = frmbgg;
    }

    public short getDrmbgg() {
        return drmbgg;
    }

    public void setDrmbgg(short drmbgg) {
        this.drmbgg = drmbgg;
    }

    public short getAsrbgg() {
        return asrbgg;
    }

    public void setAsrbgg(short asrbgg) {
        this.asrbgg = asrbgg;
    }

    public short getEdtpsc() {
        return edtpsc;
    }

    public void setEdtpsc(short edtpsc) {
        this.edtpsc = edtpsc;
    }

    public short getSlcpsc() {
        return slcpsc;
    }

    public void setSlcpsc(short slcpsc) {
        this.slcpsc = slcpsc;
    }

    public short[] getReserve2() {
        return reserve2;
    }

    public void setReserve2(short[] reserve2) {
        this.reserve2 = reserve2;
    }

    @Override
    public String toString() {
        return "ODBMDLC{" +
                "from=" + from +
                ", dram=" + dram +
                ", sram=" + sram +
                ", pmc=" + pmc +
                ", crtc=" + crtc +
                ", servo12=" + servo12 +
                ", servo34=" + servo34 +
                ", servo56=" + servo56 +
                ", servo78=" + servo78 +
                ", sic=" + sic +
                ", pos_lsi=" + pos_lsi +
                ", hi_aio=" + hi_aio +
                ", reserve=" + Arrays.toString(reserve) +
                ", drmmrc=" + drmmrc +
                ", drmarc=" + drmarc +
                ", pmcmrc=" + pmcmrc +
                ", dmaarc=" + dmaarc +
                ", iopt=" + iopt +
                ", hdiio=" + hdiio +
                ", gm2gr1=" + gm2gr1 +
                ", crtgr2=" + crtgr2 +
                ", gm1gr2=" + gm1gr2 +
                ", gm2gr2=" + gm2gr2 +
                ", cmmrb=" + cmmrb +
                ", sv5axs=" + sv5axs +
                ", sv7axs=" + sv7axs +
                ", sicaxs=" + sicaxs +
                ", posaxs=" + posaxs +
                ", hamaxs=" + hamaxs +
                ", romr64=" + romr64 +
                ", srmr64=" + srmr64 +
                ", dr1r64=" + dr1r64 +
                ", dr2r64=" + dr2r64 +
                ", iopio2=" + iopio2 +
                ", hdiio2=" + hdiio2 +
                ", cmmrb2=" + cmmrb2 +
                ", romfap=" + romfap +
                ", srmfap=" + srmfap +
                ", drmfap=" + drmfap +
                ", drmare=" + drmare +
                ", pmcmre=" + pmcmre +
                ", dmaare=" + dmaare +
                ", frmbgg=" + frmbgg +
                ", drmbgg=" + drmbgg +
                ", asrbgg=" + asrbgg +
                ", edtpsc=" + edtpsc +
                ", slcpsc=" + slcpsc +
                ", reserve2=" + Arrays.toString(reserve2) +
                '}';
    }
}
