package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class ODBMSUINF {
    private char pmc_no;
    private char dummy[];
    private int x_top_adrs;
    private int y_top_adrs;

    public char getPmc_no() {
        return pmc_no;
    }

    public void setPmc_no(char pmc_no) {
        this.pmc_no = pmc_no;
    }

    public char[] getDummy() {
        return dummy;
    }

    public void setDummy(char[] dummy) {
        this.dummy = dummy;
    }

    public int getX_top_adrs() {
        return x_top_adrs;
    }

    public void setX_top_adrs(int x_top_adrs) {
        this.x_top_adrs = x_top_adrs;
    }

    public int getY_top_adrs() {
        return y_top_adrs;
    }

    public void setY_top_adrs(int y_top_adrs) {
        this.y_top_adrs = y_top_adrs;
    }

    @Override
    public String toString() {
        return "ODBMSUINF{" +
                "pmc_no=" + pmc_no +
                ", dummy=" + Arrays.toString(dummy) +
                ", x_top_adrs=" + x_top_adrs +
                ", y_top_adrs=" + y_top_adrs +
                '}';
    }
}
