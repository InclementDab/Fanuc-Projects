package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBTLGSEXT {
    private int data1;
    private int data2;
    private int data3;
    private int data4;
    private byte tooltype;
    private byte install;
    private byte holder;
    private String toolname;

    public int getData1() {
        return data1;
    }

    public void setData1(int data1) {
        this.data1 = data1;
    }

    public int getData2() {
        return data2;
    }

    public void setData2(int data2) {
        this.data2 = data2;
    }

    public int getData3() {
        return data3;
    }

    public void setData3(int data3) {
        this.data3 = data3;
    }

    public int getData4() {
        return data4;
    }

    public void setData4(int data4) {
        this.data4 = data4;
    }

    public byte getTooltype() {
        return tooltype;
    }

    public void setTooltype(byte tooltype) {
        this.tooltype = tooltype;
    }

    public byte getInstall() {
        return install;
    }

    public void setInstall(byte install) {
        this.install = install;
    }

    public byte getHolder() {
        return holder;
    }

    public void setHolder(byte holder) {
        this.holder = holder;
    }

    public String getToolname() {
        return toolname;
    }

    public void setToolname(String toolname) {
        this.toolname = toolname;
    }

    @Override
    public String toString() {
        return "IODBTLGSEXT{" +
                "data1=" + data1 +
                ", data2=" + data2 +
                ", data3=" + data3 +
                ", data4=" + data4 +
                ", tooltype=" + tooltype +
                ", install=" + install +
                ", holder=" + holder +
                ", toolname=" + toolname +
                '}';
    }

    public void Dispose(){
        toolname = null;
    }
}
