package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBRBSIGNAL2 {
    private char type;
    private char state;
    private short no;
    private char name[];
    private char reserve[];

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }

    public char getState() {
        return state;
    }

    public void setState(char state) {
        this.state = state;
    }

    public short getNo() {
        return no;
    }

    public void setNo(short no) {
        this.no = no;
    }

    public char[] getName() {
        return name;
    }

    public void setName(char[] name) {
        this.name = name;
    }

    public char[] getReserve() {
        return reserve;
    }

    public void setReserve(char[] reserve) {
        this.reserve = reserve;
    }

    @Override
    public String toString() {
        return "IODBRBSIGNAL2{" +
                "type=" + type +
                ", state=" + state +
                ", no=" + no +
                ", name=" + Arrays.toString(name) +
                ", reserve=" + Arrays.toString(reserve) +
                '}';
    }
}
