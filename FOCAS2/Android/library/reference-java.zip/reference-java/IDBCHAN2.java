package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IDBCHAN2 {
    private short chno;
    private short axis;
    private int datanum;
    private short datainf;
    private short dataadr;
    private PMC_DATA io[];

    public short getChno() {
        return chno;
    }

    public void setChno(short chno) {
        this.chno = chno;
    }

    public short getAxis() {
        return axis;
    }

    public void setAxis(short axis) {
        this.axis = axis;
    }

    public int getDatanum() {
        return datanum;
    }

    public void setDatanum(int datanum) {
        this.datanum = datanum;
    }

    public short getDatainf() {
        return datainf;
    }

    public void setDatainf(short datainf) {
        this.datainf = datainf;
    }

    public short getDataadr() {
        return dataadr;
    }

    public void setDataadr(short dataadr) {
        this.dataadr = dataadr;
    }

    public PMC_DATA[] getIo() {
        return io;
    }

    public void setIo(PMC_DATA[] io) {
        this.io = io;
    }

    @Override
    public String toString() {
        return "IDBCHAN2{" +
                "chno=" + chno +
                ", axis=" + axis +
                ", datanum=" + datanum +
                ", datainf=" + datainf +
                ", dataadr=" + dataadr +
                ", io=" + Arrays.toString(io) +
                '}';
    }
}
