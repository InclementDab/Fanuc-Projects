package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IODBSLVPRM2 {
    private short dis_enb;
    private short ident_no;
    private char slv_flag;
    private char slv_type;
    private char reserve1[];
    private char slv_stat;
    private char wd_fact1;
    private char wd_fact2;
    private char min_tsdr;
    private char reserve2;
    private char grp_ident;
    private short user_plen;
    private char user_pdata[];
    private short cnfg_dlen;
    private char cnfg_data[];
    private short slv_ulen;
    private char slv_udata[];
    private char reserve3[];

    public short getDis_enb() {
        return dis_enb;
    }

    public void setDis_enb(short dis_enb) {
        this.dis_enb = dis_enb;
    }

    public short getIdent_no() {
        return ident_no;
    }

    public void setIdent_no(short ident_no) {
        this.ident_no = ident_no;
    }

    public char getSlv_flag() {
        return slv_flag;
    }

    public void setSlv_flag(char slv_flag) {
        this.slv_flag = slv_flag;
    }

    public char getSlv_type() {
        return slv_type;
    }

    public void setSlv_type(char slv_type) {
        this.slv_type = slv_type;
    }

    public char[] getReserve1() {
        return reserve1;
    }

    public void setReserve1(char[] reserve1) {
        this.reserve1 = reserve1;
    }

    public char getSlv_stat() {
        return slv_stat;
    }

    public void setSlv_stat(char slv_stat) {
        this.slv_stat = slv_stat;
    }

    public char getWd_fact1() {
        return wd_fact1;
    }

    public void setWd_fact1(char wd_fact1) {
        this.wd_fact1 = wd_fact1;
    }

    public char getWd_fact2() {
        return wd_fact2;
    }

    public void setWd_fact2(char wd_fact2) {
        this.wd_fact2 = wd_fact2;
    }

    public char getMin_tsdr() {
        return min_tsdr;
    }

    public void setMin_tsdr(char min_tsdr) {
        this.min_tsdr = min_tsdr;
    }

    public char getReserve2() {
        return reserve2;
    }

    public void setReserve2(char reserve2) {
        this.reserve2 = reserve2;
    }

    public char getGrp_ident() {
        return grp_ident;
    }

    public void setGrp_ident(char grp_ident) {
        this.grp_ident = grp_ident;
    }

    public short getUser_plen() {
        return user_plen;
    }

    public void setUser_plen(short user_plen) {
        this.user_plen = user_plen;
    }

    public char[] getUser_pdata() {
        return user_pdata;
    }

    public void setUser_pdata(char[] user_pdata) {
        this.user_pdata = user_pdata;
    }

    public short getCnfg_dlen() {
        return cnfg_dlen;
    }

    public void setCnfg_dlen(short cnfg_dlen) {
        this.cnfg_dlen = cnfg_dlen;
    }

    public char[] getCnfg_data() {
        return cnfg_data;
    }

    public void setCnfg_data(char[] cnfg_data) {
        this.cnfg_data = cnfg_data;
    }

    public short getSlv_ulen() {
        return slv_ulen;
    }

    public void setSlv_ulen(short slv_ulen) {
        this.slv_ulen = slv_ulen;
    }

    public char[] getSlv_udata() {
        return slv_udata;
    }

    public void setSlv_udata(char[] slv_udata) {
        this.slv_udata = slv_udata;
    }

    public char[] getReserve3() {
        return reserve3;
    }

    public void setReserve3(char[] reserve3) {
        this.reserve3 = reserve3;
    }

    @Override
    public String toString() {
        return "IODBSLVPRM2{" +
                "dis_enb=" + dis_enb +
                ", ident_no=" + ident_no +
                ", slv_flag=" + slv_flag +
                ", slv_type=" + slv_type +
                ", reserve1=" + Arrays.toString(reserve1) +
                ", slv_stat=" + slv_stat +
                ", wd_fact1=" + wd_fact1 +
                ", wd_fact2=" + wd_fact2 +
                ", min_tsdr=" + min_tsdr +
                ", reserve2=" + reserve2 +
                ", grp_ident=" + grp_ident +
                ", user_plen=" + user_plen +
                ", user_pdata=" + Arrays.toString(user_pdata) +
                ", cnfg_dlen=" + cnfg_dlen +
                ", cnfg_data=" + Arrays.toString(cnfg_data) +
                ", slv_ulen=" + slv_ulen +
                ", slv_udata=" + Arrays.toString(slv_udata) +
                ", reserve3=" + Arrays.toString(reserve3) +
                '}';
    }
}
