package jp.co.fanuc.fwlibe1;


public class IODBSFSGSIGHIS {
    private short   sno_sig ;
    private short   len_sig ;
    private short   sno_sig_his ;
    private short   len_sig_his ;
    private short   extract ;

    public short getSno_sig() {
        return sno_sig;
    }

    public void setSno_sig(short sno_sig) {
        this.sno_sig = sno_sig;
    }

    public short getLen_sig() {
        return len_sig;
    }

    public void setLen_sig(short len_sig) {
        this.len_sig = len_sig;
    }

    public short getSno_sig_his() {
        return sno_sig_his;
    }

    public void setSno_sig_his(short sno_sig_his) {
        this.sno_sig_his = sno_sig_his;
    }

    public short getLen_sig_his() {
        return len_sig_his;
    }

    public void setLen_sig_his(short len_sig_his) {
        this.len_sig_his = len_sig_his;
    }

    public short getExtract() {
        return extract;
    }

    public void setExtract(short extract) {
        this.extract = extract;
    }

    @Override
    public String toString() {
        return "IODBSFSGSIGHIS{" +
                "sno_sig=" + sno_sig +
                ", len_sig=" + len_sig +
                ", sno_sig_his=" + sno_sig_his +
                ", len_sig_his=" + len_sig_his +
                ", extract=" + extract +
                '}';
    }
}
