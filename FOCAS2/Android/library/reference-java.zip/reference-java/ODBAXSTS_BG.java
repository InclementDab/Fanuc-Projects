package jp.co.fanuc.fwlibe1;


public class ODBAXSTS_BG {
    private int flag;

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    @Override
    public String toString() {
        return "ODBAXSTS_BG{" +
                "flag=" + flag +
                '}';
    }
}
