package jp.co.fanuc.fwlibe1;


import java.util.Arrays;

public class IN_EIPS_BASIC_PRM {
    private EIP_COMMON_PRM Common;
    private short Network;
    private char pad[];
    private char Option2;
    private char AllocMax;
    private short ConnectMax;
    private short RPI_Min;
    private short RPI_Max;
    private EIP_PMC_ADDR StatusAddr;
    private int StatusSize;

    public EIP_COMMON_PRM getCommon() {
        return Common;
    }

    public void setCommon(EIP_COMMON_PRM common) {
        Common = common;
    }

    public short getNetwork() {
        return Network;
    }

    public void setNetwork(short network) {
        Network = network;
    }

    public char[] getPad() {
        return pad;
    }

    public void setPad(char[] pad) {
        this.pad = pad;
    }

    public char getOption2() {
        return Option2;
    }

    public void setOption2(char option2) {
        Option2 = option2;
    }

    public char getAllocMax() {
        return AllocMax;
    }

    public void setAllocMax(char allocMax) {
        AllocMax = allocMax;
    }

    public short getConnectMax() {
        return ConnectMax;
    }

    public void setConnectMax(short connectMax) {
        ConnectMax = connectMax;
    }

    public short getRPI_Min() {
        return RPI_Min;
    }

    public void setRPI_Min(short RPI_Min) {
        this.RPI_Min = RPI_Min;
    }

    public short getRPI_Max() {
        return RPI_Max;
    }

    public void setRPI_Max(short RPI_Max) {
        this.RPI_Max = RPI_Max;
    }

    public EIP_PMC_ADDR getStatusAddr() {
        return StatusAddr;
    }

    public void setStatusAddr(EIP_PMC_ADDR statusAddr) {
        StatusAddr = statusAddr;
    }

    public int getStatusSize() {
        return StatusSize;
    }

    public void setStatusSize(int statusSize) {
        StatusSize = statusSize;
    }

    @Override
    public String toString() {
        return "IN_EIPS_BASIC_PRM{" +
                "Common=" + Common +
                ", Network=" + Network +
                ", pad=" + Arrays.toString(pad) +
                ", Option2=" + Option2 +
                ", AllocMax=" + AllocMax +
                ", ConnectMax=" + ConnectMax +
                ", RPI_Min=" + RPI_Min +
                ", RPI_Max=" + RPI_Max +
                ", StatusAddr=" + StatusAddr +
                ", StatusSize=" + StatusSize +
                '}';
    }
}
