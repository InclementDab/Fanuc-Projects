package jp.co.fanuc.fwlibe1;


public class ODBNC {

    private String asc;
    private BIN bin;

    public String getAsc() {
        return asc;
    }

    public void setAsc(String asc) {
        this.asc = asc;
    }

    public BIN getBin() {
        return bin;
    }

    public void setBin(BIN bin) {
        this.bin = bin;
    }

    @Override
    public String toString() {
        return "ODBNC{" +
                "bin=" + bin +
                "asc=" + asc +
                '}';
    }

    public static class BIN {
        private short reg_prg;
        private short unreg_prg;
        private int used_mem;
        private int unused_mem;

        public short getReg_prg() {
            return reg_prg;
        }

        public void setReg_prg(short reg_prg) {
            this.reg_prg = reg_prg;
        }

        public short getUnreg_prg() {

            return unreg_prg;
        }

        public void setUnreg_prg(short unreg_prg) {
            this.unreg_prg = unreg_prg;
        }

        public int getUsed_mem() {

            return used_mem;
        }

        public void setUsed_mem(int used_mem) {
            this.used_mem = used_mem;
        }

        public int getUnused_mem() {

            return unused_mem;
        }

        public void setUnused_mem(int unused_mem) {
            this.unused_mem = unused_mem;
        }


        @Override
        public String toString() {
            return "BIN{" +
                    "reg_prg=" + reg_prg +
                    ", unreg_prg=" + unreg_prg +
                    ", used_mem=" + used_mem +
                    ", unused_mem=" + unused_mem +
                    '}';
        }
    }


}
