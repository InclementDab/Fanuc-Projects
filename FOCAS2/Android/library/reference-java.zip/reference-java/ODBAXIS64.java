package jp.co.fanuc.fwlibe1;

import java.util.Arrays;


public class ODBAXIS64 {
    private short dummy1;
    private short type;
    private short dummy2[];
    private REALDATA data[];

    public short getDummy1() {
        return dummy1;
    }

    public void setDummy1(short dummy1) {
        this.dummy1 = dummy1;
    }

    public short getType() {

        return type;
    }

    public void setType(short type) {
        this.type = type;
    }

    public short[] getDummy2() {

        return dummy2;
    }

    public void setDummy2(short[] dummy2) {
        this.dummy2 = dummy2;
    }

    public REALDATA[] getData() {

        return data;
    }

    public void setData(REALDATA[] data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "ODBAXIS64{" +
                "dummy1=" + dummy1 +
                ", type=" + type +
                ", dummy2=" + Arrays.toString(dummy2) +
                ", data=" + Arrays.toString(data) +
                '}';
    }
}
